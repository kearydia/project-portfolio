"""常见 TCP 端口的可能服务提示，不进行实际服务识别。"""

COMMON_TCP_SERVICES = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS over TCP",
    80: "HTTP",
    110: "POP3",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    8080: "HTTP alternate",
}

# 快速扫描只检测这 14 个端口，不代表扫描了完整范围。
COMMON_PORTS = tuple(sorted(COMMON_TCP_SERVICES))


def get_service_hint(port: int) -> str:
    """仅查询静态映射；未知端口和非标准部署都需要进一步确认。"""
    return COMMON_TCP_SERVICES.get(port, "未知")
