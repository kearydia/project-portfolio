# 网络端口扫描与基础安全检测工具

对应任务书：网络资产发现与端口安全检测工具开发项目。
截止日期：2026 年 11 月 1 日。使用 Python 标准库，只扫描本机或明确授权的环境。

## 当前版本：第四阶段

已实现并运行：IPv4/域名、单端口/范围/常用集合、串行/有限并发、四种状态、
可能服务、基础检查建议、可选 CSV、参数/连接/文件异常处理。
2026 年 10 月 28 日完整运行 52 项 unittest，全部通过。

尚未完成第五阶段的最终答辩 PPT、10 分钟演示编排与最终交付检查。
版本识别、GUI、HTML/PDF 报告为暂不实施的提升项。

## 环境与进入目录

已验证 Windows、Python 3.14.7；不需要 pip 安装第三方库。
其他系统或 Python 版本尚未实际验证。

```powershell
python -B main.py --help
```

## 本机运行

先运行会自行创建临时端口的单端口演示：

```powershell
python -B demo_local.py
```

扫描本机常用端口并导出新报告：

```powershell
python -B main.py --target localhost --common --workers 4 --timeout 1 --output reports/my-common-scan.csv
```

若该文件已存在，请使用新的文件名。不会自动覆盖旧报告。
常用集合不是完整端口范围，仅包含 21、22、23、25、53、80、110、143、443、445、3306、3389、5432、8080。

需要自己建立开放端口场景时，在一个空的实验目录启动本机 HTTP 服务：

```powershell
python -B -m http.server 8000 --bind 127.0.0.1
```

保持该终端运行，在第二个终端进入项目目录后执行：

```powershell
python -B main.py -t localhost -p 7999-8001 --timeout 5 --workers 1
python -B main.py -t localhost -p 7999-8001 --timeout 5 --workers 4 --output reports/my-range-scan.csv
```

8000 必须未被占用；实验结束后在服务终端按 Ctrl+C 关闭。HTTP 服务会共享启动目录中的文件。
本工具不读取 HTTP 响应，8000 不在当前映射中，所以可能服务显示“未知”是正常结果。

## 参数与退出码

| 参数 | 含义 |
| --- | --- |
| -t / --target | 必填；完整 IPv4 或域名，不能附带协议、路径和端口 |
| -p / --ports | 一个端口或包含两端的范围，如 80、8000-8005 |
| --common | 固定 14 个常用 TCP 端口；必须与 --ports 二选一 |
| --timeout | 每个连接等待秒数，(0, 60]，默认 1 |
| --workers | 1～64，默认 1 为串行；大于 1 为有限并发 |
| --output | 可选的新 CSV 文件路径；自动创建父目录，不覆盖同名文件 |
| -h / --help | 查看使用方法 |

退出码：0 流程完成；2 参数或域名解析失败；3 CSV 文件输出失败；130 用户中断。
并发显示可能不按端口顺序，CSV 始终按端口数值升序排列。
Ctrl+C 会停止补交任务、取消未开始的任务，等待正在连接的任务返回或超时后退出；
已打印的行保留，中断时不创建本次完整 CSV。

## 判断边界

| 状态 | 含义 |
| --- | --- |
| open | 本次 TCP 连接成功，不证明具体服务或漏洞 |
| closed | 本次被明确拒绝，可能受中间设备影响 |
| timeout | 等待到期，无法断言端口关闭 |
| unknown | 其他 Socket/系统错误，保留原因 |

服务表只提供可能名称。基础建议使用“若确认为……”或通用检查事项，不确认实际服务或漏洞。
域名扫描前只解析一次，仅使用首个 IPv4，并显示具体地址。连接 timeout 不限制系统域名解析耗时。
短超时可能来不及收到明确拒绝，因此实际未监听的端口也可能显示 timeout。
暂不支持 IPv6、UDP、CIDR、多目标、逗号端口列表、版本探测或应用内容识别。

## CSV

使用 UTF-8 BOM 和标准 csv 模块，保存全部状态，不只保存开放端口。
字段：input_target、target_ip、port、status、possible_service、advice、detail。
已有文件、目录错误和权限问题返回 3，不打印“CSV 已保存”。
写入中途发生磁盘或 I/O 错误可能留下新建的部分文件；失败文件不能视为完整报告。

实际样例：[本机范围报告](reports/stage-4-cli/range.csv)、[常用端口报告](reports/stage-4-cli/common.csv)。

## 测试与性能实验

```powershell
python -B -m unittest discover -s tests -v
python -B benchmark_local.py
```

benchmark_local.py 自建 6 个相邻本机端口，2 个监听、4 个释放，默认三轮比较串行与 4 线程，
固定每连接 timeout=5，轮换执行顺序。输出使用新时间目录，不需要外部服务。
已完成的一次实验：串行中位数 8.239248 秒，并发中位数 2.054735 秒，本次观察约 4.010 倍。
每轮都得到 2 open、4 closed；不把这个比值推广到其他网络或负载。
计时排除 CSV 写入；主命令行计时还排除域名解析。
原始数据见 [benchmark.json](reports/stage-4-benchmark/benchmark.json)。

## 学习交接

- [完整学习包：过程、讲解、全量源码和测试源码](docs/stage-4-study-pack.md)
- [发给讲解窗口的提示词](docs/tutor-prompt.md)
- [第四阶段详细教学](docs/stage-4-teaching.md)
- [第四阶段验收记录](docs/stage-4.md)
- [各阶段索引](docs/stage-learning-index.md)
- [概要设计](docs/design.md)、[任务书对照](docs/requirements.md)、[每日记录](docs/learning-log.md)

## 主要文件

main.py 处理命令行；validation.py 检查输入和解析目标；scanner.py 检测单端口；
runner.py 调度串行/并发；services.py 提供可能服务；advice.py 提供基础检查建议；
report.py 写 CSV；benchmark_local.py 进行自建本机对比实验；tests/ 保存自动测试。
