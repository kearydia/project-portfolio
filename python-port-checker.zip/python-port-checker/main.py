"""TCP 端口扫描命令行入口。仅用于本机或明确授权的环境。"""

import argparse
import sys
from time import perf_counter

from advice import get_security_advice
from report import write_csv_report
from runner import iter_scan_results
from services import COMMON_PORTS, get_service_hint
from validation import parse_ports, resolve_target, validate_timeout, validate_workers


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="TCP 端口扫描：仅扫描本机或明确授权的环境。支持串行和有限并发。",
        epilog="示例：python main.py -t localhost -p 8000-8002 --workers 4 --output reports/scan.csv",
    )
    parser.add_argument("-t", "--target", required=True, help="IPv4 地址或域名，不含协议和路径")
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("-p", "--ports", help="一个端口或闭区间，例如 80、8000-8005")
    selection.add_argument("--common", action="store_true", help="只扫描内置的 14 个常用 TCP 端口")
    parser.add_argument("--timeout", type=float, default=1.0, help="每次 TCP 连接超时秒数：(0, 60]；默认 1")
    parser.add_argument("--workers", type=int, default=1, help="1～64；默认 1 为串行，大于 1 为有限并发")
    parser.add_argument("--output", help="可选 CSV 路径；已有同名文件不覆盖")
    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    counts = {"open": 0, "closed": 0, "timeout": 0, "unknown": 0}

    try:
        # 先检查非网络参数，非法范围或超时不会触发域名解析。
        try:
            ports = COMMON_PORTS if args.common else parse_ports(args.ports)
            timeout = validate_timeout(args.timeout)
            workers = validate_workers(args.workers)
            address = resolve_target(args.target)
        except ValueError as exc:
            parser.error(str(exc))

        print(f"输入目标：{args.target.strip()}")
        print(f"扫描 IPv4：{address}（域名仅取首个 IPv4，本次只扫描此地址）")
        selection_text = "常用集合：" + ",".join(map(str, ports)) if args.common else args.ports.strip()
        mode = "串行" if workers == 1 else f"有限并发，线程上限 {workers}"
        print(f"端口：{selection_text}，共 {len(ports)} 个；{mode}；连接超时 {timeout:g} 秒")
        print("可能服务仅按端口号提示，未经实际服务识别；开放不代表存在漏洞。")
        print(f"{'PORT':<7} {'STATUS':<8} 可能服务")

        results = []
        started = perf_counter()
        scan_results = iter_scan_results(address, ports, timeout, workers)
        try:
            for result in scan_results:
                results.append(result)
                port = result["port"]
                counts[result["status"]] += 1
                print(f"{port:<7} {result['status']:<8} {get_service_hint(port)}", flush=True)
                if result["status"] == "unknown":
                    print(f"    原因：{result['detail']}", flush=True)
                if result["status"] == "open":
                    print(f"    基础建议：{get_security_advice(port, result['status'])}", flush=True)
        finally:
            scan_results.close()
        elapsed = perf_counter() - started

        print(
            f"完成：共 {sum(counts.values())} 个；open={counts['open']}，"
            f"closed={counts['closed']}，timeout={counts['timeout']}，unknown={counts['unknown']}"
        )
        print(f"扫描耗时：{elapsed:.3f} 秒（不含域名解析和 CSV 写入）")
        if args.output is not None:
            try:
                output_path = write_csv_report(args.output, args.target.strip(), results)
            except OSError as exc:
                print(f"CSV 输出失败：{exc}；本次扫描结果已显示，报告未确认写入成功。", file=sys.stderr)
                return 3
            print(f"CSV 已保存：{output_path.resolve()}")
        return 0
    except KeyboardInterrupt:
        print("\n扫描已被用户中断；已输出的结果保留；本次不生成完整 CSV。", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
