"""串行/有限并发调度，底层 TCP 状态判断仍由 scanner 负责。"""

from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

from scanner import scan_port
from validation import validate_ipv4, validate_port, validate_timeout, validate_workers


def iter_scan_results(target_ip, ports, timeout=1.0, workers=1):
    """逐项产出结果；并发时按完成顺序产出，待处理 Future 不超过 workers。

    参数在第一条连接前完整检查。调用方提前停止时应 close() 这个生成器，
    取消未运行的任务，并等待正在连接的任务按自身超时结束。
    """
    address = validate_ipv4(target_ip)
    timeout = validate_timeout(timeout)
    workers = validate_workers(workers)
    selected_ports = sorted({validate_port(port) for port in ports})

    if workers == 1:
        for port in selected_ports:
            yield scan_port(address, port, timeout)
        return

    if not selected_ports:
        return

    port_iterator = iter(selected_ports)
    executor = ThreadPoolExecutor(max_workers=workers)
    pending = {}
    try:
        # 只先提交一批，不把全部端口一次性放入线程池队列。
        for port in selected_ports[:workers]:
            pending[executor.submit(scan_port, address, port, timeout)] = port
            next(port_iterator)

        while pending:
            completed, _ = wait(pending, return_when=FIRST_COMPLETED)
            # 同一批已完成任务按端口输出；跨批次仍可能不按端口升序。
            for future in sorted(completed, key=lambda item: pending[item]):
                pending.pop(future)
                yield future.result()
                next_port = next(port_iterator, None)
                if next_port is not None:
                    pending[executor.submit(scan_port, address, next_port, timeout)] = next_port
    finally:
        for future in pending:
            future.cancel()
        # Python 线程不能强制停止正在执行的 connect，需等它返回或超时。
        executor.shutdown(wait=True, cancel_futures=True)
