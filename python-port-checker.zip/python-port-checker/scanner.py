"""单端口 TCP 连接检测。仅用于本机或明确授权的实验环境。"""

import socket

from validation import validate_ipv4, validate_port, validate_timeout


def scan_port(target_ip: str, port: int, timeout: float = 1.0) -> dict:
    """检测一个 IPv4 TCP 端口，返回 target、port、status、detail。

    timeout 是本次连接的等待上限，单位为秒，范围为 (0, 60]。
    open: 连接成功；closed: 连接被明确拒绝；timeout: 连接超时；
    unknown: 其他 Socket/系统错误，不能据此判断端口是否关闭。
    当前阶段只接收 IPv4 地址，不解析域名，不识别实际服务。
    """
    address = validate_ipv4(target_ip)
    validate_port(port)
    timeout = validate_timeout(timeout)

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.settimeout(timeout)
            client.connect((address, port))
        status = "open"
        detail = "TCP connection established."
    except ConnectionRefusedError as exc:
        status = "closed"
        detail = f"TCP connection refused: {exc}"
    except TimeoutError as exc:
        status = "timeout"
        detail = f"TCP connection timed out: {exc}"
    except OSError as exc:
        status = "unknown"
        detail = f"Socket/OS error; port state is undetermined: {exc}"

    return {
        "target": address,
        "port": port,
        "status": status,
        "detail": detail,
    }
