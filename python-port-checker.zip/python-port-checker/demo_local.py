"""自建本机临时端口，演示单端口检测；不接受外部扫描目标。"""

import socket

from scanner import scan_port


def main() -> None:
    # 端口号 0 让操作系统选择一个可用的临时端口。
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        port = listener.getsockname()[1]
        open_result = scan_port("127.0.0.1", port, timeout=1.0)
        print("Listening locally:", open_result)

    # 离开 with 后监听 Socket 已关闭；立即检测刚刚释放的同一个端口。
    # Windows 返回明确拒绝可能需要几秒钟，因此这里等待至多 5 秒。
    closed_result = scan_port("127.0.0.1", port, timeout=5.0)
    print("After listener closes:", closed_result)

    if open_result["status"] != "open" or closed_result["status"] != "closed":
        raise SystemExit("Local demo did not produce the expected states; inspect details above.")


if __name__ == "__main__":
    main()
