"""输入检查、端口范围解析和扫描前的 IPv4 目标准备。"""

import ipaddress
import math
import re
import socket


def validate_ipv4(target_ip: str) -> str:
    """验证 IPv4 字符串；单端口函数使用它，避免在每个端口重复解析域名。"""
    if not isinstance(target_ip, str):
        raise ValueError("目标 IP 必须是 IPv4 地址字符串。")
    try:
        return str(ipaddress.IPv4Address(target_ip.strip()))
    except ipaddress.AddressValueError as exc:
        raise ValueError("目标 IP 必须是合法的 IPv4 地址。") from exc


def validate_port(port: int) -> int:
    """端口必须为 1～65535 的整数，不能是布尔值。"""
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError("端口必须是 1～65535 的整数。")
    return port


def validate_timeout(timeout: float) -> float:
    """返回有效超时，单位为秒；不限制系统域名解析所用的时间。"""
    if (
        isinstance(timeout, bool)
        or not isinstance(timeout, (int, float))
        or not 0 < timeout <= 60
        or not math.isfinite(timeout)
    ):
        raise ValueError("超时必须是大于 0 且不超过 60 的有限数值，单位为秒。")
    return float(timeout)


def validate_workers(workers: int) -> int:
    """限制线程数量；1 表示串行，最多 64 个工作线程。"""
    if isinstance(workers, bool) or not isinstance(workers, int) or not 1 <= workers <= 64:
        raise ValueError("工作线程数必须是 1～64 的整数；1 表示串行。")
    return workers


def parse_ports(text: str) -> range:
    """接受一个端口或闭区间，例如 '80'、'8000-8005'；返回 range。"""
    if not isinstance(text, str):
        raise ValueError("端口参数必须是字符串，例如 80 或 8000-8005。")
    match = re.fullmatch(r"([0-9]+)(?:\s*-\s*([0-9]+))?", text.strip())
    if match is None:
        raise ValueError("端口格式应为一个端口或起止范围，例如 80 或 8000-8005。")
    start = validate_port(int(match.group(1)))
    end = validate_port(int(match.group(2))) if match.group(2) else start
    if start > end:
        raise ValueError("起始端口不能大于结束端口。")
    # range 的结束值不包含在内，因此用 end + 1 包含最后一个端口。
    return range(start, end + 1)


def normalize_target(target: str) -> str:
    """接受完整 IPv4 或主机名，拒绝 URL、附带端口的地址和 IPv6。"""
    if not isinstance(target, str) or not target.strip():
        raise ValueError("目标不能为空，请输入 IPv4 地址或域名。")
    target = target.strip()
    try:
        address = ipaddress.ip_address(target)
    except ValueError:
        address = None
    if address is not None:
        if address.version != 4:
            raise ValueError("当前阶段只支持 IPv4，暂不支持 IPv6。")
        return str(address)

    try:
        hostname = target.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ValueError("域名格式无效。") from exc
    # 允许完整域名末尾的一个根域点。
    name = hostname[:-1] if hostname.endswith(".") else hostname
    # 拒绝 127.1、整数/十六进制 IP 等系统可能接受的非标准写法。
    numeric_pattern = r"(?:0x[0-9a-f]+|[0-9]+)(?:\.(?:0x[0-9a-f]+|[0-9]+))*"
    if re.fullmatch(numeric_pattern, name):
        raise ValueError("IPv4 地址格式错误，请使用完整的四段地址。")
    label_pattern = r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?"
    if (
        len(name) > 253
        or not name
        or any(re.fullmatch(label_pattern, label) is None for label in name.split("."))
    ):
        raise ValueError("目标应为 IPv4 或合法主机名，不要填写协议、路径或端口。")
    return hostname


def resolve_target(target: str) -> str:
    """IPv4 直接返回；域名取系统解析结果中的第一个 IPv4，只在扫描前解析。"""
    hostname = normalize_target(target)
    try:
        return str(ipaddress.IPv4Address(hostname))
    except ipaddress.AddressValueError:
        pass
    try:
        addresses = socket.getaddrinfo(hostname, None, socket.AF_INET, socket.SOCK_STREAM)
    except OSError as exc:
        raise ValueError(f"无法解析目标的 IPv4 地址：{hostname}；原因：{exc}") from exc
    if not addresses:
        raise ValueError(f"目标没有可用的 IPv4 地址：{hostname}")
    return validate_ipv4(addresses[0][4][0])
