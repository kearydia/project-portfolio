"""第四阶段命令行组合与 CSV 集成测试；网络结果使用模拟。"""

from contextlib import redirect_stderr, redirect_stdout
import csv
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from main import main
from services import COMMON_PORTS


def fake_scan(address, port, timeout):
    return {"target": address, "port": port, "status": "closed", "detail": "simulated refusal"}


class Stage4CommandLineTests(unittest.TestCase):
    def test_common_selection_is_fixed_set_not_full_range(self):
        with patch("runner.scan_port", side_effect=fake_scan) as scanner:
            with redirect_stdout(io.StringIO()) as output:
                code = main(["-t", "127.0.0.1", "--common", "--workers", "4"])
        self.assertEqual(code, 0)
        self.assertEqual(scanner.call_count, len(COMMON_PORTS))
        self.assertEqual({item.args[1] for item in scanner.call_args_list}, set(COMMON_PORTS))
        self.assertIn("常用集合", output.getvalue())
        self.assertIn("有限并发", output.getvalue())

    def test_ports_and_common_are_mutually_exclusive_before_dns(self):
        with patch("main.resolve_target") as resolver, redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as stopped:
                main(["-t", "localhost", "-p", "80", "--common"])
        self.assertEqual(stopped.exception.code, 2)
        resolver.assert_not_called()

    def test_invalid_workers_are_rejected_before_dns(self):
        for workers in ("0", "65", "-1", "abc"):
            with self.subTest(workers=workers):
                with patch("main.resolve_target") as resolver, redirect_stderr(io.StringIO()):
                    with self.assertRaises(SystemExit) as stopped:
                        main(["-t", "localhost", "-p", "80", "--workers", workers])
                self.assertEqual(stopped.exception.code, 2)
                resolver.assert_not_called()

    def test_parallel_cli_writes_real_sorted_csv_with_all_states(self):
        statuses = {80: "open", 81: "closed", 82: "timeout", 83: "unknown"}

        def mixed_results(address, port, timeout):
            return {"target": address, "port": port, "status": statuses[port], "detail": "simulated detail"}

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scan.csv"
            with patch("runner.scan_port", side_effect=mixed_results), redirect_stdout(io.StringIO()) as output:
                code = main(["-t", "127.0.0.1", "-p", "80-83", "--workers", "3", "--output", str(path)])
            with path.open(encoding="utf-8-sig", newline="") as source:
                rows = list(csv.DictReader(source))
        self.assertEqual(code, 0)
        self.assertEqual([int(row["port"]) for row in rows], [80, 81, 82, 83])
        self.assertEqual([row["status"] for row in rows], list(statuses.values()))
        self.assertIn("CSV 已保存", output.getvalue())
        self.assertIn("若确认为 HTTP", rows[0]["advice"])

    def test_report_failure_returns_3_without_success_message(self):
        with patch("runner.scan_port", side_effect=fake_scan):
            with patch("main.write_csv_report", side_effect=PermissionError("simulated write denial")):
                with redirect_stdout(io.StringIO()) as output, redirect_stderr(io.StringIO()) as errors:
                    code = main(["-t", "127.0.0.1", "-p", "80", "--output", "unused.csv"])
        self.assertEqual(code, 3)
        self.assertIn("CSV 输出失败", errors.getvalue())
        self.assertNotIn("CSV 已保存", output.getvalue())

    def test_interruption_does_not_export_a_complete_report(self):
        with patch("runner.scan_port", side_effect=KeyboardInterrupt), patch("main.write_csv_report") as writer:
            with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
                code = main(["-t", "127.0.0.1", "-p", "80-81", "--output", "unused.csv"])
        self.assertEqual(code, 130)
        writer.assert_not_called()


if __name__ == "__main__":
    unittest.main()
