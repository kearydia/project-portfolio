"""检查建议的证据边界：端口映射不能成为服务或漏洞结论。"""

import unittest

from advice import get_security_advice


class AdviceTests(unittest.TestCase):
    def test_known_open_ports_use_conditional_service_wording(self):
        for port in (21, 22, 23, 80, 443, 445, 3306, 3389, 5432, 8080):
            with self.subTest(port=port):
                advice = get_security_advice(port, "open")
                self.assertTrue(advice.startswith("若确认为"), advice)
                self.assertNotIn("存在漏洞", advice)
                self.assertNotIn("已确认", advice)

    def test_unmapped_open_port_does_not_invent_service(self):
        advice = get_security_advice(65000, "open")
        self.assertIn("确认实际服务身份", advice)
        self.assertNotIn("SSH", advice)
        self.assertNotIn("存在漏洞", advice)

    def test_non_open_states_do_not_imply_service_or_safety(self):
        for status in ("closed", "timeout", "unknown"):
            with self.subTest(status=status):
                advice = get_security_advice(22, status)
                self.assertNotIn("SSH", advice)
                self.assertNotIn("若确认为", advice)
                self.assertNotIn("目标是安全的", advice)
        self.assertIn("不证明目标安全", get_security_advice(22, "closed"))
        self.assertIn("无法判断是否关闭", get_security_advice(22, "timeout"))
        self.assertIn("无法判断", get_security_advice(22, "unknown"))

    def test_invalid_status_and_port_are_rejected(self):
        for port, status in ((0, "open"), (65536, "open"), (True, "open"), (80, "safe")):
            with self.subTest(port=port, status=status), self.assertRaises(ValueError):
                get_security_advice(port, status)
