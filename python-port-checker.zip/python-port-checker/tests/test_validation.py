"""范围、目标格式和模拟域名解析；不向外部域名发起查询。"""

import socket
import unittest
from unittest.mock import patch

from validation import normalize_target, parse_ports, resolve_target


class PortRangeTests(unittest.TestCase):
    def test_single_port_and_inclusive_ranges(self):
        cases = (("80", 80, 80), (" 20 - 23 ", 20, 23), ("1-65535", 1, 65535))
        for text, start, end in cases:
            with self.subTest(text=text):
                ports = parse_ports(text)
                self.assertEqual(ports[0], start)
                self.assertEqual(ports[-1], end)
                self.assertEqual(len(ports), end - start + 1)

    def test_invalid_ranges(self):
        cases = (None, "", "0", "65536", "90-80", "-1", "1-2-3", "80,443", "80.5", "abc")
        for text in cases:
            with self.subTest(text=text), self.assertRaises(ValueError):
                parse_ports(text)


class TargetTests(unittest.TestCase):
    def test_literal_ipv4_bypasses_resolution(self):
        with patch("validation.socket.getaddrinfo") as resolver:
            self.assertEqual(resolve_target(" 127.0.0.1 "), "127.0.0.1")
            resolver.assert_not_called()

    def test_hostname_normalization(self):
        self.assertEqual(normalize_target(" LOCALHOST "), "localhost")
        self.assertEqual(normalize_target("Example.COM."), "example.com.")
        self.assertEqual(normalize_target("例子.测试"), "xn--fsqu00a.xn--0zwm56d")

    def test_invalid_targets_are_rejected_before_dns(self):
        cases = (
            None, "", "999.1.2.3", "127.1", "2130706433", "0x7f000001",
            "１２７.１", "::1", "https://localhost", "localhost:80", "localhost/path",
            "user@localhost", "-host", "host-", "a..test", "bad_name", ".",
            "a" * 64 + ".test", ".".join(["a" * 63] * 4),
        )
        for target in cases:
            with self.subTest(target=target):
                with patch("validation.socket.getaddrinfo") as resolver:
                    with self.assertRaises(ValueError):
                        resolve_target(target)
                    resolver.assert_not_called()

    def test_simulated_dns_uses_first_ipv4_once(self):
        answers = [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("192.0.2.10", 0)),
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("192.0.2.11", 0)),
        ]
        with patch("validation.socket.getaddrinfo", return_value=answers) as resolver:
            self.assertEqual(resolve_target("example.test"), "192.0.2.10")
            resolver.assert_called_once_with("example.test", None, socket.AF_INET, socket.SOCK_STREAM)

    def test_simulated_dns_failure_has_clear_error(self):
        with patch("validation.socket.getaddrinfo", side_effect=socket.gaierror("simulated DNS failure")):
            with self.assertRaisesRegex(ValueError, "无法解析目标的 IPv4 地址"):
                resolve_target("example.test")

    def test_simulated_empty_dns_result_is_rejected(self):
        with patch("validation.socket.getaddrinfo", return_value=[]):
            with self.assertRaisesRegex(ValueError, "没有可用的 IPv4 地址"):
                resolve_target("example.test")
