"""CSV 真实文件读回测试；不连接网络。"""

import csv
from pathlib import Path
import tempfile
import unittest

from report import CSV_FIELDS, write_csv_report


def result(port, status="open", detail="TCP connection established."):
    return {"target": "127.0.0.1", "port": port, "status": status, "detail": detail}


class CsvReportTests(unittest.TestCase):
    def test_round_trip_all_states_unicode_and_special_characters(self):
        special_detail = '错误原因：拒绝, retry "later"\n第二行'
        results = [
            result(65000, "unknown", special_detail),
            result(80, "open"),
            result(22, "closed", "明确拒绝"),
            result(443, "timeout", "超时"),
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "new" / "中文报告.csv"
            written = write_csv_report(path, "本机实验", iter(results))
            self.assertEqual(written, path)
            self.assertTrue(path.read_bytes().startswith(b"\xef\xbb\xbf"))
            with path.open(encoding="utf-8-sig", newline="") as source:
                reader = csv.DictReader(source)
                self.assertEqual(reader.fieldnames, list(CSV_FIELDS))
                rows = list(reader)
            self.assertEqual([int(row["port"]) for row in rows], [22, 80, 443, 65000])
            self.assertEqual({row["status"] for row in rows}, {"open", "closed", "timeout", "unknown"})
            self.assertTrue(all(row["input_target"] == "本机实验" for row in rows))
            self.assertTrue(all(row["target_ip"] == "127.0.0.1" for row in rows))
            self.assertEqual(rows[-1]["detail"], special_detail)
            self.assertEqual(rows[1]["possible_service"], "HTTP")
            self.assertTrue(rows[1]["advice"].startswith("若确认为"))
            self.assertEqual(rows[-1]["possible_service"], "未知")
            self.assertIn("无法判断是否关闭", rows[2]["advice"])

    def test_existing_report_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "existing.csv"
            original = b"old report remains unchanged\n"
            path.write_bytes(original)
            with self.assertRaises(FileExistsError):
                write_csv_report(path, "localhost", [result(80)])
            self.assertEqual(path.read_bytes(), original)

    def test_parent_file_error_is_propagated_without_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            parent_file = Path(directory) / "not-a-directory"
            parent_file.write_bytes(b"preserve me")
            with self.assertRaises(OSError):
                write_csv_report(parent_file / "report.csv", "localhost", [result(80)])
            self.assertEqual(parent_file.read_bytes(), b"preserve me")

    def test_invalid_rows_fail_before_creating_directories(self):
        invalid_results = [
            {"target": "127.0.0.1", "port": 80, "status": "safe", "detail": "not a valid state"},
            {"target": "localhost", "port": 80, "status": "open", "detail": "not a resolved IP"},
            {"target": "127.0.0.1", "port": 80, "status": "open", "detail": None},
            result(0),
        ]
        with tempfile.TemporaryDirectory() as directory:
            for item in invalid_results:
                with self.subTest(item=item):
                    path = Path(directory) / "should-not-exist" / "report.csv"
                    with self.assertRaises(ValueError):
                        write_csv_report(path, "localhost", [result(22), item])
                    self.assertFalse(path.parent.exists())

    def test_empty_results_still_produce_header_only_report(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "empty.csv"
            write_csv_report(path, "localhost", [])
            with path.open(encoding="utf-8-sig", newline="") as source:
                reader = csv.DictReader(source)
                self.assertEqual(reader.fieldnames, list(CSV_FIELDS))
                self.assertEqual(list(reader), [])


if __name__ == "__main__":
    unittest.main()
