"""真实本机连接测试 + 明确标注的异常模拟测试。"""

import errno
import socket
import unittest
from unittest.mock import patch

from scanner import scan_port


class LocalConnectionTests(unittest.TestCase):
    def test_listening_local_port_is_open(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            listener.bind(("127.0.0.1", 0))
            listener.listen(1)
            port = listener.getsockname()[1]
            result = scan_port("127.0.0.1", port)

        self.assertEqual(result["status"], "open", result)
        self.assertEqual(result["target"], "127.0.0.1")
        self.assertEqual(result["port"], port)

    def test_released_local_port_is_closed(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reserved:
            reserved.bind(("127.0.0.1", 0))
            port = reserved.getsockname()[1]
        # 释放端口后立即检测；明确拒绝可能需要几秒钟才能返回。
        result = scan_port("127.0.0.1", port, timeout=5.0)

        self.assertEqual(result["status"], "closed", result)


class SimulatedConnectionTests(unittest.TestCase):
    def run_with_connect_error(self, error):
        with patch("scanner.socket.socket") as socket_factory:
            client = socket_factory.return_value.__enter__.return_value
            client.connect.side_effect = error
            result = scan_port("127.0.0.1", 12345, timeout=0.5)
            client.settimeout.assert_called_once_with(0.5)
            client.connect.assert_called_once_with(("127.0.0.1", 12345))
            socket_factory.return_value.__exit__.assert_called_once()
        return result

    def test_simulated_refusal_is_closed(self):
        result = self.run_with_connect_error(
            ConnectionRefusedError(errno.ECONNREFUSED, "simulated refusal")
        )
        self.assertEqual(result["status"], "closed")
        self.assertIn("simulated refusal", result["detail"])

    def test_simulated_timeout_is_timeout(self):
        result = self.run_with_connect_error(socket.timeout("simulated timeout"))
        self.assertEqual(result["status"], "timeout")

    def test_simulated_unreachable_is_unknown(self):
        result = self.run_with_connect_error(
            OSError(errno.ENETUNREACH, "simulated network unreachable")
        )
        self.assertEqual(result["status"], "unknown")
        self.assertIn("simulated network unreachable", result["detail"])

    def test_simulated_reset_is_unknown(self):
        result = self.run_with_connect_error(
            ConnectionResetError(errno.ECONNRESET, "simulated reset")
        )
        self.assertEqual(result["status"], "unknown")

    def test_simulated_permission_error_is_unknown(self):
        result = self.run_with_connect_error(
            PermissionError(errno.EACCES, "simulated permission error")
        )
        self.assertEqual(result["status"], "unknown")

    def test_simulated_socket_creation_failure_is_unknown(self):
        with patch("scanner.socket.socket", side_effect=OSError("simulated creation failure")):
            result = scan_port("127.0.0.1", 12345)
        self.assertEqual(result["status"], "unknown")
        self.assertIn("simulated creation failure", result["detail"])


class ArgumentTests(unittest.TestCase):
    def test_invalid_addresses_fail_before_network_access(self):
        for address in ("", "999.1.2.3", "127.0.0", "localhost", "::1", None):
            with self.subTest(address=address):
                with patch("scanner.socket.socket") as socket_factory:
                    with self.assertRaises(ValueError):
                        scan_port(address, 80)
                    socket_factory.assert_not_called()

    def test_invalid_ports_fail_before_network_access(self):
        for port in (0, -1, 65536, "80", 80.5, True, None):
            with self.subTest(port=port):
                with patch("scanner.socket.socket") as socket_factory:
                    with self.assertRaises(ValueError):
                        scan_port("127.0.0.1", port)
                    socket_factory.assert_not_called()

    def test_invalid_timeouts_fail_before_network_access(self):
        for timeout in (0, -1, 61, float("inf"), float("nan"), "1", True, None):
            with self.subTest(timeout=timeout):
                with patch("scanner.socket.socket") as socket_factory:
                    with self.assertRaises(ValueError):
                        scan_port("127.0.0.1", 80, timeout)
                    socket_factory.assert_not_called()

    def test_valid_boundary_ports_and_whitespace_address(self):
        for port in (1, 65535):
            with self.subTest(port=port):
                with patch("scanner.socket.socket") as socket_factory:
                    client = socket_factory.return_value.__enter__.return_value
                    result = scan_port(" 127.0.0.1 ", port, timeout=60)
                    client.connect.assert_called_once_with(("127.0.0.1", port))
                    self.assertEqual(result["status"], "open")
                    self.assertEqual(result["target"], "127.0.0.1")


if __name__ == "__main__":
    unittest.main()
