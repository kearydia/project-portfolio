"""命令行行为测试；一个子进程测试真实 localhost，其余连接均模拟。"""

from contextlib import redirect_stderr, redirect_stdout
import io
from pathlib import Path
import socket
import subprocess
import sys
import unittest
from unittest.mock import call, patch

from main import main


PROJECT_DIR = Path(__file__).resolve().parents[1]


class CommandLineTests(unittest.TestCase):
    def test_serial_range_preserves_all_states_and_labels_hints(self):
        results = [
            {"target": "127.0.0.1", "port": port, "status": status, "detail": "simulated reason"}
            for port, status in zip(range(80, 84), ("open", "closed", "timeout", "unknown"))
        ]
        output = io.StringIO()
        with patch("main.resolve_target", return_value="127.0.0.1") as resolver:
            with patch("runner.scan_port", side_effect=results) as scanner:
                with redirect_stdout(output):
                    code = main(["-t", "localhost", "-p", "80-83", "--timeout", "0.5"])
        self.assertEqual(code, 0)
        resolver.assert_called_once_with("localhost")
        self.assertEqual(scanner.call_args_list, [call("127.0.0.1", port, 0.5) for port in range(80, 84)])
        text = output.getvalue()
        self.assertIn("可能服务仅按端口号提示", text)
        self.assertIn("HTTP", text)
        self.assertIn("未知", text)
        self.assertIn("原因：simulated reason", text)
        self.assertIn("共 4 个；open=1，closed=1，timeout=1，unknown=1", text)

    def test_invalid_range_exits_before_resolution_or_scan(self):
        with patch("main.resolve_target") as resolver, patch("runner.scan_port") as scanner:
            with redirect_stderr(io.StringIO()) as errors:
                with self.assertRaises(SystemExit) as stopped:
                    main(["-t", "localhost", "-p", "90-80"])
        self.assertEqual(stopped.exception.code, 2)
        self.assertIn("起始端口不能大于结束端口", errors.getvalue())
        resolver.assert_not_called()
        scanner.assert_not_called()

    def test_invalid_timeouts_exit_before_resolution(self):
        for timeout in ("0", "-1", "nan", "inf", "61", "abc"):
            with self.subTest(timeout=timeout):
                with patch("main.resolve_target") as resolver, patch("runner.scan_port") as scanner:
                    with redirect_stderr(io.StringIO()):
                        with self.assertRaises(SystemExit) as stopped:
                            main(["-t", "localhost", "-p", "80", "--timeout", timeout])
                    self.assertEqual(stopped.exception.code, 2)
                    resolver.assert_not_called()
                    scanner.assert_not_called()

    def test_missing_arguments_exit_with_usage(self):
        with redirect_stderr(io.StringIO()) as errors:
            with self.assertRaises(SystemExit) as stopped:
                main([])
        self.assertEqual(stopped.exception.code, 2)
        self.assertIn("usage:", errors.getvalue())

    def test_url_target_is_rejected_without_dns_or_scan(self):
        with patch("validation.socket.getaddrinfo") as resolver, patch("runner.scan_port") as scanner:
            with redirect_stderr(io.StringIO()) as errors:
                with self.assertRaises(SystemExit) as stopped:
                    main(["-t", "https://localhost", "-p", "80"])
        self.assertEqual(stopped.exception.code, 2)
        self.assertNotIn("Traceback", errors.getvalue())
        resolver.assert_not_called()
        scanner.assert_not_called()

    def test_simulated_dns_failure_exits_without_scan(self):
        with patch("validation.socket.getaddrinfo", side_effect=socket.gaierror("simulated failure")):
            with patch("runner.scan_port") as scanner, redirect_stderr(io.StringIO()) as errors:
                with self.assertRaises(SystemExit) as stopped:
                    main(["-t", "example.test", "-p", "80"])
        self.assertEqual(stopped.exception.code, 2)
        self.assertIn("无法解析", errors.getvalue())
        self.assertNotIn("Traceback", errors.getvalue())
        scanner.assert_not_called()

    def test_simulated_user_interrupt_returns_130(self):
        with patch("runner.scan_port", side_effect=KeyboardInterrupt):
            with redirect_stdout(io.StringIO()) as output, redirect_stderr(io.StringIO()) as errors:
                code = main(["-t", "127.0.0.1", "-p", "80-81"])
        self.assertEqual(code, 130)
        self.assertIn("中断", errors.getvalue())
        self.assertNotIn("完成：", output.getvalue())

    def test_help_in_real_subprocess(self):
        completed = subprocess.run(
            [sys.executable, "-X", "utf8", "-B", "main.py", "--help"],
            cwd=PROJECT_DIR, capture_output=True, text=True, encoding="utf-8", timeout=10,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        for option in ("--target", "--ports", "--timeout"):
            self.assertIn(option, completed.stdout)

    def test_real_localhost_scan_in_subprocess(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
            listener.bind(("127.0.0.1", 0))
            listener.listen(1)
            port = listener.getsockname()[1]
            completed = subprocess.run(
                [sys.executable, "-X", "utf8", "-B", "main.py", "--target", "localhost",
                 "--ports", str(port), "--timeout", "5"],
                cwd=PROJECT_DIR, capture_output=True, text=True, encoding="utf-8", timeout=15,
            )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        self.assertIn("扫描 IPv4：127.0.0.1", completed.stdout)
        self.assertIn("共 1 个；open=1，closed=0，timeout=0，unknown=0", completed.stdout)


if __name__ == "__main__":
    unittest.main()
