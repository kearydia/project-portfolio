"""扫描调度测试：模拟端口结果，真实线程验证并发规模；不进行网络连接。"""

from concurrent.futures import ThreadPoolExecutor
import threading
import unittest
from unittest.mock import call, patch

from runner import iter_scan_results


def make_result(port, status="open"):
    """构造与 scan_port 相同形状的模拟结果。"""
    return {"target": "127.0.0.1", "port": port, "status": status, "detail": "simulated result"}


class SerialRunnerTests(unittest.TestCase):
    def test_serial_sorts_deduplicates_and_preserves_results(self):
        expected = {80: make_result(80, "open"), 81: make_result(81, "closed"), 82: make_result(82, "timeout")}
        with patch("runner.scan_port", side_effect=lambda address, port, timeout: expected[port]) as scanner:
            results = list(iter_scan_results(" 127.0.0.1 ", [82, 80, 81, 80], timeout=0.5, workers=1))
        self.assertEqual(results, [expected[80], expected[81], expected[82]])
        self.assertEqual(scanner.call_args_list, [call("127.0.0.1", port, 0.5) for port in (80, 81, 82)])

    def test_invalid_inputs_fail_before_any_port_connection(self):
        cases = (
            {"target_ip": "localhost", "ports": [80], "timeout": 1, "workers": 1},
            {"target_ip": "127.0.0.1", "ports": [80, 443, 0], "timeout": 1, "workers": 2},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": 0, "workers": 2},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": float("nan"), "workers": 2},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": 1, "workers": 0},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": 1, "workers": 65},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": 1, "workers": True},
            {"target_ip": "127.0.0.1", "ports": [80], "timeout": 1, "workers": "2"},
        )
        for arguments in cases:
            with self.subTest(arguments=arguments):
                with patch("runner.scan_port") as scanner:
                    with self.assertRaises(ValueError):
                        list(iter_scan_results(**arguments))
                    scanner.assert_not_called()

    def test_empty_port_set_makes_no_connections(self):
        for workers in (1, 3):
            with self.subTest(workers=workers), patch("runner.scan_port") as scanner:
                self.assertEqual(list(iter_scan_results("127.0.0.1", [], workers=workers)), [])
                scanner.assert_not_called()


class ParallelRunnerTests(unittest.TestCase):
    def test_parallel_preserves_every_port_and_all_four_states_once(self):
        statuses = {80: "open", 81: "closed", 82: "timeout", 83: "unknown"}
        with patch("runner.scan_port", side_effect=lambda address, port, timeout: make_result(port, statuses[port])) as scanner:
            results = list(iter_scan_results("127.0.0.1", [83, 82, 81, 80, 80], timeout=0.5, workers=3))
        self.assertEqual(sorted(result["port"] for result in results), [80, 81, 82, 83])
        self.assertEqual({result["port"]: result["status"] for result in results}, statuses)
        self.assertEqual(scanner.call_count, 4)
        self.assertEqual({tuple(item.args) for item in scanner.call_args_list}, {("127.0.0.1", port, 0.5) for port in statuses})

    def test_real_worker_threads_overlap_without_exceeding_limit(self):
        workers = 3
        barrier = threading.Barrier(workers, timeout=5)
        lock = threading.Lock()
        active = 0
        peak = 0

        def simulated_connection(address, port, timeout):
            nonlocal active, peak
            with lock:
                active += 1
                peak = max(peak, active)
            try:
                # 每一组必须有 3 个真实工作线程同时到达，不依赖毫秒级耗时断言。
                barrier.wait()
                return make_result(port)
            finally:
                with lock:
                    active -= 1

        with patch("runner.scan_port", side_effect=simulated_connection):
            results = list(iter_scan_results("127.0.0.1", range(1, 7), workers=workers))
        self.assertEqual(len(results), 6)
        self.assertEqual(peak, workers)
        self.assertEqual(active, 0)

    def test_first_yield_is_bounded_and_early_close_does_not_refill(self):
        submitted = []

        class RecordingExecutor(ThreadPoolExecutor):
            def submit(self, function, *args, **kwargs):
                submitted.append(args[1])
                return super().submit(function, *args, **kwargs)

        with patch("runner.ThreadPoolExecutor", RecordingExecutor):
            with patch("runner.scan_port", side_effect=lambda address, port, timeout: make_result(port)) as scanner:
                iterator = iter_scan_results("127.0.0.1", range(1, 101), workers=3)
                try:
                    first = next(iterator)
                    self.assertIn(first["port"], (1, 2, 3))
                    # 100 个端口不能一次性全部提交；首个结果前只填满 3 个位置。
                    self.assertEqual(len(submitted), 3)
                finally:
                    iterator.close()
                self.assertEqual(len(submitted), 3)
                self.assertLessEqual(scanner.call_count, 3)

    def test_unexpected_worker_exception_is_not_misreported_as_port_state(self):
        def broken_connection(address, port, timeout):
            if port == 80:
                raise RuntimeError("simulated programming failure")
            return make_result(port, "closed")

        with patch("runner.scan_port", side_effect=broken_connection):
            with self.assertRaisesRegex(RuntimeError, "simulated programming failure"):
                list(iter_scan_results("127.0.0.1", [80, 81, 82], workers=2))

    def test_close_waits_for_a_running_task_to_finish(self):
        started = threading.Event()
        release = threading.Event()
        task_finished = threading.Event()
        shutdown_started = threading.Event()
        close_finished = threading.Event()

        class ObservedExecutor(ThreadPoolExecutor):
            def shutdown(self, *args, **kwargs):
                shutdown_started.set()
                return super().shutdown(*args, **kwargs)

        def simulated_connection(address, port, timeout):
            if port == 2:
                started.set()
                if not release.wait(5):
                    raise AssertionError("test did not release the simulated connection")
                task_finished.set()
            return make_result(port)

        with patch("runner.ThreadPoolExecutor", ObservedExecutor):
            with patch("runner.scan_port", side_effect=simulated_connection) as scanner:
                iterator = iter_scan_results("127.0.0.1", range(1, 101), workers=2)
                self.assertEqual(next(iterator)["port"], 1)
                self.assertTrue(started.wait(3), "second task should have started")

                def close_iterator():
                    iterator.close()
                    close_finished.set()

                closer = threading.Thread(target=close_iterator)
                closer.start()
                try:
                    self.assertTrue(shutdown_started.wait(3), "close should begin executor shutdown")
                    # 第二个任务尚未获准返回，生成器不能宣称清理已经完成。
                    self.assertFalse(close_finished.is_set())
                finally:
                    release.set()
                    closer.join(5)
                self.assertFalse(closer.is_alive())
                self.assertTrue(task_finished.is_set())
                self.assertTrue(close_finished.is_set())
                self.assertEqual(scanner.call_count, 2)


if __name__ == "__main__":
    unittest.main()
