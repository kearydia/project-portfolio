"""可复现的本机实验：自建 6 个端口，比较串行与有限并发，不访问外部目标。"""

import argparse
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import platform
import socket
from statistics import median
import sys
from time import perf_counter

from report import write_csv_report
from runner import iter_scan_results
from validation import validate_workers


def prepare_local_ports():
    """返回 6 个相邻端口与 2 个监听 Socket；其余 4 个端口释放后用作拒绝场景。"""
    for attempt in range(30):
        sockets = []
        try:
            first = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sockets.append(first)
            first.bind(("127.0.0.1", 0))
            start = first.getsockname()[1]
            if start + 5 > 65535:
                raise OSError("Not enough adjacent ports.")
            for port in range(start + 1, start + 6):
                reserved = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sockets.append(reserved)
                reserved.bind(("127.0.0.1", port))
            for listener in sockets[:2]:
                listener.listen(16)
        except OSError:
            for item in sockets:
                item.close()
            continue
        for item in sockets[2:]:
            item.close()
        return list(range(start, start + 6)), sockets[:2]
    raise OSError("无法准备 6 个相邻本机实验端口。")


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="仅使用自建 127.0.0.1 端口的串行/并发对比。")
    parser.add_argument("--rounds", type=int, default=3, help="1～5 轮，默认 3")
    parser.add_argument("--workers", type=int, default=4, help="并发工作线程数 2～64，默认 4")
    parser.add_argument("--output-dir", help="新的输出目录；省略时使用 UTC 时间命名")
    args = parser.parse_args(argv)
    if not 1 <= args.rounds <= 5:
        parser.error("rounds 必须为 1～5。")
    try:
        validate_workers(args.workers)
        if args.workers == 1:
            raise ValueError("对比实验的并发线程数至少为 2。")
    except ValueError as exc:
        parser.error(str(exc))

    label = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output_dir = Path(args.output_dir) if args.output_dir else Path("reports") / f"benchmark-{label}"
    output_dir.mkdir(parents=True, exist_ok=False)
    ports, listeners = prepare_local_ports()
    expected = {port: "open" if index < 2 else "closed" for index, port in enumerate(ports)}
    runs = []
    try:
        for round_number in range(1, args.rounds + 1):
            # 轮换先后顺序，减少总是先跑串行所带来的顺序影响。
            modes = (("serial", 1), ("parallel", args.workers))
            if round_number % 2 == 0:
                modes = tuple(reversed(modes))
            for mode, workers in modes:
                print(f"运行第 {round_number} 轮：{mode}，workers={workers}，ports={ports}", flush=True)
                started = perf_counter()
                results = list(iter_scan_results("127.0.0.1", ports, timeout=5.0, workers=workers))
                elapsed = perf_counter() - started
                actual = {result["port"]: result["status"] for result in results}
                if actual != expected or len(results) != len(ports):
                    raise RuntimeError(f"实验状态与自建场景不符，不能使用该次性能结果：{actual}")
                filename = f"round-{round_number}-{mode}.csv"
                write_csv_report(output_dir / filename, "127.0.0.1", results)
                runs.append({
                    "round": round_number, "mode": mode, "workers": workers,
                    "elapsed_seconds": elapsed, "counts": dict(Counter(actual.values())),
                    "csv": filename,
                })
                print(f"耗时 {elapsed:.6f} 秒；open=2，closed=4；CSV={filename}", flush=True)
    finally:
        for listener in listeners:
            listener.close()

    serial_median = median(run["elapsed_seconds"] for run in runs if run["mode"] == "serial")
    parallel_median = median(run["elapsed_seconds"] for run in runs if run["mode"] == "parallel")
    summary = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version.split()[0], "platform": platform.platform(),
        "target": "127.0.0.1", "ports": ports, "timeout_seconds": 5.0,
        "rounds": args.rounds, "runs": runs,
        "serial_median_seconds": serial_median, "parallel_median_seconds": parallel_median,
        "observed_speedup": serial_median / parallel_median,
        "scope": "仅为本机 2 个监听及 4 个明确拒绝端口的观察；不代表其他网络和负载。",
    }
    with (output_dir / "benchmark.json").open("x", encoding="utf-8") as output:
        json.dump(summary, output, ensure_ascii=False, indent=2)
    print(f"串行中位数 {serial_median:.6f} 秒；并发中位数 {parallel_median:.6f} 秒", flush=True)
    print(f"本次观察加速比 {summary['observed_speedup']:.3f}；范围：{summary['scope']}", flush=True)
    print(f"完整记录：{output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
