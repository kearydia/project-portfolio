"""根据端口观察给出基础检查建议，不确认实际服务或漏洞。"""

from validation import validate_port


OPEN_PORT_ADVICE = {
    21: "若确认为 FTP 服务，检查是否传输敏感信息，优先采用加密替代方案并限制访问来源。",
    22: "若确认为 SSH 服务，检查访问来源限制、身份认证、账号权限与服务更新。",
    23: "若确认为 Telnet 服务，检查明文传输需求，优先采用加密替代方案并限制访问来源。",
    80: "若确认为 HTTP 服务，检查敏感数据是否通过 HTTPS 传输，并核对访问控制。",
    443: "若确认为 HTTPS 服务，检查证书、TLS 配置、访问控制与服务更新。",
    445: "若确认为 SMB 服务，限制可信访问来源，检查共享权限与服务更新。",
    3306: "若确认为 MySQL 服务，检查监听地址、访问来源、数据库账号权限与服务更新。",
    3389: "若确认为远程桌面服务，限制访问来源，检查身份认证、账号权限与服务更新。",
    5432: "若确认为 PostgreSQL 服务，检查监听地址、访问来源、数据库账号权限与服务更新。",
    8080: "若确认为 HTTP 服务，检查敏感数据是否通过 HTTPS 传输，并核对访问控制。",
}

NON_OPEN_ADVICE = {
    "closed": "本次连接被明确拒绝；这不证明目标安全，也不证明该端口始终关闭。",
    "timeout": "本次连接等待超时；无法判断是否关闭，请检查网络、访问策略和超时设置。",
    "unknown": "本次状态无法判断；请结合错误原因检查网络、权限或系统环境。",
}


def get_security_advice(port: int, status: str) -> str:
    """返回检查建议；开放端口使用条件语句，其他状态不推断服务或安全性。"""
    validate_port(port)
    if status in NON_OPEN_ADVICE:
        return NON_OPEN_ADVICE[status]
    if status != "open":
        raise ValueError("状态必须为 open、closed、timeout 或 unknown。")
    return OPEN_PORT_ADVICE.get(
        port,
        "端口在本次检测中开放；请确认实际服务身份和业务必要性，检查访问控制与服务更新。",
    )
