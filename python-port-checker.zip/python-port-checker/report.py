"""将已完成的检测结果导出为 CSV；不覆盖已有文件。"""

import csv
from pathlib import Path

from advice import get_security_advice
from services import get_service_hint
from validation import validate_ipv4, validate_port


CSV_FIELDS = (
    "input_target", "target_ip", "port", "status", "possible_service", "advice", "detail",
)


def _build_report_rows(input_target: str, results) -> list:
    """先检查并整理全部数据，避免参数错误时创建一个不完整报告。"""
    if not isinstance(input_target, str) or not input_target.strip():
        raise ValueError("报告的输入目标必须是非空字符串。")
    rows = []
    for result in results:
        address = validate_ipv4(result["target"])
        port = validate_port(result["port"])
        status = result["status"]
        detail = result["detail"]
        if not isinstance(detail, str):
            raise ValueError("报告的 detail 字段必须是字符串。")
        # get_security_advice 同时检查状态，不能把错误状态写进报告。
        advice = get_security_advice(port, status)
        rows.append({
            "input_target": input_target,
            "target_ip": address,
            "port": port,
            "status": status,
            "possible_service": get_service_hint(port),
            "advice": advice,
            "detail": detail,
        })
    return sorted(rows, key=lambda row: row["port"])


def write_csv_report(path, input_target: str, results) -> Path:
    """按端口数值排序写入新 CSV，返回 Path；文件错误原样交给调用方处理。

    使用 utf-8-sig 便于常见表格软件读取中文，newline='' 交给 csv 处理换行。
    x 模式只允许创建新文件，已有报告不会被覆盖。
    """
    rows = _build_report_rows(input_target, results)
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("x", encoding="utf-8-sig", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    return output_path
