# -*- coding: utf-8 -*-
"""零依赖 XLSX 读写（仅用 Python 标准库 zipfile + xml）。
目的：Skill 运行环境不一定装了 openpyxl/pandas，核心功能不能依赖第三方库。"""
import re, zipfile, posixpath
from decimal import Decimal
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}

class CellText(str):
    """保留单元格数值类型和日期纪元，避免经 float 损失长编号。"""
    def __new__(cls, value, numeric=False, date1904=False):
        obj = super().__new__(cls, value)
        obj.numeric, obj.date1904 = numeric, date1904
        return obj

class TableRow(list):
    def __init__(self, values, line):
        super().__init__(values)
        self.line = line

def _col_idx(ref):
    letters = re.match(r'([A-Z]+)', ref).group(1)
    n = 0
    for ch in letters: n = n * 26 + ord(ch) - 64
    return n - 1

def read_xlsx(path):
    """返回第一个工作表的二维列表（全部为字符串）。"""
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        shared = []
        if 'xl/sharedStrings.xml' in names:
            root = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in root.findall('m:si', NS):
                shared.append(''.join(t.text or '' for t in si.iter('{%s}t' % NS['m'])))
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        props = wb.find('m:workbookPr', NS)
        date1904 = props is not None and props.get('date1904') in ('1', 'true')
        first = wb.find('m:sheets/m:sheet', NS)
        if first is None:
            return []
        rid = first.get('{%s}id' % NS['r'])
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = [r.get('Target') for r in rels if r.get('Id') == rid][0].lstrip('/')
        sheet_path = posixpath.normpath(target if target.startswith('xl/') else 'xl/' + target)
        root = ET.fromstring(z.read(sheet_path))
        rows = []
        for row in root.iter('{%s}row' % NS['m']):
            vals = {}
            for c in row.findall('m:c', NS):
                t = c.get('t'); v = c.find('m:v', NS)
                if t == 's' and v is not None: val = shared[int(v.text)]
                elif t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter('{%s}t' % NS['m']))
                else:
                    val = v.text if v is not None and v.text is not None else ''
                    val = CellText(val, numeric=t in (None, 'n') and bool(val), date1904=date1904)
                vals[_col_idx(c.get('r'))] = val
            if vals:
                rows.append(TableRow([vals.get(i, '') for i in range(max(vals) + 1)], int(row.get('r', len(rows) + 1))))
        return rows

def _cell(ref, v, bold=False):
    s = ' s="1"' if bold else ''
    if isinstance(v, (int, float, Decimal)) and not isinstance(v, bool):
        return f'<c r="{ref}"{s}><v>{v}</v></c>'
    return f'<c r="{ref}" t="inlineStr"{s}><is><t xml:space="preserve">{escape(str(v))}</t></is></c>'

def _ref(r, c):
    s = ''; c += 1
    while c: c, m = divmod(c - 1, 26); s = chr(65 + m) + s
    return f'{s}{r + 1}'

def write_xlsx(path, sheets):
    """sheets: [(工作表名, [[行...], ...]), ...]；第一行加粗。"""
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' + ''.join(f'<Override PartName="/xl/worksheets/sheet{i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(len(sheets))) + '</Types>')
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + ''.join(f'<sheet name="{escape(n[:31])}" sheetId="{i+1}" r:id="rId{i+1}"/>' for i, (n, _) in enumerate(sheets)) + '</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + ''.join(f'<Relationship Id="rId{i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i+1}.xml"/>' for i in range(len(sheets))) + f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        z.writestr('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="等线"/></font><font><b/><sz val="11"/><name val="等线"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="2"><xf fontId="0"/><xf fontId="1" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
        for i, (_, rows) in enumerate(sheets):
            body = ''.join(f'<row r="{r+1}">' + ''.join(_cell(_ref(r, c), v, r == 0) for c, v in enumerate(row) if v not in (None, '')) + '</row>' for r, row in enumerate(rows))
            z.writestr(f'xl/worksheets/sheet{i+1}.xml', '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" state="frozen"/></sheetView></sheetViews><sheetData>' + body + '</sheetData></worksheet>')
