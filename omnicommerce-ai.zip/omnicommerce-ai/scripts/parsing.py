# -*- coding: utf-8 -*-
"""无损文本、标识符、有限十进制数和日期解析；只依赖标准库。"""
import re
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

MISSING = {'', '-', '--', 'null', 'none', 'nan', 'n/a', 'na', '未知', '无', '空'}
NUMBER = re.compile(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$')
GROUPED = re.compile(r'^[+-]?\d{1,3}(?:,\d{3})+(?:\.\d+)?$')
SCIENTIFIC = re.compile(r'^[+-]?(?:\d+(?:\.\d*)?|\.\d+)[eE][+-]?\d+$')


def clean(value):
    return str(value if value is not None else '').strip().lstrip('\ufeff').strip()


def missing(value):
    return clean(value).casefold() in MISSING


def number(value):
    """非法/缺失值返回 None；不把 NaN、Infinity 或格式错误当作零。"""
    s = clean(value)
    if missing(s):
        return None
    negative = s.startswith('(') and s.endswith(')')
    if negative:
        s = s[1:-1].strip()
    s = re.sub(r'^(?:人民币|RMB|CNY|[¥￥$])\s*', '', s, flags=re.I)
    s = re.sub(r'\s*元$', '', s)
    if negative and s.startswith(('+', '-')):
        return None
    if ',' in s:
        if not GROUPED.fullmatch(s):
            return None
        s = s.replace(',', '')
    if not (NUMBER.fullmatch(s) or SCIENTIFIC.fullmatch(s)):
        return None
    try:
        d = Decimal(s)
        # 业务输入限定有效位/数量级，防止极端值破坏 Decimal 精确汇总。
        if not d.is_finite() or len(d.as_tuple().digits) > 28 or abs(d.adjusted()) > 20:
            return None
        return -d if negative else d
    except InvalidOperation:
        return None


def identifier(value):
    """返回 (文本标识, 风险说明)。仅展开已存储值，不声称恢复 Excel 丢失位。"""
    s = clean(value)
    if missing(s):
        return '', ''
    numeric_cell = getattr(value, 'numeric', False)
    scientific = bool(SCIENTIFIC.fullmatch(s))
    numeric_form = scientific or bool(re.fullmatch(r'\d+\.0+', s))
    risk = ''
    if numeric_form:
        try:
            d = Decimal(s)
            if d != d.to_integral_value() or d < 0 or abs(d.adjusted()) > 100:
                return s, '标识符不是可用的非负整数，请重新导出文本标识'
            # 普通文本的前导零必须保留；科学计数法只能展开现存数值。
            s = s.split('.')[0] if not scientific else format(d.quantize(Decimal('1')) if d.adjusted() < 28 else d, 'f').split('.')[0]
        except InvalidOperation:
            return s, '标识符无法无损解析，请重新导出文本标识'
    if scientific or (numeric_cell and s.isdigit() and len(s) >= 16):
        risk = '科学计数法或 Excel 数值型长标识可能已丢失精度；仅展开存储值，不能恢复原编号，请重新导出文本/原始 CSV'
    return s, risk


def timestamp(value):
    """Excel 序列（含小数日）及常见时间文本 → YYYY-MM-DD HH:MM:SS。"""
    s = clean(value)
    if missing(s):
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y/%m/%d %H:%M:%S',
                '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M',
                '%Y-%m-%d', '%Y/%m/%d', '%Y%m%d', '%Y-%m-%dT%H:%M:%S'):
        try:
            return datetime.strptime(s, fmt).strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            pass
    if NUMBER.fullmatch(s):
        try:
            serial = Decimal(s)
            if 0 <= serial < 2958466:
                epoch = datetime(1904, 1, 1) if getattr(value, 'date1904', False) else datetime(1899, 12, 30)
                seconds = int((serial * 86400).to_integral_value(rounding=ROUND_HALF_UP))
                return (epoch + timedelta(seconds=seconds)).strftime('%Y-%m-%d %H:%M:%S')
        except (InvalidOperation, OverflowError):
            pass
    return None
