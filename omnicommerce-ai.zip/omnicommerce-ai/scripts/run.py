# -*- coding: utf-8 -*-
"""OmniCommerce 入口（只读分析，不修改原始文件；仅需 Python 3.8+ 标准库）
用法：
  python scripts/run.py --input <订单/库存文件夹> --output <输出文件夹>
  python scripts/run.py --demo   # 用 examples/ 演示数据跑一遍并自检标准答案
"""
import argparse, os, sys, json
sys.dont_write_bytecode = True
from decimal import Decimal
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import engine, report

GOLDEN = {'订单金额': Decimal('1933.60'), '实际支付金额': Decimal('1827.80'), '已完成退款金额': Decimal('145.00'),
          '支付净额': Decimal('1682.80'), '有效订单数': 13}

def _safe_console():
    # Windows 中文控制台（GBK）或被管道重定向时，遇到无法编码的字符用 ? 代替，避免整个分析因打印失败而中断
    for stream in (sys.stdout, sys.stderr):
        try: stream.reconfigure(errors='replace')
        except (AttributeError, ValueError): pass

def main():
    _safe_console()
    ap = argparse.ArgumentParser()
    ap.add_argument('--input'); ap.add_argument('--output', default='omnicommerce_output')
    ap.add_argument('--demo', action='store_true', help='使用 examples/ 演示数据并校验标准答案')
    a = ap.parse_args()
    if a.demo: a.input = os.path.join(HERE, '..', 'examples')
    if not a.input or not os.path.isdir(a.input):
        print('错误：请用 --input 指定包含订单/库存表的文件夹', file=sys.stderr); sys.exit(2)
    source, target = os.path.realpath(a.input), os.path.realpath(a.output)
    examples = os.path.realpath(os.path.join(HERE, '..', 'examples'))
    def within(path, parent):
        try:
            return os.path.commonpath([os.path.normcase(path), os.path.normcase(parent)]) == os.path.normcase(parent)
        except ValueError:
            return False
    if within(target, source) or within(target, examples):
        print('错误：输出目录必须在输入目录和 examples 之外，避免修改原始文件或再次读入报告', file=sys.stderr); sys.exit(2)
    os.makedirs(a.output, exist_ok=True)
    res = engine.run(a.input)
    summary = report.summary(res)
    if a.demo:
        bad = {k: (str(res['metrics'][k]), str(v)) for k, v in GOLDEN.items() if res['metrics'][k] != v}
        summary['自检'] = '通过：5 项金额/订单数与人工标准答案一致' if not bad else f'失败：{bad}'
    report.excel(res, os.path.join(a.output, report.OUTPUTS[0]), summary)
    report.dashboard(res, os.path.join(a.output, report.OUTPUTS[1]), summary)
    with open(os.path.join(a.output, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str, allow_nan=False)
    print('演示数据，非真实经营数据' if summary['演示数据'] else '分析完成')
    print('一句话结论：' + summary['一句话结论'])
    print(summary['数量核对'])
    print('；'.join(k + '：' + v for k, v in summary['指标'].items()))
    for action in summary['行动建议']:
        print(str(action['优先级']) + '. ' + action['主题'] + '：' + action['依据'] + ' ' + action['建议'])
    print('输出目录：' + os.path.abspath(a.output))
    print('Excel：' + report.OUTPUTS[0] + '（8个工作表）；HTML：' + report.OUTPUTS[1] + '（浏览器打开，点击指标溯源）；完整摘要：summary.json')
    if a.demo:
        print('自检：' + summary['自检'])
    if a.demo and bad: sys.exit(1)
    if not res['orders']:
        print('错误：没有识别到任何订单表，请查看 summary.json 中的字段识别问题和未处理文件', file=sys.stderr); sys.exit(3)

if __name__ == '__main__':
    main()
