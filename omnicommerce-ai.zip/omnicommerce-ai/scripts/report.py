# -*- coding: utf-8 -*-
"""三个报告共享同一摘要、数量核对、异常和行动建议；金额不经过 float。"""
import json
import os
from decimal import Decimal
from xlsx_io import write_xlsx

OUTPUTS = ['运营分析工作簿.xlsx', '经营仪表盘.html', 'summary.json']


def _v(value):
    if isinstance(value, bool):
        return '是' if value else ''
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, default=str)
    return value


def _rows(rows, cols=None):
    if not rows:
        return [['（无）']]
    cols = cols or list(dict.fromkeys(k for r in rows for k in r))
    return [cols] + [[_v(r.get(c, '')) for c in cols] for r in rows]


def metric_text(value):
    if isinstance(value, Decimal):
        return format(value, '.%df' % max(2, -value.as_tuple().exponent))
    return str(value)


def action_items(res):
    metrics, counts = res['metrics'], res['counts']
    pending = [m for m in res['match'] if 80 <= m['分数'] < 100 and not m['冲突']]
    blocked = [m for m in res['match'] if m['冲突']]
    low = [m for m in res['match'] if m['分数'] < 80 and not m['冲突']]
    urgent = [a for a in res['alerts'] if a['风险'] in ('超卖风险', '库存不足', '库存数据异常')]
    return [
        dict(优先级=1, 主题='先处理异常与库存风险',
             建议='核查隔离订单和库存预警的来源，修正源系统后重新导出；有超卖风险时核对待发货量并调整平台库存。',
             依据=f'有效订单 {metrics["有效订单数"]} 个，支付净额 {metric_text(metrics["支付净额"])} 元；隔离 {counts["隔离行数"]} 行；紧急库存预警 {len(urgent)} 条。',
             相关SKU=sorted({a['内部SKU'] for a in urgent})),
        dict(优先级=2, 主题='确认 SKU 与字段映射',
             建议='仅对无冲突且分数≥80的候选逐条确认/拒绝；冲突项禁止合并，低分项补充标识。字段不明时先确认列含义，再提供自定义映射重跑。',
             依据=f'待确认 SKU {len(pending)} 项，属性冲突 {len(blocked)} 项，低分/无档案 {len(low)} 项，字段识别问题 {len(res["field_issues"])} 个文件。',
             相关SKU=sorted({m['内部SKU'] for m in pending if m['内部SKU']})),
        dict(优先级=3, 主题='补全数据并复核日报',
             建议='根据异常清单补齐时间和文本编号；精度已丢失的编号需从源系统重新导出。重跑后核对四口径金额和数量等式，再交付日报。',
             依据=f'读取 {counts["读取行数"]} = 保留 {counts["保留行数"]} + 重复 {counts["重复行数"]}；保留 = 非隔离 {counts["参与统计行数"]} + 隔离 {counts["隔离行数"]}；未处理文件 {len(res["errors"])} 个。',
             相关SKU=[]),
    ]


def one_line(res):
    m, c = res['metrics'], res['counts']
    plats = sorted({r['平台'] for r in res['all_rows']})
    risky = sorted({a['内部SKU'] for a in res['alerts'] if a['风险'] in ('超卖风险', '库存不足', '库存数据异常')})
    pending = [x for x in res['match'] if 80 <= x['分数'] < 100 and not x['冲突']]
    blocked = [x for x in res['match'] if x['冲突']]
    return (f"{len(plats)} 个平台共 {m['有效订单数']} 单有效订单，支付净额 {metric_text(m['支付净额'])} 元；"
            f"{c['隔离行数']} 行异常记录已隔离，数据风险：{res['quality']['风险等级']}；"
            f"{len(risky)} 个 SKU 有缺货/超卖/库存数据风险；{len(pending)} 个商品待人工确认，{len(blocked)} 个因属性冲突禁止合并。")


def summary(res):
    return dict(
        一句话结论=one_line(res),
        版本='2.1', 演示数据=any('模拟' in f for f in res['files']),
        数据状态='部分数据待修正，请结合异常和未处理文件解读' if res['anomalies'] or res['errors'] else '已完成分析',
        数量核对=next((l for l in res['log'] if l.startswith('数量核对')), ''), 数量统计=res['counts'],
        指标={k: metric_text(v) for k, v in res['metrics'].items()}, 数据质量=res['quality'],
        库存预警=res['alerts'], 库存分析=res['inventory'],
        待人工确认SKU=[m for m in res['match'] if 80 <= m['分数'] < 100 and not m['冲突']],
        禁止合并SKU=[m for m in res['match'] if m['冲突']],
        低分或未匹配SKU=[m for m in res['match'] if m['分数'] < 80 and not m['冲突']],
        SKU匹配建议=res['match'], 行动建议=action_items(res),
        异常数=len(res['anomalies']), 异常清单=res['anomalies'],
        精度风险提示=[a for a in res['anomalies'] if a['类型'] == '标识符精度风险'],
        文件识别结果=res['recognition'], 字段识别问题=res['field_issues'],
        自定义字段映射文件='字段映射_自定义.json', 未处理文件=res['errors'], 处理记录=res['log'],
        指标溯源=res['trace'], 未计入记录=res['excluded'], 订单明细=res['all_rows'], 输出文件=OUTPUTS)


def excel(res, path, data=None):
    data = data or summary(res)
    notes = {'订单金额': '非隔离、未取消订单的应付金额合计', '实际支付金额': '非隔离且待发货/已发货/已完成订单的实付合计',
             '已完成退款金额': '仅已支付订单中的已完成退款；退款中不提前扣除',
             '支付净额': '实际支付金额 − 已完成退款金额（经营指标，非会计收入/利润）', '有效订单数': '非隔离的已支付主订单去重数'}
    ov = [['指标', '数值', '口径说明'], ['一句话结论', data['一句话结论'], '数字全部来自脚本计算']]
    if data['演示数据']:
        ov.append(['提示', '演示数据', '模拟样本，不代表真实经营情况'])
    ov += [[k, v, notes.get(k, '')] for k, v in res['metrics'].items()]
    ov += [[k, v, '保留行包含隔离行；非隔离不等于已支付'] for k, v in res['counts'].items()]
    q = res['quality']
    ov.append(['数据质量综合分', q['综合分'], q['风险等级'] + ' ' + q['说明']])
    ov += [[k, v, ''] for k, v in q['分项'].items()]
    ov += [['行动优先级 ' + str(a['优先级']), a['主题'], a['建议'] + ' ' + a['依据']] for a in data['行动建议']]
    ov += [['未处理文件', '', e] for e in res['errors']]
    ov += [['字段识别问题', p['文件'], _v(p)] for p in res['field_issues']]
    if '自检' in data:
        ov.append(['自检', data['自检'], ''])
    cols = ['来源', '平台', '订单号', '子订单号', '平台商品标识', '商家编码', '内部SKU', 'SKU匹配状态',
            '商品名称', '规格', '数量', '订单金额', '实付金额', '退款金额', '原始状态', '标准状态', '售后状态',
            '原始下单时间', '下单时间', '日期', '异常', '隔离', '重复', '去重说明']
    cols += sorted({k for r in res['all_rows'] for k in r if k.startswith('脱敏_')})
    trace = [dict(指标=k, 来源=s, 金额=a) for k, rows in res['trace'].items() for s, a in rows]
    trace += [dict(指标='（未计入）', 来源=s, 金额=why) for s, why in res['excluded']]
    logs = [dict(步骤=i + 1, 记录=l) for i, l in enumerate(res['log'])]
    logs += [dict(步骤='文件识别', 记录=_v(r)) for r in res['recognition']]
    write_xlsx(path, [('经营概览', ov), ('统一订单明细', _rows(res['all_rows'], cols)),
                      ('异常清单', _rows(res['anomalies'])), ('SKU匹配建议', _rows(res['match'])),
                      ('库存分析', _rows(res['inventory'])), ('库存预警', _rows(res['alerts'])),
                      ('指标溯源', _rows(trace)), ('处理记录', _rows(logs))])


def dashboard(res, path, data=None):
    data = data or summary(res)
    with open(os.path.join(os.path.dirname(__file__), '..', 'assets', 'dashboard_template.html'), encoding='utf-8') as f:
        template = f.read()
    # 阻止 </script> 提前终止脚本和 HTML 实体注入；DOM 再用 textContent。
    payload = json.dumps(data, ensure_ascii=False, default=str, allow_nan=False)
    for char, replacement in (('&', '\\u0026'), ('<', '\\u003c'), ('>', '\\u003e'), ('\u2028', '\\u2028'), ('\u2029', '\\u2029')):
        payload = payload.replace(char, replacement)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(template.replace('/*__DATA__*/null', payload))
