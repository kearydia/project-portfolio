# -*- coding: utf-8 -*-
"""OmniCommerce AI —— 确定性数据计算引擎（比赛首版 MVP）
原则：金额/订单/库存全部由本程序计算（Decimal），AI 只负责理解需求、解释结果、给建议。
"""
import csv, json, os, re, difflib, zipfile
from datetime import datetime
from decimal import Decimal, localcontext
from collections import defaultdict
from xml.etree.ElementTree import ParseError
from parsing import clean, missing, number, identifier, timestamp
from xlsx_io import CellText, TableRow

HERE = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(HERE, '..', 'references', 'platform_mapping.json'), encoding='utf-8') as _f:
    MAPPING = json.load(_f)
PAID_STATUSES = {'待发货', '已发货', '已完成'}
CUSTOM_MAPPING = '字段映射_自定义.json'

class Record(dict):
    """数据行保留原始行号（不把元数据伪装成用户表头）。"""
    def __init__(self, values, line):
        super().__init__(values)
        self.line = line

# ---------------- 1. 文件读取与识别 ----------------
def read_table(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.csv':
        for enc in ('utf-8-sig', 'gb18030'):
            try:
                with open(path, encoding=enc, newline='') as f:
                    reader = csv.reader(f)
                    rows = []
                    while True:
                        line = reader.line_num + 1
                        try:
                            rows.append(TableRow(next(reader), line))
                        except StopIteration:
                            break
                break
            except UnicodeDecodeError:
                continue
        else:
            raise ValueError(f'无法识别编码: {path}')
    elif ext == '.xlsx':
        from xlsx_io import read_xlsx
        rows = read_xlsx(path)
    elif ext == '.xls':
        raise ValueError(f'{os.path.basename(path)} 是旧版 .xls：请在 Excel/WPS 中另存为 .xlsx 或 .csv 后重新上传')
    elif ext == '.zip':
        raise ValueError(f'{os.path.basename(path)} 是压缩包：抖店/京东导出的报表通常是加密 ZIP，请先用短信密码解压，再上传里面的 CSV/XLSX')
    else:
        raise ValueError(f'不支持的文件格式: {ext}（支持 XLSX/CSV）')
    rows = [r for r in rows if any(str(c).strip() for c in r)]
    if not rows:
        raise ValueError('空表：没有表头或数据')
    header = [clean(h) for h in rows[0]]
    nonempty = [h for h in header if h]
    if len(nonempty) != len(set(nonempty)):
        raise ValueError('存在重复表头，无法确定字段来源，请修正后重试')
    out = []
    for i, row in enumerate(rows[1:], 2):
        if any(clean(c) for c in row[len(header):]):
            raise ValueError('数据列超出表头，请检查 CSV 分隔符或表头')
        vals = [CellText(clean(c), c.numeric, c.date1904) if isinstance(c, CellText) else clean(c) for c in row]
        out.append(Record({h: vals[j] if j < len(vals) else '' for j, h in enumerate(header) if h}, getattr(row, 'line', i)))
    return header, out

def detect_file(name, header):
    hs = set(header)
    if {'实际库存', '安全库存'} <= hs: return ('仓库库存', None, 1.0)
    if '平台可售库存' in hs: return ('平台库存', None, 1.0)
    if {'内部SKU', '条码'} <= hs: return ('商品档案', None, 1.0)
    if '平台商品标识' in hs: return ('SKU映射', None, 1.0)
    best, score = None, 0.0
    for plat, sig in MAPPING['platform_signatures'].items():
        s = sum(1 for k in sig if k in hs) / len(sig)
        if s > score: best, score = plat, s
    for plat in MAPPING['platform_signatures']:  # 文件名提示
        if plat[:2] in name: best, score = plat, max(score, 0.9)
    return ('订单', best if score >= 0.6 else '通用导入', score)

# ---------------- 2. 字段映射与标准化 ----------------
def field_map(header, overrides=None):
    m = {}
    for canon, aliases in MAPPING['canonical_fields'].items():
        for a in aliases:
            if a in header: m[canon] = a; break
    m.update(overrides or {})
    return m

def to_dec(v):
    return number(v)

def std_status(s):
    s = clean(s)
    for k, vs in MAPPING['status_map'].items():
        if s in vs: return k
    return None

def mask(kind, v):
    if not v: return v
    if kind == 'receiver_phone': return re.sub(r'(\d{3})\d{4}(\d{4})', r'\1****\2', v)
    if kind == 'receiver_name': return v[0] + '*' * (len(v) - 1)
    if kind == 'receiver_address': return v[:6] + '****'
    return v

def normalize_orders(fname, platform, header, rows, log, anomalies, overrides=None):
    fm = field_map(header, overrides)
    log.append(f'[{fname}] 识别为 {platform} 订单表，字段映射：' + '，'.join(f'{k}←{v}' for k, v in fm.items()))
    missing_fields = [k for k in ('order_id', 'qty', 'order_amount', 'paid_amount', 'status') if k not in fm]
    if missing_fields:
        anomalies.append(dict(级别='严重', 文件=fname, 行='-', 类型='缺少必需字段', 说明=','.join(missing_fields)))
    out = []
    for i, r in enumerate(rows, start=2):
        i = getattr(r, 'line', i)
        g = lambda k: r.get(fm[k], '') if k in fm else ''
        issues, ids = [], {}
        for key, label in (('order_id', '订单号'), ('sub_order_id', '子订单号'), ('platform_sku', '平台商品标识'), ('seller_code', '商家编码')):
            ids[label], risk = identifier(g(key))
            if risk:
                issues.append(('严重', '标识符精度风险', label + '：' + risk))
        # 空主订单号不进入去重分组，防止多行缺失被吞并。
        if not ids['订单号']:
            issues.append(('严重', '订单号缺失', '请补充文本格式的订单号'))
        ids['子订单号'] = ids['子订单号'] or ids['订单号']
        rec = dict(来源=f'{fname}#第{i}行', 平台=platform, **ids,
                   商品名称=g('product_name'), 规格=g('spec'),
                   原始状态=g('status'), 售后状态='' if missing(g('refund_status')) else clean(g('refund_status')),
                   原始下单时间=str(g('order_time')), 下单时间=timestamp(g('order_time')))
        for k in ('receiver_name', 'receiver_phone', 'receiver_address'):
            if k in fm: rec['脱敏_' + k] = mask(k, g(k))
        rec['数量'] = to_dec(g('qty')); rec['订单金额'] = to_dec(g('order_amount'))
        rec['实付金额'] = to_dec(g('paid_amount'))
        # 仅无售后的空退款值默认零，非法文本绝不吞掉。
        rec['退款金额'] = Decimal('0') if missing(g('refund_amount')) and not rec['售后状态'] else to_dec(g('refund_amount'))
        rec['标准状态'] = std_status(rec['原始状态'])
        if missing_fields:
            issues.append(('严重', '缺少必需字段', ','.join(missing_fields)))
        if rec['标准状态'] is None: issues.append(('一般', '订单状态无法识别', rec['原始状态']))
        for k, source in (('数量', 'qty'), ('订单金额', 'order_amount'), ('实付金额', 'paid_amount'), ('退款金额', 'refund_amount')):
            if rec[k] is None:
                issues.append(('严重', f'{k}无法解析', g(source)))
            elif rec[k] < 0:
                issues.append(('严重', f'{k}为负数', str(rec[k])))
        if rec['数量'] is not None and (rec['数量'] <= 0 or rec['数量'] != rec['数量'].to_integral_value()):
            issues.append(('严重', '数量必须为正整数', str(rec['数量'])))
        if rec['实付金额'] is not None and rec['订单金额'] is not None and rec['实付金额'] > rec['订单金额']:
            issues.append(('严重', '实付金额大于订单金额', ''))
        if rec['实付金额'] is not None and rec['退款金额'] is not None and rec['退款金额'] > rec['实付金额']:
            issues.append(('严重', '退款金额大于实付金额', ''))
        if rec['售后状态'] and rec['售后状态'] not in MAPPING['refund_success'] + MAPPING['refund_pending']:
            issues.append(('一般', '售后状态无法识别', rec['售后状态']))
        rec['日期'] = rec['下单时间'][:10] if rec['下单时间'] else None
        if not rec['日期']:
            issues.append(('一般', '下单时间缺失或格式错误', rec['原始下单时间']))
        rec['异常'] = '；'.join(t for _, t, _ in issues)
        rec['隔离'] = any(lv == '严重' for lv, _, _ in issues)
        for lv, t, d in issues:
            anomalies.append(dict(级别=lv, 文件=fname, 行=i, 类型=t, 说明=d))
        out.append(rec)
    return out

def deduplicate(orders, anomalies):
    groups, out, dup = {}, [], 0
    signature_fields = ('数量', '订单金额', '实付金额', '退款金额', '标准状态', '原始状态',
                        '售后状态', '平台商品标识', '商家编码', '商品名称', '规格', '下单时间', '隔离')
    status_rank = {'已完成': 5, '已发货': 4, '待发货': 3, '已取消': 2, '待付款': 1}
    def rank(r):
        refund = 2 if r['售后状态'] in MAPPING['refund_success'] else 1 if r['售后状态'] in MAPPING['refund_pending'] else 0
        complete = sum(r.get(k) not in (None, '') for k in signature_fields)
        return (not r['隔离'], refund, status_rank.get(r['标准状态'], 0), r['下单时间'] or '', complete)
    for r in orders:
        r['重复'] = False
        r['去重说明'] = ''
        key = (r['平台'], r['订单号'], r['子订单号'])
        if not r['订单号'] or '标识符精度风险' in r['异常']:
            key = ('不可合并', r['来源'])
        groups.setdefault(key, []).append(r)
    for group in groups.values():
        winner = max(group, key=rank)  # 同优先级保持文件名/行号顺序的第一条
        out.append(winner)
        for r in group:
            if r is winner:
                continue
            dup += 1
            same = all(r.get(k) == winner.get(k) for k in signature_fields)
            reason = ('内容完全相同' if same else '有效记录 > 售后进度 > 订单状态 > 下单时间 > 字段完整度')
            r['重复'] = True
            r['去重说明'] = f'保留 {winner["来源"]}；排除 {r["来源"]}；依据：{reason}；同优先级保留先读行'
            anomalies.append(dict(级别='提示' if same else '严重', 文件=r['来源'].rsplit('#', 1)[0], 行=r['来源'].rsplit('#', 1)[1],
                                   类型='重复订单行' if same else '同一子订单内容冲突', 说明=r['去重说明']))
    return out, dup

# ---------------- 3. 销售统计（四口径，带溯源） ----------------
def sales_metrics(orders):
    m = {k: Decimal('0') for k in ('订单金额', '实际支付金额', '已完成退款金额', '支付净额')}
    trace = defaultdict(list); excluded = []
    for r in orders:
        if r['隔离']:
            excluded.append((r['来源'], '严重异常已隔离，不参与任何金额计算')); continue
        if r['标准状态'] != '已取消' and r['订单金额'] is not None:
            m['订单金额'] += r['订单金额']; trace['订单金额'].append((r['来源'], str(r['订单金额'])))
        if r['标准状态'] in PAID_STATUSES:
            m['实际支付金额'] += r['实付金额']; trace['实际支付金额'].append((r['来源'], str(r['实付金额'])))
            if r['售后状态'] in MAPPING['refund_success'] and r['退款金额'] > 0:
                m['已完成退款金额'] += r['退款金额']; trace['已完成退款金额'].append((r['来源'], str(r['退款金额'])))
            elif r['售后状态'] in MAPPING['refund_pending']:
                excluded.append((r['来源'], f'退款处理中（{r["退款金额"]}元）暂不扣除'))
        else:
            excluded.append((r['来源'], f'状态为{r["标准状态"] or "未识别"}，不计入实际支付'))
    m['支付净额'] = m['实际支付金额'] - m['已完成退款金额']
    trace['支付净额'] = [(r['来源'], str(r['实付金额'] - (r['退款金额'] if r['售后状态'] in MAPPING['refund_success'] else Decimal('0'))))
                       for r in orders if not r['隔离'] and r['标准状态'] in PAID_STATUSES]
    m['有效订单数'] = len({(r['平台'], r['订单号']) for r in orders if not r['隔离'] and r['标准状态'] in PAID_STATUSES})
    seen = set()
    for r in orders:
        key = (r['平台'], r['订单号'])
        if not r['隔离'] and r['标准状态'] in PAID_STATUSES and key not in seen:
            trace['有效订单数'].append((r['来源'], '1'))
            seen.add(key)
    return m, trace, excluded

# ---------------- 4. SKU 匹配（四层算法 + 冲突拦截 + 人工确认） ----------------
COLORS = ['奶白', '雾蓝', '黑', '白', '灰', '红', '蓝', '粉', '绿']
def attrs(text):
    t = text or ''
    a = {}
    c = [x for x in COLORS if x in t]
    if c: a['颜色'] = max(c, key=len)
    v = re.search(r'(\d+)\s*(ml|ML|毫升|L)', t);  a['容量'] = v.group(1) + 'ml' if v else None
    s = re.search(r'(\d+)\s*寸', t);  a['尺寸'] = s.group(1) + '寸' if s else None
    p = re.search(r'(\d+)\s*双装', t);  a['套装数'] = p.group(1) + '双装' if p else None
    a['礼盒'] = '礼盒装' if '礼盒' in t else None
    return {k: v for k, v in a.items() if v not in (None, False)}

def match_one(item, master, confirmed):
    plat, pid, code = item['平台'], item['平台商品标识'], item['商家编码']
    for key in ((plat, pid), (plat, f"{item['商品名称']}|{item['规格']}"), (plat, item['商品名称'])):
        if key[1] and key[1] != '|' and key in confirmed:   # 无平台商品ID时，可用“商品名称|规格”确认
            return dict(内部SKU=confirmed[key], 分数=100, 结论='已确认映射（复用历史人工确认）', 冲突='')
    for m in master:
        if code and code in (m['内部SKU'], m['条码']):
            return dict(内部SKU=m['内部SKU'], 分数=100, 结论='标识精确匹配（商家编码/条码）', 冲突='')
    text = f"{item['商品名称']} {item['规格']}"; ia = attrs(text)
    best = None
    for m in master:
        mt = f"{m['商品名称']} {m['品牌']} {m['型号']}"; ma = attrs(mt + ' ' + m['颜色'] + ' ' + m['规格'])
        conflicts = [f'{k}:{ia[k]}≠{ma.get(k, "无")}' for k in ia if k in ('颜色', '容量', '尺寸', '套装数', '礼盒') and ia.get(k) != ma.get(k)]
        sim = difflib.SequenceMatcher(None, re.sub(r'\s', '', item['商品名称']), re.sub(r'\s', '', m['商品名称'])).ratio()
        brand = 15 if m['品牌'] and m['品牌'] in text else 0
        agree = sum(1 for k in ia if ma.get(k) == ia[k])
        score = round(min(99, sim * 60 + brand + agree * 10 + (10 if not conflicts else 0)))
        cand = dict(内部SKU=m['内部SKU'], 分数=score, 冲突='；'.join(conflicts))
        if best is None or (not cand['冲突'], cand['分数']) > (not best['冲突'], best['分数']): best = cand
    if best is None:
        return dict(内部SKU='', 分数=0, 结论='缺少商品档案，无法匹配', 冲突='')
    if best['冲突']:
        best['结论'] = '关键属性冲突，禁止合并'; best['分数'] = min(best['分数'], 79)
    elif best['分数'] >= 95: best['结论'] = '高匹配候选，待人工确认'
    elif best['分数'] >= 80: best['结论'] = '中等匹配，需人工审核'
    else: best['结论'] = '低于80分，不主动推荐'
    return best

def match_skus(orders, master, confirmed):
    res, cache = [], {}
    for r in orders:
        k = (r['平台'], r['平台商品标识'], r['商家编码'], r['商品名称'], r['规格'])
        if k not in cache:
            cache[k] = match_one(r, master, confirmed)
            res.append(dict(平台=r['平台'], 平台商品标识=r['平台商品标识'], 商家编码=r['商家编码'],
                            商品名称=r['商品名称'], 规格=r['规格'], **cache[k]))
        mm = cache[k]
        r['内部SKU'] = mm['内部SKU'] if mm['分数'] == 100 else ''   # 只有已确认/标识精确的才参与联动
        r['SKU匹配状态'] = mm['结论']
    return res

# ---------------- 5. 库存（三层模型 + 五类风险） ----------------
def inventory(orders, stock_rows, platform_stock, anomalies, days_threshold=7):
    reserved, sold = defaultdict(Decimal), defaultdict(Decimal)
    dates = sorted({r['日期'] for r in orders if r['日期'] and not r['隔离'] and r['标准状态'] in PAID_STATUSES})
    span = (datetime.fromisoformat(dates[-1]) - datetime.fromisoformat(dates[0])).days + 1 if dates else 0
    for r in orders:
        if r['隔离'] or not r['内部SKU']: continue
        if r['标准状态'] == '待发货': reserved[r['内部SKU']] += r['数量']
        if r['标准状态'] in PAID_STATUSES: sold[r['内部SKU']] += r['数量']
    table, alerts = [], []
    for s in stock_rows:
        sku = s['内部SKU']; phys, frz, safe = (to_dec(s.get(k, '')) for k in ('实际库存', '冻结库存', '安全库存'))
        row = dict(内部SKU=sku, 实际库存=phys, 已占用库存=reserved[sku], 冻结库存=frz, 安全库存=safe)
        invalid = [k for k, v in (('实际库存', phys), ('冻结库存', frz), ('安全库存', safe))
                   if v is None or v < 0 or v != v.to_integral_value()]
        if invalid:
            why = '、'.join(invalid) + '缺失、非法、负数或非整数，该SKU其余库存指标不计算'
            alerts.append(dict(内部SKU=sku, 风险='库存数据异常', 依据=why))
            anomalies.append(dict(级别='严重', 文件=s.get('来源', '仓库库存'), 行='-', 类型='库存数据异常', 说明=sku + '：' + why))
            row.update(可用库存=None, 安全库存后可售=None, 预计可售天数=None); table.append(row); continue
        avail = phys - reserved[sku] - frz; sellable = max(Decimal('0'), avail - safe)
        row.update(可用库存=avail, 安全库存后可售=sellable)
        if span >= 3 and sold[sku] > 0:
            daily = sold[sku] / Decimal(span); row['预计可售天数'] = (avail / daily).quantize(Decimal('0.1')) if avail > 0 else Decimal('0')
        else:
            row['预计可售天数'] = None
        if reserved[sku] > phys - frz:
            alerts.append(dict(内部SKU=sku, 风险='超卖风险', 依据=f'待发货占用{reserved[sku]} > 实物可用{phys - frz}'))
        if avail < safe:
            alerts.append(dict(内部SKU=sku, 风险='库存不足', 依据=f'可用库存{avail} < 安全库存{safe}'))
        if row['预计可售天数'] is not None and row['预计可售天数'] < days_threshold:
            alerts.append(dict(内部SKU=sku, 风险='即将售罄', 依据=f'按近{span}天日均销量估算仅可售{row["预计可售天数"]}天'))
        elif row['预计可售天数'] is None and sold[sku] > 0:
            row['预计可售天数'] = '历史数据不足，不估算'
        for p in platform_stock:
            if p['商家编码'] == sku:
                ps = to_dec(p['平台可售库存'])
                if ps is not None and ps > sellable:
                    alerts.append(dict(内部SKU=sku, 风险='平台库存不一致', 依据=f'{p["平台"]}展示可售{ps} > 仓库安全可售{sellable}（存在超卖隐患，建议下调）'))
        table.append(row)
    return table, alerts, span

# ---------------- 6. 数据质量评分（五维 + 风险等级） ----------------
def quality(all_rows, kept, dup, match_res, anomalies):
    n = max(1, len(all_rows))
    req = ('订单号', '数量', '实付金额', '标准状态', '日期')
    miss = sum(1 for r in all_rows for k in req if r.get(k) in (None, ''))
    severe = [a for a in anomalies if a['级别'] == '严重']
    amount_err = [a for a in severe if '金额' in a['类型']]
    # 同一来源行的多个派生错误只扣一次，避免一个负实付同时触发多项校验重复扣分。
    def affected(predicate):
        return len({(a['文件'], str(a['行'])) for a in anomalies if predicate(a)})
    sc = {
        '完整性': round(100 * (1 - miss / (n * len(req)))),
        '准确性': round(100 * (1 - affected(lambda a: '金额' in a['类型']) / n)),
        '一致性': round(100 * (1 - affected(lambda a: '状态' in a['类型'] or '时间' in a['类型']) / n)),
        '唯一性': round(100 * (1 - dup / n)),
        'SKU匹配质量': round(100 * sum(1 for m in match_res if m['分数'] == 100) / max(1, len(match_res))),
    }
    sc = {k: max(0, min(100, v)) for k, v in sc.items()}
    overall = round(sum(sc.values()) / len(sc))
    level = '高风险' if amount_err else ('中风险' if severe or overall < 85 else '低风险')
    note = '存在严重金额错误：相关记录已隔离，不被其他维度的高分抵消' if amount_err else ''
    return dict(分项=sc, 综合分=overall, 风险等级=level, 说明=note)

# ---------------- 主流程 ----------------
SHAREABLE = {'order_amount', 'paid_amount'}   # 平台只有一列金额时，可同时作为应付和实付

def _dup_columns(mapping, explicit=None):
    """同一原始列被多个标准字段使用 → 配置错误；唯一例外：用户在自定义映射里
    同时、显式地把 order_amount 和 paid_amount 指向同一列（平台只导出一列金额）。"""
    explicit = mapping if explicit is None else explicit
    seen = defaultdict(set)
    for k, v in mapping.items(): seen[v].add(k)
    return any(len(ks) > 1 and not (ks <= SHAREABLE and all(explicit.get(k) == v for k in ks))
               for v, ks in seen.items())

def load_overrides(input_dir, errors):
    path = os.path.join(input_dir, CUSTOM_MAPPING)
    if not os.path.isfile(path):
        return {}, False
    try:
        with open(path, encoding='utf-8-sig') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError('顶层必须为文件名对象')
        for name, mapping in data.items():
            if not isinstance(name, str) or os.path.basename(name) != name or not os.path.isfile(os.path.join(input_dir, name)):
                raise ValueError('文件名不存在或不是输入目录内的文件：' + str(name))
            if not isinstance(mapping, dict) or not mapping:
                raise ValueError(name + ' 的映射必须是非空对象')
            if any(k not in MAPPING['canonical_fields'] or not isinstance(v, str) or not v.strip() for k, v in mapping.items()):
                raise ValueError(name + ' 含未知标准字段或无效表头')
            if _dup_columns(mapping):
                raise ValueError(name + ' 的同一原始列不能映射为多个标准字段')
        return data, False
    except (ValueError, OSError) as e:
        errors.append(CUSTOM_MAPPING + ' 无效：' + str(e))
        return {}, True


def sanitize_support(rows, columns, fname, anomalies):
    """辅助表标识使用同一解析器；不可信键不参与匹配或库存联动。"""
    out = []
    for i, r in enumerate(rows, 2):
        i = getattr(r, 'line', i)
        r = dict(r, 来源=f'{fname}#第{i}行')
        valid = True
        for col in columns:
            value, risk = identifier(r.get(col, ''))
            r[col] = value
            if risk or not value:
                valid = False
                anomalies.append(dict(级别='严重', 文件=fname, 行=i, 类型='标识符精度风险' if risk else '标识符缺失',
                                       说明=col + '：' + (risk or '该行不参与联动'))) 
        if valid:
            out.append(r)
    return out


def run(input_dir):
    with localcontext() as ctx:
        ctx.prec = 64
        return _run(input_dir)


TOTAL_ROW = re.compile(r'(合计|总计|小计|汇总|共计|total)[:：]?', re.I)

def suggest_mapping(header, absent):
    """对缺失的标准字段，按别名相似度给出候选原始列（仅建议，必须由用户确认）。"""
    import difflib
    out = {}
    for canon in absent:
        aliases = MAPPING['canonical_fields'].get(canon, [])
        best = []
        for h in header:
            hs = clean(h)
            score = max([difflib.SequenceMatcher(None, hs, a).ratio() for a in aliases] + [0])
            if any(len(a) >= 2 and (a in hs or hs in a) for a in aliases if hs): score = max(score, 0.8)
            if score >= 0.4: best.append((round(score, 2), hs))
        out[canon] = [dict(原始列=h, 相似度=sc) for sc, h in sorted(best, reverse=True)[:3]]
    return out

def _run(input_dir):
    log, anomalies, orders, master, confirmed, stock, pstock = [], [], [], [], {}, [], []
    files = sorted(f for f in os.listdir(input_dir) if os.path.splitext(f)[1].lower() in ('.csv', '.xlsx', '.xls', '.zip'))
    errors = []
    recognition, field_issues = [], []
    overrides, config_invalid = load_overrides(input_dir, errors)
    for f in list(files):
        try:
            header, rows = read_table(os.path.join(input_dir, f))
        except (ValueError, OSError, zipfile.BadZipFile, ParseError, KeyError, IndexError, csv.Error) as e:
            errors.append(f'{f}：{e}'); log.append(f'[{f}] 未处理：{e}'); files.remove(f); continue
        kind, plat, conf = detect_file(f, header)
        custom = overrides.get(f, {})
        if custom:
            kind = '订单'
        fm = field_map(header, custom) if kind == '订单' else {}
        absent = [k for k in ('order_id', 'qty', 'order_amount', 'paid_amount', 'status') if k not in fm]
        bad_headers = [v for v in custom.values() if v not in header]
        if custom and _dup_columns(fm, custom):
            bad_headers.append('同一原始列被多个标准字段使用，请同时修正冲突字段')
        if kind == '订单' and (absent or bad_headers or config_invalid):
            field_issues.append(dict(文件=f, 表头=header, 缺失标准字段=absent, 无效映射表头=bad_headers,
                                     建议映射=suggest_mapping(header, absent),
                                     建议='确认列含义后在输入目录创建/修正 ' + CUSTOM_MAPPING + ' 并重跑'))
        recognition.append(dict(文件=f, 文件类型=kind, 平台=plat or '-', 置信度=conf, 行数=len(rows), 字段映射=fm))
        log.append(f'[{f}] 文件类型={kind} 平台={plat or "-"} 识别置信度={conf:.2f} 行数={len(rows)}')
        if kind == '订单':
            kept_rows = []
            for r in rows:
                vals = list(r.values()) if isinstance(r, dict) else list(r)
                if any(TOTAL_ROW.fullmatch(clean(v)) for v in vals[:3]):
                    log.append(f'[{f}] 跳过第{getattr(r, "line", "?")}行：合计/小计/汇总行，不作为订单')
                else:
                    kept_rows.append(r)
            rows = kept_rows
        if kind == '订单':
            if bad_headers or config_invalid:
                errors.append(f + '：自定义映射无效，未处理订单')
                continue
            if 'order_id' not in fm and 'paid_amount' not in fm:
                errors.append(f + '：未识别订单字段，请提供自定义映射')
                continue
            orders += normalize_orders(f, plat or '通用导入', header, rows, log, anomalies, custom)
        elif kind == '商品档案':
            for r in sanitize_support(rows, ('内部SKU',), f, anomalies):
                barcode, risk = identifier(r.get('条码', ''))
                r['条码'] = '' if risk else barcode
                if risk:
                    anomalies.append(dict(级别='严重', 文件=f, 行='-', 类型='标识符精度风险', 说明='条码：' + risk))
                master.append({k: r.get(k, '') for k in ('内部SKU', '条码', '商品名称', '品牌', '型号', '颜色', '规格')})
        elif kind == 'SKU映射':
            confirmed.update({(r.get('平台', ''), r['平台商品标识']): r['内部SKU'] for r in sanitize_support(rows, ('平台商品标识', '内部SKU'), f, anomalies)})
        elif kind == '仓库库存': stock.extend(sanitize_support(rows, ('内部SKU',), f, anomalies))
        elif kind == '平台库存':
            for r in sanitize_support(rows, ('商家编码',), f, anomalies):
                count = to_dec(r.get('平台可售库存', ''))
                if count is None or count < 0 or count != count.to_integral_value():
                    anomalies.append(dict(级别='严重', 文件=f, 行='-', 类型='库存数据异常', 说明='平台可售库存必须是非负整数'))
                else:
                    r.setdefault('平台', '未知平台')
                    pstock.append(r)
    total_rows = len(orders)
    kept, dup = deduplicate(orders, anomalies)
    log.append(f'数量核对：读取订单行 {total_rows} = 保留 {len(kept)} + 重复 {dup}（其中隔离 {sum(r["隔离"] for r in kept)} 行仍保留在明细中）')
    match_res = match_skus(kept, master, confirmed)
    metrics, trace, excluded = sales_metrics(kept)
    excluded += [(r['来源'], r['去重说明']) for r in orders if r['重复']]
    inv, alerts, span = inventory(kept, stock, pstock, anomalies)
    q = quality(orders, kept, dup, match_res, anomalies)
    counts = dict(读取行数=total_rows, 保留行数=len(kept), 重复行数=dup, 隔离行数=sum(r['隔离'] for r in kept),
                  参与统计行数=sum(not r['隔离'] for r in kept))
    return dict(files=files, errors=errors, log=log, anomalies=anomalies, orders=kept, all_rows=orders, dup=dup, match=match_res,
                counts=counts, recognition=recognition, field_issues=field_issues,
                metrics=metrics, trace=trace, excluded=excluded, inventory=inv, alerts=alerts, span=span, quality=q)
