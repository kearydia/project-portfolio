# -*- coding: utf-8 -*-
"""标准答案测试：python -m unittest discover -s tests"""
import os, sys, unittest
sys.dont_write_bytecode = True
from decimal import Decimal
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import engine

class T(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.r = engine.run(os.path.join(ROOT, 'examples'))
    def test_amounts(self):  # 人工逐行核算的标准答案
        m = self.r['metrics']
        self.assertEqual(m['订单金额'], Decimal('1933.60'))
        self.assertEqual(m['实际支付金额'], Decimal('1827.80'))
        self.assertEqual(m['已完成退款金额'], Decimal('145.00'))   # 退款中的 95 元不扣
        self.assertEqual(m['支付净额'], Decimal('1682.80'))
        self.assertEqual(m['有效订单数'], 13)
    def test_dedup_keeps_count(self):
        self.assertEqual(len(self.r['all_rows']), len(self.r['orders']) + self.r['dup'])
        self.assertEqual(self.r['dup'], 1)
    def test_sub_orders_not_deleted(self):  # 同一主订单的两个子订单都要保留
        self.assertEqual(sum(1 for o in self.r['orders'] if o['订单号'] == 'DY1001'), 2)
    def test_negative_amount_isolated(self):
        jd5 = [o for o in self.r['orders'] if o['订单号'] == 'JD2005'][0]
        self.assertTrue(jd5['隔离']); self.assertEqual(self.r['quality']['风险等级'], '高风险')
    def test_sku_conflict_blocked(self):
        m = {x['平台商品标识']: x for x in self.r['match'] if x['平台'] == '京东'}
        self.assertIn('禁止合并', m['100090']['结论'])   # 礼盒 vs 单品
        self.assertIn('禁止合并', m['100091']['结论'])   # 3双装 vs 5双装
    def test_inventory_alerts(self):
        got = {(a['内部SKU'], a['风险']) for a in self.r['alerts']}
        for exp in [('SKU-TB-001', '库存不足'), ('SKU-TB-003', '超卖风险'), ('SKU-TB-001', '平台库存不一致'), ('SKU-SK-020', '库存数据异常')]:
            self.assertIn(exp, got)
        inv = {x['内部SKU']: x for x in self.r['inventory']}
        self.assertEqual(inv['SKU-TB-001']['已占用库存'], Decimal('4'))
        self.assertEqual(inv['SKU-TB-001']['可用库存'], Decimal('2'))
    def test_privacy_masked(self):
        o = [o for o in self.r['orders'] if o['订单号'] == 'DY1001'][0]
        self.assertEqual(o['脱敏_receiver_phone'], '138****5678')

    def test_demo_sku_scores_and_decimal_inventory_preserved(self):
        matches = self.r['match']
        self.assertEqual(self.r['quality']['综合分'], 91)
        self.assertEqual([m['分数'] for m in matches if m['商品名称'] == '行野轻量双肩包'], [80])
        self.assertTrue(all(m['分数'] < 80 for m in matches if m['平台商品标识'] in ('100090', '100091')))
        for row in self.r['inventory']:
            if isinstance(row['预计可售天数'], (int, Decimal)):
                self.assertIsInstance(row['预计可售天数'], Decimal)

class TestV2ZeroDependency(unittest.TestCase):
    def test_xlsx_roundtrip(self):
        import tempfile
        from xlsx_io import write_xlsx, read_xlsx
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        p = os.path.join(tmp.name, 't.xlsx')
        write_xlsx(p, [('表一', [['订单号', '金额'], ['A001', 12.5], ['B&<002>', '']]), ('表二', [['x']])])
        self.assertEqual(read_xlsx(p), [['订单号', '金额'], ['A001', '12.5'], ['B&<002>']])

    def test_zip_gives_friendly_error(self):
        import tempfile, zipfile
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        d = tmp.name; zipfile.ZipFile(os.path.join(d, 'x.zip'), 'w').close()
        with self.assertRaises(ValueError) as cm:
            engine.read_table(os.path.join(d, 'x.zip'))
        self.assertIn('解压', str(cm.exception))

    def test_no_third_party_imports(self):
        import re
        for f in os.listdir(os.path.join(ROOT, 'scripts')):
            if f.endswith('.py'):
                with open(os.path.join(ROOT, 'scripts', f), encoding='utf-8') as stream:
                    src = stream.read()
                self.assertIsNone(re.search(r'^\s*(import|from)\s+(openpyxl|pandas|numpy)', src, re.M), f)


class TestConfirmByName(unittest.TestCase):
    def test_confirm_without_platform_id(self):
        import tempfile, shutil
        tmp = tempfile.TemporaryDirectory(); self.addCleanup(tmp.cleanup)
        d = os.path.join(tmp.name, 'in'); shutil.copytree(os.path.join(ROOT, 'examples'), d)
        with open(os.path.join(d, 'SKU映射_已确认.csv'), 'a', encoding='utf-8') as f:
            f.write('小红书电商,行野轻量双肩包|黑色 15寸,SKU-BG-010,演示,2026-11-13\n')
        r = engine.run(d)
        self.assertEqual([m['分数'] for m in r['match'] if m['商品名称'] == '行野轻量双肩包'], [100])
        self.assertEqual(r['metrics']['支付净额'], Decimal('1682.80'))  # 确认映射不改变金额


class TestImportRegressions(unittest.TestCase):
    """全部从临时 CSV/XLSX 经 engine.run 进入；不依赖演示数据补丁。"""
    def setUp(self):
        import tempfile
        from pathlib import Path
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name)
        self.headers = ['订单号', '子订单号', '商品ID', '商家编码', '商品名称', '规格', '数量',
                        '订单金额', '实付金额', '订单状态', '售后状态', '退款金额', '下单时间']

    def row(self, **values):
        row = dict(zip(self.headers, ['A001', 'A001-1', 'P1', 'SKU1', '测试商品', '黑色', '1',
                                     '99', '90', '已完成', '', '0', '2026-11-08 10:12:00']))
        row.update(values)
        return row

    def csv(self, rows, name='订单.csv', headers=None):
        import csv
        headers = headers or self.headers
        with (self.folder / name).open('w', encoding='utf-8-sig', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows([[r.get(h, '') for h in headers] for r in rows])
        return self.folder / name

    def xlsx(self, rows, name='订单.xlsx'):
        from xlsx_io import write_xlsx
        path = self.folder / name
        write_xlsx(path, [('订单', [self.headers] + [[r.get(h, '') for h in self.headers] for r in rows])])
        return path

    def run_engine(self):
        return engine.run(str(self.folder))

    def test_a_identifiers_text_leading_zero_and_long_digits(self):
        self.csv([self.row(订单号='0000123.0', 子订单号='00004.00', 商品ID='00005', 商家编码='000006'),
                  self.row(订单号='1234567890123456789', 子订单号='123456789012345678901')])
        r = self.run_engine()
        self.assertEqual(r['orders'][0]['订单号'], '0000123')
        self.assertEqual(r['orders'][0]['子订单号'], '00004')
        self.assertEqual(r['orders'][0]['商家编码'], '000006')
        self.assertEqual(r['orders'][1]['订单号'], '1234567890123456789')
        self.assertFalse(any(o['隔离'] for o in r['orders']))

    def test_a_scientific_and_excel_long_number_warn_without_inventing_digits(self):
        self.xlsx([self.row(订单号=Decimal('1.23E+18'), 子订单号=1234567890123456789),
                   self.row(订单号='0001234567890123456789', 子订单号='0002')])
        self.csv([self.row(订单号='1.23457E+18', 商家编码='6.9E+15')])
        r = self.run_engine()
        ids = {o['订单号']: o for o in r['orders']}
        self.assertIn('1230000000000000000', ids)
        self.assertIn('1234570000000000000', ids)
        self.assertTrue(ids['1230000000000000000']['隔离'])
        self.assertFalse(ids['0001234567890123456789']['隔离'])
        import report
        self.assertGreaterEqual(len(report.summary(r)['精度风险提示']), 3)
        self.assertTrue(all('不能恢复' in a['说明'] for a in report.summary(r)['精度风险提示']))

    def test_a_support_tables_share_identifier_rules(self):
        self.csv([self.row(商品ID='00088.0', 商家编码='')])
        self.csv([{'平台': '通用导入', '平台商品标识': '00088', '内部SKU': '00001.0'},
                  {'平台': '通用导入', '平台商品标识': '6.9E+15', '内部SKU': 'bad'}],
                 '映射.csv', ['平台', '平台商品标识', '内部SKU'])
        self.csv([{'内部SKU': '00001', '实际库存': '10', '冻结库存': '0', '安全库存': '2'}],
                 '库存.csv', ['内部SKU', '实际库存', '冻结库存', '安全库存'])
        r = self.run_engine()
        self.assertEqual(r['orders'][0]['内部SKU'], '00001')
        self.assertEqual(r['inventory'][0]['内部SKU'], '00001')
        self.assertTrue(any(a['类型'] == '标识符精度风险' for a in r['anomalies']))

    def test_b_money_formats_and_strict_grouping(self):
        values = ['￥1,234.50', '99元', '1,234.5', '(12.00)', '1,23.50', 'NaN', 'Infinity', 'abc', '']
        self.csv([self.row(订单号=str(i), 实付金额=v, 订单金额='2000') for i, v in enumerate(values)])
        r = self.run_engine()
        self.assertEqual(r['metrics']['实际支付金额'], Decimal('2568.00'))
        self.assertEqual(sum(o['隔离'] for o in r['orders']), 6)
        self.assertIsNone(r['orders'][4]['实付金额'])
        self.assertEqual(r['orders'][3]['实付金额'], Decimal('-12.00'))

    def test_b_invalid_refund_and_refund_exceeds_zero_isolated(self):
        self.csv([self.row(订单号='A', 退款金额='坏值'), self.row(订单号='B', 售后状态='退款成功', 退款金额=''),
                  self.row(订单号='C', 实付金额='0', 退款金额='1'), self.row(订单号='D', 退款金额='-1'),
                  self.row(订单号='E', 退款金额='', 售后状态='')])
        r = self.run_engine()
        self.assertEqual(r['counts']['隔离行数'], 4)
        self.assertIsNone(r['orders'][0]['退款金额'])
        self.assertEqual(r['orders'][4]['退款金额'], Decimal('0'))
        self.assertEqual(r['metrics']['支付净额'], Decimal('90'))
        self.assertEqual(r['quality']['风险等级'], '高风险')

    def test_c_missing_ids_not_deduplicated_and_invalid_quantities(self):
        self.csv([self.row(订单号=''), self.row(订单号='NULL'), self.row(订单号='-'),
                  self.row(订单号='A', 数量='1.5'), self.row(订单号='B', 数量='0'),
                  self.row(订单号='C', 数量='-1'), self.row(订单号='D', 数量='NaN')])
        r = self.run_engine()
        self.assertEqual(r['counts']['读取行数'], 7)
        self.assertEqual(r['counts']['保留行数'], 7)
        self.assertEqual(r['dup'], 0)
        self.assertTrue(all(o['隔离'] for o in r['orders']))
        self.assertEqual(r['metrics']['实际支付金额'], Decimal('0'))

    def test_c_required_columns_isolate_and_empty_master_safe(self):
        self.csv([self.row()], headers=[h for h in self.headers if h != '订单金额'])
        r = self.run_engine()
        self.assertTrue(r['orders'][0]['隔离'])
        self.assertIn('order_amount', r['field_issues'][0]['缺失标准字段'])
        self.assertEqual(r['match'][0]['分数'], 0)

    def test_c_inventory_invalid_values_do_not_crash_or_become_zero(self):
        self.csv([self.row(订单状态='待发货')])
        cols = ['内部SKU', '实际库存', '冻结库存', '安全库存']
        self.csv([dict(zip(cols, ['S1', '5', 'oops', '1'])), dict(zip(cols, ['S2', '5', '0', '-2'])),
                  dict(zip(cols, ['S3', 'NaN', '0', '1'])), dict(zip(cols, ['S4', '5', '0', '1.5']))], '库存.csv', cols)
        r = self.run_engine()
        self.assertEqual(len(r['inventory']), 4)
        self.assertTrue(all(v['可用库存'] is None for v in r['inventory']))
        self.assertEqual(sum(a['风险'] == '库存数据异常' for a in r['alerts']), 4)

    def test_c_empty_and_bad_xlsx_and_duplicate_headers_reported(self):
        (self.folder / 'empty.csv').write_text('', encoding='utf-8')
        (self.folder / 'bad.xlsx').write_bytes(b'broken')
        self.csv([self.row()], '重复表头.csv', ['订单号', '订单号'])
        r = self.run_engine()
        self.assertEqual(len(r['errors']), 3)
        self.assertEqual(r['orders'], [])

    def test_c_source_row_numbers_survive_blank_lines(self):
        path = self.csv([self.row(), self.row(订单号='A002')])
        text = path.read_text(encoding='utf-8-sig')
        path.write_text('\n' + text.replace('\n', '\n\n', 1), encoding='utf-8-sig')
        r = self.run_engine()
        self.assertTrue(r['orders'][0]['来源'].endswith('#第4行'))
        self.assertTrue(r['orders'][1]['来源'].endswith('#第5行'))

    def test_d_dates_csv_and_excel_fractional_serial(self):
        self.csv([self.row(订单号='A', 下单时间='2026/11/8 10:12'),
                  self.row(订单号='B', 下单时间='2026-11-08'), self.row(订单号='C', 下单时间='20261108'),
                  self.row(订单号='D', 下单时间='not-a-date')])
        self.xlsx([self.row(订单号='E', 下单时间=Decimal('45970.5'))])
        r = self.run_engine()
        got = {o['订单号']: o['下单时间'] for o in r['orders']}
        self.assertEqual(got['A'], '2026-11-08 10:12:00')
        self.assertEqual(got['B'], '2026-11-08 00:00:00')
        self.assertEqual(got['B'], got['C'])
        self.assertIsNone(got['D'])
        from datetime import datetime, timedelta
        self.assertEqual(got['E'], (datetime(1899, 12, 30) + timedelta(days=45970, hours=12)).strftime('%Y-%m-%d %H:%M:%S'))

    def test_e_refund_progress_beats_file_order_and_traces_loser(self):
        self.csv([self.row(售后状态='退款中', 退款金额='20')], 'a.csv')
        self.csv([self.row(售后状态='退款成功', 退款金额='20')], 'z.csv')
        r = self.run_engine()
        self.assertTrue(r['orders'][0]['来源'].startswith('z.csv'))
        self.assertEqual(r['metrics']['支付净额'], Decimal('70'))
        self.assertEqual(r['dup'], 1)
        self.assertEqual(r['all_rows'][0]['重复'], True)
        self.assertIn('z.csv', r['all_rows'][0]['去重说明'])
        self.assertTrue(any('a.csv' in source for source, reason in r['excluded']))
        self.assertTrue(any(a['类型'] == '同一子订单内容冲突' for a in r['anomalies']))

    def test_e_state_date_completeness_and_ties(self):
        self.csv([self.row(订单状态='待付款', 实付金额='0'), self.row(订单状态='待发货'),
                  self.row(订单状态='已发货'), self.row(下单时间='2026-11-09'),
                  self.row(下单时间='2026-11-10', 商家编码=''), self.row(下单时间='2026-11-10'),
                  self.row(下单时间='2026-11-10')])
        r = self.run_engine()
        self.assertTrue(r['orders'][0]['来源'].endswith('#第7行'))
        self.assertEqual(r['dup'], 6)
        self.assertEqual(sum(a['类型'] == '重复订单行' for a in r['anomalies']), 1)
        c = r['counts']
        self.assertEqual(c['读取行数'], c['参与统计行数'] + c['隔离行数'] + c['重复行数'])

    def test_e_amount_and_product_conflicts_not_called_identical(self):
        self.csv([self.row(), self.row(订单金额='100'), self.row(退款金额='10'),
                  self.row(商品ID='P2'), self.row(规格='蓝色')])
        r = self.run_engine()
        conflicts = [a for a in r['anomalies'] if a['类型'] == '同一子订单内容冲突']
        self.assertEqual(len(conflicts), 4)
        self.assertEqual(r['metrics']['实际支付金额'], Decimal('90'))

    def test_e_valid_record_wins_over_isolated_refund(self):
        self.csv([self.row(售后状态='退款成功', 退款金额='999'), self.row()])
        r = self.run_engine()
        self.assertFalse(r['orders'][0]['隔离'])
        self.assertEqual(r['metrics']['支付净额'], Decimal('90'))

    def test_f_unknown_headers_suggest_then_custom_mapping_reruns(self):
        import json
        import report
        names = {'order_id': '业务流水', 'qty': '件', 'order_amount': '总额', 'paid_amount': '到账', 'status': '阶段', 'order_time': '发生时间'}
        self.csv([dict(zip(names.values(), ['0001', '1', '0.30', '0.10', '已完成', '20261108']))], 'custom.csv', list(names.values()))
        before = self.run_engine()
        self.assertEqual(before['orders'], [])
        self.assertTrue(report.summary(before)['字段识别问题'])
        config = self.folder / engine.CUSTOM_MAPPING
        config.write_text(json.dumps({'custom.csv': names}, ensure_ascii=False), encoding='utf-8')
        after = self.run_engine()
        self.assertEqual(after['metrics']['支付净额'], Decimal('0.10'))
        self.assertEqual(after['orders'][0]['订单号'], '0001')
        self.assertEqual(after['field_issues'], [])
        self.assertEqual(json.loads(config.read_text(encoding='utf-8')), {'custom.csv': names})

    def test_f_invalid_mapping_is_visible_and_not_silently_used(self):
        import json
        self.csv([self.row()])
        path = self.folder / engine.CUSTOM_MAPPING
        for config in ('[]', '{bad', json.dumps({'订单.csv': {'bad_key': '订单号'}}),
                       json.dumps({'订单.csv': {'paid_amount': '订单金额'}}),
                       json.dumps({'订单.csv': {'order_id': '不存在'}})):
            with self.subTest(config=config):
                path.write_text(config, encoding='utf-8')
                r = self.run_engine()
                self.assertTrue(r['errors'])
                self.assertEqual(r['orders'], [])
                self.assertTrue(r['field_issues'])

    def test_g_h_reports_share_summary_and_escape_script_injection(self):
        import json
        import re
        import zipfile
        import report
        from xlsx_io import read_xlsx
        attack = '</script><script>alert("x")</script><img src=x onerror=alert(1)>&\u2028尾'
        self.csv([self.row(商品名称=attack, 实付金额='0.10', 订单金额='0.30'),
                  self.row(订单号='A002', 实付金额='0.20', 订单金额='0.30')])
        r = self.run_engine()
        data = report.summary(r)
        html = self.folder / 'report.html'
        book = self.folder / 'report.xlsx'
        report.dashboard(r, html, data)
        report.excel(r, book, data)
        text = html.read_text(encoding='utf-8')
        self.assertNotIn(attack, text)
        self.assertEqual(text.count('</script>'), 1)
        payload = re.search(r'const D=(.*?);\nfunction node', text, re.S).group(1)
        decoded = json.loads(payload)
        self.assertEqual(decoded, json.loads(json.dumps(data, ensure_ascii=False, default=str)))
        self.assertEqual(decoded['订单明细'][0]['商品名称'], attack)
        self.assertEqual(decoded['指标']['支付净额'], '0.30')
        self.assertEqual([a['优先级'] for a in data['行动建议']], [1, 2, 3])
        overview = read_xlsx(book)
        self.assertIn(['支付净额', '0.30', '实际支付金额 − 已完成退款金额（经营指标，非会计收入/利润）'], overview)
        with zipfile.ZipFile(book) as z:
            self.assertEqual(sum(n.startswith('xl/worksheets/sheet') for n in z.namelist()), 8)
            detail = z.read('xl/worksheets/sheet2.xml').decode('utf-8')
            self.assertNotIn('<f>', detail)
            self.assertIn('&lt;/script&gt;', detail)
        self.assertNotIn('innerHTML', text)

    def test_cli_no_orders_still_writes_diagnostics(self):
        import json
        import subprocess
        self.csv([{'不明列': '内容'}], headers=['不明列'])
        source = self.folder / 'input'
        source.mkdir()
        (self.folder / '订单.csv').rename(source / '订单.csv')
        output = self.folder / 'out'
        proc = subprocess.run([sys.executable, '-B', os.path.join(ROOT, 'scripts', 'run.py'),
                               '--input', str(source), '--output', str(output)],
                              capture_output=True, env=dict(os.environ, PYTHONIOENCODING='utf-8'))
        self.assertEqual(proc.returncode, 3, proc.stderr)
        data = json.loads((output / 'summary.json').read_text(encoding='utf-8'))
        self.assertTrue(data['字段识别问题'])
        self.assertEqual(len(list(output.iterdir())), 3)

    def test_cli_rejects_output_in_input_without_modification(self):
        import subprocess
        source = self.csv([self.row()])
        original = source.read_bytes()
        output = self.folder / 'reports'
        proc = subprocess.run([sys.executable, '-B', os.path.join(ROOT, 'scripts', 'run.py'),
                               '--input', str(self.folder), '--output', str(output)],
                              capture_output=True, env=dict(os.environ, PYTHONIOENCODING='utf-8'))
        self.assertEqual(proc.returncode, 2)
        self.assertFalse(output.exists())
        self.assertEqual(source.read_bytes(), original)


if __name__ == '__main__':
    unittest.main()



class TestReviewerFixes(unittest.TestCase):
    """v2.1 审核时补充：合计行、建议映射、共用金额列、一句话结论。"""
    def _dir(self, files):
        import tempfile
        d = tempfile.mkdtemp()
        for name, text in files.items():
            with open(os.path.join(d, name), 'w', encoding='utf-8') as f: f.write(text)
        return d

    def test_total_row_skipped(self):
        d = self._dir({'抖音_订单_t.csv': '主订单编号,子订单编号,商品名称,商品数量,订单应付金额,实付金额,订单状态,售后状态,退款金额,订单提交时间\n'
                       'A1,A1-1,杯,1,10.00,9.00,已完成,,0,2026-11-01\n合计,,,1,10.00,9.00,,,,\n'})
        r = engine.run(d)
        self.assertEqual(len(r['all_rows']), 1)
        self.assertEqual(r['metrics']['实际支付金额'], Decimal('9.00'))
        self.assertTrue(any('合计' in l and '跳过' in l for l in r['log']))

    def test_mapping_suggestion_and_shared_amount(self):
        import json
        d = self._dir({'未知_订单.csv': '单号,货品,件数,付款额,当前状况\nZ1,袜子,1,10.00,已完成\n'})
        r = engine.run(d)
        sug = r['field_issues'][0]['建议映射']
        self.assertEqual(sug['order_id'][0]['原始列'], '单号')
        with open(os.path.join(d, '字段映射_自定义.json'), 'w', encoding='utf-8') as f:
            json.dump({'未知_订单.csv': {'order_id': '单号', 'qty': '件数', 'order_amount': '付款额',
                                         'paid_amount': '付款额', 'status': '当前状况'}}, f, ensure_ascii=False)
        r = engine.run(d)
        self.assertEqual(r['errors'], [])
        self.assertEqual(r['metrics']['实际支付金额'], Decimal('10.00'))

    def test_one_line_conclusion(self):
        import report
        line = report.summary(engine.run(os.path.join(ROOT, 'examples')))['一句话结论']
        self.assertIn('13 单有效订单', line); self.assertIn('1682.80 元', line); self.assertIn('高风险', line)
