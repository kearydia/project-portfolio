# 阶段 1 接口契约

本页保存阶段 1 历史契约。全量版本使用同目录的当前接口契约，原先列出的后续路由已接入实现。真实 JDBC 验收以交付矩阵为准。

接口前缀 `/api`。成功为 `{code:"OK",message:"操作成功",data:…,fieldErrors:{}}`。失败返回中文 message 及稳定 code。400 处理字段或参数错误，401 要求登录，403 表示模块、操作或 CSRF 校验拒绝，404 表示可见范围内无数据，409 表示唯一性、外键引用或状态冲突。失败的 `data` 为 null。列表返回 `list`、`total`、`page`、`pageSize`。页码从 1 起，每页默认 10，最大 100。

## 会话

1. 登录页先发 `GET /auth/csrf`，保留返回的 Cookie 和 `data.csrfToken`。
2. `POST /auth/login` 传 `username`、`password`。所有写请求（包括登录）发送 `X-CSRF-Token`。登录成功返回 `data.user`、新的 `data.csrfToken` 并更换会话 ID。
3. 页面刷新可以 `GET /auth/me` 取当前身份与 CSRF 值。身份字段为 id、username、displayName、role、enabled、employeeId、departmentId。角色为 SALES 或 ADMIN。
4. `POST /auth/logout` 销毁会话。账号启用状态、角色或绑定员工变化时，旧会话下次请求失效。
5. Vite 开发期代理相对路径 `/api`，演示期页面与接口同源。Cookie 按会话发放，HttpOnly、SameSite=Strict。候选本机 HTTP 默认保留 Secure=false，HTTPS 部署设置 `OPS_SECURE_COOKIE=true`。前端不得把页面上的身份缓存当作授权结果。

## 档案、账号、操作日志

档案资源支持列表 GET、新增 POST、详情 GET、完整修改 PUT 和删除 DELETE。前端分页或搜索变化后重新请求服务器。以下字段用于写入。

| 路径 | 写入字段与列表条件 | 权限 |
|---|---|---|
| `/departments` | name、enabled。列表可用 q 搜部门名 | 管理员 |
| `/departments/options` | GET 只返回 id、name，也包含用于历史筛选的停用部门 | 已登录 |
| `/employees` | employeeNo、name、departmentId、status（ACTIVE / INACTIVE / LEFT）。列表支持 q、departmentId | 管理员 |
| `/customers` | name、ownerId、enabled。列表支持 q、ownerId。业务员可省 ownerId，由会话填本人 | 管理员 CRUD，业务员本人读与新增、修改，无删除 |
| `/products` | sku、name、unitPrice、enabled。列表支持 q、enabled | 管理员 CRUD，业务员只读 |
| `/users` | 列表及详情 GET，创建 POST，完整修改 PUT。创建需 username、displayName、password、role、enabled、employeeId。修改使用 displayName、role、enabled、employeeId。列表支持 q | 管理员，业务员账号必须绑定唯一员工 |
| `/operation-logs` | GET。筛选 dateFrom、dateTo（ISO 日期，含当天）、actorId、action、resource。阶段 1 动作为 CREATE、UPDATE、DELETE | 仅管理员 |

顾客转交只改变客户档案归属。业务员传其他员工的 ownerId 返回 403，访问不可见的详情返回 404。部门选项无员工数据。删除引用冲突返回 409，业务可改为停用、停售或离职。新增、修改、删除同一事务记录前后摘要，日志与账号接口从不返回密码散列。

## 后续接口预留

经授权访问下列接口返回 501 和 `NOT_IMPLEMENTED`。无权限的请求仍为 403。订单无 DELETE 接口。

- GET、POST `/orders`，GET `/orders/{id}`。未来列表支持 dateFrom、dateTo、departmentId（成交时）、customerName（模糊）、status、orderNo。管理员可筛 employeeId，业务员只取本人。列表有效合计覆盖全部匹配的有效订单。
- PUT `/orders/{id}` 仅管理员，订单须 ACTIVE，带 expectedVersion。可改客户、日期、明细，经办人及成交部门快照不变。明细有独立 lineId、displayOrder，允许同产品多行。已有行产品不变，保留其成交价。新增或换品取当前档案价。后端用 BigDecimal 重算，表列用 DECIMAL。停用客户不得用于新单或改单，停售产品可保留在原历史行，禁止作为新行或换品。
- POST `/orders/{id}/void`、POST `/orders/{id}/unvoid` 仅管理员，带 expectedVersion 和原因。条件更新防止冲突，冲突 409，记录前后状态。作废剔除统计，撤销后计入。
- GET `/stats/overview` 复用订单过滤及权限。只聚合有效单并避免多明细重复累加。管理员看月度销售额、员工业绩、客户排行。业务员看本人经办订单限定的近 6 个自然月及客户排行。客户转交不改旧单和排行归属。
- POST `/orders/export` 管理员按获准查询范围导出，业务员导出本人。导出筛选匹配的所有行，后续契约建议订单汇总与明细两表，明细含订单状态。作废可随状态筛选出现，有效合计排除作废。
- POST `/maintenance/batch-update`、POST `/maintenance/cleanup-preview`、POST `/maintenance/cleanup` 仅管理员。批量默认仅变更产品在售、客户和员工状态。清理先预览再校验，只处理无引用的失效档案，作废订单的引用也须保护。
- POST、GET `/maintenance/backups`，GET `/maintenance/backups/{id}/file`。POST `/maintenance/restores/preview`，POST `/maintenance/restores`，GET `/maintenance/restores/{jobId}`。备份和在线恢复均为管理员必做项。恢复只接收课程范围、版本化白名单的结构化数据包，校验 manifest、大小、解压路径、哈希、字段、引用和管理员可用性。执行前自动备份、二次确认和暂停并发写入。导入经精确检查为全新的候选课程库，全部校验通过才切换连接池，切换后使旧会话失效。失败时继续使用原库。恢复日志单独保留。严禁向任意旧库导入，禁止执行上传 SQL。
