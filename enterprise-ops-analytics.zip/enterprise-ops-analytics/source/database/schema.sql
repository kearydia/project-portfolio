-- 仅在已完成认证、同名检查并新建的课程库中手动执行。
-- 文件不选择数据库、不创建账号、不改权限，也不覆盖已存在的表。
CREATE TABLE departments (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    enabled BOOLEAN NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE employees (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    employee_no VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(80) NOT NULL,
    department_id BIGINT NOT NULL,
    status ENUM('ACTIVE', 'INACTIVE', 'LEFT') NOT NULL,
    CONSTRAINT fk_employee_department FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE users (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(40) NOT NULL UNIQUE,
    display_name VARCHAR(80) NOT NULL,
    password_hash VARCHAR(100) NOT NULL,
    role ENUM('SALES', 'ADMIN') NOT NULL,
    enabled BOOLEAN NOT NULL,
    employee_id BIGINT UNIQUE,
    auth_version BIGINT NOT NULL DEFAULT 0,
    INDEX ix_users_enabled_role (role, enabled, id),
    CONSTRAINT ck_sales_employee CHECK (role <> 'SALES' OR employee_id IS NOT NULL),
    CONSTRAINT fk_user_employee FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE customers (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    owner_id BIGINT NOT NULL,
    enabled BOOLEAN NOT NULL,
    INDEX ix_customer_owner_id (owner_id, id),
    CONSTRAINT fk_customer_owner FOREIGN KEY (owner_id) REFERENCES employees (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE products (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sku VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    unit_price DECIMAL(12, 2) NOT NULL,
    enabled BOOLEAN NOT NULL,
    CONSTRAINT ck_product_price CHECK (unit_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 订单表只定义数据模型。阶段 1 没有订单写入功能。
CREATE TABLE sales_orders (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_no VARCHAR(40) NOT NULL UNIQUE,
    business_date DATE NOT NULL,
    customer_id BIGINT NOT NULL,
    employee_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL COMMENT '成交时部门快照 ID',
    status ENUM('ACTIVE', 'VOID') NOT NULL DEFAULT 'ACTIVE',
    total_amount DECIMAL(18, 2) NOT NULL,
    version BIGINT NOT NULL DEFAULT 0,
    voided_by BIGINT,
    voided_at DATETIME(6),
    INDEX ix_order_date_id (business_date, id),
    INDEX ix_order_employee_date (employee_id, business_date, id),
    INDEX ix_order_department_date (department_id, business_date, id),
    CONSTRAINT ck_order_amount CHECK (total_amount >= 0),
    CONSTRAINT fk_order_customer FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_order_employee FOREIGN KEY (employee_id) REFERENCES employees (id) ON DELETE RESTRICT,
    CONSTRAINT fk_order_department FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE RESTRICT,
    CONSTRAINT fk_order_void_actor FOREIGN KEY (voided_by) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sales_order_items (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    display_order INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(12, 2) NOT NULL COMMENT '成交单价快照',
    line_amount DECIMAL(18, 2) NOT NULL,
    INDEX ix_item_order_line (order_id, display_order, id),
    CONSTRAINT ck_item_quantity CHECK (quantity > 0),
    CONSTRAINT ck_item_prices CHECK (unit_price >= 0 AND line_amount = quantity * unit_price),
    CONSTRAINT fk_item_order FOREIGN KEY (order_id) REFERENCES sales_orders (id) ON DELETE RESTRICT,
    CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE operation_logs (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    occurred_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    actor_id BIGINT NOT NULL,
    actor_name VARCHAR(40) NOT NULL,
    actor_role ENUM('SALES', 'ADMIN') NOT NULL,
    action VARCHAR(32) NOT NULL,
    resource VARCHAR(32) NOT NULL,
    target_id BIGINT NOT NULL,
    before_json JSON,
    after_json JSON,
    INDEX ix_log_time (occurred_at, id),
    INDEX ix_log_actor_time (actor_id, occurred_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
