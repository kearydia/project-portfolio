# Prepared for a separately authorized local HTTP run. This file starts no application.
[CmdletBinding()]
param (
    [uri]$BaseUri = 'http://127.0.0.1:8080/',
    [string]$AdminUsername,
    [Security.SecureString]$AdminPassword,
    [switch]$ApproveStage1HttpWrites,
    [hashtable]$ConfirmedOrderReferences
)
$ErrorActionPreference = 'Stop'
$VerbosePreference = 'SilentlyContinue'
$DebugPreference = 'SilentlyContinue'
if (-not $ApproveStage1HttpWrites -or [string]::IsNullOrWhiteSpace($AdminUsername) -or
    $null -eq $AdminPassword -or $AdminPassword.Length -eq 0) {
    throw 'Requires a separately authorized HTTP run and an administrator credential supplied in memory.'
}
if (-not $BaseUri.IsAbsoluteUri -or $BaseUri.Host -ne '127.0.0.1' -or $BaseUri.Scheme -notin @('http','https') -or
    $BaseUri.AbsolutePath -ne '/' -or $BaseUri.UserInfo -or $BaseUri.Query -or $BaseUri.Fragment) {
    throw 'Use the verified root URL of the authorized loopback course application.'
}

$marker = '课程演示验收-HTTP-' + [guid]::NewGuid().ToString('N').Substring(0, 8)
$fixtureToken = [guid]::NewGuid().ToString('N').Substring(0, 10)
$outcomes = [Collections.Generic.List[object]]::new()
$created = [Collections.Generic.List[object]]::new()

function Check([string]$name, [bool]$assertion) {
    $outcomes.Add([pscustomobject]@{ case=$name; state=if ($assertion) {'PASS'} else {'FAIL'} })
    if (-not $assertion) { throw "HTTP assertion failed: $name" }
}
function Skip([string]$name, [string]$reason) {
    $outcomes.Add([pscustomobject]@{ case=$name; state='SKIP'; reason=$reason })
}
function New-RuntimePassword {
    $bytes = [byte[]]::new(24)
    [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    $secure = [Security.SecureString]::new()
    try {
        foreach ($character in [Convert]::ToHexString($bytes).ToCharArray()) {
            $secure.AppendChar($character)
        }
        $secure.MakeReadOnly()
        return $secure
    } finally {
        [Array]::Clear($bytes, 0, $bytes.Length)
    }
}
function Invoke-Api {
    param (
        [string]$Case,
        [Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [string]$Path,
        [ValidateSet('GET','POST','PUT','DELETE')][string]$Method = 'GET',
        [hashtable]$Body,
        [string]$Csrf,
        [Security.SecureString]$Secret,
        [int]$Expected = 200,
        [string]$ExpectedCode
    )
    if (-not $Path.StartsWith('/api/')) { throw 'Only local stage 1 API paths are allowed.' }
    $uri = [uri]::new($BaseUri, $Path)
    if ($uri.Host -ne $BaseUri.Host -or $uri.Port -ne $BaseUri.Port -or $uri.Scheme -ne $BaseUri.Scheme) {
        throw 'Cross-origin credential forwarding refused.'
    }
    $headers = @{ Accept='application/json' }
    if ($Csrf) { $headers['X-CSRF-Token'] = $Csrf }
    $parameters = @{
        Uri=$uri; Method=$Method; WebSession=$Session; Headers=$headers
        NoProxy=$true; MaximumRedirection=0; SkipHttpErrorCheck=$true
        TimeoutSec=15; ErrorAction='Stop'; Verbose=$false; Debug=$false
    }
    $payload = $null
    $bstr = [IntPtr]::Zero
    try {
        if ($null -ne $Body) {
            $payload = $Body.Clone()
            if ($null -ne $Secret) {
                $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secret)
                $payload['password'] = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
            }
            $parameters['ContentType'] = 'application/json; charset=utf-8'
            $parameters['Body'] = $payload | ConvertTo-Json -Depth 6 -Compress
        }
        $response = Invoke-WebRequest @parameters
        $json = $response.Content | ConvertFrom-Json -Depth 12
    } catch {
        $outcomes.Add([pscustomobject]@{ case=$Case; state='FAIL'; reason='Local connection, request or JSON response error' })
        throw "HTTP request failed: $Case. Request and response details withheld."
    } finally {
        if ($null -ne $payload) { $payload.Clear() }
        if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        $parameters.Remove('Body')
    }
    if (-not $ExpectedCode -and $Expected -eq 200) { $ExpectedCode = 'OK' }
    Check $Case ([int]$response.StatusCode -eq $Expected -and (-not $ExpectedCode -or $json.code -ceq $ExpectedCode))
    return $json
}
function Session-Id([Microsoft.PowerShell.Commands.WebRequestSession]$session) {
    $cookie = $session.Cookies.GetCookies($BaseUri)['JSESSIONID']
    if ($null -ne $cookie) { return $cookie.Value }
    return $null
}
function Start-Login([string]$label, [string]$username, [Security.SecureString]$secret,
                     [string]$role, [switch]$VerifyRotation) {
    $session = [Microsoft.PowerShell.Commands.WebRequestSession]::new()
    $challenge = (Invoke-Api "$label CSRF bootstrap" $session '/api/auth/csrf').data.csrfToken
    $before = Session-Id $session
    if ($VerifyRotation) {
        Check "$label anonymous cookie issued" (-not [string]::IsNullOrWhiteSpace($before))
        $null = Invoke-Api "$label login without CSRF" $session '/api/auth/login' -Method POST -Body @{ username=$username } -Secret $secret -Expected 403 -ExpectedCode 'CSRF_INVALID'
    }
    $signed = (Invoke-Api "$label login" $session '/api/auth/login' -Method POST -Csrf $challenge -Body @{ username=$username } -Secret $secret).data
    Check "$label authenticated identity" ($signed.user.role -ceq $role -and $signed.user.username -ceq $username)
    if ($VerifyRotation) {
        $after = Session-Id $session
        Check "$label session ID and CSRF rotated" ($after -and $after -cne $before -and $signed.csrfToken -cne $challenge)
        $oldSession = [Microsoft.PowerShell.Commands.WebRequestSession]::new()
        $oldSession.Cookies.Add([Net.Cookie]::new('JSESSIONID', $before, '/', $BaseUri.Host))
        $null = Invoke-Api "$label pre-login cookie cannot replay" $oldSession '/api/auth/me' -Expected 401 -ExpectedCode 'AUTH_REQUIRED'
        $null = Invoke-Api "$label stale CSRF rejected" $session '/api/auth/logout' -Method POST -Csrf $challenge -Expected 403 -ExpectedCode 'CSRF_INVALID'
    }
    return [pscustomobject]@{ Session=$session; Csrf=$signed.csrfToken; User=$signed.user }
}
function New-Record($actor, [string]$resource, [string]$suffix, [hashtable]$body, [Security.SecureString]$secret) {
    $entry = (Invoke-Api "create $resource $suffix" $actor.Session "/api/$resource" -Method POST -Csrf $actor.Csrf -Body $body -Secret $secret).data
    $created.Add([pscustomobject]@{ resource=$resource; id=$entry.id; fixture=$suffix; state='CREATED' })
    return $entry
}
function Update-Record($actor, [string]$resource, [long]$id, [hashtable]$body) {
    return (Invoke-Api "update $resource" $actor.Session "/api/$resource/$id" -Method PUT -Csrf $actor.Csrf -Body $body).data
}
function Delete-TestRecord($actor, [string]$resource, [long]$id, [int]$expected = 200) {
    $null = Invoke-Api "delete $resource expected $expected" $actor.Session "/api/$resource/$id" -Method DELETE -Csrf $actor.Csrf -Expected $expected
    if ($expected -eq 200) {
        foreach ($entry in ($created | Where-Object { $_.resource -eq $resource -and $_.id -eq $id })) {
            $entry.state = 'DELETED'
        }
    }
}
function Find-AuditEvents($admin, [string]$resource, [string]$action, [long]$id) {
    $page = 1
    do {
        $query = "/api/operation-logs?actorId=$($admin.User.id)&resource=$resource&action=$action&page=$page&pageSize=100"
        $body = (Invoke-Api "administrator audit page $resource/$action" $admin.Session $query).data
        foreach ($row in $body.list) { if ($row.targetId -eq $id) { $row } }
        $page++
    } while (($page - 1) * 100 -lt $body.total)
}
function Get-AuditTotal($admin, [string]$resource, [string]$action) {
    $query = "/api/operation-logs?actorId=$($admin.User.id)&resource=$resource&action=$action&page=1&pageSize=1"
    return (Invoke-Api "administrator audit total $resource/$action" $admin.Session $query).data.total
}

$eastPassword = New-RuntimePassword
$westPassword = New-RuntimePassword
$invalidPassword = New-RuntimePassword
try {
    $anonymous = [Microsoft.PowerShell.Commands.WebRequestSession]::new()
    $null = Invoke-Api 'anonymous records rejected' $anonymous '/api/products' -Expected 401 -ExpectedCode 'AUTH_REQUIRED'
    $wrongToken = (Invoke-Api 'failed-login CSRF bootstrap' $anonymous '/api/auth/csrf').data.csrfToken
    $null = Invoke-Api 'invalid credential rejected' $anonymous '/api/auth/login' -Method POST -Csrf $wrongToken -Body @{ username=$AdminUsername } -Secret $invalidPassword -Expected 401 -ExpectedCode 'LOGIN_FAILED'

    $admin = Start-Login 'ADMIN' $AdminUsername $AdminPassword ADMIN -VerifyRotation
    $adminMe = (Invoke-Api 'current administrator' $admin.Session '/api/auth/me').data.user
    Check 'administrator identity matches session' ($adminMe.id -eq $admin.User.id -and $adminMe.role -ceq 'ADMIN')

    $deptA = New-Record $admin 'departments' 'east' @{ name="$marker 东部"; enabled=$true }
    $deptB = New-Record $admin 'departments' 'west' @{ name="$marker 西部"; enabled=$true }
    $spareDept = New-Record $admin 'departments' 'disposable' @{ name="$marker 临时部门"; enabled=$true }
    $null = Invoke-Api 'department detail' $admin.Session "/api/departments/$($spareDept.id)"
    $null = Update-Record $admin 'departments' $spareDept.id @{ name="$marker 临时部门改"; enabled=$false }
    Delete-TestRecord $admin 'departments' $spareDept.id
    $null = Invoke-Api 'deleted department absent' $admin.Session "/api/departments/$($spareDept.id)" -Expected 404
    $filter = [uri]::EscapeDataString($marker)
    $pageOne = (Invoke-Api 'department page 1' $admin.Session "/api/departments?q=$filter&page=1&pageSize=1").data
    $pageTwo = (Invoke-Api 'department page 2' $admin.Session "/api/departments?q=$filter&page=2&pageSize=1").data
    Check 'page total and distinct rows' ($pageOne.total -eq 2 -and $pageTwo.total -eq 2 -and
        $pageOne.page -eq 1 -and $pageTwo.page -eq 2 -and $pageOne.list.Count -eq 1 -and
        $pageTwo.list.Count -eq 1 -and $pageOne.list[0].id -ne $pageTwo.list[0].id)
    $null = Invoke-Api 'invalid page size' $admin.Session '/api/departments?pageSize=101' -Expected 400 -ExpectedCode 'INVALID_PAGE'

    $empA = New-Record $admin 'employees' 'east' @{ employeeNo="$fixtureToken-E"; name="$marker 员工甲"; departmentId=$deptA.id; status='ACTIVE' }
    $empB = New-Record $admin 'employees' 'west' @{ employeeNo="$fixtureToken-W"; name="$marker 员工乙"; departmentId=$deptB.id; status='ACTIVE' }
    $spareEmp = New-Record $admin 'employees' 'disposable' @{ employeeNo="$fixtureToken-T"; name="$marker 临时员工"; departmentId=$deptA.id; status='ACTIVE' }
    $null = Invoke-Api 'employee detail' $admin.Session "/api/employees/$($spareEmp.id)"
    $null = Update-Record $admin 'employees' $spareEmp.id @{ employeeNo="$fixtureToken-T"; name="$marker 临时员工改"; departmentId=$deptA.id; status='INACTIVE' }
    Delete-TestRecord $admin 'employees' $spareEmp.id
    $null = Invoke-Api 'deleted employee absent' $admin.Session "/api/employees/$($spareEmp.id)" -Expected 404

    $salesAInput = @{ username="ops-east-$fixtureToken"; displayName="$marker 业务员甲"; role='SALES'; enabled=$true; employeeId=$empA.id }
    $salesBInput = @{ username="ops-west-$fixtureToken"; displayName="$marker 业务员乙"; role='SALES'; enabled=$true; employeeId=$empB.id }
    $accountA = New-Record $admin 'users' 'east' $salesAInput $eastPassword
    $accountB = New-Record $admin 'users' 'west' $salesBInput $westPassword
    $userView = (Invoke-Api 'account detail' $admin.Session "/api/users/$($accountA.id)").data
    Check 'account view contains no password field' (@($userView.PSObject.Properties.Name | Where-Object { $_ -match 'password|secret|hash' }).Count -eq 0)
    $east = Start-Login 'SALES East' $salesAInput.username $eastPassword SALES
    $west = Start-Login 'SALES West' $salesBInput.username $westPassword SALES
    Check 'sales accounts bind different employees' ($east.User.employeeId -eq $empA.id -and $west.User.employeeId -eq $empB.id)
    foreach ($path in @('/api/employees','/api/users','/api/operation-logs','/api/departments')) {
        $null = Invoke-Api "sales forbidden $path" $east.Session $path -Expected 403 -ExpectedCode 'FORBIDDEN'
    }
    $options = (Invoke-Api 'sales department options' $east.Session '/api/departments/options').data
    $matching = @($options | Where-Object id -eq $deptA.id)
    Check 'department option contains only id and name' ($matching.Count -eq 1 -and
        ((($matching[0].PSObject.Properties.Name | Sort-Object) -join ',') -ceq 'id,name'))

    $customerA = New-Record $east 'customers' 'east' @{ name="$marker 客户甲"; enabled=$true }
    $customerB = New-Record $west 'customers' 'west' @{ name="$marker 客户乙"; enabled=$true }
    Check 'customer owner set from session' ($customerA.ownerId -eq $empA.id -and $customerB.ownerId -eq $empB.id)
    $null = Invoke-Api 'sales reads own customer' $east.Session "/api/customers/$($customerA.id)"
    $ownPage = (Invoke-Api 'sales own customer list' $east.Session "/api/customers?q=$filter").data
    $adminPage = (Invoke-Api 'administrator customer list' $admin.Session "/api/customers?q=$filter").data
    Check 'sales and administrator see different scopes' ($ownPage.total -eq 1 -and $ownPage.list[0].id -eq $customerA.id -and $adminPage.total -eq 2)
    $null = Invoke-Api 'east cannot read west customer' $east.Session "/api/customers/$($customerB.id)" -Expected 404
    $null = Invoke-Api 'west cannot read east customer' $west.Session "/api/customers/$($customerA.id)" -Expected 404
    $null = Invoke-Api 'cross-owner list blocked' $east.Session "/api/customers?ownerId=$($empB.id)" -Expected 403
    $null = Invoke-Api 'forged owner blocked' $east.Session '/api/customers' -Method POST -Csrf $east.Csrf -Body @{ name="$marker 越权"; ownerId=$empB.id; enabled=$true } -Expected 403
    $null = Invoke-Api 'cross-owner update blocked' $east.Session "/api/customers/$($customerB.id)" -Method PUT -Csrf $east.Csrf -Body @{ name="$marker 越权"; enabled=$true } -Expected 404
    $null = Update-Record $east 'customers' $customerA.id @{ name="$marker 客户甲改"; enabled=$true }
    $null = Invoke-Api 'sales cannot delete own customer' $east.Session "/api/customers/$($customerA.id)" -Method DELETE -Csrf $east.Csrf -Expected 403
    $spareCustomer = New-Record $admin 'customers' 'disposable' @{ name="$marker 临时客户"; ownerId=$empA.id; enabled=$true }
    Delete-TestRecord $admin 'customers' $spareCustomer.id
    $null = Invoke-Api 'deleted customer absent' $admin.Session "/api/customers/$($spareCustomer.id)" -Expected 404

    $productBody = @{ sku="OPS-$fixtureToken"; name="$marker 产品"; unitPrice=19.90; enabled=$true }
    $bad = Invoke-Api 'invalid form fields rejected' $admin.Session '/api/products' -Method POST -Csrf $admin.Csrf -Body @{sku='';name='';unitPrice=-1;enabled=$true} -Expected 400
    Check 'field-specific server errors' ($bad.fieldErrors.sku -and $bad.fieldErrors.unitPrice)
    $product = New-Record $admin 'products' 'disposable' $productBody
    $null = Invoke-Api 'sales can read product' $east.Session "/api/products/$($product.id)"
    $null = Invoke-Api 'sales cannot write product' $east.Session "/api/products/$($product.id)" -Method PUT -Csrf $east.Csrf -Body $productBody -Expected 403
    $productBody['name'] = "$marker 产品更新"
    $productBody['unitPrice'] = 21.50
    $updated = Update-Record $admin 'products' $product.id $productBody
    Check 'decimal price and updated name persisted' ([decimal]$updated.unitPrice -eq 21.50 -and $updated.name -ceq $productBody.name)
    $createLogsBefore = @(Find-AuditEvents $admin PRODUCT CREATE $product.id)
    $updateLogs = @(Find-AuditEvents $admin PRODUCT UPDATE $product.id)
    Check 'one create and one update audit' ($createLogsBefore.Count -eq 1 -and $updateLogs.Count -eq 1 -and
        $updateLogs[0].before.name -ceq "$marker 产品" -and $updateLogs[0].after.name -ceq $productBody.name)
    $allProductCreatesBefore = Get-AuditTotal $admin PRODUCT CREATE
    $null = Invoke-Api 'unique SKU rejected' $admin.Session '/api/products' -Method POST -Csrf $admin.Csrf -Body $productBody -Expected 409
    $productList = (Invoke-Api 'failed write leaves one product' $admin.Session "/api/products?q=$filter").data
    $createLogsAfter = @(Find-AuditEvents $admin PRODUCT CREATE $product.id)
    $allProductCreatesAfter = Get-AuditTotal $admin PRODUCT CREATE
    Check 'failed product request does not change row or add audit' ($productList.total -eq 1 -and
        $productList.list[0].id -eq $product.id -and $createLogsAfter.Count -eq $createLogsBefore.Count -and
        $allProductCreatesAfter -eq $allProductCreatesBefore)
    Delete-TestRecord $admin 'products' $product.id
    $null = Invoke-Api 'deleted product absent' $admin.Session "/api/products/$($product.id)" -Expected 404
    $deleteLogs = @(Find-AuditEvents $admin PRODUCT DELETE $product.id)
    Check 'product delete audited once' ($deleteLogs.Count -eq 1 -and $deleteLogs[0].before.id -eq $product.id)

    $departmentDeleteBefore = @(Find-AuditEvents $admin DEPARTMENT DELETE $deptA.id)
    $employeeDeleteBefore = @(Find-AuditEvents $admin EMPLOYEE DELETE $empA.id)
    Delete-TestRecord $admin 'departments' $deptA.id 409
    Delete-TestRecord $admin 'employees' $empA.id 409
    $null = Invoke-Api 'referenced department remains' $admin.Session "/api/departments/$($deptA.id)"
    $null = Invoke-Api 'referenced employee remains' $admin.Session "/api/employees/$($empA.id)"
    $departmentDeleteAfter = @(Find-AuditEvents $admin DEPARTMENT DELETE $deptA.id)
    $employeeDeleteAfter = @(Find-AuditEvents $admin EMPLOYEE DELETE $empA.id)
    Check 'rejected reference deletes have no success audit' ($departmentDeleteAfter.Count -eq $departmentDeleteBefore.Count -and
        $employeeDeleteAfter.Count -eq $employeeDeleteBefore.Count)

    if ($null -ne $ConfirmedOrderReferences) {
        $referenceMarker = [string]$ConfirmedOrderReferences.marker
        Check 'order fixtures are an explicit demonstration batch' ($referenceMarker -match '^课程演示验收-[0-9A-Za-z-]{8,40}$')
        foreach ($resource in @('customers','employees','products')) {
            $resourceId = [long]$ConfirmedOrderReferences[$resource]
            Check "positive demo reference ID $resource" ($resourceId -gt 0)
            $row = (Invoke-Api "confirm marked order reference $resource" $admin.Session "/api/$resource/$resourceId").data
            Check "exact order reference marker $resource" ($row.name -ceq $referenceMarker)
            Delete-TestRecord $admin $resource $resourceId 409
        }
    } else {
        Skip 'order-linked archive protection over HTTP' 'Needs separately approved and SQL-verified demo order references.'
    }
    Skip 'inject audit insert failure during HTTP write' 'No safe stage 1 fault-injection entry point; SQL rollback and HTTP conflict are distinct checks.'

    $accountBodyA = @{ displayName=$salesAInput.displayName; role='ADMIN'; enabled=$true; employeeId=$empA.id }
    $null = Update-Record $admin 'users' $accountA.id $accountBodyA
    $null = Invoke-Api 'role change invalidates old sales session' $east.Session '/api/auth/me' -Expected 401 -ExpectedCode 'AUTH_REQUIRED'
    $accountBodyA['role'] = 'SALES'
    $accountBodyA['enabled'] = $false
    $null = Update-Record $admin 'users' $accountA.id $accountBodyA
    ($created | Where-Object { $_.resource -eq 'users' -and $_.id -eq $accountA.id }).state = 'DISABLED'
    $accountBodyB = @{ displayName=$salesBInput.displayName; role='SALES'; enabled=$false; employeeId=$empB.id }
    $null = Update-Record $admin 'users' $accountB.id $accountBodyB
    $null = Invoke-Api 'disabled account invalidates old sales session' $west.Session '/api/auth/me' -Expected 401 -ExpectedCode 'AUTH_REQUIRED'
    ($created | Where-Object { $_.resource -eq 'users' -and $_.id -eq $accountB.id }).state = 'DISABLED'
    $disabledSession = [Microsoft.PowerShell.Commands.WebRequestSession]::new()
    $disabledToken = (Invoke-Api 'disabled login CSRF bootstrap' $disabledSession '/api/auth/csrf').data.csrfToken
    $null = Invoke-Api 'disabled login rejected' $disabledSession '/api/auth/login' -Method POST -Csrf $disabledToken -Body @{username=$salesBInput.username} -Secret $westPassword -Expected 401 -ExpectedCode 'LOGIN_FAILED'
    $null = Invoke-Api 'administrator logout' $admin.Session '/api/auth/logout' -Method POST -Csrf $admin.Csrf
    $null = Invoke-Api 'logout prevents session reuse' $admin.Session '/api/auth/me' -Expected 401 -ExpectedCode 'AUTH_REQUIRED'
} finally {
    $eastPassword.Dispose()
    $westPassword.Dispose()
    $invalidPassword.Dispose()
    [pscustomobject]@{ fixture=$marker; cases=$outcomes.ToArray(); created=$created.ToArray() } | ConvertTo-Json -Depth 8
}
