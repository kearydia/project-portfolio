# Run only against the explicitly approved isolated copy. Script starts no service.
[CmdletBinding()]
param(
    [string]$Schema,
    [uri]$Origin='http://127.0.0.1:8080/',
    [string]$AdminUsername,
    [Security.SecureString]$AdminSecret,
    [switch]$RunIsolatedCases,
    [switch]$ConfirmIsolatedRecovery
)
$ErrorActionPreference='Stop'
$VerbosePreference='SilentlyContinue'
$DebugPreference='SilentlyContinue'
if (-not $RunIsolatedCases -or $Schema -notmatch '\Aenterprise_ops_course_20261123_s1_[0-9]{6,12}\z' -or
    $Origin.Host -ne '127.0.0.1' -or $Origin.Scheme -notin @('http','https') -or $Origin.UserInfo -or
    $Origin.AbsolutePath -ne '/' -or $Origin.Fragment -or $Origin.Query -or
    -not $AdminUsername -or -not $AdminSecret -or $AdminSecret.Length -eq 0) {
    throw '需同一进程内的应用管理员对象、独立测试库与显式执行授权。'
}
$marker='课程演示验收-' + [guid]::NewGuid().ToString('N').Substring(0,8)
$ledger=[Collections.Generic.List[object]]::new()
$clients=[Collections.Generic.List[object]]::new()
function Open-Client {
    $handler=[Net.Http.HttpClientHandler]::new()
    $handler.UseProxy=$false
    $handler.AllowAutoRedirect=$false
    $client=[Net.Http.HttpClient]::new($handler)
    $client.Timeout=[TimeSpan]::FromSeconds(120)
    $profile=@{Client=$client;Csrf=$null}
    $clients.Add($profile)
    return $profile
}
function Request($who,[string]$method,[string]$path,[int]$expected,[string]$label,$body=$null,
                 [Security.SecureString]$password=$null,[byte[]]$upload=$null,[switch]$Binary) {
    if (-not $path.StartsWith('/api/')) { throw '仅允许同一课程 API。' }
    $request=[Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::new($method),[uri]::new($Origin,$path))
    $reply=$null
    $bstr=[IntPtr]::Zero
    $data=$null
    try {
        if ($who.Csrf) { $null=$request.Headers.TryAddWithoutValidation('X-CSRF-Token',$who.Csrf) }
        if ($null -ne $upload) {
            $multipart=[Net.Http.MultipartFormDataContent]::new()
            $multipart.Add([Net.Http.ByteArrayContent]::new($upload),'file','course-test.zip')
            $request.Content=$multipart
        } elseif ($null -ne $body) {
            $data=$body.Clone()
            if ($password) {
                $bstr=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
                $data['password']=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
            }
            $request.Content=[Net.Http.StringContent]::new(($data | ConvertTo-Json -Compress -Depth 12),[Text.Encoding]::UTF8,'application/json')
        }
        $reply=$who.Client.Send($request)
        $code=[int]$reply.StatusCode
        $ledger.Add([pscustomobject]@{case=$label;expected=$expected;actual=$code;status=if($code -eq $expected){'PASS'}else{'FAIL'}})
        if ($code -ne $expected) { throw 'Unexpected HTTP status' }
        if ($Binary) { return ,($reply.Content.ReadAsByteArrayAsync().GetAwaiter().GetResult()) }
        $json=$reply.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
        return $json.data
    } catch {
        throw "HTTP 测项 $label 未通过，未输出应答正文。"
    } finally {
        if ($data) { $data.Clear() }
        if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
        if ($reply) { $reply.Dispose() }
        $request.Dispose()
    }
}
function Check([string]$label,[bool]$valid) {
    $ledger.Add([pscustomobject]@{case=$label;status=if($valid){'PASS'}else{'FAIL'}})
    if (-not $valid) { throw "测试断言失败 $label" }
}
function Login([string]$name,[Security.SecureString]$secret,[string]$role) {
    $who=Open-Client
    $who.Csrf=(Request $who GET '/api/auth/csrf' 200 'CSRF challenge').csrfToken
    $login=Request $who POST '/api/auth/login' 200 "$role login" @{username=$name} $secret
    Check "$role identity" ($login.user.role -ceq $role)
    $who.Csrf=$login.csrfToken
    return $who
}
function New-SessionSecret {
    $bytes=[byte[]]::new(24)
    [Security.Cryptography.RandomNumberGenerator]::Fill($bytes)
    try {
        $result=[Security.SecureString]::new()
        foreach($character in [Convert]::ToHexString($bytes).ToCharArray()) { $result.AppendChar($character) }
        $result.MakeReadOnly()
        return $result
    } finally { [Array]::Clear($bytes,0,$bytes.Length) }
}
function Read-ZipText([byte[]]$bytes,[string]$entry) {
    $stream=[IO.MemoryStream]::new($bytes)
    $zip=[IO.Compression.ZipArchive]::new($stream,[IO.Compression.ZipArchiveMode]::Read)
    try {
        $part=$zip.GetEntry($entry)
        if (-not $part) { throw '归档缺少预期条目。' }
        $reader=[IO.StreamReader]::new($part.Open(),[Text.Encoding]::UTF8)
        try { return $reader.ReadToEnd() } finally { $reader.Dispose() }
    } finally { $zip.Dispose(); $stream.Dispose() }
}
$salesSecret=New-SessionSecret
$otherSecret=New-SessionSecret
try {
    $admin=Login $AdminUsername $AdminSecret ADMIN
    $target=Request $admin GET '/api/maintenance/target' 200 'verify active isolated schema'
    Check 'test copy exact match' ($target.base -ceq $Schema -and $target.active -ceq $Schema)
    $d=Request $admin POST '/api/departments' 200 'department A' @{name="$marker 部门甲";enabled=$true}
    $d2=Request $admin POST '/api/departments' 200 'department B' @{name="$marker 部门乙";enabled=$true}
    $e=Request $admin POST '/api/employees' 200 'employee A' @{employeeNo="$marker-A";name="$marker 经办甲";departmentId=$d.id;status='ACTIVE'}
    $e2=Request $admin POST '/api/employees' 200 'employee B' @{employeeNo="$marker-B";name="$marker 经办乙";departmentId=$d2.id;status='ACTIVE'}
    $username='course-' + [guid]::NewGuid().ToString('N').Substring(0,12)
    $otherName=$username+'-b'
    $null=Request $admin POST '/api/users' 200 'account A' @{username=$username;displayName="$marker 业务员甲";role='SALES';enabled=$true;employeeId=$e.id} $salesSecret
    $null=Request $admin POST '/api/users' 200 'account B' @{username=$otherName;displayName="$marker 业务员乙";role='SALES';enabled=$true;employeeId=$e2.id} $otherSecret
    $a=Login $username $salesSecret SALES
    $b=Login $otherName $otherSecret SALES
    $customer=Request $a POST '/api/customers' 200 'customer A' @{name="$marker 客户";enabled=$true}
    $product=Request $admin POST '/api/products' 200 'product fixture' @{sku="$marker-SKU";name="$marker 产品";unitPrice=11.26;enabled=$true}
    $date=[TimeZoneInfo]::ConvertTimeBySystemTimeZoneId([DateTimeOffset]::UtcNow,'China Standard Time').ToString('yyyy-MM-dd')
    $body=@{businessDate=$date;customerId=$customer.id;items=@(@{productId=$product.id;quantity=2},@{productId=$product.id;quantity=3})}
    $order=Request $a POST '/api/orders' 200 'same-SKU two-line order' $body
    $id=$order.order.id
    $amount=[decimal]$product.unitPrice*5
    Check 'two line identifiers and exact value' ($order.items.Count -eq 2 -and $order.items[0].lineId -ne $order.items[1].lineId -and [decimal]$order.order.totalAmount -eq $amount)
    $null=Request $b GET "/api/orders/$id" 404 'other salesperson cannot see order'
    $null=Request $a PUT "/api/orders/$id" 403 'sales cannot amend' $body
    $null=Request $a POST "/api/orders/$id/void" 403 'sales cannot void' @{expectedVersion=0;reason='课程演示'}
    $filter=@{customerName=$marker;departmentId=$d.id;dateFrom=$date;dateTo=$date}
    $q=[uri]::EscapeDataString($marker)
    $stats=Request $a GET "/api/stats/overview?customerName=$q&departmentId=$($d.id)&dateFrom=$date&dateTo=$date" 200 'scope dashboard'
    Check 'amount agrees and no employee rank to sales' ([decimal]$stats.effective.amount -eq $amount -and $null -eq $stats.employeeRanking)
    [byte[]]$xlsx=Request $a POST '/api/orders/export' 200 'own orders XLSX' $filter -Binary
    Check 'XLSX sheets, status and exact amount' ((Read-ZipText $xlsx 'xl/worksheets/sheet1.xml').Contains($amount.ToString('0.00',[CultureInfo]::InvariantCulture)) -and
        (Read-ZipText $xlsx 'xl/worksheets/sheet2.xml').Contains('有效'))
    $closed=Request $admin POST "/api/orders/$id/void" 200 'admin voids' @{expectedVersion=$order.order.version;reason='课程演示统计核对'}
    $vstats=Request $a GET "/api/stats/overview?customerName=$q&departmentId=$($d.id)&dateFrom=$date&dateTo=$date" 200 'voided status dashboard'
    Check 'voided order contributes zero' ([decimal]$vstats.effective.amount -eq 0)
    $null=Request $admin DELETE "/api/products/$($product.id)" 409 'void order still protects product'
    $null=Request $admin POST "/api/orders/$id/unvoid" 409 'stale version rejected' @{expectedVersion=$order.order.version;reason='课程演示'}
    $null=Request $admin POST "/api/orders/$id/unvoid" 200 'admin unvoids' @{expectedVersion=$closed.order.version;reason='课程演示'}
    $again=Request $a GET "/api/orders?customerName=$q&departmentId=$($d.id)&dateFrom=$date&dateTo=$date&pageSize=1" 200 'reconciled filtered listing'
    Check 'unvoid restores effective total' ([decimal]$again.effectiveTotal -eq $amount)
    $unused=Request $admin POST '/api/products' 200 'unreferenced cleanup fixture' @{sku="$marker-CLEAN";name="$marker 临时品";unitPrice=1.1;enabled=$true}
    $null=Request $admin POST '/api/maintenance/batch-update' 200 'batch sets inactive' @{kind='PRODUCT';status='DISABLED';ids=@($unused.id)}
    $preview=Request $admin POST '/api/maintenance/cleanup-preview' 200 'cleanup preview only' @{kind='PRODUCT'}
    Check 'new disposable product is a candidate' ($null -ne ($preview.eligible | Where-Object id -eq $unused.id))
    $null=Request $admin POST '/api/maintenance/cleanup' 200 'cleanup disposable fixture only' @{kind='PRODUCT';token=$preview.token;ids=@($unused.id);confirmed=$true}
    $saved=Request $admin POST '/api/maintenance/backups' 200 'structured backup'
    [byte[]]$archive=Request $admin GET "/api/maintenance/backups/$($saved.id)/file" 200 'backup download' -Binary
    Check 'archive contains no password hash column' ((Read-ZipText $archive 'data.json') -notmatch '"password_hash"')
    $null=Request $admin POST '/api/maintenance/restores/preview' 400 'bad archive rejected' -upload ([byte[]](1,2,3))
    $same=Request $admin GET '/api/maintenance/target' 200 'unchanged after bad archive'
    Check 'invalid archive does not switch active schema' ($same.active -ceq $Schema)
    if ($ConfirmIsolatedRecovery) {
        $ready=Request $admin POST '/api/maintenance/restores/preview' 200 'valid archive preview' -upload $archive
        Check 'candidate suffix belongs to isolated test copy' ($ready.target -cmatch ('\A'+[regex]::Escape($Schema)+'_r_[a-f0-9]{16}\z'))
        $job=Request $admin POST '/api/maintenance/restores' 200 'restore isolated new schema' @{token=$ready.token;target=$ready.target;sha256=$ready.sha256;confirmed=$true}
        Check 'candidate created and cutover confirmed' ($job.state -eq 'COMPLETE' -and $job.source -ceq $Schema -and $job.target -ceq $ready.target)
        $null=Request $a GET '/api/auth/me' 401 'old session invalidated after cutover'
        $newAdmin=Login $AdminUsername $AdminSecret ADMIN
        $current=Request $newAdmin GET '/api/maintenance/target' 200 'relogin sees selected candidate'
        Check 'active candidate' ($current.active -ceq $ready.target)
    } else {
        $ledger.Add([pscustomobject]@{case='successful restore and cutover';status='SKIP';reason='No explicit isolated restore switch'})
    }
} finally {
    $salesSecret.Dispose()
    $otherSecret.Dispose()
    foreach($profile in $clients) { $profile.Client.Dispose() }
    [pscustomobject]@{schema=$Schema;fixture=$marker;cases=$ledger.ToArray()} | ConvertTo-Json -Depth 6
}
