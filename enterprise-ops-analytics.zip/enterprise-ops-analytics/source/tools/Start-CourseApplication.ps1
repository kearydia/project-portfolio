[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$DbUser,
    [string]$Schema = 'enterprise_ops_course_20261123_s1',
    [ValidateRange(1024,65535)][int]$Port = 8080,
    [string]$Jar,
    [switch]$InitializeAdmin,
    [string]$AdminUsername
)
$ErrorActionPreference = 'Stop'
if ($Schema -notmatch '\Aenterprise_ops_course_20261123_s1(?:_[0-9]+)?\z' -or
    $DbUser -notmatch '\A[A-Za-z0-9_.-]{1,64}\z' -or
    ($InitializeAdmin -and $AdminUsername -notmatch '\A[A-Za-z0-9_.-]{3,40}\z')) {
    throw '请指定精确课程库、合法 JDBC 账号及可选的初始应用管理员名。'
}
if (-not $PSBoundParameters.ContainsKey('Jar')) {
    $Jar = Join-Path $PSScriptRoot '..\backend\target\enterprise-ops-0.1.0-login-fix.jar'
    if (-not (Test-Path -LiteralPath $Jar -PathType Leaf)) {
        $Jar = Join-Path $PSScriptRoot '..\backend\target\enterprise-ops-0.1.0.jar'
    }
}
$jarPath = (Resolve-Path -LiteralPath $Jar -ErrorAction Stop).ProviderPath
$java = (Get-Command java.exe -ErrorAction Stop).Source

function Test-AdminSecret([Security.SecureString]$secret) {
    if ($null -eq $secret -or $secret.Length -lt 10 -or $secret.Length -gt 72) { return $false }
    $characters = [char[]]::new($secret.Length)
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
    try {
        [Runtime.InteropServices.Marshal]::Copy($ptr,$characters,0,$characters.Length)
        $hasContent = $false
        foreach ($character in $characters) {
            if (-not [char]::IsWhiteSpace($character)) { $hasContent = $true; break }
        }
        return $hasContent -and ([Text.Encoding]::UTF8.GetByteCount($characters,0,$characters.Length) -le 72)
    } finally {
        [Array]::Clear($characters,0,$characters.Length)
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}

function Send-SecureLine([IO.StreamWriter]$stream,[Security.SecureString]$secret) {
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret)
    try {
        for ($i=0; $i -lt $secret.Length; $i++) {
            $value=[Runtime.InteropServices.Marshal]::ReadInt16($ptr, $i * 2)
            $stream.Write([char]($value -band 0xffff))
        }
        $stream.WriteLine()
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}
$dbSecret = $null
$adminSecret = $null
$process = $null
try {
    $dbSecret = Read-Host "输入 MySQL 数据库密码（账号 $DbUser，网页登录密码稍后在网页里输入）" -AsSecureString
    if ($dbSecret.Length -eq 0 -or $dbSecret.Length -gt 256) { throw 'JDBC 口令为空或过长。' }
    if ($InitializeAdmin) {
        while ($true) {
            $adminSecret = Read-Host '为 course-admin 新设网页登录密码（至少 10 个字符，最多 72 个 UTF-8 字节）' -AsSecureString
            if (Test-AdminSecret $adminSecret) { break }
            if ($adminSecret) { $adminSecret.Dispose(); $adminSecret = $null }
            Write-Host '请重新设置网页登录密码。建议使用 12 个以上的英文字母、数字或符号，不能全为空格。' -ForegroundColor Yellow
        }
    }
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $java
    $start.WorkingDirectory = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).ProviderPath
    $start.UseShellExecute = $false
    $start.RedirectStandardInput = $true
    $start.StandardInputEncoding=[Text.UTF8Encoding]::new($false)
    foreach ($argument in @('-jar',$jarPath,'--course-stdin')) { $start.ArgumentList.Add($argument) }
    foreach ($key in @('OPS_DB_SCHEMA','OPS_DB_USER','OPS_DB_PASSWORD','OPS_BOOTSTRAP_NAME',
        'OPS_BOOTSTRAP_PASSWORD','OPS_BOOTSTRAP_ENABLED','OPS_DEMO_SEED','OPS_DEMO_ADMIN_PASSWORD',
        'OPS_DEMO_EAST_PASSWORD','OPS_DEMO_WEST_PASSWORD','SPRING_APPLICATION_JSON','JAVA_TOOL_OPTIONS',
        'JDK_JAVA_OPTIONS','_JAVA_OPTIONS','MYSQL_PWD')) { $null=$start.Environment.Remove($key) }
    $start.Environment['OPS_PORT'] = $Port.ToString()
    $process = [Diagnostics.Process]::Start($start)
    $writer = $process.StandardInput
    try {
        $writer.WriteLine($Schema)
        $writer.WriteLine($DbUser)
        Send-SecureLine $writer $dbSecret
        if ($InitializeAdmin) {
            $writer.WriteLine($AdminUsername)
            Send-SecureLine $writer $adminSecret
        } else {
            $writer.WriteLine()
            $writer.WriteLine()
        }
    } finally {
        $writer.Dispose()
    }
    $dbSecret.Dispose()
    $dbSecret = $null
    if ($adminSecret) { $adminSecret.Dispose(); $adminSecret = $null }
    while (-not $process.WaitForExit(250)) {}
    exit $process.ExitCode
} finally {
    if ($dbSecret) { $dbSecret.Dispose() }
    if ($adminSecret) { $adminSecret.Dispose() }
    if ($process) {
        if (-not $process.HasExited) { $process.Kill(); $process.WaitForExit() }
        $process.Dispose()
    }
}
