<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { onBeforeRouteLeave } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { api, money, session, statusText } from '../api.js'

const props = defineProps({ resource: { type: String, required: true } })
const admin = computed(() => session.user?.role === 'ADMIN')
const config = {
  customers: { name: '客户', cols: [['name','名称'],['ownerId','负责人'],['enabled','状态']],
    form:[['name','客户名称','text'],['ownerId','负责人','owner'],['enabled','状态','toggle']] },
  products: { name: '产品', cols:[['sku','货号'],['name','名称'],['unitPrice','单价（元）'],['enabled','状态']],
    form:[['sku','货号','text'],['name','产品名称','text'],['unitPrice','单价（元）','money'],['enabled','在售状态','toggle']] },
  employees: { name:'员工', cols:[['employeeNo','员工编号'],['name','姓名'],['departmentId','部门'],['status','在职状态']],
    form:[['employeeNo','员工编号','text'],['name','姓名','text'],['departmentId','部门','department'],['status','在职状态','employment']] },
  departments: { name:'部门', cols:[['name','名称'],['enabled','状态']], form:[['name','部门名称','text'],['enabled','启用状态','toggle']] },
  users: { name:'账号', cols:[['username','账号'],['displayName','姓名'],['role','角色'],['employeeId','绑定员工'],['enabled','状态']],
    form:[['username','账号','identity'],['displayName','显示姓名','text'],['password','初始密码','password'],['role','角色','role'],
      ['employeeId','绑定员工','owner'],['enabled','状态','toggle']] }
}
const meta = computed(() => config[props.resource])
const canWrite = computed(() => admin.value || props.resource === 'customers')
const query = ref(''), page = ref(1), size = ref(10), data = ref({ list: [], total: 0 })
const loading = ref(false), issue = ref(''), formError = ref(''), errors = ref({}), dialog = ref(false), saving = ref(false)
const departments = ref([]), staff = ref([])
const initial = ref(''), id = ref(null), viewOnly = ref(false), form = reactive({})
const visibleFields = computed(() => meta.value.form.filter(([, ,type]) =>
  !(type === 'password' && (id.value || viewOnly.value)) && !(type === 'owner' && !admin.value)))
async function refresh(reset = false) {
  if (reset) page.value = 1
  loading.value = true
  issue.value = ''
  try { data.value = await api('/' + props.resource, { params: { q: query.value, page: page.value, pageSize: size.value } }) }
  catch (error) { issue.value = error.message }
  finally { loading.value = false }
}
async function staffLookup(q) {
  try { staff.value = (await api('/employees', { params: { q, pageSize: 100 } })).list }
  catch (error) { ElMessage.error(error.message) }
}
onMounted(async () => {
  refresh()
  try {
    if (props.resource === 'employees') departments.value = await api('/departments/options')
    if (admin.value && ['customers', 'users'].includes(props.resource)) staffLookup()
  } catch (error) { issue.value = error.message }
})
function display(row, key) {
  const v = row[key]
  if (v == null) return '—'
  if (key === 'unitPrice') return money(v)
  if (key === 'enabled') return v ? (props.resource==='products'?'在售':'启用') : (props.resource==='products'?'停售':'停用')
  if (key === 'departmentId') return departments.value.find(x => x.id === v)?.name || v
  if (['employeeId','ownerId'].includes(key)) return staff.value.find(x => x.id === v)?.name || (v === session.user?.employeeId ? '本人' : v)
  if (key === 'status' && v === 'ACTIVE') return '在职'
  return ['role','status'].includes(key) ? (statusText[v] || v) : v
}
async function show(row, view = false) {
  try {
    const source = row ? await api('/' + props.resource + '/' + row.id) : null
    id.value = source?.id ?? null
    viewOnly.value = view
    for (const key of Object.keys(form)) delete form[key]
    for (const [key, ,type] of meta.value.form) {
      form[key] = source?.[key] ?? (type === 'toggle' ? true : type === 'employment' ? 'ACTIVE' : type === 'role' ? 'SALES' :
        ['owner','department','money'].includes(type) ? null : '')
    }
    initial.value = JSON.stringify(form)
    errors.value = {}
    formError.value = ''
    dialog.value = true
  } catch (error) { ElMessage.error(error.message) }
}
async function mayLeave() {
  if (!session.user || !dialog.value || viewOnly.value || initial.value === JSON.stringify(form)) return true
  try { await ElMessageBox.confirm('有未保存的修改，确认放弃？', '离开编辑'); return true }
  catch { return false }
}
onBeforeRouteLeave(mayLeave)
async function close(done) {
  if (!saving.value && await mayLeave()) {
    if (done) done(); else dialog.value = false
    if (form.password) form.password = ''
  }
}
async function submit() {
  if (saving.value || viewOnly.value) return
  errors.value = {}
  formError.value = ''
  const body = {}
  for (const [key,label,type] of visibleFields.value) {
    if (type === 'identity' && id.value) continue
    const v = form[key]
    if ((['text','identity','password'].includes(type) && !v?.trim()) || (['money','department'].includes(type) && v == null)
        || (type === 'owner' && v == null && (props.resource === 'customers' || form.role === 'SALES'))) {
      errors.value[key] = '请填写' + label
    }
    body[key] = typeof v === 'string' && type !== 'password' ? v.trim() : v
  }
  if (Object.keys(errors.value).length) return
  saving.value = true
  try {
    await api('/' + props.resource + (id.value ? '/' + id.value : ''), { method: id.value ? 'PUT' : 'POST', data: body })
    if (form.password) form.password = ''
    initial.value = JSON.stringify(form)
    dialog.value = false
    ElMessage.success('已保存')
    refresh()
  } catch (error) { formError.value = error.message; errors.value = error.fields }
  finally { saving.value = false }
}
async function remove(row) {
  if (saving.value) return
  try { await ElMessageBox.confirm('确认删除所选' + meta.value.name + '？存在业务引用时系统会拒绝。', '删除确认', { type: 'warning' }) }
  catch { return }
  saving.value = true
  try {
    await api('/' + props.resource + '/' + row.id, { method: 'DELETE' })
    ElMessage.success('已删除')
    refresh(data.value.list.length === 1)
  } catch (error) { ElMessage.error(error.message) }
  finally { saving.value = false }
}
</script>
<template>
  <section class="card">
    <div class="controls"><el-form class="filters" @submit.prevent="refresh(true)">
      <el-input v-model="query" clearable placeholder="按关键词搜索" aria-label="关键词" />
      <el-button type="primary" native-type="submit">查询</el-button>
    </el-form><el-button v-if="canWrite" type="primary" @click="show()">新增{{ meta.name }}</el-button></div>
    <el-alert v-if="issue" :title="issue" type="error" show-icon :closable="false" />
    <el-table :data="data.list" v-loading="loading" empty-text="没有符合条件的记录">
      <el-table-column prop="id" label="编号" width="80" />
      <el-table-column v-for="[key,label] in meta.cols" :key="key" :label="label" min-width="110" :align="key === 'unitPrice' ? 'right' : 'left'">
        <template #default="{ row }">{{ display(row,key) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="160"><template #default="{ row }">
        <el-button link type="primary" @click="show(row,true)">查看</el-button><el-button v-if="canWrite" link type="primary" @click="show(row)">编辑</el-button>
        <el-button v-if="admin && resource !== 'users'" link type="danger" :disabled="saving" @click="remove(row)">删除</el-button>
      </template></el-table-column>
    </el-table>
    <div class="table-footer"><span>共 {{ data.total }} 条</span><el-pagination v-model:current-page="page" v-model:page-size="size" :page-sizes="[10,20,50,100]" :total="data.total" layout="sizes, prev, pager, next" @current-change="refresh()" @size-change="refresh(true)" /></div>
  </section>
  <el-dialog v-model="dialog" :title="(viewOnly ? '查看' : id ? '编辑' : '新增') + meta.name" width="min(90vw,560px)" :before-close="close" :close-on-click-modal="false">
    <el-alert v-if="formError" :title="formError" type="error" :closable="false" />
    <el-form label-width="100px" :disabled="viewOnly" @submit.prevent="submit">
      <el-form-item v-for="[key,label,type] in visibleFields" :key="key" :label="label" :error="errors[key]">
        <el-switch v-if="type === 'toggle'" v-model="form[key]" />
        <el-input-number v-else-if="type === 'money'" v-model="form[key]" :min="0" :precision="2" />
        <el-select v-else-if="type === 'role'" v-model="form[key]"><el-option value="SALES" label="普通业务员" /><el-option value="ADMIN" label="财务管理员" /></el-select>
        <el-select v-else-if="type === 'employment'" v-model="form[key]"><el-option value="ACTIVE" label="在职" /><el-option value="INACTIVE" label="停用" /><el-option value="LEFT" label="离职" /></el-select>
        <el-select v-else-if="type === 'owner'" v-model="form[key]" clearable filterable remote :remote-method="staffLookup">
          <el-option v-if="form[key] && !staff.some(x => x.id === form[key])" :value="form[key]" :label="'员工 ' + form[key]" disabled />
          <el-option v-for="e in staff" :key="e.id" :value="e.id" :label="e.name" :disabled="e.status !== 'ACTIVE' && e.id !== form[key]" />
        </el-select>
        <el-select v-else-if="type === 'department'" v-model="form[key]"><el-option v-for="d in departments" :key="d.id" :value="d.id" :label="d.name" /></el-select>
        <el-input v-else v-model="form[key]" :type="type === 'password' ? 'password' : 'text'" :autocomplete="type === 'password' ? 'new-password' : 'off'" :disabled="type === 'identity' && !!id" />
      </el-form-item>
    </el-form>
    <template #footer><el-button :disabled="saving" @click="close()">{{ viewOnly ? '关闭' : '取消' }}</el-button><el-button v-if="!viewOnly" type="primary" :loading="saving" @click="submit">保存</el-button></template>
  </el-dialog>
</template>
