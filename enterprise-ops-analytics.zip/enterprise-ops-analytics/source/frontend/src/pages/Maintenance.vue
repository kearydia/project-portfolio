<script setup>
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { api, download, session } from '../api.js'

const router = useRouter()
const names = { CUSTOMER: '客户', PRODUCT: '产品', EMPLOYEE: '员工' }
const resources = { CUSTOMER: 'customers', PRODUCT: 'products', EMPLOYEE: 'employees' }
const tab = ref('batch'), kind = ref('PRODUCT'), status = ref('DISABLED'), keyword = ref('')
const rows = ref([]), ids = ref([]), cleanupKind = ref('PRODUCT'), cleanupIds = ref([]), preview = ref()
const backups = ref([]), inputFile = ref(), selectedFile = ref(), restore = ref(), job = ref(), jobId = ref('')
const busy = ref(false), error = ref('')
const statuses = computed(() => kind.value === 'EMPLOYEE'
  ? [['ACTIVE','在职'],['INACTIVE','停用'],['LEFT','离职']]
  : [['ENABLED','启用 / 在售'],['DISABLED','停用 / 停售']])
async function run(callback) {
  if (busy.value) return
  error.value = ''
  busy.value = true
  try { await callback() } catch (problem) { error.value = problem.message }
  finally { busy.value = false }
}
async function relevant() {
  const result = await api('/' + resources[kind.value], { params: { q: keyword.value, pageSize: 100 } })
  ids.value = []
  rows.value = result.list
}
function setKind() { status.value = kind.value === 'EMPLOYEE' ? 'INACTIVE' : 'DISABLED'; run(relevant) }
async function batch() {
  if (!ids.value.length) return
  try { await ElMessageBox.confirm('对选中的 ' + ids.value.length + ' 条记录执行同一状态变更。任一记录失败则全部回滚。', '批量确认') }
  catch { return }
  run(async () => {
    const result = await api('/maintenance/batch-update', { method: 'POST', data: { kind: kind.value, status:status.value,ids:ids.value } })
    ElMessage.success('已更新 ' + result.updated + ' 条')
    await relevant()
  })
}
function inspectCleanup() {
  run(async () => {
    cleanupIds.value = []
    preview.value = await api('/maintenance/cleanup-preview', { method: 'POST', data: {kind:cleanupKind.value} })
  })
}
async function executeCleanup() {
  if (!preview.value || !cleanupIds.value.length) return
  try { await ElMessageBox.confirm('将删除选中的无引用失效档案。提交时会再次核对状态与历史引用。', '清理确认', {type:'warning'}) }
  catch { return }
  run(async () => {
    const input = {kind:cleanupKind.value,token:preview.value.token,ids:cleanupIds.value,confirmed:true}
    preview.value = undefined
    const result = await api('/maintenance/cleanup', { method: 'POST', data: input })
    ElMessage.success('已清理 ' + result.deleted + ' 条')
  })
}
async function listBackups() { backups.value = await api('/maintenance/backups') }
function makeBackup() {
  run(async () => { await api('/maintenance/backups',{method:'POST'}); await listBackups(); ElMessage.success('备份已生成') })
}
function fetchBackup(row) { run(async () => download(await api('/maintenance/backups/' + row.id + '/file',{blob:true}), 'course-' + row.id + '.zip')) }
function fileChanged(event) { selectedFile.value = event.target.files?.[0]; restore.value = undefined }
function previewRestore() {
  if (!selectedFile.value || selectedFile.value.size > 4*1024*1024) { error.value = '请选择不超过 4 MiB 的课程备份 ZIP'; return }
  run(async () => {
    const file = new FormData()
    file.append('file',selectedFile.value)
    restore.value = await api('/maintenance/restores/preview',{method:'POST',data:file})
    job.value = undefined
  })
}
async function confirmRestore() {
  const plan = restore.value
  if (!plan) return
  try {
    const response = await ElMessageBox.prompt('恢复前会自动备份。输入候选课程库名以确认切换，原库会保留。', '恢复二次确认',
      { inputValidator: value => value === plan.target || '必须输入完整候选课程库名' })
    if (response.value !== plan.target) return
  } catch { return }
  run(async () => {
    restore.value = undefined
    try {
      job.value = await api('/maintenance/restores',{method:'POST',timeout:180000,data:{token:plan.token,
        target:plan.target,sha256:plan.sha256,confirmed:true}})
      jobId.value = job.value.id
      ElMessage.success(job.value.message)
      session.user = null
      session.csrf = ''
      await router.replace('/login')
    } catch (problem) {
      if (problem.data?.id) { job.value = problem.data; jobId.value = problem.data.id }
      throw problem
    }
  })
}
function lookupJob() {
  if (!jobId.value.trim()) return
  run(async () => { job.value = await api('/maintenance/restores/' + encodeURIComponent(jobId.value.trim())) })
}
onMounted(() => run(async () => { await relevant(); await listBackups() }))
</script>
<template>
  <section class="card">
    <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
    <el-tabs v-model="tab">
      <el-tab-pane label="批量状态" name="batch">
        <div class="filters">
          <el-select v-model="kind" @change="setKind"><el-option v-for="(label,key) in names" :key="key" :value="key" :label="label" /></el-select>
          <el-input v-model="keyword" clearable placeholder="搜索目标记录" @keyup.enter="run(relevant)" />
          <el-button @click="run(relevant)">查询</el-button>
          <el-select v-model="status"><el-option v-for="[key,label] in statuses" :key="key" :value="key" :label="label" /></el-select>
          <el-button type="primary" :disabled="!ids.length" :loading="busy" @click="batch">更新选中项</el-button>
        </div>
        <el-table :data="rows" empty-text="暂无匹配档案" @selection-change="items => ids = items.map(row => row.id)">
          <el-table-column type="selection" /><el-table-column prop="id" label="编号" width="90" /><el-table-column prop="name" label="档案名称" />
          <el-table-column label="当前状态"><template #default="{ row }">{{ row.status || (row.enabled ? '启用' : '停用') }}</template></el-table-column>
        </el-table>
      </el-tab-pane>
      <el-tab-pane label="失效档案清理" name="cleanup">
        <div class="filters"><el-select v-model="cleanupKind" @change="preview=undefined"><el-option v-for="(label,key) in names" :key="key" :value="key" :label="label" /></el-select>
          <el-button type="primary" :loading="busy" @click="inspectCleanup">预览候选</el-button><el-button type="danger" :disabled="!cleanupIds.length || !preview" @click="executeCleanup">确认清理</el-button></div>
        <template v-if="preview">
          <h3>可清理</h3><el-table :data="preview.eligible" empty-text="没有可清理档案" @selection-change="items => cleanupIds = items.map(row => row.id)">
            <el-table-column type="selection" /><el-table-column prop="id" label="编号" /><el-table-column prop="name" label="档案名称" />
          </el-table>
          <h3>受历史引用保护</h3><el-table :data="preview.protectedRows" empty-text="没有受保护的失效档案">
            <el-table-column prop="id" label="编号" /><el-table-column prop="name" label="档案名称" />
          </el-table>
        </template>
      </el-tab-pane>
      <el-tab-pane label="备份与在线恢复" name="backups">
        <div class="controls"><h2>课程数据备份</h2><div><el-button @click="run(listBackups)">刷新</el-button><el-button type="primary" :loading="busy" @click="makeBackup">生成备份</el-button></div></div>
        <el-table :data="backups" empty-text="暂无备份">
          <el-table-column prop="id" label="备份编号" min-width="260" /><el-table-column prop="savedAt" label="生成时间" min-width="170" /><el-table-column prop="bytes" label="字节数" width="120" />
          <el-table-column label="操作" width="100"><template #default="{row}"><el-button link type="primary" @click="fetchBackup(row)">下载</el-button></template></el-table-column>
        </el-table>
        <h3>恢复到新候选课程库</h3>
        <div class="filters"><input ref="inputFile" type="file" accept=".zip,application/zip" @change="fileChanged" aria-label="选择课程备份" />
          <el-button :disabled="!selectedFile" :loading="busy" @click="previewRestore">校验与预览</el-button></div>
        <div v-if="restore" class="warning-strip">
          <p>候选库 <strong>{{ restore.target }}</strong></p><p>数据行数 {{ Object.values(restore.counts).reduce((sum,count) => sum + count,0) }}</p>
          <p>仅恢复匹配的应用账号，不从备份导入凭据。执行会先备份当前库。</p>
          <el-button type="warning" :loading="busy" @click="confirmRestore">二次确认恢复</el-button>
        </div>
        <div class="filters"><el-input v-model="jobId" placeholder="恢复作业编号" /><el-button @click="lookupJob">查看作业</el-button></div>
        <el-alert v-if="job" :title="job.message" :description="'作业 ' + job.id + ' · ' + job.target" :type="job.state === 'FAILED' ? 'error' : 'info'" :closable="false" />
      </el-tab-pane>
    </el-tabs>
  </section>
</template>
