<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { api, money, session } from '../api.js'
import SalesChart from '../components/SalesChart.vue'
const admin = computed(() => session.user?.role === 'ADMIN')
const filters = reactive({ dateFrom: '', dateTo: '', departmentId: null, employeeId: null })
const summary = ref(), departments = ref([]), employees = ref([])
const error = ref(''), busy = ref(false)
async function refresh() {
  error.value = ''
  busy.value = true
  try {
    const params = Object.fromEntries(Object.entries(filters).filter(([,value]) => value != null && value !== ''))
    summary.value = await api('/stats/overview', { params })
  } catch (problem) { error.value = problem.message; summary.value = undefined }
  finally { busy.value = false }
}
onMounted(async () => {
  refresh()
  if (admin.value) {
    try {
      departments.value = await api('/departments/options')
      employees.value = (await api('/employees', { params: { pageSize: 100 } })).list
    } catch (problem) { error.value = problem.message }
  }
})
</script>
<template>
  <section v-if="admin" class="card">
    <el-form class="filters" @submit.prevent="refresh">
      <el-date-picker v-model="filters.dateFrom" type="date" value-format="YYYY-MM-DD" placeholder="起始日期" />
      <el-date-picker v-model="filters.dateTo" type="date" value-format="YYYY-MM-DD" placeholder="截止日期" />
      <el-select v-model="filters.departmentId" clearable placeholder="成交部门"><el-option v-for="d in departments" :key="d.id" :label="d.name" :value="d.id" /></el-select>
      <el-select v-model="filters.employeeId" clearable filterable placeholder="经办人"><el-option v-for="row in employees" :key="row.id" :label="row.name" :value="row.id" /></el-select>
      <el-button native-type="submit" type="primary" :loading="busy">查询</el-button>
    </el-form>
  </section>
  <el-alert v-if="error" :title="error" type="error" :closable="false" show-icon />
  <div v-loading="busy" style="min-height:160px">
    <template v-if="summary">
      <div class="grid">
        <section class="card kpi"><span>有效销售额（元）</span><strong>{{ money(summary.effective.amount) }}</strong></section>
        <section class="card kpi"><span>有效订单（笔）</span><strong>{{ summary.effective.count }}</strong></section>
      </div>
      <section class="card">
        <h2>{{ admin ? '月度销售额' : '本人近 6 个月销售额' }}</h2>
        <SalesChart :points="summary.months" />
        <el-table :data="summary.months" empty-text="暂无统计数据">
          <el-table-column prop="month" label="月份" /><el-table-column prop="count" label="订单数" align="right" />
          <el-table-column label="销售额（元）" align="right"><template #default="{ row }">{{ money(row.amount) }}</template></el-table-column>
          <el-table-column label="环比" align="right"><template #default="{ row }">{{ row.growthPercent == null ? '—' : money(row.growthPercent) + '%' }}</template></el-table-column>
        </el-table>
      </section>
      <div class="grid">
        <section class="card"><h2>客户消费排行</h2><el-empty v-if="!summary.customerRanking.length" description="暂无有效消费" :image-size="60" />
          <div class="rank-item" v-for="(item,index) in summary.customerRanking" :key="item.id"><span>{{ index+1 }}</span><span>{{ item.name }}</span><strong>{{ money(item.amount) }}</strong></div>
        </section>
        <section v-if="admin" class="card"><h2>员工业绩排行</h2><el-empty v-if="!summary.employeeRanking?.length" description="暂无有效业绩" :image-size="60" />
          <div class="rank-item" v-for="(item,index) in summary.employeeRanking" :key="item.id"><span>{{ index+1 }}</span><span>{{ item.name }}</span><strong>{{ money(item.amount) }}</strong></div>
        </section>
      </div>
    </template>
  </div>
</template>
