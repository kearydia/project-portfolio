<script setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { onBeforeRouteLeave } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { api, download, money, session, statusText } from '../api.js'

const admin = computed(() => session.user?.role === 'ADMIN')
const query = reactive({ dateFrom: '', dateTo: '', departmentId: null, employeeId: null, customerName: '', status: '', orderNo: '' })
const applied = ref({})
const page = ref(1), size = ref(10), listing = ref({ list: [], total: 0 })
const departments = ref([]), employees = ref([]), customers = ref([]), products = ref([])
const loading = ref(false), busy = ref(false), exportBusy = ref(false), issue = ref('')
const dialog = ref(false), mode = ref('create'), initial = ref(''), formProblem = ref(''), fields = ref({})
const form = reactive({ id: null, expectedVersion: null, businessDate: '', customerId: null, employeeId: null, items: [] })
let key = 0
const cleanParams = () => Object.fromEntries(Object.entries(query).filter(([,value]) => value !== '' && value != null))
function fail(error) { issue.value = error.message }
async function list(reset = false) {
  if (reset) { page.value = 1; applied.value = cleanParams() }
  loading.value = true
  issue.value = ''
  try { listing.value = await api('/orders', { params: { ...applied.value, page: page.value, pageSize: size.value } }) }
  catch (error) { fail(error) }
  finally { loading.value = false }
}
function clear() {
  Object.assign(query, { dateFrom: '', dateTo: '', departmentId: null, employeeId: null, customerName: '', status: '', orderNo: '' })
  list(true)
}
async function lookup(name, q) {
  try {
    const params = { q, pageSize: 100 }
    if (name === 'products') params.enabled = true
    const { list } = await api('/' + name, { params })
    if (name === 'employees') employees.value = list
    if (name === 'products') products.value = list
    if (name === 'customers') customers.value = list.filter(row => row.enabled)
  } catch (error) { ElMessage.error(error.message) }
}
onMounted(async () => {
  list()
  try { departments.value = await api('/departments/options') } catch (error) { fail(error) }
  if (admin.value) lookup('employees')
})
function newLine(saved) {
  return { key: ++key, lineId: saved?.lineId ?? null, productId: saved?.productId ?? null, quantity: saved?.quantity ?? 1, saved }
}
const canEdit = computed(() => mode.value !== 'view')
const dirty = computed(() => canEdit.value && dialog.value && JSON.stringify(form) !== initial.value)
function rate(line) {
  if (!line.productId) return null
  if (line.saved?.productId === line.productId) return line.saved.unitPrice
  return products.value.find(row => row.id === line.productId)?.unitPrice ?? null
}
const estimate = computed(() => form.items.reduce((sum, line) => sum + Math.round((rate(line) ?? 0) * 100) * (line.quantity || 0), 0) / 100)
function start() {
  const local = new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date())
  Object.assign(form, { id: null, expectedVersion: null, businessDate: local, customerId: null,
    customerName: '', employeeId: null, employeeName: admin.value ? '' : session.user.displayName, items: [newLine()] })
  open('create')
}
async function details(row, next) {
  try {
    const data = await api('/orders/' + row.id)
    Object.assign(form, { id: row.id, expectedVersion: data.order.version, businessDate: data.order.businessDate, customerId: data.order.customerId,
      customerName: data.order.customerName, employeeId: data.order.employeeId, employeeName: data.order.employeeName, items: data.items.map(newLine) })
    open(next)
  } catch (error) { ElMessage.error(error.message) }
}
function open(next) {
  mode.value = next
  formProblem.value = ''
  fields.value = {}
  initial.value = JSON.stringify(form)
  dialog.value = true
  if (next !== 'view') { lookup('customers'); lookup('products') }
}
async function allowLeave() {
  if (!session.user || !dirty.value) return true
  try { await ElMessageBox.confirm('有未保存的订单修改，确认放弃？', '离开编辑', { type: 'warning' }); return true }
  catch { return false }
}
async function dismiss(done) {
  if (!busy.value && await allowLeave()) { if (done) done(); else dialog.value = false }
}
onBeforeRouteLeave(allowLeave)
async function save() {
  if (busy.value) return
  if (!form.customerId || !form.businessDate || (admin.value && mode.value === 'create' && !form.employeeId) ||
      !form.items.length || form.items.some(row => !row.productId || !Number.isInteger(row.quantity) || row.quantity < 1)) {
    formProblem.value = '请填写有效的日期、客户、经办人与商品明细'
    return
  }
  busy.value = true
  formProblem.value = ''
  fields.value = {}
  try {
    const data = { businessDate: form.businessDate, customerId: form.customerId,
      items: form.items.map(row => ({ lineId: row.lineId, productId: row.productId, quantity: row.quantity })) }
    if (mode.value === 'edit') data.expectedVersion = form.expectedVersion
    else if (admin.value) data.employeeId = form.employeeId
    await api(mode.value === 'edit' ? '/orders/' + form.id : '/orders',
      { method: mode.value === 'edit' ? 'PUT' : 'POST', data })
    initial.value = JSON.stringify(form)
    dialog.value = false
    ElMessage.success('订单已保存')
    list()
  } catch (error) { formProblem.value = error.message; fields.value = error.fields }
  finally { busy.value = false }
}
async function change(row) {
  if (busy.value) return
  const action = row.status === 'VOID' ? 'unvoid' : 'void'
  let reason
  try {
    const res = await ElMessageBox.prompt(action === 'void' ? '作废后该订单将退出有效统计。请输入原因。' : '撤销后订单会重新计入有效统计。请输入原因。',
      action === 'void' ? '确认作废' : '确认撤销作废',
      { inputValidator: value => value?.trim().length > 0 && value.trim().length <= 200 || '请输入 1 至 200 字的原因' })
    reason = res.value.trim()
  } catch { return }
  if (busy.value) return
  busy.value = true
  try {
    await api('/orders/' + row.id + '/' + action, { method: 'POST', data: { expectedVersion: row.version, reason } })
    ElMessage.success('订单状态已更新')
    list()
  } catch (error) { ElMessage.error(error.message); if (error.status === 409) list() }
  finally { busy.value = false }
}
async function exportFile() {
  if (exportBusy.value) return
  exportBusy.value = true
  try { download(await api('/orders/export', { method: 'POST', data: applied.value, blob: true }), '销售订单.xlsx') }
  catch (error) { ElMessage.error(error.message) }
  finally { exportBusy.value = false }
}
</script>

<template>
  <section class="card">
    <el-form class="filters" @submit.prevent="list(true)">
      <el-date-picker v-model="query.dateFrom" type="date" value-format="YYYY-MM-DD" placeholder="起始日期" aria-label="起始日期" />
      <el-date-picker v-model="query.dateTo" type="date" value-format="YYYY-MM-DD" placeholder="截止日期" aria-label="截止日期" />
      <el-select v-model="query.departmentId" clearable placeholder="成交部门" aria-label="成交部门"><el-option v-for="d in departments" :key="d.id" :value="d.id" :label="d.name" /></el-select>
      <el-select v-if="admin" v-model="query.employeeId" clearable filterable remote :remote-method="q => lookup('employees',q)" placeholder="经办人" aria-label="经办人"><el-option v-for="e in employees" :key="e.id" :value="e.id" :label="e.name" /></el-select>
      <el-input v-model="query.customerName" clearable placeholder="客户名称" aria-label="客户名称" />
      <el-input v-model="query.orderNo" clearable placeholder="订单号" aria-label="订单号" />
      <el-select v-model="query.status" clearable placeholder="订单状态" aria-label="订单状态"><el-option value="ACTIVE" label="有效" /><el-option value="VOID" label="已作废" /></el-select>
      <el-button native-type="submit" type="primary">查询</el-button><el-button @click="clear">重置</el-button>
    </el-form>
  </section>
  <section class="card">
    <div class="controls"><h2>订单列表</h2><div><el-button :loading="exportBusy" @click="exportFile">导出 Excel</el-button><el-button type="primary" @click="start">新增订单</el-button></div></div>
    <el-alert v-if="issue" :title="issue" type="error" :closable="false" show-icon />
    <el-table :data="listing.list" v-loading="loading" empty-text="没有符合条件的订单" row-key="id">
      <el-table-column prop="orderNo" label="订单编号" min-width="165" show-overflow-tooltip /><el-table-column prop="businessDate" label="订单日期" width="112" />
      <el-table-column prop="customerName" label="客户" min-width="100" /><el-table-column prop="employeeName" label="经办人" width="110" /><el-table-column prop="departmentName" label="成交部门" min-width="110" />
      <el-table-column label="订单金额" align="right" width="130"><template #default="{ row }">{{ money(row.totalAmount) }}</template></el-table-column>
      <el-table-column label="状态" width="95"><template #default="{ row }"><span :class="row.status === 'VOID' ? 'pill-void' : 'pill-active'">{{ statusText[row.status] }}</span></template></el-table-column>
      <el-table-column label="操作" width="175"><template #default="{ row }">
        <el-button link type="primary" @click="details(row,'view')">查看</el-button>
        <el-button v-if="admin && row.status === 'ACTIVE'" link type="primary" @click="details(row,'edit')">编辑</el-button>
        <el-button v-if="admin" link type="primary" :disabled="busy" @click="change(row)">{{ row.status === 'VOID' ? '撤销作废' : '作废' }}</el-button>
      </template></el-table-column>
    </el-table>
    <div class="table-footer"><span>全量有效合计 <strong>{{ money(listing.effectiveTotal) }}</strong> 元 · {{ listing.effectiveCount ?? 0 }} 笔</span><el-pagination v-model:current-page="page" v-model:page-size="size" :page-sizes="[10,20,50,100]" :total="listing.total" layout="total, sizes, prev, pager, next" @current-change="list()" @size-change="list(true)" /></div>
  </section>
  <el-dialog v-model="dialog" :title="mode === 'create' ? '新增订单' : mode === 'edit' ? '编辑订单' : '订单详情'" width="min(92vw, 850px)" :before-close="dismiss" :close-on-click-modal="false">
    <el-alert v-if="formProblem" :title="formProblem" :description="Object.values(fields).join('；')" type="error" :closable="false" />
    <div class="filters">
      <el-date-picker v-model="form.businessDate" :disabled="!canEdit" type="date" value-format="YYYY-MM-DD" placeholder="订单日期" />
      <el-select v-model="form.customerId" :disabled="!canEdit" filterable remote :remote-method="q => lookup('customers',q)" placeholder="客户">
        <el-option v-if="form.customerId && !customers.some(c => c.id === form.customerId)" :value="form.customerId" :label="form.customerName || ('客户 ' + form.customerId)" disabled />
        <el-option v-for="c in customers" :key="c.id" :value="c.id" :label="c.name" />
      </el-select>
      <el-select v-if="admin && mode === 'create'" v-model="form.employeeId" filterable remote :remote-method="q => lookup('employees',q)" placeholder="经办人"><el-option v-for="e in employees.filter(item => item.status === 'ACTIVE')" :key="e.id" :value="e.id" :label="e.name" /></el-select>
      <span v-else-if="form.employeeName" class="muted">经办人 {{ form.employeeName }}</span>
    </div>
    <div class="order-lines">
      <div class="order-line muted"><span>商品</span><span>数量</span><span>单价（元）</span><span></span></div>
      <div class="order-line" v-for="(line,index) in form.items" :key="line.key">
        <el-select v-model="line.productId" :disabled="!canEdit" filterable remote :remote-method="q => lookup('products',q)" placeholder="选择商品">
          <el-option v-if="line.saved && line.productId === line.saved.productId && !products.some(p => p.id === line.productId)" :value="line.productId" :label="line.saved.productName" disabled />
          <el-option v-for="p in products" :key="p.id" :value="p.id" :label="p.name" />
        </el-select>
        <el-input-number v-model="line.quantity" :disabled="!canEdit" :min="1" :max="1000000" :precision="0" aria-label="数量" />
        <span>{{ money(rate(line)) }}</span>
        <el-button v-if="canEdit" link type="danger" :disabled="form.items.length <= 1" @click="form.items.splice(index,1)">移除</el-button>
      </div>
    </div>
    <div class="controls"><el-button v-if="canEdit" :disabled="form.items.length >= 100" @click="form.items.push(newLine())">添加明细</el-button><span>{{ canEdit ? '预估金额，以成交价为准' : '订单金额' }} <strong>{{ money(estimate) }}</strong> 元</span></div>
    <template #footer><el-button :disabled="busy" @click="dismiss()">{{ canEdit ? '取消' : '关闭' }}</el-button><el-button v-if="canEdit" type="primary" :loading="busy" @click="save">保存订单</el-button></template>
  </el-dialog>
</template>
