<script setup>
import { onMounted, reactive, ref } from 'vue'
import { api, statusText } from '../api.js'
const actions = { CREATE:'新增',UPDATE:'修改',DELETE:'删除',VOID:'作废',UNVOID:'撤销作废',EXPORT:'导出',BACKUP:'备份',RESTORE:'恢复' }
const resources = {DEPARTMENT:'部门',EMPLOYEE:'员工',CUSTOMER:'客户',PRODUCT:'产品',USER:'账号',ORDER:'订单',MAINTENANCE:'系统维护'}
const query = reactive({ dateFrom: '', dateTo: '', action: '', resource: '', actorId: undefined })
const listing = ref({ list: [], total: 0 }), page = ref(1), size = ref(10)
const detail = ref(), dialog = ref(false), error = ref(''), loading = ref(false)
async function refresh(reset = false) {
  if (reset) page.value = 1
  loading.value = true
  error.value = ''
  try { listing.value = await api('/operation-logs', { params: {...Object.fromEntries(Object.entries(query).filter(([,v]) => v != null && v !== '')),page:page.value,pageSize:size.value} }) }
  catch (problem) { error.value = problem.message }
  finally { loading.value = false }
}
function show(row) { detail.value = row; dialog.value = true }
onMounted(refresh)
</script>
<template>
  <section class="card">
    <el-form class="filters" @submit.prevent="refresh(true)">
      <el-date-picker v-model="query.dateFrom" type="date" value-format="YYYY-MM-DD" placeholder="起始日期" />
      <el-date-picker v-model="query.dateTo" type="date" value-format="YYYY-MM-DD" placeholder="截止日期" />
      <el-select v-model="query.action" clearable placeholder="操作类型"><el-option v-for="(label,key) in actions" :key="key" :value="key" :label="label" /></el-select>
      <el-select v-model="query.resource" clearable placeholder="资源类型"><el-option v-for="(label,key) in resources" :key="key" :value="key" :label="label" /></el-select>
      <el-input-number v-model="query.actorId" :min="0" :controls="false" placeholder="操作者编号" />
      <el-button type="primary" native-type="submit">查询</el-button>
    </el-form>
  </section>
  <section class="card">
    <el-alert v-if="error" :title="error" type="error" :closable="false" />
    <el-table v-loading="loading" :data="listing.list" empty-text="没有符合条件的审计记录">
      <el-table-column label="操作时间" width="192"><template #default="{ row }">{{ row.occurredAt?.replace('T',' ').slice(0,19) }}</template></el-table-column>
      <el-table-column prop="actorName" label="操作者" min-width="125" show-overflow-tooltip />
      <el-table-column label="角色" width="115"><template #default="{ row }">{{ statusText[row.actorRole] || row.actorRole }}</template></el-table-column>
      <el-table-column label="动作" width="112"><template #default="{ row }">{{ actions[row.action] || row.action }}</template></el-table-column>
      <el-table-column label="资源" width="118"><template #default="{ row }">{{ resources[row.resource] || row.resource }}</template></el-table-column>
      <el-table-column prop="targetId" label="目标编号" width="105" />
      <el-table-column label="详情" width="80"><template #default="{ row }"><el-button link type="primary" @click="show(row)">查看</el-button></template></el-table-column>
    </el-table>
    <div class="table-footer"><span>共 {{ listing.total }} 条</span><el-pagination v-model:current-page="page" v-model:page-size="size" :page-sizes="[10,20,50,100]" :total="listing.total" layout="sizes, prev, pager, next" @current-change="refresh()" @size-change="refresh(true)" /></div>
  </section>
  <el-dialog v-model="dialog" title="审计详情" width="min(90vw,720px)"><div v-if="detail"><h3>操作前</h3><pre style="white-space:pre-wrap">{{ JSON.stringify(detail.before,null,2) }}</pre><h3>操作后</h3><pre style="white-space:pre-wrap">{{ JSON.stringify(detail.after,null,2) }}</pre></div></el-dialog>
</template>
