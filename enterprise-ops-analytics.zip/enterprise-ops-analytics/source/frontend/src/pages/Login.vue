<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { signIn } from '../api.js'

const router = useRouter()
const form = reactive({ username: '', password: '' })
const busy = ref(false)
const problem = ref('')
async function submit() {
  if (busy.value) return
  if (!form.username.trim() || !form.password) { problem.value = '请输入账号与密码'; return }
  busy.value = true
  problem.value = ''
  try { await signIn(form.username.trim(), form.password); router.replace('/') }
  catch (error) { problem.value = error.message }
  finally { form.password = ''; busy.value = false }
}
</script>

<template>
  <main class="login-shell">
    <section class="login-brand">
      <div class="login-mark">企</div>
      <h1>企业运营<br>数据分析系统</h1>
      <p>销售订单、档案与经营统计</p>
    </section>
    <section class="login-panel">
      <form class="login-form" @submit.prevent="submit">
        <h2>登录工作台</h2>
        <label for="login-account">账号</label>
        <el-input id="login-account" v-model="form.username" autocomplete="username" maxlength="40" placeholder="输入应用账号" />
        <label for="login-password">密码</label>
        <el-input id="login-password" v-model="form.password" type="password" autocomplete="current-password" placeholder="输入密码" />
        <p v-if="problem" role="alert" class="problem">{{ problem }}</p>
        <el-button type="primary" native-type="submit" :loading="busy">登录</el-button>
      </form>
    </section>
  </main>
</template>
