<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { session, signOut, statusText } from './api.js'

const route = useRoute()
const router = useRouter()
const business = [['/', '概', '数据概览'], ['/orders', '单', '销售订单'], ['/customers', '客', '客户档案'], ['/products', '品', '产品档案']]
const adminLinks = [['/employees', '员', '员工档案'], ['/departments', '部', '部门管理'], ['/users', '账', '账号与角色'],
  ['/maintenance', '维', '数据维护'], ['/logs', '志', '操作日志']]
const admin = computed(() => session.user?.role === 'ADMIN')
async function logout() {
  try { await signOut(); router.replace('/login') } catch (error) { ElMessage.error(error.message) }
}
</script>

<template>
  <RouterView v-if="route.path === '/login' || !session.user" />
  <div v-else class="shell">
    <aside class="site-side">
      <div class="brand"><span>企</span><div><strong>企业运营分析</strong><small>数据管理工作台</small></div></div>
      <nav aria-label="业务导航">
        <div class="nav-label">运营业务</div>
        <RouterLink v-for="[path,icon,label] in business" :key="path" :to="path" class="nav-link"><span class="nav-symbol">{{ icon }}</span>{{ label }}</RouterLink>
        <template v-if="admin">
          <div class="nav-label">系统管理</div>
          <RouterLink v-for="[path,icon,label] in adminLinks" :key="path" :to="path" class="nav-link"><span class="nav-symbol">{{ icon }}</span>{{ label }}</RouterLink>
        </template>
      </nav>
    </aside>
    <div class="site-main">
      <header class="site-header">
        <span>企业运营 / {{ route.meta.title }}</span>
        <div class="header-account"><el-tag effect="plain">{{ statusText[session.user.role] }}</el-tag><strong>{{ session.user.displayName }}</strong><el-button text @click="logout">退出</el-button></div>
      </header>
      <main class="content">
        <h1>{{ route.meta.title }}</h1>
        <div class="scope"><strong>数据范围</strong><span>{{ admin ? '全部获授权业务数据' : '本人经办订单与本人负责客户' }}</span></div>
        <RouterView :key="route.path" />
      </main>
    </div>
  </div>
</template>
