import axios from 'axios'
import { reactive } from 'vue'

export const session = reactive({ user: null, csrf: '', checked: false })
const client = axios.create({ baseURL: '/api', timeout: 25000 })
let authFailure = () => {}
export function onAuthFailure(callback) { authFailure = callback }

function reset() {
  session.user = null
  session.csrf = ''
}
function useSession(data) {
  session.user = data.user
  session.csrf = data.csrfToken
  session.checked = true
  return data.user
}
async function fromError(error, route) {
  const status = error.response?.status
  let body = error.response?.data
  if (body instanceof Blob) {
    try { body = JSON.parse(await body.text()) } catch { body = null }
  }
  if (status === 401 && !route.startsWith('/auth/')) {
    reset()
    authFailure()
  }
  const message = body?.message || (status === 403 ? '您没有此操作权限' : status === 409 ? '记录已变化，请刷新后重试' :
    error.code === 'ECONNABORTED' ? '请求超时，请核对结果后重试' : '无法连接服务，请稍后重试')
  return Object.assign(new Error(message), { status, fields: body?.fieldErrors || {}, data: body?.data })
}

export async function api(route, { method = 'GET', params, data, blob = false, timeout } = {}) {
  const headers = {}
  if (!['GET', 'HEAD', 'OPTIONS'].includes(method) && session.csrf) {
    headers['X-CSRF-Token'] = session.csrf
  }
  try {
    const response = await client.request({ url: route, method, params, data, headers,
      ...(timeout ? { timeout } : {}), ...(blob ? { responseType: 'blob' } : {}) })
    return blob ? response.data : response.data.data
  } catch (error) {
    throw await fromError(error, route)
  }
}
export async function checkSession() {
  if (session.checked) return session.user
  try { return useSession(await api('/auth/me')) } catch (error) {
    reset()
    session.checked = true
    if (error.status !== 401) throw error
    return null
  }
}
export async function signIn(username, password) {
  session.csrf = (await api('/auth/csrf')).csrfToken
  return useSession(await api('/auth/login', { method: 'POST', data: { username, password } }))
}
export async function signOut() {
  try { await api('/auth/logout', { method: 'POST' }) } catch (error) {
    if (error.status !== 401) throw error
  }
  reset()
}
export function download(blob, filename) {
  const url = URL.createObjectURL(blob)
  const handle = document.createElement('a')
  handle.href = url
  handle.download = filename
  handle.click()
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
export const money = (value) => value == null ? '—' : new Intl.NumberFormat('zh-CN', {
  minimumFractionDigits: 2, maximumFractionDigits: 2
}).format(value)
export const statusText = { ACTIVE: '有效', VOID: '已作废', INACTIVE: '停用', LEFT: '离职', SALES: '普通业务员', ADMIN: '财务管理员' }
