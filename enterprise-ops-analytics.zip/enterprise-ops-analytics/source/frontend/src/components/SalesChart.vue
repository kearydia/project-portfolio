<script setup>
import { nextTick, onMounted, onBeforeUnmount, ref, watch } from 'vue'
import { init, use } from 'echarts/core'
import { BarChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, AriaComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'

use([BarChart, GridComponent, TooltipComponent, AriaComponent, CanvasRenderer])
const props = defineProps({ points: { type: Array, required: true } })
const host = ref()
let chart, resize
async function draw() {
  await nextTick()
  if (!host.value) return
  chart ??= init(host.value)
  chart.setOption({
    aria: { enabled: true }, color:['#1f5fa8'], tooltip:{trigger:'axis'}, grid:{left:55,right:15,top:20,bottom:35},
    xAxis:{type:'category',data:props.points.map(p => p.month)}, yAxis:{type:'value',name:'元'},
    series:[{type:'bar',name:'有效销售额',data:props.points.map(p => Number(p.amount)),barMaxWidth:42,itemStyle:{borderRadius:[4,4,0,0]}}]
  })
}
watch(() => props.points, draw)
onMounted(() => { draw(); resize = new ResizeObserver(() => chart?.resize()); resize.observe(host.value) })
onBeforeUnmount(() => { resize?.disconnect(); chart?.dispose(); chart = null })
</script>
<template><div ref="host" class="chart" role="img" aria-label="月度有效销售额柱状图"></div></template>
