import { createApp } from 'vue'
import { createRouter, createWebHashHistory } from 'vue-router'
import ElementPlus, { ElMessage } from 'element-plus'
import zhCN from 'element-plus/dist/locale/zh-cn.mjs'
import 'element-plus/dist/index.css'
import './style.css'
import App from './App.vue'
import Login from './pages/Login.vue'
import { checkSession, onAuthFailure, session } from './api.js'

const catalog = () => import('./pages/CatalogPage.vue')
const routes = [
  { path: '/login', component: Login, meta: { title: '登录', public: true } },
  { path: '/', component: () => import('./pages/Overview.vue'), meta: { title: '数据概览' } },
  { path: '/orders', component: () => import('./pages/OrdersPage.vue'), meta: { title: '销售订单' } },
  ...[
    ['customers', '客户档案', false], ['products', '产品档案', false],
    ['employees', '员工档案', true], ['departments', '部门管理', true], ['users', '账号与角色', true]
  ].map(([key, title, admin]) => ({ path: '/' + key, component: catalog, props: { resource: key }, meta: { title, admin } })),
  { path: '/maintenance', component: () => import('./pages/Maintenance.vue'), meta: { title: '数据维护', admin: true } },
  { path: '/logs', component: () => import('./pages/Logs.vue'), meta: { title: '操作日志', admin: true } },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]
const router = createRouter({ history: createWebHashHistory(), routes })
router.beforeEach(async (to) => {
  if (!session.checked) {
    try { await checkSession() } catch (error) { if (!to.meta.public) ElMessage.error(error.message) }
  }
  if (to.meta.public) return session.user ? '/' : true
  if (!session.user) return '/login'
  if (to.meta.admin && session.user.role !== 'ADMIN') {
    ElMessage.warning('您没有此页面访问权限')
    return '/'
  }
})
onAuthFailure(() => {
  if (router.currentRoute.value.path !== '/login') {
    ElMessage.warning('会话已结束，请重新登录')
    router.replace('/login')
  }
})
createApp(App).use(router).use(ElementPlus, { locale: zhCN }).mount('#app')
