package course.ops;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.zip.*;

final class BackupArchive {
    static final int MAX_COMPRESSED = 4*1024*1024;
    private static final int MAX_PAYLOAD = 12*1024*1024;
    private static final String MANIFEST = "manifest.json";
    private static final String DATA = "data.json";
    private final ObjectMapper json;

    record Manifest(int format,int schemaVersion,String lineage,String source,String generatedAt,
                    String sha256,Map<String,Integer> counts) {}
    record Bundle(Manifest manifest,Map<String,List<Map<String,String>>> data) {}

    BackupArchive(ObjectMapper json) {
        this.json = json.copy().enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION);
    }

    byte[] encode(String lineage,String source,Map<String,List<Map<String,String>>> data) throws IOException {
        BackupTables.validate(data);
        byte[] body = json.writeValueAsBytes(data);
        if (body.length > MAX_PAYLOAD) { throw Api.invalid("备份内容超过配额"); }
        var manifest = new Manifest(1,1,lineage,source,Instant.now().toString(),hash(body),counts(data));
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (var zip = new ZipOutputStream(buffer,StandardCharsets.UTF_8)) {
            put(zip,MANIFEST,json.writeValueAsBytes(manifest));
            put(zip,DATA,body);
        }
        if (buffer.size() > MAX_COMPRESSED) { throw Api.invalid("压缩备份超过配额"); }
        return buffer.toByteArray();
    }

    Bundle decode(byte[] bytes,String expectedLineage) {
        if (bytes.length == 0 || bytes.length > MAX_COMPRESSED) { throw Api.invalid("上传备份大小不符合限制"); }
        Map<String,byte[]> files = new HashMap<>();
        try (var zip = new ZipInputStream(new ByteArrayInputStream(bytes),StandardCharsets.UTF_8)) {
            for (ZipEntry file; (file = zip.getNextEntry()) != null;) {
                String name = file.getName();
                if (file.isDirectory() || !Set.of(MANIFEST,DATA).contains(name) || files.containsKey(name)) {
                    throw Api.invalid("备份条目不受支持或重复");
                }
                int limit = name.equals(MANIFEST) ? 16*1024 : MAX_PAYLOAD;
                byte[] content = zip.readNBytes(limit+1);
                if (content.length > limit) { throw Api.invalid("备份解压超过配额"); }
                files.put(name,content);
                zip.closeEntry();
            }
            if (files.size() != 2) { throw Api.invalid("备份必须包含清单和数据"); }
            Manifest manifest = json.readValue(files.get(MANIFEST),Manifest.class);
            String source = manifest.source();
            if (manifest.format() != 1 || manifest.schemaVersion() != 1 || !expectedLineage.equals(manifest.lineage())
                    || source == null || !(source.equals(expectedLineage) ||
                    source.matches(java.util.regex.Pattern.quote(expectedLineage)+"_r_[a-f0-9]{16}"))
                    || !hash(files.get(DATA)).equals(manifest.sha256())) {
                throw Api.invalid("备份版本、所属课程库或数据校验值无效");
            }
            JsonNode tree = json.readTree(files.get(DATA));
            if (tree == null || !tree.isObject()) { throw Api.invalid("备份数据必须使用白名单 JSON 对象"); }
            var tables = tree.fields();
            while (tables.hasNext()) {
                JsonNode rows = tables.next().getValue();
                if (!rows.isArray()) { throw Api.invalid("备份表必须是行数组"); }
                for (JsonNode row : rows) {
                    if (!row.isObject()) { throw Api.invalid("备份行必须是对象"); }
                    for (JsonNode column : row) {
                        if (!column.isTextual() && !column.isNull()) {
                            throw Api.invalid("备份列只能是约定文本或空值");
                        }
                    }
                }
            }
            Map<String,List<Map<String,String>>> data = json.convertValue(tree,new TypeReference<>() {});
            BackupTables.validate(data);
            if (!counts(data).equals(manifest.counts())) { throw Api.invalid("备份行数与清单不符"); }
            return new Bundle(manifest,data);
        } catch (IOException | IllegalArgumentException failure) {
            throw Api.invalid("无法读取受控课程备份包");
        }
    }

    private Map<String,Integer> counts(Map<String,List<Map<String,String>>> data) {
        var result = new LinkedHashMap<String,Integer>();
        data.forEach((key,rows) -> result.put(key,rows.size()));
        return result;
    }

    private void put(ZipOutputStream stream,String name,byte[] data) throws IOException {
        stream.putNextEntry(new ZipEntry(name));
        stream.write(data);
        stream.closeEntry();
    }

    static String hash(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (java.security.NoSuchAlgorithmException impossible) {
            throw new IllegalStateException(impossible);
        }
    }
}
