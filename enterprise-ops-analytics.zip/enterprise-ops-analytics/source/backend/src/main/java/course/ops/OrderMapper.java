package course.ops;

import course.ops.Orders.*;
import org.apache.ibatis.annotations.Update;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.*;

@Mapper
interface OrderMapper {
    String COLUMNS = """
            o.id,o.order_no,o.business_date,o.customer_id,c.name AS customer_name,
            o.employee_id,e.name AS employee_name,o.department_id,d.name AS department_name,
            o.status,o.total_amount,o.version,o.voided_by,o.voided_at
            """;
    String FROM = """
            FROM sales_orders o JOIN customers c ON c.id=o.customer_id
            JOIN employees e ON e.id=o.employee_id JOIN departments d ON d.id=o.department_id
            """;
    String FILTER = """
             WHERE (#{f.employeeId} IS NULL OR o.employee_id=#{f.employeeId})
              AND (#{f.departmentId} IS NULL OR o.department_id=#{f.departmentId})
              AND (#{f.dateFrom} IS NULL OR o.business_date >= #{f.dateFrom})
              AND (#{f.dateTo} IS NULL OR o.business_date <= #{f.dateTo})
              AND (#{f.status} IS NULL OR o.status=#{f.status})
              AND (#{f.customerName} IS NULL OR c.name LIKE #{f.customerName} ESCAPE '!')
              AND (#{f.orderNo} IS NULL OR o.order_no LIKE #{f.orderNo} ESCAPE '!')
            """;
    String EFFECTIVE = " AND o.status='ACTIVE' ";
    String LINE_COLUMNS = """
            i.id AS line_id,i.order_id,i.product_id,p.name AS product_name,i.display_order,
            i.quantity,i.unit_price,i.line_amount
            """;

    @Select("SELECT " + COLUMNS + FROM + FILTER + " ORDER BY o.business_date DESC,o.id DESC LIMIT #{size} OFFSET #{offset}")
    List<Row> list(@Param("f") Filter f, @Param("size") int size, @Param("offset") long offset);

    @Select("SELECT COUNT(*) " + FROM + FILTER)
    long count(@Param("f") Filter f);

    @Select("SELECT COUNT(*) AS count,COALESCE(SUM(o.total_amount),0) AS amount " + FROM + FILTER + EFFECTIVE)
    Totals effective(@Param("f") Filter f);

    @Select("SELECT " + COLUMNS + FROM + " WHERE o.id=#{id} AND (#{owner} IS NULL OR o.employee_id=#{owner})")
    Row one(long id, Long owner);

    @Select("SELECT id FROM sales_orders WHERE id=#{id} FOR UPDATE")
    Long lock(long id);

    @Select("SELECT " + LINE_COLUMNS + " FROM sales_order_items i JOIN products p ON p.id=i.product_id"
            + " WHERE i.order_id=#{id} ORDER BY i.display_order,i.id")
    List<Line> lines(long id);

    @Select("SELECT " + LINE_COLUMNS + FROM + " JOIN sales_order_items i ON i.order_id=o.id "
            + " JOIN products p ON p.id=i.product_id " + FILTER
            + " ORDER BY o.business_date DESC,o.id DESC,i.display_order,i.id LIMIT #{limit}")
    List<Line> exportLines(@Param("f") Filter f, @Param("limit") int limit);

    @Select("SELECT DATE_FORMAT(o.business_date,'%Y-%m') AS month, COUNT(*) AS count, SUM(o.total_amount) AS amount "
            + FROM + FILTER + EFFECTIVE + " GROUP BY month ORDER BY month")
    List<MonthRow> months(@Param("f") Filter f);

    record MonthRow(String month, long count, BigDecimal amount) {}

    @Select("SELECT e.id,e.name,COUNT(*) AS count,SUM(o.total_amount) AS amount "
            + FROM + FILTER + EFFECTIVE + " GROUP BY e.id,e.name ORDER BY amount DESC,e.id LIMIT 10")
    List<Rank> employees(@Param("f") Filter f);

    @Select("SELECT c.id,c.name,COUNT(*) AS count,SUM(o.total_amount) AS amount "
            + FROM + FILTER + EFFECTIVE + " GROUP BY c.id,c.name ORDER BY amount DESC,c.id LIMIT 10")
    List<Rank> customers(@Param("f") Filter f);

    @Insert("""
            INSERT INTO sales_orders(order_no,business_date,customer_id,employee_id,department_id,total_amount)
            VALUES(#{number},#{date},#{customer},#{employee},#{department},#{amount})
            """)
    void insert(String number, LocalDate date, long customer, long employee, long department, BigDecimal amount);

    @Select("SELECT LAST_INSERT_ID()")
    long insertedId();

    @Update("""
            UPDATE sales_orders SET business_date=#{date},customer_id=#{customer},total_amount=#{amount},version=version+1
            WHERE id=#{id} AND status='ACTIVE' AND version=#{version}
            """)
    int update(long id, long version, LocalDate date, long customer, BigDecimal amount);

    @Update("""
            UPDATE sales_orders SET status=#{next},voided_by=#{actor},voided_at=#{at},version=version+1
            WHERE id=#{id} AND status=#{previous} AND version=#{version}
            """)
    int change(long id, long version, Status previous, Status next, Long actor, LocalDateTime at);

    @Insert("""
            INSERT INTO sales_order_items(order_id,product_id,display_order,quantity,unit_price,line_amount)
            VALUES(#{id},#{line.productId},#{line.displayOrder},#{line.quantity},#{line.unitPrice},#{line.lineAmount})
            """)
    void addLine(long id, Line line);

    @Update("""
            UPDATE sales_order_items SET product_id=#{line.productId},display_order=#{line.displayOrder},
                quantity=#{line.quantity},unit_price=#{line.unitPrice},line_amount=#{line.lineAmount}
            WHERE id=#{line.lineId} AND order_id=#{id}
            """)
    void updateLine(long id, Line line);

    @Delete("DELETE FROM sales_order_items WHERE id=#{line} AND order_id=#{id}")
    void deleteLine(long id, long line);
}
