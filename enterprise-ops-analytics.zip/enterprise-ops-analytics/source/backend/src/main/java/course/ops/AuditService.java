package course.ops;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import course.ops.AuditMapper.Action;
import course.ops.AuditMapper.Resource;
import course.ops.SessionAccess.Actor;
import java.time.LocalDate;
import java.time.LocalDateTime;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
class AuditService {
    private final AuditMapper logs;
    private final ObjectMapper json;

    AuditService(AuditMapper logs, ObjectMapper json) {
        this.logs = logs;
        this.json = json;
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void record(Actor actor, Action action, Resource resource, long id, Object before, Object after) {
        logs.insert(actor.id(), actor.username(), actor.role(), action, resource, id, encode(before), encode(after));
    }

    record View(long id, LocalDateTime occurredAt, long actorId, String actorName, Accounts.Role actorRole,
                Action action, Resource resource, long targetId, JsonNode before, JsonNode after) {}

    @Transactional(readOnly = true)
    public Api.Reply list(LocalDate dateFrom, LocalDate dateTo, Long actorId, Action action, Resource resource,
                          Api.Paging paging) {
        if (dateFrom != null && dateTo != null && dateFrom.isAfter(dateTo)) {
            throw Api.invalid("开始日期不能晚于结束日期");
        }
        if (dateTo != null && dateTo.getYear() >= 9999) {
            throw Api.invalid("结束日期超出可查询范围");
        }
        var from = dateFrom == null ? null : dateFrom.atStartOfDay();
        var until = dateTo == null ? null : dateTo.plusDays(1).atStartOfDay();
        var rows = logs.list(from, until, actorId, action, resource, paging.size(), paging.offset())
                .stream().map(row -> new View(row.id(), row.occurredAt(), row.actorId(), row.actorName(),
                        row.actorRole(), row.action(), row.resource(), row.targetId(),
                        decode(row.beforeJson()), decode(row.afterJson()))).toList();
        return paging.result(rows, logs.count(from, until, actorId, action, resource));
    }

    private String encode(Object value) {
        try {
            return value == null ? null : json.writeValueAsString(value);
        } catch (JsonProcessingException failure) {
            throw new IllegalStateException("操作日志序列化失败", failure);
        }
    }

    private JsonNode decode(String value) {
        try {
            return value == null ? null : json.readTree(value);
        } catch (JsonProcessingException failure) {
            throw new IllegalStateException("操作日志格式异常", failure);
        }
    }
}
