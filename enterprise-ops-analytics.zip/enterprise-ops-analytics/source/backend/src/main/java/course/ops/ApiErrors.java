package course.ops;

import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

@RestControllerAdvice
class ApiErrors {
    @ExceptionHandler(Api.Failure.class)
    ResponseEntity<Api.Reply> business(Api.Failure failure) {
        return error(failure.status, failure.code, failure.getMessage(), Map.of());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<Api.Reply> fields(MethodArgumentNotValidException failure) {
        Map<String, String> fields = new LinkedHashMap<>();
        failure.getBindingResult().getFieldErrors()
                .forEach(item -> fields.putIfAbsent(item.getField(), item.getDefaultMessage()));
        return error(HttpStatus.BAD_REQUEST, "VALIDATION_FAILED", "请检查表单后重试", fields);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, MethodArgumentTypeMismatchException.class,
            ServletRequestBindingException.class})
    ResponseEntity<Api.Reply> request() {
        return business(Api.invalid("请求字段、参数或格式不正确"));
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    ResponseEntity<Api.Reply> integrity() {
        return business(Api.conflict("记录仍有关联数据或编号已存在，请检查后重试"));
    }

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    ResponseEntity<Api.Reply> uploadLimit() {
        return error(HttpStatus.PAYLOAD_TOO_LARGE, "UPLOAD_LIMIT", "上传文件超过课程备份限制", Map.of());
    }

    @ExceptionHandler(NoResourceFoundException.class)
    ResponseEntity<Api.Reply> missing() {
        return business(Api.missing());
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    ResponseEntity<Api.Reply> method() {
        return error(HttpStatus.METHOD_NOT_ALLOWED, "METHOD_NOT_ALLOWED", "该接口不支持此操作", Map.of());
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Api.Reply> unexpected(Exception failure) {
        LoggerFactory.getLogger(ApiErrors.class).error("请求处理失败，异常类型 {}", failure.getClass().getSimpleName());
        String databaseMessage = CourseDataSource.connectionFailureMessage(failure);
        if (databaseMessage != null) {
            return error(HttpStatus.SERVICE_UNAVAILABLE, "DATABASE_UNAVAILABLE", databaseMessage, Map.of());
        }
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "SERVER_ERROR", "服务暂时无法处理该请求", Map.of());
    }

    private ResponseEntity<Api.Reply> error(HttpStatus status, String code, String message, Map<String, String> fields) {
        return ResponseEntity.status(status).body(new Api.Reply(code, message, null, fields));
    }
}
