package course.ops;

import course.ops.Accounts.*;
import course.ops.SessionAccess.Actor;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class AccountService {
    private final AccountMapper accounts;
    private final CatalogMapper catalog;
    private final AuditService audit;
    private final BCryptPasswordEncoder passwords = new BCryptPasswordEncoder();

    AccountService(AccountMapper accounts, CatalogMapper catalog, AuditService audit) {
        this.accounts = accounts;
        this.catalog = catalog;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public Api.Reply list(String q, Api.Paging page) {
        String search = Api.search(q);
        return page.result(accounts.list(search, page.size(), page.offset()).stream().map(Row::view).toList(),
                accounts.count(search));
    }

    @Transactional
    public View create(Actor actor, Create input) {
        String hash = hashPassword(input.password());
        validateEmployee(input.role(), input.employeeId(), true);
        accounts.insert(input.username(), input.displayName().strip(), hash, input.role(), input.enabled(), input.employeeId());
        View view = accounts.byId(accounts.insertedId()).view();
        audit.record(actor, AuditMapper.Action.CREATE, AuditMapper.Resource.USER, view.id(), null, view);
        return view;
    }

    @Transactional
    public View update(Actor actor, long id, Update input) {
        List<Long> enabledAdministrators = accounts.lockEnabledAdmins();
        Api.required(accounts.lock(id));
        View before = Api.required(accounts.byId(id)).view();
        if (enabledAdministrators.size() == 1 && enabledAdministrators.contains(id)
                && (!input.enabled() || input.role() != Role.ADMIN)) {
            throw Api.conflict("至少保留一个启用的财务管理员");
        }
        boolean rebind = !Objects.equals(input.employeeId(), before.employeeId());
        validateEmployee(input.role(), input.employeeId(), rebind || input.role() != before.role());
        boolean invalidate = before.enabled() != input.enabled() || before.role() != input.role() || rebind;
        accounts.update(id, input.displayName().strip(), input.role(), input.enabled(), input.employeeId(), invalidate ? 1 : 0);
        View view = accounts.byId(id).view();
        audit.record(actor, AuditMapper.Action.UPDATE, AuditMapper.Resource.USER, id, before, view);
        return view;
    }

    String hashPassword(String value) {
        if (value == null || value.isBlank() || value.length() < 10 || value.getBytes(StandardCharsets.UTF_8).length > 72) {
            throw Api.invalid("密码至少 10 个字符且不可超过 72 字节");
        }
        return passwords.encode(value);
    }

    private void validateEmployee(Role role, Long employeeId, boolean requireActive) {
        if (role == Role.SALES && employeeId == null) {
            throw Api.invalid("业务员账号必须绑定员工");
        }
        if (employeeId != null) {
            Catalog.Employee employee = catalog.employee(employeeId, true);
            if (employee == null || (requireActive && employee.status() != Catalog.Employment.ACTIVE)) {
                throw Api.invalid("请选择在职员工绑定账号");
            }
        }
    }
}
