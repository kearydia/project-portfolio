package course.ops;

import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import course.ops.SessionAccess.Actor;
import course.ops.Catalog.*;

@Service
class MaintenanceService {
    enum Kind { CUSTOMER, PRODUCT, EMPLOYEE }
    enum Target { ENABLED, DISABLED, ACTIVE, INACTIVE, LEFT }

    record Batch(@NotNull Kind kind,@NotNull Target status,@NotEmpty @Size(max=100) List<@NotNull @Positive Long> ids) {}
    record PreviewInput(Kind kind) {}
    record Confirm(@NotBlank String token,@NotNull Kind kind,@NotEmpty @Size(max=100) List<@NotNull @Positive Long> ids,
                   boolean confirmed) {}
    record Preview(String token,List<CleanupMapper.Candidate> eligible,List<CleanupMapper.Candidate> protectedRows) {}
    private record Ticket(long owner,long epoch,Instant expires,Map<Kind,Set<Long>> ids) {}

    private final CatalogMapper catalog;
    private final CatalogService service;
    private final CleanupMapper cleanup;
    private final Map<String,Ticket> tickets = new ConcurrentHashMap<>();

    MaintenanceService(CatalogMapper catalog,CatalogService service,CleanupMapper cleanup) {
        this.catalog = catalog;
        this.service = service;
        this.cleanup = cleanup;
    }

    @Transactional
    public Map<String,Integer> batch(Actor actor,Batch batch) {
        admin(actor);
        List<Long> ids = unique(batch.ids());
        for (long id : ids) {
            switch (batch.kind()) {
                case CUSTOMER -> {
                    Customer row = Api.required(catalog.customer(id,null,true));
                    service.updateCustomer(actor,id,new CustomerInput(row.name(),row.ownerId(),enabled(batch.status())));
                }
                case PRODUCT -> {
                    Product row = Api.required(catalog.product(id,true));
                    service.updateProduct(actor,id,new ProductInput(row.sku(),row.name(),row.unitPrice(),enabled(batch.status())));
                }
                case EMPLOYEE -> {
                    Employee row = Api.required(catalog.employee(id,true));
                    if (batch.status() == Target.ENABLED || batch.status() == Target.DISABLED) {
                        throw Api.invalid("员工仅可批量变更在职状态");
                    }
                    service.updateEmployee(actor,id,new EmployeeInput(row.employeeNo(),row.name(),row.departmentId(),
                            Employment.valueOf(batch.status().name())));
                }
            }
        }
        return Map.of("updated",ids.size());
    }

    public synchronized Preview preview(Actor actor,Kind kind) {
        admin(actor);
        tickets.values().removeIf(ticket -> ticket.expires().isBefore(Instant.now()));
        if (tickets.size() >= 64) { throw Api.conflict("清理预览过多，请稍后重试"); }
        var rows = cleanup.list(kind);
        var eligible = rows.stream().filter(row -> !row.blocked()).toList();
        var protectedRows = rows.stream().filter(CleanupMapper.Candidate::blocked).toList();
        Map<Kind,Set<Long>> ids = new EnumMap<>(Kind.class);
        for (var row : eligible) {
            ids.computeIfAbsent(row.kind(),unused -> new HashSet<>()).add(row.id());
        }
        String token = UUID.randomUUID().toString();
        tickets.put(token,new Ticket(actor.id(),DbGate.EPOCH.get(),Instant.now().plusSeconds(300),ids));
        return new Preview(token,eligible,protectedRows);
    }

    @Transactional
    public Map<String,Integer> confirm(Actor actor,Confirm confirm) {
        admin(actor);
        List<Long> ids = unique(confirm.ids());
        Ticket ticket = tickets.get(confirm.token());
        if (!confirm.confirmed() || ticket == null || ticket.owner() != actor.id()
                || ticket.epoch() != DbGate.EPOCH.get() || ticket.expires().isBefore(Instant.now())
                || !ticket.ids().getOrDefault(confirm.kind(),Set.of()).containsAll(ids)
                || !tickets.remove(confirm.token(),ticket)) {
            throw Api.conflict("清理范围、预览或确认无效，请重新预览");
        }
        for (long id : ids) {
            switch (confirm.kind()) {
                case CUSTOMER -> {
                    if (Api.required(catalog.customer(id,null,true)).enabled()) { throw Api.conflict("客户已恢复启用"); }
                    service.deleteCustomer(actor,id);
                }
                case PRODUCT -> {
                    if (Api.required(catalog.product(id,true)).enabled()) { throw Api.conflict("产品已恢复在售"); }
                    service.deleteProduct(actor,id);
                }
                case EMPLOYEE -> {
                    if (Api.required(catalog.employee(id,true)).status() == Employment.ACTIVE) {
                        throw Api.conflict("员工已恢复在职");
                    }
                    service.deleteEmployee(actor,id);
                }
            }
        }
        // The database rechecks all references, including void orders, in this same DML transaction.
        return Map.of("deleted",ids.size());
    }

    private void admin(Actor actor) {
        if (!actor.admin()) { throw Api.denied(); }
    }

    private boolean enabled(Target target) {
        return switch (target) {
            case ENABLED -> true;
            case DISABLED -> false;
            default -> throw Api.invalid("客户和产品只接受启用或停用状态");
        };
    }

    private List<Long> unique(List<Long> ids) {
        List<Long> result = ids.stream().distinct().sorted().toList();
        if (result.size() != ids.size()) { throw Api.invalid("编号不可重复"); }
        return result;
    }
}
