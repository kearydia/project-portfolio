package course.ops;

import course.ops.Orders.*;
import course.ops.SessionAccess.Actor;
import jakarta.validation.Valid;
import java.nio.charset.StandardCharsets;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
class OrderController {
    private final OrderService service;

    OrderController(OrderService service) {
        this.service = service;
    }

    @GetMapping("/orders")
    Api.Reply list(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @ModelAttribute Filter filter,
                   @RequestParam(defaultValue="1") int page, @RequestParam(defaultValue="10") int pageSize) {
        return Api.Reply.ok(service.list(actor,filter,Api.Paging.of(page,pageSize)));
    }

    @GetMapping("/orders/{id}")
    Api.Reply one(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        return Api.Reply.ok(service.detail(actor,id));
    }

    @PostMapping("/orders")
    Api.Reply create(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid Create input) {
        return Api.Reply.ok(service.create(actor,input));
    }

    @SessionAccess.AdminOnly
    @PutMapping("/orders/{id}")
    Api.Reply update(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                     @RequestBody @Valid Update input) {
        return Api.Reply.ok(service.update(actor,id,input));
    }

    @SessionAccess.AdminOnly
    @PostMapping("/orders/{id}/void")
    Api.Reply voidOrder(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                        @RequestBody @Valid Change input) {
        return Api.Reply.ok(service.change(actor,id,input,Status.VOID));
    }

    @SessionAccess.AdminOnly
    @PostMapping("/orders/{id}/unvoid")
    Api.Reply unvoidOrder(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                          @RequestBody @Valid Change input) {
        return Api.Reply.ok(service.change(actor,id,input,Status.ACTIVE));
    }

    @GetMapping("/stats/overview")
    Api.Reply statistics(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @ModelAttribute Filter filter) {
        return Api.Reply.ok(service.overview(actor,filter));
    }

    @PostMapping("/orders/export")
    ResponseEntity<byte[]> export(@RequestAttribute(SessionAccess.ACTOR) Actor actor,
                                  @RequestBody(required=false) Filter filter) {
        Filter scope = filter == null ? new Filter(null,null,null,null,null,null,null) : filter;
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.attachment()
                        .filename("销售订单.xlsx",StandardCharsets.UTF_8).build().toString())
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(service.export(actor,scope));
    }
}
