package course.ops;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;

final class Catalog {
    private Catalog() {}

    enum Employment { ACTIVE, INACTIVE, LEFT }

    record Option(long id, String name) {}
    record Department(long id, String name, boolean enabled) {}
    record Employee(long id, String employeeNo, String name, long departmentId, Employment status) {}
    record Customer(long id, String name, long ownerId, boolean enabled) {}
    record Product(long id, String sku, String name, BigDecimal unitPrice, boolean enabled) {}

    record DepartmentInput(@NotBlank(message = "请输入部门名称") @Size(max = 80, message = "部门名称过长") String name,
                           @NotNull(message = "请选择启用状态") Boolean enabled) {}

    record EmployeeInput(@NotBlank(message = "请输入工号") @Size(max = 40, message = "工号过长") String employeeNo,
                         @NotBlank(message = "请输入员工姓名") @Size(max = 80, message = "员工姓名过长") String name,
                         @NotNull(message = "请选择部门") @Positive(message = "部门编号无效") Long departmentId,
                         @NotNull(message = "请选择在职状态") Employment status) {}

    record CustomerInput(@NotBlank(message = "请输入客户名称") @Size(max = 120, message = "客户名称过长") String name,
                         @Positive(message = "负责人编号无效") Long ownerId,
                         @NotNull(message = "请选择启用状态") Boolean enabled) {}

    record ProductInput(@NotBlank(message = "请输入产品编号") @Size(max = 40, message = "产品编号过长") String sku,
                        @NotBlank(message = "请输入产品名称") @Size(max = 120, message = "产品名称过长") String name,
                        @NotNull(message = "请输入单价")
                        @DecimalMin(value = "0.00", message = "单价不能为负数")
                        @Digits(integer = 10, fraction = 2, message = "单价最多 10 位整数和 2 位小数") BigDecimal unitPrice,
                        @NotNull(message = "请选择在售状态") Boolean enabled) {}
}
