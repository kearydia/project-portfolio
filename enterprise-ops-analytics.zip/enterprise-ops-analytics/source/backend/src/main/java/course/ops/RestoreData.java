package course.ops;

import course.ops.BackupTables.*;
import course.ops.SessionAccess.Actor;
import java.sql.*;
import java.util.*;
import javax.sql.DataSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.stereotype.Component;

@Component
class RestoreData {
    record Credential(String hash,String role,boolean enabled,String employee) {}
    private final DataSource source;
    private final JdbcTemplate jdbc;

    RestoreData(DataSource source) {
        this.source = source;
        this.jdbc = new JdbcTemplate(source);
    }

    CourseDataSource routing() {
        if (source instanceof CourseDataSource routing) { return routing; }
        throw new IllegalStateException("需要真实课程 MySQL 数据源");
    }

    Map<String,List<Map<String,String>>> read() {
        var data = new LinkedHashMap<String,List<Map<String,String>>>();
        int total = 0;
        for (Table table : BackupTables.TABLES) {
            var rows = jdbc.query("SELECT "+table.columns()+" FROM "+table.name()+" ORDER BY id LIMIT 25001",(rs,n) -> {
                Map<String,String> row = new LinkedHashMap<>();
                for (Field field : table.fields()) { row.put(field.name(),rs.getString(field.name())); }
                return row;
            });
            if ((total += rows.size()) > 25000) { throw Api.invalid("备份最多支持 25000 行"); }
            data.put(table.name(),rows);
        }
        return data;
    }

    Map<String,Credential> credentials(BackupArchive.Bundle bundle,Actor actor) {
        Map<String,Credential> result = new HashMap<>();
        boolean administratorPresent = false;
        for (var row : bundle.data().get("users")) {
            List<Credential> matches = jdbc.query("""
                    SELECT password_hash,role,enabled,employee_id FROM users WHERE id=? AND BINARY username=BINARY ?
                    """, (rs,n) -> new Credential(rs.getString(1),rs.getString(2),rs.getBoolean(3),rs.getString(4)),
                    Long.parseLong(row.get("id")),row.get("username"));
            if (matches.size() != 1 || !matches.get(0).role().equals(row.get("role"))
                    || !Objects.equals(matches.get(0).employee(),row.get("employee_id"))
                    || !matches.get(0).hash().matches("\\$2[aby]\\$\\d{2}\\$[./A-Za-z0-9]{53}")) {
                throw Api.conflict("备份应用账号与当前身份或绑定不同，不能安全恢复");
            }
            Credential match = matches.get(0);
            boolean enabled = match.enabled() && flag(row.get("enabled"));
            result.put(row.get("id"),new Credential(match.hash(),match.role(),enabled,match.employee()));
            if (Long.toString(actor.id()).equals(row.get("id")) && match.role().equals("ADMIN") && enabled) {
                administratorPresent = true;
            }
        }
        if (!administratorPresent) { throw Api.conflict("备份缺少仍可用的当前财务管理员"); }
        return result;
    }

    void create(String target) {
        CourseDataSource router = routing();
        if (!router.owns(target) || router.base().equals(target) || router.catalog().equals(target)
                || !DbGate.LOCK.isWriteLockedByCurrentThread()) {
            throw Api.invalid("候选课程库目标无效");
        }
        Integer count = jdbc.queryForObject(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE BINARY SCHEMA_NAME=BINARY ?",Integer.class,target);
        if (!Objects.equals(count,0)) { throw Api.conflict("候选课程库已存在，未执行覆盖"); }
        // Identifier comes solely from the random server-generated course scope above.
        jdbc.execute("CREATE DATABASE "+target+" CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci");
    }

    void initialize(String target,BackupArchive.Bundle bundle,Map<String,Credential> credentials,Actor actor)
            throws SQLException {
        try (Connection connection = routing().direct(target)) {
            if (!target.equals(connection.getCatalog())) { throw new SQLException("候选课程库选择不一致"); }
            ScriptUtils.executeSqlScript(connection,new ClassPathResource("schema.sql"));
            connection.setAutoCommit(false);
            try {
                for (Table table : BackupTables.TABLES) {
                    write(connection,table,bundle.data().get(table.name()),credentials);
                    try (var statement = connection.createStatement();
                         var rows = statement.executeQuery("SELECT COUNT(*) FROM "+table.name())) {
                        if (!rows.next() || rows.getInt(1) != bundle.manifest().counts().get(table.name())) {
                            throw new SQLException("候选库行数校验失败");
                        }
                    }
                }
                try (var statement = connection.prepareStatement(
                        "SELECT COUNT(*) FROM users WHERE id=? AND role='ADMIN' AND enabled=1")) {
                    statement.setLong(1,actor.id());
                    try (var rows = statement.executeQuery()) {
                        if (!rows.next() || rows.getInt(1) != 1) { throw new SQLException("候选管理员不可用"); }
                    }
                }
                try (var statement = connection.prepareStatement("""
                        INSERT INTO operation_logs(actor_id,actor_name,actor_role,action,resource,target_id)
                        VALUES (?,?,'ADMIN','RESTORE','MAINTENANCE',0)
                        """)) {
                    statement.setLong(1,actor.id());
                    statement.setString(2,actor.username());
                    statement.executeUpdate();
                }
                connection.commit();
            } catch (SQLException | RuntimeException failure) {
                connection.rollback();
                throw failure;
            }
        }
    }

    private void write(Connection connection,Table table,List<Map<String,String>> rows,Map<String,Credential> credentials)
            throws SQLException {
        boolean account = table.name().equals("users");
        int count = table.fields().size()+(account ? 1 : 0);
        String columns = table.columns()+(account ? ",password_hash" : "");
        try (var statement = connection.prepareStatement("INSERT INTO "+table.name()+" ("+columns+") VALUES ("+
                String.join(",",Collections.nCopies(count,"?"))+")")) {
            int pending = 0;
            for (var row : rows) {
                Credential current = account ? credentials.get(row.get("id")) : null;
                for (int index=0; index<table.fields().size(); index++) {
                    Field field = table.fields().get(index);
                    String value = row.get(field.name());
                    if (account && field.name().equals("enabled")) { value = current.enabled() ? "1" : "0"; }
                    if (field.type() == Type.FLAG) { value = flag(value) ? "1" : "0"; }
                    statement.setString(index+1,value);
                }
                if (account) { statement.setString(count,current.hash()); }
                statement.addBatch();
                if (++pending == 500) { statement.executeBatch(); statement.clearBatch(); pending = 0; }
            }
            if (pending != 0) { statement.executeBatch(); }
        }
    }

    private boolean flag(String value) { return "1".equals(value) || "true".equals(value); }
}
