package course.ops;

import com.zaxxer.hikari.HikariDataSource;
import java.io.IOException;
import java.nio.file.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.SQLTransientConnectionException;
import java.util.UUID;
import org.springframework.jdbc.datasource.AbstractDataSource;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

final class CourseDataSource extends AbstractDataSource implements AutoCloseable {
    private final String base;
    private final String user;
    private final String password;
    private final Path state;
    private volatile HikariDataSource active;
    private volatile String catalog;

    CourseDataSource(String base,String user,String password) {
        this.base = base;
        this.user = user;
        this.password = password;
        this.state = Path.of("ops-data",base).toAbsolutePath().normalize();
        Path pointer = state.resolve("active-schema");
        try {
            if (Files.isRegularFile(pointer,LinkOption.NOFOLLOW_LINKS) && Files.size(pointer) <= 120) {
                catalog = Files.readString(pointer).strip();
                if (!owns(catalog) || catalog.equals(base)) { throw new IOException(); }
            } else if (Files.exists(pointer,LinkOption.NOFOLLOW_LINKS)) {
                throw new IOException();
            } else {
                catalog = base;
            }
        } catch (IOException failure) {
            throw new IllegalStateException("课程库指针无效，请核查该应用的恢复状态");
        }
        active = pool(catalog);
    }

    String base() { return base; }
    String catalog() { return catalog; }
    Path state() { return state; }

    void verifyConnection() throws SQLException {
        try (Connection connection = getConnection()) {
            if (!catalog.equals(connection.getCatalog())) {
                throw new SQLException("目标课程库不一致", "3D000");
            }
        }
    }

    static String connectionFailureMessage(Throwable failure) {
        boolean connectionFailed = false;
        for (Throwable cause = failure; cause != null; cause = cause.getCause()) {
            if (cause instanceof SQLException sql) {
                if (sql.getErrorCode() == 1045 || "28000".equals(sql.getSQLState())) {
                    return "MySQL 拒绝了应用的数据库登录，请在本机启动窗口核对 MySQL 账号和数据库密码。";
                }
                if (sql.getErrorCode() == 1044 || sql.getErrorCode() == 1049 || "3D000".equals(sql.getSQLState())) {
                    return "无法使用目标课程库，请核对课程库名称和 MySQL 账号权限。";
                }
                connectionFailed |= sql instanceof SQLNonTransientConnectionException
                        || sql instanceof SQLTransientConnectionException
                        || (sql.getSQLState() != null && sql.getSQLState().startsWith("08"));
            }
            connectionFailed |= cause instanceof CannotGetJdbcConnectionException;
        }
        return connectionFailed ? "应用暂时无法连接 MySQL，请检查本机数据库服务。" : null;
    }

    boolean owns(String schema) {
        return base.equals(schema) || schema.matches(java.util.regex.Pattern.quote(base) + "_r_[a-f0-9]{16}");
    }

    String candidate() {
        return base + "_r_" + UUID.randomUUID().toString().replace("-","").substring(0,16);
    }

    Connection direct(String schema) throws SQLException {
        if (!owns(schema)) { throw new IllegalArgumentException("课程库不在恢复范围内"); }
        return DriverManager.getConnection(url(schema),user,password);
    }

    @Override
    public Connection getConnection() throws SQLException { return active.getConnection(); }

    @Override
    public Connection getConnection(String user,String password) throws SQLException {
        throw new SQLException("课程池只使用启动时授权的连接");
    }

    void switchTo(String next) throws IOException,SQLException {
        if (!owns(next) || next.equals(base) || !DbGate.LOCK.isWriteLockedByCurrentThread()) {
            throw new IllegalStateException("切换仅允许在恢复排他区进行");
        }
        HikariDataSource fresh = pool(next);
        try {
            try (Connection connection = fresh.getConnection()) {
                if (!next.equals(connection.getCatalog())) { throw new SQLException("候选课程库连接不一致"); }
            }
            Files.createDirectories(state);
            Path temp = Files.createTempFile(state,"active-",".tmp");
            try {
                Files.writeString(temp,next + "\n");
                Files.move(temp,state.resolve("active-schema"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
            } finally {
                Files.deleteIfExists(temp);
            }
        } catch (IOException | SQLException | RuntimeException failure) {
            fresh.close();
            throw failure;
        }
        HikariDataSource old = active;
        active = fresh;
        catalog = next;
        DbGate.EPOCH.incrementAndGet();
        old.close();
    }

    private HikariDataSource pool(String schema) {
        HikariDataSource source = new HikariDataSource();
        source.setJdbcUrl(url(schema));
        source.setUsername(user);
        source.setPassword(password);
        source.setConnectionTimeout(5000);
        source.addDataSourceProperty("connectTimeout", 5000);
        return source;
    }

    private String url(String schema) {
        return "jdbc:mysql://127.0.0.1:3306/" + schema;
    }

    @Override
    public void close() { active.close(); }
}
