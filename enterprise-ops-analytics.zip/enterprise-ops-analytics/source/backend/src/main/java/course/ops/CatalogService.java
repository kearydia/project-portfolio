package course.ops;

import course.ops.Api.Paging;
import course.ops.Catalog.*;
import course.ops.SessionAccess.Actor;
import static course.ops.AuditMapper.Action.*;
import static course.ops.AuditMapper.Resource.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
class CatalogService {
    private final CatalogMapper catalog;
    private final AuditService audit;

    CatalogService(CatalogMapper catalog, AuditService audit) {
        this.catalog = catalog;
        this.audit = audit;
    }

    @Transactional(readOnly = true)
    public Api.Reply departments(String q, Paging page) {
        String search = Api.search(q);
        return page.result(catalog.departments(search, page.size(), page.offset()), catalog.departmentCount(search));
    }

    @Transactional
    public Department createDepartment(Actor actor, DepartmentInput input) {
        catalog.insertDepartment(input.name().strip(), input.enabled());
        Department current = catalog.department(catalog.insertedId(), false);
        audit.record(actor, CREATE, DEPARTMENT, current.id(), null, current);
        return current;
    }

    @Transactional
    public Department updateDepartment(Actor actor, long id, DepartmentInput input) {
        Department before = Api.required(catalog.department(id, true));
        catalog.updateDepartment(id, input.name().strip(), input.enabled());
        Department current = catalog.department(id, false);
        audit.record(actor, UPDATE, DEPARTMENT, id, before, current);
        return current;
    }

    @Transactional
    public void deleteDepartment(Actor actor, long id) {
        Department before = Api.required(catalog.department(id, true));
        catalog.deleteDepartment(id);
        audit.record(actor, DELETE, DEPARTMENT, id, before, null);
    }

    @Transactional(readOnly = true)
    public Api.Reply employees(String q, Long departmentId, Paging page) {
        String search = Api.search(q);
        return page.result(catalog.employees(search, departmentId, page.size(), page.offset()),
                catalog.employeeCount(search, departmentId));
    }

    @Transactional
    public Employee createEmployee(Actor actor, EmployeeInput input) {
        ensureActiveDepartment(input.departmentId());
        catalog.insertEmployee(input.employeeNo().strip(), input.name().strip(), input.departmentId(), input.status());
        Employee current = catalog.employee(catalog.insertedId(), false);
        audit.record(actor, CREATE, EMPLOYEE, current.id(), null, current);
        return current;
    }

    @Transactional
    public Employee updateEmployee(Actor actor, long id, EmployeeInput input) {
        Employee before = Api.required(catalog.employee(id, true));
        if (before.departmentId() != input.departmentId()) {
            ensureActiveDepartment(input.departmentId());
        }
        catalog.updateEmployee(id, input.employeeNo().strip(), input.name().strip(), input.departmentId(), input.status());
        Employee current = catalog.employee(id, false);
        audit.record(actor, UPDATE, EMPLOYEE, id, before, current);
        return current;
    }

    @Transactional
    public void deleteEmployee(Actor actor, long id) {
        Employee before = Api.required(catalog.employee(id, true));
        catalog.deleteEmployee(id);
        audit.record(actor, DELETE, EMPLOYEE, id, before, null);
    }

    @Transactional(readOnly = true)
    public Api.Reply customers(Actor actor, String q, Long requestedOwner, Paging page) {
        String search = Api.search(q);
        Long owner = readableOwner(actor, requestedOwner);
        return page.result(catalog.customers(search, owner, page.size(), page.offset()), catalog.customerCount(search, owner));
    }

    public Customer customer(Actor actor, long id) {
        return Api.required(catalog.customer(id, readableOwner(actor, null), false));
    }

    @Transactional
    public Customer createCustomer(Actor actor, CustomerInput input) {
        long owner = writeOwner(actor, input.ownerId());
        ensureActiveOwner(owner);
        catalog.insertCustomer(input.name().strip(), owner, input.enabled());
        Customer current = catalog.customer(catalog.insertedId(), owner, false);
        audit.record(actor, CREATE, CUSTOMER, current.id(), null, current);
        return current;
    }

    @Transactional
    public Customer updateCustomer(Actor actor, long id, CustomerInput input) {
        Customer before = Api.required(catalog.customer(id, readableOwner(actor, null), true));
        long owner = writeOwner(actor, input.ownerId());
        if (owner != before.ownerId()) {
            ensureActiveOwner(owner);
        }
        catalog.updateCustomer(id, input.name().strip(), owner, input.enabled());
        Customer current = catalog.customer(id, owner, false);
        audit.record(actor, UPDATE, CUSTOMER, id, before, current);
        return current;
    }

    @Transactional
    public void deleteCustomer(Actor actor, long id) {
        Customer before = Api.required(catalog.customer(id, null, true));
        catalog.deleteCustomer(id);
        audit.record(actor, DELETE, CUSTOMER, id, before, null);
    }

    @Transactional(readOnly = true)
    public Api.Reply products(String q, Boolean enabled, Paging page) {
        String search = Api.search(q);
        return page.result(catalog.products(search, enabled, page.size(), page.offset()), catalog.productCount(search, enabled));
    }

    @Transactional
    public Product createProduct(Actor actor, ProductInput input) {
        catalog.insertProduct(input.sku().strip(), input.name().strip(), input.unitPrice(), input.enabled());
        Product current = catalog.product(catalog.insertedId(), false);
        audit.record(actor, CREATE, PRODUCT, current.id(), null, current);
        return current;
    }

    @Transactional
    public Product updateProduct(Actor actor, long id, ProductInput input) {
        Product before = Api.required(catalog.product(id, true));
        catalog.updateProduct(id, input.sku().strip(), input.name().strip(), input.unitPrice(), input.enabled());
        Product current = catalog.product(id, false);
        audit.record(actor, UPDATE, PRODUCT, id, before, current);
        return current;
    }

    @Transactional
    public void deleteProduct(Actor actor, long id) {
        Product before = Api.required(catalog.product(id, true));
        catalog.deleteProduct(id);
        audit.record(actor, DELETE, PRODUCT, id, before, null);
    }

    private Long readableOwner(Actor actor, Long requested) {
        if (actor.admin()) {
            return requested;
        }
        if (actor.employeeId() == null || (requested != null && !requested.equals(actor.employeeId()))) {
            throw Api.denied();
        }
        return actor.employeeId();
    }

    private long writeOwner(Actor actor, Long requested) {
        Long owner = readableOwner(actor, requested);
        if (owner == null) {
            throw Api.invalid("请选择客户负责人");
        }
        return owner;
    }

    private void ensureActiveOwner(long id) {
        Employee owner = catalog.employee(id, true);
        if (owner == null || owner.status() != Employment.ACTIVE) {
            throw Api.invalid("请选择在职员工为客户负责人");
        }
    }

    private void ensureActiveDepartment(long id) {
        Department department = catalog.department(id, true);
        if (department == null || !department.enabled()) {
            throw Api.invalid("请选择启用的部门");
        }
    }
}
