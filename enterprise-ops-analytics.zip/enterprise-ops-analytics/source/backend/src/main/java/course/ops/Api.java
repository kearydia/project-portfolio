package course.ops;

import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;

public final class Api {
    private Api() {}

    public record Reply(String code, String message, Object data, Map<String, String> fieldErrors) {
        public static Reply ok(Object value) {
            return new Reply("OK", "操作成功", value, Map.of());
        }
    }

    public record Page<T>(List<T> list, long total, int page, int pageSize) {}

    record Paging(int page, int size, long offset) {
        static Paging of(int page, int size) {
            if (page < 1 || size < 1 || size > 100) {
                throw new Failure(HttpStatus.BAD_REQUEST, "INVALID_PAGE", "页码须从 1 开始，每页 1 至 100 条");
            }
            return new Paging(page, size, (long) (page - 1) * size);
        }

        <T> Reply result(List<T> list, long total) {
            return Reply.ok(new Page<>(list, total, page, size));
        }
    }

    static final class Failure extends RuntimeException {
        final HttpStatus status;
        final String code;

        Failure(HttpStatus status, String code, String message) {
            super(message);
            this.status = status;
            this.code = code;
        }
    }

    static Failure missing() {
        return new Failure(HttpStatus.NOT_FOUND, "NOT_FOUND", "该记录不存在或不可查看");
    }

    static Failure denied() {
        return new Failure(HttpStatus.FORBIDDEN, "FORBIDDEN", "没有权限执行该操作");
    }

    static Failure invalid(String message) {
        return new Failure(HttpStatus.BAD_REQUEST, "INVALID_REQUEST", message);
    }

    static Failure conflict(String message) {
        return new Failure(HttpStatus.CONFLICT, "CONFLICT", message);
    }

    static <T> T required(T value) {
        if (value == null) {
            throw missing();
        }
        return value;
    }

    static String search(String query) {
        if (query == null || query.isBlank()) {
            return null;
        }
        String keyword = query.strip();
        if (keyword.length() > 100) {
            throw invalid("关键词不能超过 100 个字符");
        }
        return "%" + keyword.replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%";
    }
}
