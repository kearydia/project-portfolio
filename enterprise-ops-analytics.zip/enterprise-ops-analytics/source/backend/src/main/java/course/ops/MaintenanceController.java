package course.ops;

import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import course.ops.SessionAccess.Actor;

@RestController
@SessionAccess.AdminOnly
@RequestMapping("/api/maintenance")
class MaintenanceController {
    private final MaintenanceService service;

    MaintenanceController(MaintenanceService service) {
        this.service = service;
    }

    @PostMapping("/batch-update")
    Api.Reply batch(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@Valid @RequestBody MaintenanceService.Batch input) {
        return Api.Reply.ok(service.batch(actor,input));
    }

    @PostMapping("/cleanup-preview")
    Api.Reply preview(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@RequestBody(required=false) MaintenanceService.PreviewInput input) {
        return Api.Reply.ok(service.preview(actor,input == null ? null : input.kind()));
    }

    @PostMapping("/cleanup")
    Api.Reply cleanup(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@Valid @RequestBody MaintenanceService.Confirm input) {
        return Api.Reply.ok(service.confirm(actor,input));
    }
}
