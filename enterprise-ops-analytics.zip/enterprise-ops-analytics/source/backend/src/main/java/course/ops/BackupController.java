package course.ops;

import course.ops.SessionAccess.Actor;
import jakarta.validation.Valid;
import java.io.IOException;
import java.util.Map;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@SessionAccess.AdminOnly
@RequestMapping("/api/maintenance")
class BackupController {
    private final BackupService service;

    BackupController(BackupService service) {
        this.service = service;
    }

    @PostMapping("/backups")
    Api.Reply make(@RequestAttribute(SessionAccess.ACTOR) Actor actor) { return Api.Reply.ok(service.make(actor)); }

    @GetMapping("/backups")
    Api.Reply list(@RequestAttribute(SessionAccess.ACTOR) Actor actor) { return Api.Reply.ok(service.list(actor)); }

    @GetMapping("/target")
    Api.Reply target(@RequestAttribute(SessionAccess.ACTOR) Actor actor) { return Api.Reply.ok(service.target(actor)); }

    @GetMapping("/backups/{id}/file")
    ResponseEntity<byte[]> file(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@PathVariable String id) {
        byte[] bytes = service.file(actor,id);
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/zip"))
                .header(HttpHeaders.CONTENT_DISPOSITION,ContentDisposition.attachment().filename("course-"+id+".zip").build().toString())
                .body(bytes);
    }

    @PostMapping("/restores/preview")
    Api.Reply preview(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@RequestParam("file") MultipartFile file)
            throws IOException {
        if (file.getSize() > BackupArchive.MAX_COMPRESSED || file.isEmpty()) {
            throw Api.invalid("请上传不超过 4 MiB 的课程备份");
        }
        return Api.Reply.ok(service.preview(actor,file.getBytes()));
    }

    @PostMapping("/restores")
    ResponseEntity<Api.Reply> confirm(@RequestAttribute(SessionAccess.ACTOR) Actor actor,
                                     @Valid @RequestBody BackupService.Confirm input) {
        BackupService.Job job = service.restore(actor,input);
        return job.state().equals("COMPLETE") ? ResponseEntity.ok(Api.Reply.ok(job))
                : ResponseEntity.status(HttpStatus.CONFLICT)
                .body(new Api.Reply("RESTORE_FAILED",job.message(),job,Map.of()));
    }

    @GetMapping("/restores/{jobId}")
    Api.Reply job(@RequestAttribute(SessionAccess.ACTOR) Actor actor,@PathVariable String jobId) {
        return Api.Reply.ok(service.job(actor,jobId));
    }
}
