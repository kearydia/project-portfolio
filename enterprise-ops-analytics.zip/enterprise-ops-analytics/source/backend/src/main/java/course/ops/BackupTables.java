package course.ops;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

final class BackupTables {
    private BackupTables() {}
    enum Type { ID, POS_INT, FLAG, MONEY, DATE, TIME, TEXT, SALES_ROLE, EMPLOYMENT, ORDER_STATE }
    record Field(String name, Type type, boolean optional, int max) {}
    record Table(String name,List<Field> fields) {
        String columns() {
            return fields.stream().map(Field::name).collect(Collectors.joining(","));
        }
    }

    static final List<Table> TABLES = List.of(
        table("departments",id("id"),text("name",80),flag("enabled")),
        table("employees",id("id"),text("employee_no",40),text("name",80),id("department_id"),f("status",Type.EMPLOYMENT)),
        table("users",id("id"),text("username",40),text("display_name",80),f("role",Type.SALES_ROLE),flag("enabled"),opt("employee_id",Type.ID)),
        table("customers",id("id"),text("name",120),id("owner_id"),flag("enabled")),
        table("products",id("id"),text("sku",40),text("name",120),f("unit_price",Type.MONEY),flag("enabled")),
        table("sales_orders",id("id"),text("order_no",40),f("business_date",Type.DATE),id("customer_id"),id("employee_id"),
                id("department_id"),f("status",Type.ORDER_STATE),f("total_amount",Type.MONEY),
                new Field("version",Type.ID,false,1),opt("voided_by",Type.ID),opt("voided_at",Type.TIME)),
        table("sales_order_items",id("id"),id("order_id"),id("product_id"),f("display_order",Type.POS_INT),f("quantity",Type.POS_INT),
                f("unit_price",Type.MONEY),f("line_amount",Type.MONEY)),
        table("operation_logs",id("id"),f("occurred_at",Type.TIME),new Field("actor_id",Type.ID,false,1),text("actor_name",40),
                f("actor_role",Type.SALES_ROLE),text("action",32),text("resource",32),
                new Field("target_id",Type.ID,false,1))
    );
    private static final DateTimeFormatter TIMESTAMP = DateTimeFormatter.ofPattern("uuuu-MM-dd HH:mm:ss[.SSSSSS][.SSSSS][.SSSS][.SSS][.SS][.S]");
    private static final int MAX_ROWS = 25000;

    static Map<String,Map<String,Map<String,String>>> validate(Map<String,List<Map<String,String>>> data) {
        if (!data.keySet().equals(TABLES.stream().map(Table::name).collect(Collectors.toSet()))) {
            throw Api.invalid("备份表范围不符合课程白名单");
        }
        var indexed = new HashMap<String,Map<String,Map<String,String>>>();
        long count = 0;
        for (Table table : TABLES) {
            var fields = table.fields().stream().map(Field::name).collect(Collectors.toSet());
            List<Map<String,String>> rows = data.get(table.name());
            if (rows == null || (count += rows.size()) > MAX_ROWS) { throw Api.invalid("备份数据超过配额"); }
            Map<String,Map<String,String>> byId = new HashMap<>();
            for (var row : rows) {
                if (row == null || !row.keySet().equals(fields)) { throw Api.invalid("备份字段与白名单不一致"); }
                for (Field field : table.fields()) { validateValue(field,row.get(field.name())); }
                if (byId.put(row.get("id"),row) != null) { throw Api.invalid("备份存在重复主键"); }
            }
            indexed.put(table.name(),byId);
        }
        for (var row : indexed.get("employees").values()) { refer(indexed,row,"department_id","departments"); }
        for (var row : indexed.get("customers").values()) { refer(indexed,row,"owner_id","employees"); }
        Set<String> accountEmployees = new HashSet<>();
        for (var row : indexed.get("users").values()) {
            refer(indexed,row,"employee_id","employees");
            String employee = row.get("employee_id");
            if ((employee == null && "SALES".equals(row.get("role"))) || (employee != null && !accountEmployees.add(employee))) {
                throw Api.invalid("备份应用账号绑定无效");
            }
        }
        Map<String,BigDecimal> sums = new HashMap<>();
        for (var row : indexed.get("sales_orders").values()) {
            refer(indexed,row,"customer_id","customers"); refer(indexed,row,"employee_id","employees");
            refer(indexed,row,"department_id","departments"); refer(indexed,row,"voided_by","users");
        }
        Set<String> positions = new HashSet<>();
        for (var row : indexed.get("sales_order_items").values()) {
            refer(indexed,row,"order_id","sales_orders"); refer(indexed,row,"product_id","products");
            BigDecimal amount = decimal(row.get("line_amount"));
            BigDecimal correct = decimal(row.get("unit_price")).multiply(new BigDecimal(row.get("quantity")));
            if (amount.compareTo(correct) != 0 || !positions.add(row.get("order_id")+":"+row.get("display_order"))) {
                throw Api.invalid("备份订单明细金额或顺序无效");
            }
            sums.merge(row.get("order_id"),amount,BigDecimal::add);
        }
        for (var row : indexed.get("sales_orders").values()) {
            var sum = sums.get(row.get("id"));
            if (sum == null || decimal(row.get("total_amount")).compareTo(sum) != 0) {
                throw Api.invalid("备份订单合计与明细不一致");
            }
        }
        unique(indexed.get("departments"),"name"); unique(indexed.get("employees"),"employee_no");
        unique(indexed.get("users"),"username"); unique(indexed.get("products"),"sku");
        unique(indexed.get("sales_orders"),"order_no");
        return indexed;
    }

    private static void unique(Map<String,Map<String,String>> rows,String column) {
        Set<String> values = new HashSet<>();
        for (var row : rows.values()) {
            if (!values.add(row.get(column).toLowerCase(Locale.ROOT))) { throw Api.invalid("备份存在重复唯一字段"); }
        }
    }

    private static void refer(Map<String,Map<String,Map<String,String>>> tables,Map<String,String> row,String key,String target) {
        String value = row.get(key);
        if (value != null && !tables.get(target).containsKey(value)) { throw Api.invalid("备份包含无效的引用"); }
    }

    private static BigDecimal decimal(String value) {
        return new BigDecimal(value);
    }

    private static void validateValue(Field field,String value) {
        if (value == null && field.optional()) { return; }
        if (value == null || value.length() > Math.max(field.max(),50) || value.indexOf('\0') >= 0) {
            throw Api.invalid("备份字段为空或超出长度限制");
        }
        try {
            boolean valid = switch (field.type()) {
                case ID -> value.matches("0|[1-9][0-9]{0,18}") && Long.parseLong(value) >= (field.max() == 1 ? 0 : 1);
                case POS_INT -> value.matches("[1-9][0-9]{0,9}") && Integer.parseInt(value) > 0;
                case FLAG -> Set.of("0","1","true","false").contains(value);
                case MONEY -> value.matches("[0-9]{1,16}(?:\\.[0-9]{1,2})?");
                case DATE -> LocalDate.parse(value).getYear() >= 1000;
                case TIME -> LocalDateTime.parse(value,TIMESTAMP).getYear() >= 1000;
                case TEXT -> !value.isBlank() && value.length() <= field.max();
                case SALES_ROLE -> Set.of("ADMIN","SALES").contains(value);
                case EMPLOYMENT -> Set.of("ACTIVE","INACTIVE","LEFT").contains(value);
                case ORDER_STATE -> Set.of("ACTIVE","VOID").contains(value);
            };
            if (valid) { return; }
        } catch (IllegalArgumentException | java.time.DateTimeException ignored) {
            // A malformed archive value is reported without revealing raw content.
        }
        throw Api.invalid("备份字段类型或范围无效");
    }

    private static Table table(String name,Field... fields) { return new Table(name,List.of(fields)); }
    private static Field f(String name,Type type) { return new Field(name,type,false,0); }
    private static Field opt(String name,Type type) { return new Field(name,type,true,0); }
    private static Field id(String name) { return f(name,Type.ID); }
    private static Field flag(String name) { return f(name,Type.FLAG); }
    private static Field text(String name,int max) { return new Field(name,Type.TEXT,false,max); }
}
