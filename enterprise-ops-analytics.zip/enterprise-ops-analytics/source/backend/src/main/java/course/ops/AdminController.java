package course.ops;

import course.ops.Api.Paging;
import course.ops.SessionAccess.Actor;
import jakarta.validation.Valid;
import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

@SessionAccess.AdminOnly
@RestController
@RequestMapping("/api")
class AdminController {
    private final AccountService accounts;
    private final AccountMapper accountMapper;
    private final AuditService audit;

    AdminController(AccountService accounts, AccountMapper accountMapper, AuditService audit) {
        this.accounts = accounts;
        this.accountMapper = accountMapper;
        this.audit = audit;
    }

    @GetMapping("/users")
    Api.Reply users(@RequestParam(required = false) String q, @RequestParam(defaultValue = "1") int page,
                    @RequestParam(defaultValue = "10") int pageSize) {
        return accounts.list(q, Paging.of(page, pageSize));
    }

    @GetMapping("/users/{id}")
    Api.Reply user(@PathVariable long id) {
        return Api.Reply.ok(Api.required(accountMapper.byId(id)).view());
    }

    @PostMapping("/users")
    Api.Reply create(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid Accounts.Create input) {
        return Api.Reply.ok(accounts.create(actor, input));
    }

    @PutMapping("/users/{id}")
    Api.Reply update(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                     @RequestBody @Valid Accounts.Update input) {
        return Api.Reply.ok(accounts.update(actor, id, input));
    }

    @GetMapping("/operation-logs")
    Api.Reply logs(@RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                   @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateTo,
                   @RequestParam(required = false) Long actorId, @RequestParam(required = false) AuditMapper.Action action,
                   @RequestParam(required = false) AuditMapper.Resource resource,
                   @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int pageSize) {
        return audit.list(dateFrom, dateTo, actorId, action, resource, Paging.of(page, pageSize));
    }
}
