package course.ops;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

final class Orders {
    private Orders() {}

    enum Status { ACTIVE, VOID }

    record Filter(@DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate dateFrom,
                  @DateTimeFormat(iso=DateTimeFormat.ISO.DATE) LocalDate dateTo, Long departmentId, String customerName,
                  String orderNo, Long employeeId, Status status) {}

    record Row(long id, String orderNo, LocalDate businessDate, long customerId, String customerName,
               long employeeId, String employeeName, long departmentId, String departmentName,
               Status status, BigDecimal totalAmount, long version, Long voidedBy, LocalDateTime voidedAt) {}

    record Line(long lineId, long orderId, long productId, String productName, int displayOrder,
                int quantity, BigDecimal unitPrice, BigDecimal lineAmount) {}

    record Detail(Row order, List<Line> items) {}

    record InputLine(@Positive(message="明细编号无效") Long lineId,
                     @NotNull(message="请选择商品") @Positive(message="商品编号无效") Long productId,
                     @NotNull(message="请输入数量") @Positive(message="数量须大于零")
                     @Max(value=1000000,message="数量不能超过一百万") Integer quantity) {}

    record Create(@NotNull LocalDate businessDate, @NotNull @Positive Long customerId,
                  @Positive Long employeeId, @NotEmpty @Size(max=100) List<@NotNull @Valid InputLine> items) {}

    record Update(@NotNull LocalDate businessDate, @NotNull @Positive Long customerId,
                  @NotNull @PositiveOrZero Long expectedVersion,
                  @NotEmpty @Size(max=100) List<@NotNull @Valid InputLine> items) {}

    record Change(@NotNull(message="缺少订单版本") @PositiveOrZero(message="版本无效") Long expectedVersion,
                  @NotBlank(message="请输入原因") @Size(max=200,message="原因最多 200 字") String reason) {}

    record Page(List<Row> list, long total, int page, int pageSize, BigDecimal effectiveTotal, long effectiveCount) {}

    record Totals(long count, BigDecimal amount) {}

    record Month(String month, long count, BigDecimal amount, BigDecimal growthPercent) {}

    record Rank(long id, String name, long count, BigDecimal amount) {}
}
