package course.ops;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.concurrent.locks.Lock;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
class RestoreBarrier extends OncePerRequestFilter {
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return !request.getServletPath().startsWith("/api/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain)
            throws IOException,ServletException {
        boolean restore = "POST".equals(request.getMethod()) && "/api/maintenance/restores".equals(request.getServletPath());
        Lock lock = restore ? DbGate.LOCK.writeLock() : DbGate.LOCK.readLock();
        if (!lock.tryLock()) {
            response.setStatus(409);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"code\":\"MAINTENANCE_BUSY\",\"message\":\"系统恢复或写入正在进行，请稍后再试\",\"data\":null,\"fieldErrors\":{}}");
            return;
        }
        try {
            chain.doFilter(request,response);
        } finally {
            lock.unlock();
        }
    }
}
