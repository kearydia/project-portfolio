package course.ops;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantReadWriteLock;

final class DbGate {
    static final ReentrantReadWriteLock LOCK = new ReentrantReadWriteLock(true);
    static final AtomicLong EPOCH = new AtomicLong();

    private DbGate() {}
}
