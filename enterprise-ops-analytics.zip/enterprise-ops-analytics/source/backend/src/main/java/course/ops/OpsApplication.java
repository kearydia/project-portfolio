package course.ops;

import com.zaxxer.hikari.pool.HikariPool.PoolInitializationException;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
@MapperScan(basePackages = "course.ops", annotationClass = org.apache.ibatis.annotations.Mapper.class)
public class OpsApplication {
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(OpsApplication.class);
        if (args.length == 1 && "--course-stdin".equals(args[0])) {
            application.setDefaultProperties(StartupInput.load(System.in));
            var context = application.run();
            context.getEnvironment().getPropertySources().remove("defaultProperties");
            return;
        }
        application.run(args);
    }

    @Bean
    DataSource dataSource(@Value("${OPS_DB_SCHEMA:}") String schema,
                          @Value("${OPS_DB_USER:}") String username,
                          @Value("${OPS_DB_PASSWORD:}") String password) {
        if (!schema.matches("enterprise_ops_course_20261123_s1(?:_[0-9]{1,12})?") || username.isBlank() || password.isEmpty()) {
            throw new IllegalStateException("请显式提供本次新建的课程库名和已授权的连接账号");
        }
        CourseDataSource source = new CourseDataSource(schema, username, password);
        try {
            source.verifyConnection();
            return source;
        } catch (SQLException | PoolInitializationException failure) {
            source.close();
            String message = CourseDataSource.connectionFailureMessage(failure);
            throw new IllegalStateException(message == null ? "启动前无法验证课程库连接。" : message);
        }
    }
}
