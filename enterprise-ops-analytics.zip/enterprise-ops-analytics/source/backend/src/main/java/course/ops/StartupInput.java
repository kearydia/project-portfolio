package course.ops;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class StartupInput {
    private StartupInput() {}

    static Map<String,Object> load(InputStream input) {
        try {
            Reader reader = new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));
            Map<String,Object> properties = new HashMap<>();
            properties.put("OPS_DB_SCHEMA",line(reader));
            properties.put("OPS_DB_USER",line(reader));
            String dbPassword = line(reader);
            if (dbPassword.isEmpty()) { throw new IllegalArgumentException(); }
            properties.put("OPS_DB_PASSWORD",dbPassword);
            String adminName = line(reader);
            String adminPassword = line(reader);
            if (!adminName.isBlank() || !adminPassword.isEmpty()) {
                if (adminName.isBlank() || adminPassword.isEmpty()) { throw new IllegalArgumentException(); }
                properties.put("ops.bootstrap.enabled","true");
                properties.put("OPS_BOOTSTRAP_NAME",adminName);
                properties.put("OPS_BOOTSTRAP_PASSWORD",adminPassword);
            }
            return properties;
        } catch (IOException | IllegalArgumentException failure) {
            throw new IllegalStateException("本机启动器未交付完整的内存配置");
        }
    }

    private static String line(Reader reader) throws IOException {
        char[] buffer = new char[512];
        int length = 0;
        try {
            for (int value; (value = reader.read()) != -1;) {
                if (value == '\n') { return new String(buffer,0,length); }
                if (value == '\r') { continue; }
                if (value == 0 || length == buffer.length) { throw new IllegalArgumentException(); }
                buffer[length++] = (char)value;
            }
            throw new IllegalArgumentException();
        } finally {
            Arrays.fill(buffer,'\0');
        }
    }
}
