package course.ops;

import course.ops.Api.Paging;
import course.ops.Catalog.*;
import course.ops.SessionAccess.Actor;
import course.ops.SessionAccess.AdminOnly;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
class CatalogController {
    private final CatalogService service;
    private final CatalogMapper catalog;

    CatalogController(CatalogService service, CatalogMapper catalog) {
        this.service = service;
        this.catalog = catalog;
    }

    @GetMapping("/departments/options")
    Api.Reply departmentOptions() {
        return Api.Reply.ok(catalog.departmentsForFilter());
    }

    @AdminOnly
    @GetMapping("/departments")
    Api.Reply departments(@RequestParam(required = false) String q, @RequestParam(defaultValue = "1") int page,
                          @RequestParam(defaultValue = "10") int pageSize) {
        return service.departments(q, Paging.of(page, pageSize));
    }

    @AdminOnly
    @GetMapping("/departments/{id}")
    Api.Reply department(@PathVariable long id) {
        return Api.Reply.ok(Api.required(catalog.department(id, false)));
    }

    @AdminOnly
    @PostMapping("/departments")
    Api.Reply createDepartment(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid DepartmentInput input) {
        return Api.Reply.ok(service.createDepartment(actor, input));
    }

    @AdminOnly
    @PutMapping("/departments/{id}")
    Api.Reply updateDepartment(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                               @RequestBody @Valid DepartmentInput input) {
        return Api.Reply.ok(service.updateDepartment(actor, id, input));
    }

    @AdminOnly
    @DeleteMapping("/departments/{id}")
    Api.Reply deleteDepartment(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        service.deleteDepartment(actor, id);
        return Api.Reply.ok(null);
    }

    @AdminOnly
    @GetMapping("/employees")
    Api.Reply employees(@RequestParam(required = false) String q, @RequestParam(required = false) Long departmentId,
                        @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int pageSize) {
        return service.employees(q, departmentId, Paging.of(page, pageSize));
    }

    @AdminOnly
    @GetMapping("/employees/{id}")
    Api.Reply employee(@PathVariable long id) {
        return Api.Reply.ok(Api.required(catalog.employee(id, false)));
    }

    @AdminOnly
    @PostMapping("/employees")
    Api.Reply createEmployee(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid EmployeeInput input) {
        return Api.Reply.ok(service.createEmployee(actor, input));
    }

    @AdminOnly
    @PutMapping("/employees/{id}")
    Api.Reply updateEmployee(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                             @RequestBody @Valid EmployeeInput input) {
        return Api.Reply.ok(service.updateEmployee(actor, id, input));
    }

    @AdminOnly
    @DeleteMapping("/employees/{id}")
    Api.Reply deleteEmployee(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        service.deleteEmployee(actor, id);
        return Api.Reply.ok(null);
    }

    @GetMapping("/customers")
    Api.Reply customers(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestParam(required = false) String q,
                        @RequestParam(required = false) Long ownerId, @RequestParam(defaultValue = "1") int page,
                        @RequestParam(defaultValue = "10") int pageSize) {
        return service.customers(actor, q, ownerId, Paging.of(page, pageSize));
    }

    @GetMapping("/customers/{id}")
    Api.Reply customer(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        return Api.Reply.ok(service.customer(actor, id));
    }

    @PostMapping("/customers")
    Api.Reply createCustomer(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid CustomerInput input) {
        return Api.Reply.ok(service.createCustomer(actor, input));
    }

    @PutMapping("/customers/{id}")
    Api.Reply updateCustomer(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                             @RequestBody @Valid CustomerInput input) {
        return Api.Reply.ok(service.updateCustomer(actor, id, input));
    }

    @AdminOnly
    @DeleteMapping("/customers/{id}")
    Api.Reply deleteCustomer(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        service.deleteCustomer(actor, id);
        return Api.Reply.ok(null);
    }

    @GetMapping("/products")
    Api.Reply products(@RequestParam(required = false) String q, @RequestParam(required = false) Boolean enabled,
                       @RequestParam(defaultValue = "1") int page, @RequestParam(defaultValue = "10") int pageSize) {
        return service.products(q, enabled, Paging.of(page, pageSize));
    }

    @GetMapping("/products/{id}")
    Api.Reply product(@PathVariable long id) {
        return Api.Reply.ok(Api.required(catalog.product(id, false)));
    }

    @AdminOnly
    @PostMapping("/products")
    Api.Reply createProduct(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @RequestBody @Valid ProductInput input) {
        return Api.Reply.ok(service.createProduct(actor, input));
    }

    @AdminOnly
    @PutMapping("/products/{id}")
    Api.Reply updateProduct(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id,
                            @RequestBody @Valid ProductInput input) {
        return Api.Reply.ok(service.updateProduct(actor, id, input));
    }

    @AdminOnly
    @DeleteMapping("/products/{id}")
    Api.Reply deleteProduct(@RequestAttribute(SessionAccess.ACTOR) Actor actor, @PathVariable long id) {
        service.deleteProduct(actor, id);
        return Api.Reply.ok(null);
    }
}
