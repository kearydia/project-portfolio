package course.ops;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
class AuthController {
    private final AccountMapper accounts;
    private final SessionAccess sessions;
    private final BCryptPasswordEncoder passwords = new BCryptPasswordEncoder();
    private final String dummyHash = passwords.encode(java.util.UUID.randomUUID().toString());

    AuthController(AccountMapper accounts, SessionAccess sessions) {
        this.accounts = accounts;
        this.sessions = sessions;
    }

    @SessionAccess.Anonymous
    @GetMapping("/ready")
    Api.Reply ready() {
        if (accounts.selectedSchema() == null) {
            throw new Api.Failure(HttpStatus.SERVICE_UNAVAILABLE, "DATABASE_UNAVAILABLE", "应用尚未连接课程库");
        }
        return Api.Reply.ok(null);
    }

    @SessionAccess.Anonymous
    @GetMapping("/csrf")
    Api.Reply csrf(HttpServletRequest request) {
        return Api.Reply.ok(Map.of("csrfToken", sessions.csrf(request.getSession(true))));
    }

    @SessionAccess.Anonymous
    @PostMapping("/login")
    Api.Reply login(HttpServletRequest request, @RequestBody @Valid Accounts.Login input) {
        if (input.password().getBytes(StandardCharsets.UTF_8).length > 72) {
            throw badLogin();
        }
        Accounts.Row account = accounts.byUsername(input.username().strip());
        String hash = account == null ? dummyHash : account.passwordHash();
        boolean verified = passwords.matches(input.password(), hash);
        if (!verified || account == null || !account.enabled()) {
            throw badLogin();
        }
        return Api.Reply.ok(sessions.login(request, account));
    }

    @GetMapping("/me")
    Api.Reply me(HttpSession session, @RequestAttribute(SessionAccess.ACTOR) SessionAccess.Actor actor) {
        return Api.Reply.ok(sessions.me(session, actor));
    }

    @PostMapping("/logout")
    Api.Reply logout(HttpSession session) {
        session.invalidate();
        return Api.Reply.ok(null);
    }

    private Api.Failure badLogin() {
        return new Api.Failure(HttpStatus.UNAUTHORIZED, "LOGIN_FAILED", "账号或密码错误");
    }
}
