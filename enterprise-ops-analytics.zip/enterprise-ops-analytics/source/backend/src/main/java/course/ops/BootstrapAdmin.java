package course.ops;

import course.ops.Accounts.Role;
import course.ops.AuditMapper.Action;
import course.ops.AuditMapper.Resource;
import course.ops.SessionAccess.Actor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@ConditionalOnProperty(prefix="ops.bootstrap",name="enabled",havingValue="true")
class BootstrapAdmin implements ApplicationRunner {
    private final AccountMapper accounts;
    private final AccountService service;
    private final AuditService audit;
    private final String schema;
    private final String name;
    private String password;

    BootstrapAdmin(AccountMapper accounts, AccountService service, AuditService audit,
                   @Value("${OPS_DB_SCHEMA:}") String schema, @Value("${OPS_BOOTSTRAP_NAME:}") String name,
                   @Value("${OPS_BOOTSTRAP_PASSWORD:}") String password) {
        this.accounts = accounts;
        this.service = service;
        this.audit = audit;
        this.schema = schema;
        this.name = name;
        this.password = password;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        String input = password;
        password = null;
        if (!schema.matches("enterprise_ops_course_20261123_s1(?:_[0-9]{1,12})?")
                || !name.matches("[a-zA-Z0-9_.-]{3,40}") || !schema.equals(accounts.selectedSchema())) {
            throw new IllegalStateException("初始管理员初始化的数据库或应用账号不符合限制");
        }
        if (!accounts.lockForBootstrap().isEmpty()) {
            throw new IllegalStateException("已有应用账号，已停止初始化，原账号保持有效");
        }
        accounts.insert(name,"课程财务管理员",service.hashPassword(input),Role.ADMIN,true,null);
        long id = accounts.insertedId();
        Actor actor = new Actor(id,name,Role.ADMIN,null);
        audit.record(actor,Action.CREATE,Resource.USER,id,null,accounts.byId(id).view());
    }
}
