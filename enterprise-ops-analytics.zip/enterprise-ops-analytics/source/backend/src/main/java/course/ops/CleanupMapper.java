package course.ops;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
interface CleanupMapper {
    record Candidate(MaintenanceService.Kind kind, long id, String name, boolean blocked) {}

    @Select("""
            SELECT kind,id,name,blocked FROM (
              SELECT 'CUSTOMER' AS kind,c.id,c.name,
                EXISTS(SELECT 1 FROM sales_orders o WHERE o.customer_id=c.id) AS blocked
                FROM customers c WHERE c.enabled=0
              UNION ALL
              SELECT 'PRODUCT',p.id,p.name,
                EXISTS(SELECT 1 FROM sales_order_items i WHERE i.product_id=p.id)
                FROM products p WHERE p.enabled=0
              UNION ALL
              SELECT 'EMPLOYEE',e.id,e.name,
                (EXISTS(SELECT 1 FROM sales_orders o WHERE o.employee_id=e.id)
                 OR EXISTS(SELECT 1 FROM customers c WHERE c.owner_id=e.id)
                 OR EXISTS(SELECT 1 FROM users u WHERE u.employee_id=e.id))
                FROM employees e WHERE e.status <> 'ACTIVE'
            ) AS inactive
            WHERE (#{kind} IS NULL OR kind=#{kind})
            ORDER BY kind,id LIMIT 100
            """)
    List<Candidate> list(MaintenanceService.Kind kind);
}
