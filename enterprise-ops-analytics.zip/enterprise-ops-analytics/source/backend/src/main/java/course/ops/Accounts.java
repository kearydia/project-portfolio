package course.ops;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

final class Accounts {
    private Accounts() {}

    enum Role { SALES, ADMIN }

    record Row(long id, String username, String displayName, String passwordHash, Role role,
               boolean enabled, Long employeeId, Long departmentId, long authVersion) {
        View view() {
            return new View(id, username, displayName, role, enabled, employeeId, departmentId);
        }
    }

    record View(long id, String username, String displayName, Role role, boolean enabled,
                Long employeeId, Long departmentId) {}

    record Create(@NotBlank(message = "请输入账号")
                  @Pattern(regexp = "[a-zA-Z0-9_.-]{3,40}", message = "账号须为 3 至 40 位字母、数字或 ._-") String username,
                  @NotBlank(message = "请输入显示姓名") @Size(max = 80, message = "显示姓名过长") String displayName,
                  @NotBlank(message = "请输入密码") @Size(min = 10, max = 72, message = "密码长度须为 10 至 72") String password,
                  @NotNull(message = "请选择角色") Role role,
                  @NotNull(message = "请选择启用状态") Boolean enabled,
                  @Positive(message = "员工编号无效") Long employeeId) {}

    record Update(@NotBlank(message = "请输入显示姓名") @Size(max = 80, message = "显示姓名过长") String displayName,
                  @NotNull(message = "请选择角色") Role role,
                  @NotNull(message = "请选择启用状态") Boolean enabled,
                  @Positive(message = "员工编号无效") Long employeeId) {}

    record Login(@NotBlank(message = "请输入账号") @Size(max = 40, message = "账号过长") String username,
                 @NotBlank(message = "请输入密码") @Size(max = 72, message = "密码过长") String password) {}
}
