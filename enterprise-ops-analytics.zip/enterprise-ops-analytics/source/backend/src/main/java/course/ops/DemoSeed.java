package course.ops;

import course.ops.Accounts.Role;
import course.ops.AuditMapper.Action;
import course.ops.AuditMapper.Resource;
import course.ops.Catalog.*;
import course.ops.SessionAccess.Actor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@ConditionalOnProperty(prefix = "ops.demo", name = "seed", havingValue = "true")
class DemoSeed implements ApplicationRunner {
    private final AccountMapper accounts;
    private final AccountService accountService;
    private final CatalogMapper catalog;
    private final CatalogService catalogService;
    private final AuditService audit;
    private final String adminPassword;
    private final String eastPassword;
    private final String westPassword;

    DemoSeed(AccountMapper accounts, AccountService accountService, CatalogMapper catalog, CatalogService catalogService,
             AuditService audit, @Value("${OPS_DEMO_ADMIN_PASSWORD:}") String adminPassword,
             @Value("${OPS_DEMO_EAST_PASSWORD:}") String eastPassword,
             @Value("${OPS_DEMO_WEST_PASSWORD:}") String westPassword) {
        this.accounts = accounts;
        this.accountService = accountService;
        this.catalog = catalog;
        this.catalogService = catalogService;
        this.audit = audit;
        this.adminPassword = adminPassword;
        this.eastPassword = eastPassword;
        this.westPassword = westPassword;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (accounts.count(null) != 0 || catalog.departmentCount(null) != 0 || catalog.employeeCount(null, null) != 0
                || catalog.customerCount(null, null) != 0 || catalog.productCount(null, null) != 0) {
            throw new IllegalStateException("模拟种子要求空白课程库，未执行种子写入");
        }
        if (adminPassword.equals(eastPassword) || adminPassword.equals(westPassword) || eastPassword.equals(westPassword)) {
            throw Api.invalid("三个演示账号须配置各自独立的密码");
        }
        accounts.insert("demo_admin", "模拟演示财务管理员", accountService.hashPassword(adminPassword), Role.ADMIN, true, null);
        long adminId = accounts.insertedId();
        Actor admin = new Actor(adminId, "demo_admin", Role.ADMIN, null);
        audit.record(admin, Action.CREATE, Resource.USER, adminId, null, accounts.byId(adminId).view());
        seedSales(admin, "东区", "01", "demo_sales_east", eastPassword);
        seedSales(admin, "西区", "02", "demo_sales_west", westPassword);
        catalogService.createProduct(admin, new ProductInput("DEMO-01", "模拟演示产品",
                new java.math.BigDecimal("19.90"), true));
    }

    private void seedSales(Actor admin, String side, String suffix, String username, String password) {
        Department department = catalogService.createDepartment(admin, new DepartmentInput("模拟演示" + side, true));
        Employee employee = catalogService.createEmployee(admin, new EmployeeInput("DEMO-" + suffix,
                "模拟演示业务员" + side, department.id(), Employment.ACTIVE));
        accountService.create(admin, new Accounts.Create(username, employee.name(), password, Role.SALES, true, employee.id()));
        catalogService.createCustomer(admin, new CustomerInput("模拟演示客户" + side, employee.id(), true));
    }
}
