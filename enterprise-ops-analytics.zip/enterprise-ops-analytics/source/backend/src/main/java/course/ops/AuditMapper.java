package course.ops;

import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
interface AuditMapper {
    enum Action { CREATE, UPDATE, DELETE, VOID, UNVOID, EXPORT, BACKUP, RESTORE }
    enum Resource { DEPARTMENT, EMPLOYEE, CUSTOMER, PRODUCT, USER, ORDER, MAINTENANCE }

    record Row(long id, LocalDateTime occurredAt, long actorId, String actorName, Accounts.Role actorRole,
               Action action, Resource resource, long targetId, String beforeJson, String afterJson) {}

    String FILTER = """
             WHERE (#{from} IS NULL OR occurred_at >= #{from})
               AND (#{until} IS NULL OR occurred_at < #{until})
               AND (#{actorId} IS NULL OR actor_id = #{actorId})
               AND (#{action} IS NULL OR action = #{action})
               AND (#{resource} IS NULL OR resource = #{resource})
            """;

    @Insert("""
            INSERT INTO operation_logs (actor_id, actor_name, actor_role, action, resource, target_id, before_json, after_json)
            VALUES (#{actorId}, #{actorName}, #{actorRole}, #{action}, #{resource}, #{targetId}, #{beforeJson}, #{afterJson})
            """)
    void insert(long actorId, String actorName, Accounts.Role actorRole, Action action, Resource resource, long targetId,
                String beforeJson, String afterJson);

    @Select("""
            SELECT id, occurred_at, actor_id, actor_name, actor_role, action, resource, target_id, before_json, after_json
              FROM operation_logs
            """ + FILTER + " ORDER BY id DESC LIMIT #{size} OFFSET #{offset}")
    List<Row> list(LocalDateTime from, LocalDateTime until, Long actorId, Action action, Resource resource, int size, long offset);

    @Select("SELECT COUNT(*) FROM operation_logs" + FILTER)
    long count(LocalDateTime from, LocalDateTime until, Long actorId, Action action, Resource resource);
}
