package course.ops;

import course.ops.Accounts.Role;
import course.ops.Accounts.Row;
import course.ops.Accounts.View;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Set;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Component
class SessionAccess implements HandlerInterceptor {
    private static final String SESSION_LOGIN = "ops.login";
    private static final String SESSION_CSRF = "ops.csrf";
    static final String ACTOR = "ops.actor";
    static final String CSRF_HEADER = "X-CSRF-Token";
    private static final Set<String> SAFE = Set.of("GET", "HEAD", "OPTIONS");
    private final SecureRandom random = new SecureRandom();
    private final AccountMapper accounts;

    SessionAccess(AccountMapper accounts) {
        this.accounts = accounts;
    }

    @Target(ElementType.METHOD)
    @Retention(RetentionPolicy.RUNTIME)
    @interface Anonymous {}

    @Target({ElementType.METHOD, ElementType.TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    @interface AdminOnly {}

    record Actor(long id, String username, Role role, Long employeeId) {
        boolean admin() {
            return role == Role.ADMIN;
        }
    }

    record Identity(long accountId, long version, long epoch) {}
    record SignedIn(View user, String csrfToken) {}

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (!(handler instanceof HandlerMethod method)) {
            return true;
        }
        response.setHeader("Cache-Control", "no-store");
        HttpSession session = request.getSession(false);
        if (!method.hasMethodAnnotation(Anonymous.class)) {
            Actor actor = current(session);
            if ((method.hasMethodAnnotation(AdminOnly.class)
                    || AnnotatedElementUtils.hasAnnotation(method.getBeanType(), AdminOnly.class)) && !actor.admin()) {
                throw Api.denied();
            }
            request.setAttribute(ACTOR, actor);
        }
        if (!SAFE.contains(request.getMethod())) {
            String expected = session == null ? null : (String) session.getAttribute(SESSION_CSRF);
            String supplied = request.getHeader(CSRF_HEADER);
            if (expected == null || supplied == null || supplied.length() != expected.length()
                    || !MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
                            supplied.getBytes(StandardCharsets.UTF_8))) {
                throw new Api.Failure(HttpStatus.FORBIDDEN, "CSRF_INVALID", "请求校验已过期，请刷新后重试");
            }
        }
        return true;
    }

    String csrf(HttpSession session) {
        synchronized (session) {
            String token = (String) session.getAttribute(SESSION_CSRF);
            return token == null ? rotateToken(session) : token;
        }
    }

    SignedIn login(HttpServletRequest request, Row row) {
        HttpSession session = request.getSession(true);
        request.changeSessionId();
        session.setAttribute(SESSION_LOGIN, new Identity(row.id(), row.authVersion(), DbGate.EPOCH.get()));
        return new SignedIn(row.view(), rotateToken(session));
    }

    SignedIn me(HttpSession session, Actor actor) {
        return new SignedIn(Api.required(accounts.byId(actor.id())).view(), csrf(session));
    }

    private Actor current(HttpSession session) {
        if (session != null && session.getAttribute(SESSION_LOGIN) instanceof Identity identity) {
            if (identity.epoch() != DbGate.EPOCH.get()) {
                session.invalidate();
                throw new Api.Failure(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "数据库已切换，请重新登录");
            }
            Row row = accounts.byId(identity.accountId());
            if (row != null && row.enabled() && row.authVersion() == identity.version()) {
                return new Actor(row.id(), row.username(), row.role(), row.employeeId());
            }
            session.invalidate();
        }
        throw new Api.Failure(HttpStatus.UNAUTHORIZED, "AUTH_REQUIRED", "请登录或重新登录");
    }

    private String rotateToken(HttpSession session) {
        byte[] secret = new byte[32];
        random.nextBytes(secret);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(secret);
        session.setAttribute(SESSION_CSRF, token);
        return token;
    }
}

@Configuration
class WebConfig implements WebMvcConfigurer {
    private final SessionAccess sessions;

    WebConfig(SessionAccess sessions) {
        this.sessions = sessions;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(sessions).addPathPatterns("/api/**");
    }
}
