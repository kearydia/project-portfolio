package course.ops;

import course.ops.Accounts.Role;
import course.ops.Accounts.Row;
import java.util.List;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
interface AccountMapper {
    @Select("SELECT DATABASE()")
    String selectedSchema();

    @Select("SELECT id FROM users ORDER BY id FOR UPDATE")
    List<Long> lockForBootstrap();

    String COLUMNS = "u.id, u.username, u.display_name, u.password_hash, u.role, u.enabled, "
            + "u.employee_id, e.department_id, u.auth_version";
    String FROM = " FROM users u LEFT JOIN employees e ON e.id = u.employee_id";
    String FILTER = " WHERE (#{query} IS NULL OR u.username LIKE #{query} ESCAPE '!'"
            + " OR u.display_name LIKE #{query} ESCAPE '!')";

    @Select("SELECT " + COLUMNS + FROM + " WHERE u.username = #{username}")
    Row byUsername(String username);

    @Select("SELECT " + COLUMNS + FROM + " WHERE u.id = #{id}")
    Row byId(long id);

    @Select("SELECT " + COLUMNS + FROM + FILTER + " ORDER BY u.id DESC LIMIT #{size} OFFSET #{offset}")
    List<Row> list(String query, int size, long offset);

    @Select("SELECT COUNT(*) FROM users u" + FILTER)
    long count(String query);

    @Select("SELECT id FROM users WHERE role = 'ADMIN' AND enabled = 1 ORDER BY id FOR UPDATE")
    List<Long> lockEnabledAdmins();

    @Select("SELECT id FROM users WHERE id = #{id} FOR UPDATE")
    Long lock(long id);

    @Insert("""
            INSERT INTO users (username, display_name, password_hash, role, enabled, employee_id)
            VALUES (#{username}, #{displayName}, #{passwordHash}, #{role}, #{enabled}, #{employeeId})
            """)
    void insert(String username, String displayName, String passwordHash, Role role, boolean enabled, Long employeeId);

    @Select("SELECT LAST_INSERT_ID()")
    long insertedId();

    @Update("""
            UPDATE users SET display_name=#{displayName}, role=#{role}, enabled=#{enabled},
              employee_id=#{employeeId}, auth_version=auth_version+#{versionDelta} WHERE id=#{id}
            """)
    void update(long id, String displayName, Role role, boolean enabled, Long employeeId, int versionDelta);
}
