package course.ops;

import com.fasterxml.jackson.databind.ObjectMapper;
import course.ops.SessionAccess.Actor;
import jakarta.validation.constraints.NotBlank;
import java.io.IOException;
import java.nio.file.*;
import java.sql.SQLException;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

@Service
class BackupService {
    record Saved(String id,long bytes,Instant savedAt) {}
    record Preview(String token,String target,String sha256,Instant expires,Map<String,Integer> counts) {}
    record Confirm(@NotBlank String token,@NotBlank String target,@NotBlank String sha256,boolean confirmed) {}
    record Job(String id,String state,String source,String target,String automaticBackup,
               boolean candidateCreated,String message,Instant at) {}
    private record Ticket(long actor,long epoch,String current,Instant expires,String target,
                          String sha256,BackupArchive.Bundle bundle) {}

    private final RestoreData data;
    private final ObjectMapper json;
    private final BackupArchive archive;
    private final TransactionTemplate snapshot;
    private final TransactionTemplate transaction;
    private final AuditService audit;
    private final Map<String,Ticket> previews = new ConcurrentHashMap<>();
    private final Map<String,Job> jobs = new ConcurrentHashMap<>();

    BackupService(RestoreData data,ObjectMapper json,PlatformTransactionManager transactions,AuditService audit) {
        this.data = data;
        this.json = json;
        this.archive = new BackupArchive(json);
        this.snapshot = new TransactionTemplate(transactions);
        this.snapshot.setIsolationLevel(TransactionDefinition.ISOLATION_REPEATABLE_READ);
        this.snapshot.setReadOnly(true);
        this.transaction = new TransactionTemplate(transactions);
        this.audit = audit;
    }

    public Saved make(Actor actor) {
        admin(actor);
        try {
            Saved saved = save(capture());
            transaction.executeWithoutResult(status -> audit.record(actor,AuditMapper.Action.BACKUP,
                    AuditMapper.Resource.MAINTENANCE,0,null,Map.of("backupId",saved.id(),"bytes",saved.bytes())));
            return saved;
        } catch (IOException failure) {
            throw Api.conflict("无法保存备份，请检查应用数据目录");
        }
    }

    public List<Saved> list(Actor actor) {
        admin(actor);
        try (var files = Files.list(storage("backups"))) {
            var items = new ArrayList<Saved>();
            for (Path file : files.filter(path -> path.getFileName().toString().matches("[0-9a-f-]{36}\\.zip"))
                    .filter(path -> Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS)).limit(100).toList()) {
                String filename = file.getFileName().toString();
                items.add(new Saved(filename.substring(0,36),Files.size(file),Files.getLastModifiedTime(file).toInstant()));
            }
            items.sort(Comparator.comparing(Saved::savedAt).reversed());
            return items;
        } catch (IOException failure) {
            throw Api.conflict("无法读取备份目录");
        }
    }

    Map<String,String> target(Actor actor) {
        admin(actor);
        CourseDataSource router = data.routing();
        return Map.of("base",router.base(),"active",router.catalog());
    }

    public byte[] file(Actor actor,String id) {
        admin(actor);
        requireId(id);
        try {
            Path file = storage("backups").resolve(id+".zip");
            if (!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)) { throw Api.missing(); }
            if (Files.size(file) > BackupArchive.MAX_COMPRESSED) { throw Api.invalid("备份大小不符合限制"); }
            return Files.readAllBytes(file);
        } catch (IOException failure) {
            throw Api.conflict("无法读取备份文件");
        }
    }

    public synchronized Preview preview(Actor actor,byte[] bytes) {
        admin(actor);
        var router = data.routing();
        previews.values().removeIf(ticket -> ticket.expires().isBefore(Instant.now()));
        if (previews.size() >= 6) { throw Api.conflict("恢复预览过多，请等待预览过期"); }
        var bundle = archive.decode(bytes,router.base());
        data.credentials(bundle,actor);
        String token = UUID.randomUUID().toString();
        String target = router.candidate();
        Instant expiry = Instant.now().plusSeconds(300);
        String digest = BackupArchive.hash(bytes);
        previews.put(token,new Ticket(actor.id(),DbGate.EPOCH.get(),router.catalog(),expiry,target,digest,bundle));
        return new Preview(token,target,digest,expiry,bundle.manifest().counts());
    }

    public Job restore(Actor actor,Confirm input) {
        admin(actor);
        CourseDataSource router = data.routing();
        Ticket ticket = previews.get(input.token());
        if (!DbGate.LOCK.isWriteLockedByCurrentThread() || !input.confirmed() || ticket == null || ticket.actor() != actor.id()
                || ticket.epoch() != DbGate.EPOCH.get() || !ticket.current().equals(router.catalog())
                || ticket.expires().isBefore(Instant.now()) || !ticket.target().equals(input.target())
                || !ticket.sha256().equals(input.sha256()) || !previews.remove(input.token(),ticket)) {
            throw Api.conflict("恢复确认已过期、范围不符或系统正在使用，请重新预览");
        }
        String jobId = UUID.randomUUID().toString();
        String backup = null;
        boolean created = false;
        try {
            record(new Job(jobId,"STARTED",ticket.current(),ticket.target(),null,false,"准备保护原库",Instant.now()));
            Map<String,RestoreData.Credential> credentials = data.credentials(ticket.bundle(),actor);
            backup = make(actor).id();
            record(new Job(jobId,"IMPORTING",ticket.current(),ticket.target(),backup,false,"自动备份已生成",Instant.now()));
            data.create(ticket.target());
            created = true;
            record(new Job(jobId,"VALIDATING",ticket.current(),ticket.target(),backup,true,"在新候选库导入并验证",Instant.now()));
            data.initialize(ticket.target(),ticket.bundle(),credentials,actor);
            router.switchTo(ticket.target());
            return record(new Job(jobId,"COMPLETE",ticket.current(),ticket.target(),backup,true,
                    "恢复已切换至候选库，请重新登录。原库保留。",Instant.now()));
        } catch (IOException | SQLException | RuntimeException failure) {
            if (ticket.target().equals(router.catalog())) {
                Job applied = new Job(jobId,"COMPLETE",ticket.current(),ticket.target(),backup,created,
                        "恢复已切换，候选库保留恢复审计；请核查本地恢复状态记录",Instant.now());
                jobs.put(jobId,applied);
                return applied;
            }
            String reason = failure instanceof Api.Failure domain ? domain.getMessage()
                    : "恢复未切换。请核查课程账号建库权限、候选结构或导入约束";
            Job failed = new Job(jobId,"FAILED",ticket.current(),ticket.target(),backup,created,reason,Instant.now());
            try {
                return record(failed);
            } catch (IOException journalFailure) {
                jobs.put(jobId,failed);
                return failed;
            }
        }
    }

    public Job job(Actor actor,String id) {
        admin(actor);
        requireId(id);
        Job current = jobs.get(id);
        if (current != null) { return current; }
        try {
            Path file = storage("restore-journal").resolve(id+".json");
            if (!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS) || Files.size(file) > 16384) { throw Api.missing(); }
            return json.readValue(Files.readAllBytes(file),Job.class);
        } catch (IOException failure) {
            throw Api.conflict("无法读取恢复作业记录");
        }
    }

    private byte[] capture() throws IOException {
        CourseDataSource router = data.routing();
        return archive.encode(router.base(),router.catalog(),Objects.requireNonNull(snapshot.execute(status -> data.read())));
    }

    private synchronized Saved save(byte[] bytes) throws IOException {
        Path folder = storage("backups");
        try (var files = Files.list(folder)) {
            if (files.limit(100).count() >= 100) { throw Api.conflict("备份目录达到 100 份保留配额"); }
        }
        String id = UUID.randomUUID().toString();
        Files.write(folder.resolve(id+".zip"),bytes,StandardOpenOption.CREATE_NEW);
        return new Saved(id,bytes.length,Instant.now());
    }

    private Job record(Job job) throws IOException {
        Path folder = storage("restore-journal");
        Path temp = Files.createTempFile(folder,"journal-",".tmp");
        try {
            Files.write(temp,json.writeValueAsBytes(job));
            Files.move(temp,folder.resolve(job.id()+".json"),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
        } finally {
            Files.deleteIfExists(temp);
        }
        jobs.put(job.id(),job);
        return job;
    }

    private Path storage(String segment) throws IOException {
        Path root = data.routing().state();
        Path folder = root.resolve(segment);
        if (Files.isSymbolicLink(root) || Files.isSymbolicLink(folder)) { throw new IOException("恢复目录不允许链接"); }
        return Files.createDirectories(folder);
    }

    private void admin(Actor actor) {
        if (!actor.admin()) { throw Api.denied(); }
    }

    private void requireId(String id) {
        if (!id.matches("[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}")) { throw Api.missing(); }
    }
}
