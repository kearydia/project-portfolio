package course.ops;

import course.ops.Catalog.*;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

@Mapper
interface CatalogMapper {
    String DEPARTMENT_SEARCH = " WHERE (#{q} IS NULL OR name LIKE #{q} ESCAPE '!')";
    String EMPLOYEE_SEARCH = " WHERE (#{q} IS NULL OR name LIKE #{q} ESCAPE '!' OR employee_no LIKE #{q} ESCAPE '!')"
            + " AND (#{departmentId} IS NULL OR department_id = #{departmentId})";
    String CUSTOMER_SCOPE = " (#{ownerId} IS NULL OR owner_id = #{ownerId})";
    String CUSTOMER_SEARCH = " WHERE" + CUSTOMER_SCOPE + " AND (#{q} IS NULL OR name LIKE #{q} ESCAPE '!')";
    String PRODUCT_SEARCH = " WHERE (#{q} IS NULL OR name LIKE #{q} ESCAPE '!' OR sku LIKE #{q} ESCAPE '!')"
            + " AND (#{enabled} IS NULL OR enabled = #{enabled})";
    String PAGE = " ORDER BY id DESC LIMIT #{size} OFFSET #{offset}";
    String LOCK = "<if test='lock'> FOR UPDATE</if></script>";

    @Select("SELECT LAST_INSERT_ID()")
    long insertedId();

    @Select("SELECT id, name FROM departments ORDER BY name, id")
    List<Option> departmentsForFilter();

    @Select("SELECT id, name, enabled FROM departments" + DEPARTMENT_SEARCH + PAGE)
    List<Department> departments(String q, int size, long offset);

    @Select("SELECT COUNT(*) FROM departments" + DEPARTMENT_SEARCH)
    long departmentCount(String q);

    @Select("<script>SELECT id, name, enabled FROM departments WHERE id=#{id}" + LOCK)
    Department department(long id, boolean lock);

    @Insert("INSERT INTO departments (name, enabled) VALUES (#{name}, #{enabled})")
    void insertDepartment(String name, boolean enabled);

    @Update("UPDATE departments SET name=#{name}, enabled=#{enabled} WHERE id=#{id}")
    void updateDepartment(long id, String name, boolean enabled);

    @Delete("DELETE FROM departments WHERE id=#{id}")
    void deleteDepartment(long id);

    @Select("SELECT id, employee_no, name, department_id, status FROM employees" + EMPLOYEE_SEARCH + PAGE)
    List<Employee> employees(String q, Long departmentId, int size, long offset);

    @Select("SELECT COUNT(*) FROM employees" + EMPLOYEE_SEARCH)
    long employeeCount(String q, Long departmentId);

    @Select("<script>SELECT id, employee_no, name, department_id, status FROM employees WHERE id=#{id}" + LOCK)
    Employee employee(long id, boolean lock);

    @Insert("INSERT INTO employees (employee_no, name, department_id, status) VALUES (#{employeeNo}, #{name}, #{departmentId}, #{status})")
    void insertEmployee(String employeeNo, String name, long departmentId, Employment status);

    @Update("UPDATE employees SET employee_no=#{employeeNo}, name=#{name}, department_id=#{departmentId}, status=#{status} WHERE id=#{id}")
    void updateEmployee(long id, String employeeNo, String name, long departmentId, Employment status);

    @Delete("DELETE FROM employees WHERE id=#{id}")
    void deleteEmployee(long id);

    @Select("SELECT id, name, owner_id, enabled FROM customers" + CUSTOMER_SEARCH + PAGE)
    List<Customer> customers(String q, Long ownerId, int size, long offset);

    @Select("SELECT COUNT(*) FROM customers" + CUSTOMER_SEARCH)
    long customerCount(String q, Long ownerId);

    @Select("<script>SELECT id, name, owner_id, enabled FROM customers WHERE id=#{id} AND" + CUSTOMER_SCOPE + LOCK)
    Customer customer(long id, Long ownerId, boolean lock);

    @Insert("INSERT INTO customers (name, owner_id, enabled) VALUES (#{name}, #{ownerId}, #{enabled})")
    void insertCustomer(String name, long ownerId, boolean enabled);

    @Update("UPDATE customers SET name=#{name}, owner_id=#{ownerId}, enabled=#{enabled} WHERE id=#{id}")
    void updateCustomer(long id, String name, long ownerId, boolean enabled);

    @Delete("DELETE FROM customers WHERE id=#{id}")
    void deleteCustomer(long id);

    @Select("SELECT id, sku, name, unit_price, enabled FROM products" + PRODUCT_SEARCH + PAGE)
    List<Product> products(String q, Boolean enabled, int size, long offset);

    @Select("SELECT COUNT(*) FROM products" + PRODUCT_SEARCH)
    long productCount(String q, Boolean enabled);

    @Select("<script>SELECT id, sku, name, unit_price, enabled FROM products WHERE id=#{id}" + LOCK)
    Product product(long id, boolean lock);

    @Insert("INSERT INTO products (sku, name, unit_price, enabled) VALUES (#{sku}, #{name}, #{unitPrice}, #{enabled})")
    void insertProduct(String sku, String name, BigDecimal unitPrice, boolean enabled);

    @Update("UPDATE products SET sku=#{sku}, name=#{name}, unit_price=#{unitPrice}, enabled=#{enabled} WHERE id=#{id}")
    void updateProduct(long id, String sku, String name, BigDecimal unitPrice, boolean enabled);

    @Delete("DELETE FROM products WHERE id=#{id}")
    void deleteProduct(long id);
}
