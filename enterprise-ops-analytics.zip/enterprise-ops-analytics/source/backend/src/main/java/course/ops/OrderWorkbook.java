package course.ops;

import course.ops.Orders.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

final class OrderWorkbook {
    private static final String MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
    private static final String REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    private OrderWorkbook() {}

    static byte[] build(List<Row> orders, List<Line> items, Totals effective) {
        var bytes = new ByteArrayOutputStream();
        try (var zip = new ZipOutputStream(bytes,StandardCharsets.UTF_8)) {
            entry(zip,"[Content_Types].xml","""
                    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
                      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
                      <Default Extension="xml" ContentType="application/xml"/>
                      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
                      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
                      <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
                      <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
                    </Types>""");
            entry(zip,"_rels/.rels",relationships("<Relationship Id=\"rId1\" Type=\""+REL+"/officeDocument\" Target=\"xl/workbook.xml\"/>"));
            entry(zip,"xl/workbook.xml","<workbook xmlns=\""+MAIN+"\" xmlns:r=\""+REL+
                    "\"><sheets><sheet name=\"订单汇总\" sheetId=\"1\" r:id=\"rId1\"/>"+
                    "<sheet name=\"商品明细\" sheetId=\"2\" r:id=\"rId2\"/></sheets></workbook>");
            entry(zip,"xl/_rels/workbook.xml.rels",relationships(
                    "<Relationship Id=\"rId1\" Type=\""+REL+"/worksheet\" Target=\"worksheets/sheet1.xml\"/>"+
                    "<Relationship Id=\"rId2\" Type=\""+REL+"/worksheet\" Target=\"worksheets/sheet2.xml\"/>"+
                    "<Relationship Id=\"rId3\" Type=\""+REL+"/styles\" Target=\"styles.xml\"/>"));
            entry(zip,"xl/styles.xml","""
                    <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
                    <fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts>
                    <fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
                    <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
                    <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
                    <cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
                    <xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs>
                    <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
                    </styleSheet>""");
            Map<Long,Row> byId = new HashMap<>();
            XMLStreamWriter sheet = sheet(zip,1);
            row(sheet,"订单编号","订单日期","客户","经办人","成交部门","订单状态","订单金额","有效金额贡献");
            for (Row order : orders) {
                byId.put(order.id(),order);
                row(sheet,order.orderNo(),order.businessDate(),order.customerName(),order.employeeName(),order.departmentName(),
                        status(order),order.totalAmount(),order.status() == Status.ACTIVE ? order.totalAmount() : BigDecimal.ZERO);
            }
            row(sheet,"有效合计","","","","","",effective.amount(),effective.amount());
            row(sheet,"有效笔数",effective.count());
            finish(sheet,zip);
            sheet = sheet(zip,2);
            row(sheet,"订单编号","订单状态","明细序号","商品","数量","成交单价","行金额");
            for (Line item : items) {
                Row order = byId.get(item.orderId());
                row(sheet,order.orderNo(),status(order),item.displayOrder(),item.productName(),item.quantity(),
                        item.unitPrice(),item.lineAmount());
            }
            finish(sheet,zip);
        } catch (IOException | XMLStreamException failure) {
            throw new IllegalStateException("无法生成 Excel",failure);
        }
        return bytes.toByteArray();
    }

    private static String status(Row row) {
        return row.status() == Status.ACTIVE ? "有效" : "已作废";
    }

    private static String relationships(String body) {
        return "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"+body+"</Relationships>";
    }

    private static void entry(ZipOutputStream zip, String name, String value) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(value.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static XMLStreamWriter sheet(ZipOutputStream zip,int index) throws IOException, XMLStreamException {
        zip.putNextEntry(new ZipEntry("xl/worksheets/sheet"+index+".xml"));
        XMLStreamWriter writer = XMLOutputFactory.newFactory().createXMLStreamWriter(zip,"UTF-8");
        writer.writeStartDocument("UTF-8","1.0");
        writer.writeStartElement("worksheet");
        writer.writeDefaultNamespace(MAIN);
        writer.writeStartElement("sheetData");
        return writer;
    }

    private static void finish(XMLStreamWriter writer,ZipOutputStream zip) throws IOException,XMLStreamException {
        writer.writeEndElement();
        writer.writeEndElement();
        writer.writeEndDocument();
        writer.flush();
        zip.closeEntry();
    }

    private static void row(XMLStreamWriter writer,Object... values) throws XMLStreamException {
        writer.writeStartElement("row");
        for (Object value : values) {
            writer.writeStartElement("c");
            if (value instanceof Number number) {
                if (number instanceof BigDecimal decimal) {
                    writer.writeAttribute("s","1");
                    writer.writeStartElement("v");
                    writer.writeCharacters(decimal.toPlainString());
                } else {
                    writer.writeStartElement("v");
                    writer.writeCharacters(number.toString());
                }
                writer.writeEndElement();
            } else {
                writer.writeAttribute("t","inlineStr");
                writer.writeStartElement("is");
                writer.writeStartElement("t");
                writer.writeAttribute("xml","http://www.w3.org/XML/1998/namespace","space","preserve");
                // Typed string cells cannot be evaluated as spreadsheet formulas.
                writer.writeCharacters(value.toString().replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\uFFFE\\uFFFF]",""));
                writer.writeEndElement();
                writer.writeEndElement();
            }
            writer.writeEndElement();
        }
        writer.writeEndElement();
    }
}
