package course.ops;

import course.ops.Orders.*;
import course.ops.Orders.Month;
import course.ops.SessionAccess.Actor;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.*;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static course.ops.AuditMapper.Action.*;
import static course.ops.AuditMapper.Resource.ORDER;

@Service
class OrderService {
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final BigDecimal ZERO = BigDecimal.ZERO.setScale(2);
    private static final int EXPORT_ORDERS = 5000;
    private static final int EXPORT_LINES = 50000;
    private final OrderMapper orders;
    private final CatalogMapper catalog;
    private final AuditService audit;

    OrderService(OrderMapper orders, CatalogMapper catalog, AuditService audit) {
        this.orders = orders;
        this.catalog = catalog;
        this.audit = audit;
    }

    @Transactional(readOnly=true)
    public Page list(Actor actor, Filter query, Api.Paging page) {
        Filter filter = scoped(actor, query);
        Totals totals = orders.effective(filter);
        return new Page(orders.list(filter, page.size(), page.offset()), orders.count(filter),
                page.page(), page.size(), totals.amount(), totals.count());
    }

    @Transactional(readOnly=true)
    public Detail detail(Actor actor, long id) {
        return read(id, owner(actor));
    }

    @Transactional
    public Detail create(Actor actor, Create input) {
        LocalDate date = date(input.businessDate());
        Long id = owner(actor);
        if (id != null && input.employeeId() != null && !id.equals(input.employeeId())) {
            throw Api.denied();
        }
        long employeeId = id == null ? requireEmployee(input.employeeId()) : id;
        var employee = catalog.employee(employeeId, true);
        if (employee == null || employee.status() != Catalog.Employment.ACTIVE) {
            throw Api.invalid("请选择在职经办人");
        }
        validateCustomer(input.customerId(), id);
        List<Line> lines = priceLines(input.items(), Map.of());
        String number = "SO-" + UUID.randomUUID().toString().replace("-", "");
        orders.insert(number, date, input.customerId(), employeeId, employee.departmentId(), total(lines));
        long orderId = orders.insertedId();
        for (Line line : lines) {
            orders.addLine(orderId, line);
        }
        Detail after = read(orderId, id);
        audit.record(actor, CREATE, ORDER, orderId, null, after);
        return after;
    }

    @Transactional
    public Detail update(Actor actor, long id, Update input) {
        requireAdmin(actor);
        Api.required(orders.lock(id));
        Detail before = read(id, null);
        checkState(before.order(), Status.ACTIVE, input.expectedVersion());
        validateCustomer(input.customerId(), null);
        Map<Long, Line> original = before.items().stream().collect(Collectors.toMap(Line::lineId, Function.identity()));
        List<Line> lines = priceLines(input.items(), original);
        if (orders.update(id, input.expectedVersion(), date(input.businessDate()), input.customerId(), total(lines)) != 1) {
            throw Api.conflict("订单已变化，请刷新后重试");
        }
        for (Line line : lines) {
            if (line.lineId() == 0) {
                orders.addLine(id, line);
            } else {
                orders.updateLine(id, line);
                original.remove(line.lineId());
            }
        }
        for (Long removed : original.keySet()) {
            orders.deleteLine(id, removed);
        }
        Detail after = read(id, null);
        audit.record(actor, UPDATE, ORDER, id, before, after);
        return after;
    }

    @Transactional
    public Detail change(Actor actor, long id, Change input, Status next) {
        requireAdmin(actor);
        Api.required(orders.lock(id));
        Detail before = read(id, null);
        boolean voiding = next == Status.VOID;
        Status previous = voiding ? Status.ACTIVE : Status.VOID;
        checkState(before.order(), previous, input.expectedVersion());
        if (orders.change(id, input.expectedVersion(), previous, next, voiding ? actor.id() : null,
                voiding ? LocalDateTime.now(BUSINESS_ZONE) : null) != 1) {
            throw Api.conflict("订单已变化，请刷新后重试");
        }
        Detail after = read(id, null);
        audit.record(actor, voiding ? VOID : UNVOID, ORDER, id, before.order(),
                Map.of("order", after.order(), "reason", input.reason().strip()));
        return after;
    }

    @Transactional(readOnly=true)
    public Map<String,Object> overview(Actor actor, Filter query) {
        Filter scoped = scoped(actor, query);
        YearMonth current = YearMonth.now(BUSINESS_ZONE);
        LocalDate start = scoped.dateFrom() == null ? current.minusMonths(5).atDay(1) : scoped.dateFrom();
        LocalDate end = scoped.dateTo() == null ? current.atEndOfMonth() : scoped.dateTo();
        if (!actor.admin()) {
            start = start.isBefore(current.minusMonths(5).atDay(1)) ? current.minusMonths(5).atDay(1) : start;
            end = end.isAfter(current.atEndOfMonth()) ? current.atEndOfMonth() : end;
        }
        if (start.isAfter(end) || java.time.temporal.ChronoUnit.MONTHS.between(YearMonth.from(start), YearMonth.from(end)) > 119) {
            throw Api.invalid("请选择有效的统计时间范围，最多 120 个月");
        }
        Filter window = new Filter(start,end,scoped.departmentId(),scoped.customerName(),
                scoped.orderNo(),scoped.employeeId(),scoped.status());
        Map<String,OrderMapper.MonthRow> values = orders.months(window).stream()
                .collect(Collectors.toMap(OrderMapper.MonthRow::month, Function.identity()));
        List<Month> months = new ArrayList<>();
        BigDecimal previous = ZERO;
        for (YearMonth month = YearMonth.from(start); !month.isAfter(YearMonth.from(end)); month = month.plusMonths(1)) {
            OrderMapper.MonthRow row = values.get(month.toString());
            BigDecimal amount = row == null ? ZERO : row.amount();
            BigDecimal growth = previous.signum() == 0 ? null : amount.subtract(previous)
                    .multiply(BigDecimal.valueOf(100)).divide(previous, 2, RoundingMode.HALF_UP);
            months.add(new Month(month.toString(),row == null ? 0 : row.count(),amount,growth));
            previous = amount;
        }
        var result = new LinkedHashMap<String,Object>();
        result.put("effective",orders.effective(window));
        result.put("months",months);
        result.put("customerRanking",orders.customers(window));
        if (actor.admin()) {
            result.put("employeeRanking",orders.employees(window));
        }
        return result;
    }

    @Transactional
    public byte[] export(Actor actor, Filter query) {
        Filter filter = scoped(actor, query);
        long count = orders.count(filter);
        if (count > EXPORT_ORDERS) {
            throw Api.invalid("导出最多 5000 笔，请缩小查询范围");
        }
        List<Row> rows = orders.list(filter,EXPORT_ORDERS,0);
        List<Line> lines = orders.exportLines(filter,EXPORT_LINES+1);
        if (lines.size() > EXPORT_LINES) {
            throw Api.invalid("导出最多 50000 条明细，请缩小查询范围");
        }
        Totals effective = orders.effective(filter);
        byte[] workbook = OrderWorkbook.build(rows,lines,effective);
        audit.record(actor, EXPORT, ORDER, 0, null, Map.of("orders",rows.size(),"lines",lines.size()));
        return workbook;
    }

    private Detail read(long id, Long scope) {
        Row row = Api.required(orders.one(id, scope));
        return new Detail(row, orders.lines(id));
    }

    private List<Line> priceLines(List<InputLine> inputs, Map<Long,Line> original) {
        List<Line> lines = new ArrayList<>(inputs.size());
        Set<Long> seen = new HashSet<>();
        int sequence = 0;
        for (InputLine input : inputs) {
            Line prior = input.lineId() == null ? null : original.get(input.lineId());
            if (input.lineId() != null && (prior == null || !seen.add(input.lineId()))) {
                throw Api.invalid("明细编号不属于当前订单或重复");
            }
            BigDecimal unitPrice;
            String name;
            if (prior != null && prior.productId() == input.productId()) {
                unitPrice = prior.unitPrice();
                name = prior.productName();
            } else {
                var product = catalog.product(input.productId(), true);
                if (product == null || !product.enabled()) {
                    throw Api.invalid("第 " + (sequence + 1) + " 行请选择在售产品");
                }
                unitPrice = product.unitPrice();
                name = product.name();
            }
            BigDecimal amount = money(unitPrice.multiply(BigDecimal.valueOf(input.quantity())));
            lines.add(new Line(prior == null ? 0 : prior.lineId(),0,input.productId(),name,++sequence,
                    input.quantity(),unitPrice,amount));
        }
        return lines;
    }

    private BigDecimal total(List<Line> lines) {
        return money(lines.stream().map(Line::lineAmount).reduce(ZERO,BigDecimal::add));
    }

    private BigDecimal money(BigDecimal value) {
        BigDecimal amount = value.setScale(2, RoundingMode.UNNECESSARY);
        if (amount.precision() > 18 || amount.signum() < 0) {
            throw Api.invalid("金额超出可保存的范围，请减少数量");
        }
        return amount;
    }

    private void validateCustomer(long customerId, Long scope) {
        var customer = catalog.customer(customerId,scope,true);
        if (customer == null || !customer.enabled()) {
            throw Api.invalid("请选择可见且启用的客户");
        }
    }

    private long requireEmployee(Long id) {
        if (id == null) { throw Api.invalid("请选择经办人"); }
        return id;
    }

    private Long owner(Actor actor) {
        if (actor.admin()) { return null; }
        if (actor.employeeId() == null) { throw Api.denied(); }
        return actor.employeeId();
    }

    private void requireAdmin(Actor actor) {
        if (!actor.admin()) { throw Api.denied(); }
    }

    private LocalDate date(LocalDate value) {
        if (value.getYear() < 1000 || value.isAfter(LocalDate.now(BUSINESS_ZONE))) {
            throw Api.invalid("订单日期不得晚于今天");
        }
        return value;
    }

    private void checkState(Row row, Status required, long version) {
        if (row.version() != version || row.status() != required) {
            throw Api.conflict("订单状态或版本已变化，请刷新后重试");
        }
    }

    private Filter scoped(Actor actor, Filter filter) {
        Long employee = owner(actor);
        if (employee != null && filter.employeeId() != null && !employee.equals(filter.employeeId())) {
            throw Api.denied();
        }
        if (filter.dateFrom() != null && filter.dateTo() != null && filter.dateFrom().isAfter(filter.dateTo())) {
            throw Api.invalid("开始日期不能晚于结束日期");
        }
        return new Filter(filter.dateFrom(),filter.dateTo(),filter.departmentId(),Api.search(filter.customerName()),
                Api.search(filter.orderNo()),employee == null ? filter.employeeId() : employee,filter.status());
    }
}
