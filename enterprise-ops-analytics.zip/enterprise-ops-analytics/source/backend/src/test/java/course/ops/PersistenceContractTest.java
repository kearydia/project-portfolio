package course.ops;

import course.ops.Accounts.Role;
import course.ops.Accounts.Row;
import course.ops.Catalog.Customer;
import course.ops.Catalog.CustomerInput;
import course.ops.Catalog.Employee;
import course.ops.Catalog.Employment;
import course.ops.SessionAccess.Actor;
import java.sql.PreparedStatement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import org.apache.ibatis.scripting.defaults.DefaultParameterHandler;
import org.apache.ibatis.reflection.ParamNameResolver;
import org.apache.ibatis.session.Configuration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class PersistenceContractTest {
    @ParameterizedTest
    @ValueSource(strings = {"count", "effective", "months", "employees", "customers", "list", "exportLines"})
    void orderQueriesBindDefaultAndSelectedFilters(String query) throws Exception {
        Configuration config = new Configuration();
        config.addMapper(OrderMapper.class);
        var method = Arrays.stream(OrderMapper.class.getDeclaredMethods())
                .filter(item -> item.getName().equals(query)).findFirst().orElseThrow();
        var parameters = new ParamNameResolver(config, method);
        var statement = config.getMappedStatement(OrderMapper.class.getName() + "." + query);
        var from = LocalDate.of(2026, 11, 1);
        var to = LocalDate.of(2026, 11, 30);
        var selected = new Orders.Filter(from, to, 7L, "%测试%", "%ORD%", 20L, Orders.Status.ACTIVE);
        var defaults = new Orders.Filter(null, null, null, null, null, null, null);
        Object[] arguments = switch (query) {
            case "list" -> new Object[]{defaults, 10, 30L};
            case "exportLines" -> new Object[]{defaults, 100};
            default -> new Object[]{defaults};
        };
        var unset = parameters.getNamedParams(arguments);
        PreparedStatement emptyCall = mock(PreparedStatement.class);
        new DefaultParameterHandler(statement, unset, statement.getBoundSql(unset)).setParameters(emptyCall);
        for (int index = 1; index <= 14; index++) {
            verify(emptyCall).setNull(index, Types.OTHER);
        }

        arguments[0] = selected;
        var populated = parameters.getNamedParams(arguments);
        PreparedStatement filteredCall = mock(PreparedStatement.class);
        new DefaultParameterHandler(statement, populated, statement.getBoundSql(populated)).setParameters(filteredCall);
        for (int index = 1; index <= 2; index++) {
            verify(filteredCall).setLong(index, 20L);
            verify(filteredCall).setLong(index + 2, 7L);
            verify(filteredCall).setObject(index + 4, from);
            verify(filteredCall).setObject(index + 6, to);
            verify(filteredCall).setString(index + 8, "ACTIVE");
            verify(filteredCall).setString(index + 10, "%测试%");
            verify(filteredCall).setString(index + 12, "%ORD%");
        }
        if (query.equals("list")) {
            verify(filteredCall).setInt(15, 10);
            verify(filteredCall).setLong(16, 30L);
        }
        if (query.equals("exportLines")) {
            verify(filteredCall).setInt(15, 100);
        }
    }

    @Test
    void mapperBindsNamedArgumentsAndAddsRowLockOnlyForWrites() {
        Configuration config = new Configuration();
        config.addMapper(CatalogMapper.class);
        config.addMapper(AccountMapper.class);
        config.addMapper(AuditMapper.class);
        var method = Arrays.stream(CatalogMapper.class.getMethods())
                .filter(item -> item.getName().equals("customer")).findFirst().orElseThrow();
        var parameters = new ParamNameResolver(config, method);
        var statement = config.getMappedStatement(CatalogMapper.class.getName() + ".customer");
        var boundSql = statement.getBoundSql(parameters.getNamedParams(new Object[]{44L, 20L, true}));
        assertThat(boundSql.getSql()).contains("owner_id = ?", "FOR UPDATE").doesNotContain("44", "20");
        assertThat(boundSql.getParameterMappings()).extracting("property").containsExactly("id", "ownerId", "ownerId");
        assertThat(statement.getBoundSql(parameters.getNamedParams(new Object[]{44L, null, false})).getSql())
                .doesNotContain("FOR UPDATE");
    }

    @Test
    void customerCreationDerivesOwnerAndRecordsAudit() {
        CatalogMapper catalog = mock(CatalogMapper.class);
        AuditService audit = mock(AuditService.class);
        Actor actor = new Actor(2, "sandbox_east", Role.SALES, 20L);
        when(catalog.employee(20, true)).thenReturn(new Employee(20, "T-2", "测试员", 1, Employment.ACTIVE));
        when(catalog.insertedId()).thenReturn(44L);
        Customer current = new Customer(44, "测试客户", 20, true);
        when(catalog.customer(44, 20L, false)).thenReturn(current);
        assertThat(new CatalogService(catalog, audit).createCustomer(actor, new CustomerInput("测试客户", null, true)))
                .isEqualTo(current);
        verify(catalog).insertCustomer("测试客户", 20, true);
        verify(audit).record(actor, AuditMapper.Action.CREATE, AuditMapper.Resource.CUSTOMER, 44, null, current);
    }

    @Test
    void disablingUserIncrementsVersionAndAuditsSafeViews() {
        AccountMapper accounts = mock(AccountMapper.class);
        CatalogMapper catalog = mock(CatalogMapper.class);
        AuditService audit = mock(AuditService.class);
        Actor admin = new Actor(1, "sandbox_admin", Role.ADMIN, null);
        Row before = new Row(2, "sandbox_east", "测试业务员", "hash-only", Role.SALES, true, 20L, 1L, 1);
        Row after = new Row(2, "sandbox_east", "测试业务员", "hash-only", Role.SALES, false, 20L, 1L, 2);
        when(accounts.lockEnabledAdmins()).thenReturn(List.of(1L));
        when(accounts.lock(2)).thenReturn(2L);
        when(accounts.byId(2)).thenReturn(before, after);
        when(catalog.employee(20, true)).thenReturn(new Employee(20, "T-2", "测试员", 1, Employment.ACTIVE));
        var result = new AccountService(accounts, catalog, audit).update(admin, 2,
                new Accounts.Update("测试业务员", Role.SALES, false, 20L));
        verify(accounts).update(2, "测试业务员", Role.SALES, false, 20L, 1);
        verify(audit).record(admin, AuditMapper.Action.UPDATE, AuditMapper.Resource.USER, 2, before.view(), after.view());
        assertThat(result.enabled()).isFalse();
    }
}
