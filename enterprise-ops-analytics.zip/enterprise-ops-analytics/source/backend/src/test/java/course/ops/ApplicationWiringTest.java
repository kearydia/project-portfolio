package course.ops;

import com.zaxxer.hikari.pool.HikariPool.PoolInitializationException;
import java.sql.SQLException;
import javax.sql.DataSource;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class ApplicationWiringTest {
    @MockitoBean
    DataSource dataSource;

    @Autowired
    MockMvc mvc;

    @Test
    void bootsActualConfigurationWithoutConnectingToMySql() throws Exception {
        mvc.perform(get("/api/auth/csrf")).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.csrfToken").isString());
        mvc.perform(get("/api/operation-logs")).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH_REQUIRED"));
        verifyNoInteractions(dataSource);
    }

    @Test
    void requiresExplicitCourseSchemaBeforeCreatingDataSource() {
        var app = new OpsApplication();
        assertThatThrownBy(() -> app.dataSource("", "sandbox", "")).isInstanceOf(IllegalStateException.class);
        assertThatThrownBy(() -> app.dataSource("another_database", "sandbox", ""))
                .isInstanceOf(IllegalStateException.class);
    }

    @Test
    void classifiesPoolStartupRejectionWithoutExposingDriverDiagnostics() {
        var rejected = new SQLException("driver diagnostics should stay private", "28000", 1045);
        assertThat(CourseDataSource.connectionFailureMessage(new PoolInitializationException(rejected)))
                .contains("MySQL").doesNotContain(rejected.getMessage());
        assertThat(CourseDataSource.connectionFailureMessage(new SQLException("test syntax", "42000", 1064)))
                .isNull();
    }
}
