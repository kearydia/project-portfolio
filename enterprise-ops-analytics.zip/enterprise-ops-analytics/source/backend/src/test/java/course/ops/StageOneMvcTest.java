package course.ops;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import course.ops.Accounts.Role;
import course.ops.Accounts.Row;
import course.ops.Catalog.Customer;
import course.ops.Catalog.Option;
import course.ops.Catalog.Product;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

class StageOneMvcTest {
    private static final String PASSWORD = "test-only-stage1";
    private static final String HASH = new BCryptPasswordEncoder().encode(PASSWORD);
    private static final String JSON_PASSWORD = "\",\"password\":\"" + PASSWORD + "\"}";
    private static final Row EAST = new Row(2, "sandbox_east", "East", HASH, Role.SALES, true, 20L, 1L, 1);
    private static final Row WEST = new Row(3, "sandbox_west", "West", HASH, Role.SALES, true, 30L, 2L, 1);
    private static final Row ADMIN = new Row(1, "sandbox_admin", "Admin", HASH, Role.ADMIN, true, null, null, 1);

    private final JsonMapper json = JsonMapper.builder().findAndAddModules()
            .enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES).build();
    private AccountMapper accounts;
    private CatalogMapper catalog;
    private AuditService audit;
    private MockMvc mvc;

    @BeforeEach
    void setup() {
        accounts = mock(AccountMapper.class);
        catalog = mock(CatalogMapper.class);
        audit = mock(AuditService.class);
        for (Row row : List.of(EAST, WEST, ADMIN)) {
            when(accounts.byId(row.id())).thenReturn(row);
            when(accounts.byUsername(row.username())).thenReturn(row);
        }
        var access = new SessionAccess(accounts);
        mvc = MockMvcBuilders.standaloneSetup(new AuthController(accounts, access),
                        new CatalogController(new CatalogService(catalog, audit), catalog),
                        new AdminController(new AccountService(accounts, catalog, audit), accounts, audit),
                        new OrderController(mock(OrderService.class)),
                        new BackupController(mock(BackupService.class)))
                .setControllerAdvice(new ApiErrors())
                .setMessageConverters(new MappingJackson2HttpMessageConverter(json))
                .addInterceptors(access)
                .build();
    }

    @Test
    void requiresAuthenticationAndCsrfForLogin() throws Exception {
        mvc.perform(get("/api/products")).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("AUTH_REQUIRED"));
        mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\":\"sandbox_east" + JSON_PASSWORD))
                .andExpect(status().isForbidden()).andExpect(jsonPath("$.code").value("CSRF_INVALID"));
    }

    @Test
    void readinessRequiresCourseDatabaseAndDoesNotExposeSchema() throws Exception {
        mvc.perform(get("/api/auth/ready")).andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.code").value("DATABASE_UNAVAILABLE"));
        when(accounts.selectedSchema()).thenReturn("enterprise_ops_course_20261123_s1");
        mvc.perform(get("/api/auth/ready")).andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("OK"))
                .andExpect(jsonPath("$.data").doesNotExist());
    }

    @Test
    void loginDistinguishesDatabaseRejectionFromInvalidWebPassword() throws Exception {
        MvcResult challenge = mvc.perform(get("/api/auth/csrf")).andExpect(status().isOk()).andReturn();
        var loginRequest = post("/api/auth/login")
                .session((MockHttpSession) challenge.getRequest().getSession(false))
                .header(SessionAccess.CSRF_HEADER, token(challenge))
                .contentType(MediaType.APPLICATION_JSON).content("{\"username\":\"sandbox_missing" + JSON_PASSWORD);
        mvc.perform(loginRequest).andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.code").value("LOGIN_FAILED"));
        when(accounts.byUsername("sandbox_missing")).thenThrow(new CannotGetJdbcConnectionException("test wrapper",
                new SQLException("driver diagnostics should stay private", "28000", 1045)));
        mvc.perform(loginRequest).andExpect(status().isServiceUnavailable())
                .andExpect(jsonPath("$.code").value("DATABASE_UNAVAILABLE"))
                .andExpect(jsonPath("$.message").value(not(containsString("driver diagnostics"))));
    }

    @Test
    void rotatesSessionIdAndInvalidatesOnLogout() throws Exception {
        SignedIn east = signIn(EAST);
        mvc.perform(get("/api/auth/me").session(east.session)).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.user.employeeId").value(20))
                .andExpect(jsonPath("$.data.user.passwordHash").doesNotExist());
        mvc.perform(post("/api/auth/logout").session(east.session))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/auth/logout").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf))
                .andExpect(status().isOk());
        assertThat(east.session.isInvalid()).isTrue();
        mvc.perform(get("/api/auth/me").session(east.session)).andExpect(status().isUnauthorized());
    }

    @Test
    void rejectsStaleSessionsAfterAccountRoleChangeAndDisable() throws Exception {
        SignedIn east = signIn(EAST);
        SignedIn west = signIn(WEST);
        when(accounts.byId(EAST.id())).thenReturn(new Row(EAST.id(), EAST.username(), EAST.displayName(), HASH,
                Role.ADMIN, true, EAST.employeeId(), EAST.departmentId(), 2));
        when(accounts.byId(WEST.id())).thenReturn(new Row(WEST.id(), WEST.username(), WEST.displayName(), HASH,
                Role.SALES, false, WEST.employeeId(), WEST.departmentId(), 2));
        mvc.perform(get("/api/employees").session(east.session)).andExpect(status().isUnauthorized());
        mvc.perform(get("/api/auth/me").session(west.session)).andExpect(status().isUnauthorized());
        assertThat(east.session.isInvalid()).isTrue();
        assertThat(west.session.isInvalid()).isTrue();
    }

    @Test
    void salesCannotOpenAdminModulesOrModifyReadOnlyResources() throws Exception {
        SignedIn east = signIn(EAST);
        for (String path : List.of("/api/employees", "/api/users", "/api/operation-logs",
                "/api/maintenance/backups", "/api/departments")) {
            mvc.perform(get(path).session(east.session)).andExpect(status().isForbidden());
        }
        mvc.perform(delete("/api/customers/44").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/products").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/orders/4/unvoid").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf))
                .andExpect(status().isForbidden());
        verifyNoInteractions(catalog);
    }

    @Test
    void departmentOptionsExposeOnlyIdAndName() throws Exception {
        SignedIn east = signIn(EAST);
        when(catalog.departmentsForFilter()).thenReturn(List.of(new Option(1, "模拟东区")));
        mvc.perform(get("/api/departments/options").session(east.session)).andExpect(status().isOk())
                .andExpect(jsonPath("$.data[0].id").value(1))
                .andExpect(jsonPath("$.data[0].name").value("模拟东区"))
                .andExpect(jsonPath("$.data[0].employeeId").doesNotExist())
                .andExpect(jsonPath("$.data[0].enabled").doesNotExist());
    }

    @Test
    void enforcesCustomerOwnershipInReadAndWrite() throws Exception {
        SignedIn east = signIn(EAST);
        when(catalog.customer(44, 20L, false)).thenReturn(new Customer(44, "东区客户", 20, true));
        mvc.perform(get("/api/customers/44").session(east.session)).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.ownerId").value(20));
        mvc.perform(get("/api/customers/45").session(east.session)).andExpect(status().isNotFound());
        mvc.perform(get("/api/customers").param("ownerId", "30").session(east.session)).andExpect(status().isForbidden());
        mvc.perform(post("/api/customers").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf)
                .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"测试客户\",\"ownerId\":30,\"enabled\":true}"))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/customers").session(east.session).header(SessionAccess.CSRF_HEADER, east.csrf)
                .contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"测试客户\",\"role\":\"ADMIN\",\"enabled\":true}"))
                .andExpect(status().isBadRequest());
        verify(catalog, never()).insertCustomer(anyString(), anyLong(), anyBoolean());
    }

    @Test
    void paginatesAndValidatesFields() throws Exception {
        SignedIn admin = signIn(ADMIN);
        when(catalog.products(null, null, 2, 2)).thenReturn(List.of(new Product(3, "T-3", "测试",
                new BigDecimal("10.00"), true)));
        when(catalog.productCount(null, null)).thenReturn(3L);
        mvc.perform(get("/api/products").param("page", "2").param("pageSize", "2").session(admin.session))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.total").value(3))
                .andExpect(jsonPath("$.data.list[0].id").value(3));
        mvc.perform(get("/api/products").param("pageSize", "101").session(admin.session))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/products").session(admin.session).header(SessionAccess.CSRF_HEADER, admin.csrf)
                .contentType(MediaType.APPLICATION_JSON).content("{\"sku\":\"\",\"name\":\"测试\",\"unitPrice\":-1,\"enabled\":true}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.sku").exists())
                .andExpect(jsonPath("$.fieldErrors.unitPrice").exists());
    }

    @Test
    void translatesReferenceConflictAndDoesNotLogSuccess() throws Exception {
        SignedIn admin = signIn(ADMIN);
        when(catalog.customer(44, null, true)).thenReturn(new Customer(44, "测试客户", 20, true));
        doThrow(new DataIntegrityViolationException("test FK rejection")).when(catalog).deleteCustomer(44);
        mvc.perform(delete("/api/customers/44").session(admin.session).header(SessionAccess.CSRF_HEADER, admin.csrf))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONFLICT"));
        verifyNoInteractions(audit);
    }

    @Test
    void validatesNewWritesAndDoesNotExposeOrderDeletion() throws Exception {
        SignedIn admin = signIn(ADMIN);
        mvc.perform(post("/api/orders/999/unvoid").session(admin.session).header(SessionAccess.CSRF_HEADER, admin.csrf)
                        .contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/maintenance/restores").session(admin.session).header(SessionAccess.CSRF_HEADER, admin.csrf)
                        .contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest());
        mvc.perform(delete("/api/orders/999").session(admin.session).header(SessionAccess.CSRF_HEADER, admin.csrf))
                .andExpect(status().isMethodNotAllowed());
    }

    private SignedIn signIn(Row row) throws Exception {
        MvcResult challenge = mvc.perform(get("/api/auth/csrf")).andExpect(status().isOk()).andReturn();
        MockHttpSession session = (MockHttpSession) challenge.getRequest().getSession(false);
        String oldId = session.getId();
        String oldToken = token(challenge);
        MvcResult login = mvc.perform(post("/api/auth/login").session(session).header(SessionAccess.CSRF_HEADER, oldToken)
                        .contentType(MediaType.APPLICATION_JSON).content("{\"username\":\"" + row.username() + JSON_PASSWORD))
                .andExpect(status().isOk()).andReturn();
        assertThat(session.getId()).isNotEqualTo(oldId);
        assertThat(token(login)).isNotEqualTo(oldToken);
        return new SignedIn(session, token(login));
    }

    private String token(MvcResult response) throws Exception {
        return json.readTree(response.getResponse().getContentAsByteArray()).path("data").path("csrfToken").asText();
    }

    private record SignedIn(MockHttpSession session, String csrf) {}
}
