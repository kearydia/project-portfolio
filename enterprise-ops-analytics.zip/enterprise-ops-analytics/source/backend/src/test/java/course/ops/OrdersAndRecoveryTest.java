package course.ops;

import com.fasterxml.jackson.databind.ObjectMapper;
import course.ops.Accounts.Role;
import course.ops.Catalog.*;
import course.ops.Orders.*;
import course.ops.SessionAccess.Actor;
import java.io.*;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;
import java.util.zip.*;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class OrdersAndRecoveryTest {
    private static final Actor EAST = new Actor(2,"sales-test",Role.SALES,21L);
    private static final Actor ADMIN = new Actor(1,"admin-test",Role.ADMIN,null);
    private static final LocalDate DATE = LocalDate.of(2026,11,1);
    private final OrderMapper orders = mock(OrderMapper.class);
    private final CatalogMapper catalog = mock(CatalogMapper.class);
    private final AuditService audit = mock(AuditService.class);
    private final OrderService service = new OrderService(orders,catalog,audit);

    @Test
    void sameProductCreatesTwoIndependentLinesWithExactAmountAndDepartment() {
        when(catalog.employee(21,true)).thenReturn(new Employee(21,"A","甲",55,Employment.ACTIVE));
        when(catalog.customer(28,21L,true)).thenReturn(new Customer(28,"客户",21,true));
        when(catalog.product(30,true)).thenReturn(new Product(30,"SKU","产品",new BigDecimal("11.26"),true));
        when(orders.insertedId()).thenReturn(8L);
        when(orders.one(8L,21L)).thenReturn(row(new BigDecimal("56.30"),Status.ACTIVE,0));
        service.create(EAST,new Create(DATE,28L,null,List.of(new InputLine(null,30L,2),new InputLine(null,30L,3))));
        var lines = ArgumentCaptor.forClass(Line.class);
        verify(orders,times(2)).addLine(eq(8L),lines.capture());
        assertThat(lines.getAllValues()).extracting(Line::displayOrder).containsExactly(1,2);
        assertThat(lines.getAllValues()).extracting(Line::lineAmount)
                .containsExactly(new BigDecimal("22.52"),new BigDecimal("33.78"));
        verify(orders).insert(anyString(),eq(DATE),eq(28L),eq(21L),eq(55L),eq(new BigDecimal("56.30")));
        verify(audit).record(eq(EAST),eq(AuditMapper.Action.CREATE),eq(AuditMapper.Resource.ORDER),eq(8L),isNull(),any());
    }

    @Test
    void unchangedHistoricalProductKeepsPriceAndVersionMismatchDoesNotWrite() {
        when(orders.lock(8)).thenReturn(8L);
        when(orders.one(8,null)).thenReturn(row(new BigDecimal("5.00"),Status.ACTIVE,3));
        when(orders.lines(8)).thenReturn(List.of(new Line(18,8,30,"停售品",1,2,new BigDecimal("2.50"),new BigDecimal("5.00"))));
        when(catalog.customer(28,null,true)).thenReturn(new Customer(28,"客户",21,true));
        when(catalog.product(31,true)).thenReturn(new Product(31,"SKU","新产品",new BigDecimal("7.10"),true));
        Update stale = new Update(DATE,28L,2L,List.of(new InputLine(18L,30L,3)));
        assertThatThrownBy(() -> service.update(ADMIN,8,stale)).isInstanceOf(Api.Failure.class)
                .hasMessageContaining("版本");
        verify(orders,never()).update(anyLong(),anyLong(),any(),anyLong(),any());
        Update current = new Update(DATE,28L,3L,List.of(new InputLine(18L,30L,3),new InputLine(null,31L,1)));
        when(orders.update(8,3,DATE,28,new BigDecimal("14.60"))).thenReturn(1);
        service.update(ADMIN,8,current);
        verify(catalog,never()).product(30,true);
        verify(orders).updateLine(eq(8L),argThat(line -> line.lineId() == 18 && line.unitPrice().equals(new BigDecimal("2.50"))));
        verify(orders).addLine(eq(8L),argThat(line -> line.unitPrice().equals(new BigDecimal("7.10"))));
    }

    @Test
    void sellerStatisticsAreScopedToSixMonthsAndDoNotQueryEmployeeRanking() {
        var filter = new Filter(null,null,55L,null,null,null,null);
        when(orders.effective(any())).thenReturn(new Totals(0,BigDecimal.ZERO));
        assertThat(service.overview(EAST,filter)).containsKey("customerRanking").doesNotContainKey("employeeRanking");
        var captured = ArgumentCaptor.forClass(Filter.class);
        verify(orders).customers(captured.capture());
        Filter actual = captured.getValue();
        assertThat(actual.employeeId()).isEqualTo(21);
        assertThat(actual.departmentId()).isEqualTo(55);
        assertThat(java.time.temporal.ChronoUnit.MONTHS.between(java.time.YearMonth.from(actual.dateFrom()),
                java.time.YearMonth.from(actual.dateTo()))).isEqualTo(5);
        verify(orders,never()).employees(any());
        assertThatThrownBy(() -> service.list(EAST,new Filter(null,null,null,null,null,22L,null),Api.Paging.of(1,10)))
                .isInstanceOf(Api.Failure.class);
    }

    @Test
    void archiveAcceptsOnlyStructuredCurrentLineageAndRejectsUnknownEntries() throws Exception {
        var codec = new BackupArchive(new ObjectMapper());
        Map<String,List<Map<String,String>>> empty = new LinkedHashMap<>();
        for (var table : BackupTables.TABLES) { empty.put(table.name(),List.of()); }
        String schema = "enterprise_ops_course_20261123_s1";
        byte[] zip = codec.encode(schema,schema,empty);
        assertThat(codec.decode(zip,schema).manifest().counts()).hasSize(8);
        assertThatThrownBy(() -> codec.decode(zip,schema+"_2")).isInstanceOf(Api.Failure.class);
        var buffer = new ByteArrayOutputStream();
        try (var output = new ZipOutputStream(buffer)) {
            output.putNextEntry(new ZipEntry("../unexpected.json"));
            output.write(1);
            output.closeEntry();
        }
        assertThatThrownBy(() -> codec.decode(buffer.toByteArray(),schema)).isInstanceOf(Api.Failure.class)
                .hasMessageContaining("条目");
        Map<String,String> invalid = Map.of("id","1","sku","one","name","test","enabled","1","unit_price","-1");
        empty.put("products",List.of(invalid));
        assertThatThrownBy(() -> codec.encode(schema,schema,empty)).isInstanceOf(Api.Failure.class);
    }

    @Test
    void workbookIncludesOrderAndLineStatusAndWritesUntrustedTextAsString() throws Exception {
        var row = row(new BigDecimal("56.30"),Status.VOID,1);
        var item = new Line(20,8,30,"=1+1",1,2,new BigDecimal("28.15"),new BigDecimal("56.30"));
        Map<String,String> entries = new HashMap<>();
        try (var zip = new ZipInputStream(new ByteArrayInputStream(OrderWorkbook.build(List.of(row),List.of(item),
                new Totals(0,new BigDecimal("0.00")))),StandardCharsets.UTF_8)) {
            for (ZipEntry entry; (entry = zip.getNextEntry()) != null;) {
                entries.put(entry.getName(),new String(zip.readAllBytes(),StandardCharsets.UTF_8));
            }
        }
        assertThat(entries.get("xl/worksheets/sheet1.xml")).contains("已作废","有效合计","0.00");
        assertThat(entries.get("xl/worksheets/sheet2.xml")).contains("已作废","inlineStr","=1+1").doesNotContain("<f>");
    }

    private Orders.Row row(BigDecimal amount,Status status,long version) {
        return new Orders.Row(8,"SO-TEST",DATE,28,"客户",21,"甲",55,"东区",status,amount,version,null,null);
    }
}
