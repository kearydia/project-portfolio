# 企业运营数据深度分析管理系统

课程项目组内评审版。支持员工、客户、产品和销售订单管理，多商品订单、组合筛选、Excel 导出、销售图表、角色权限和操作日志。此处提供 Java / Spring Boot、MyBatis、MySQL 与 Vue 3 / Element Plus / ECharts 源码及虚构示例数据。

## 从源码构建

在项目根目录用 PowerShell 执行，环境需要 Node.js、JDK 17 或以上、Maven 与本机 MySQL 8.0。

```powershell
Set-Location source/frontend
npm ci
npm run build
Set-Location ../backend
mvn -s .mvn/settings.xml -B -ntp package
Copy-Item -LiteralPath 'target/${project.artifactId}-${project.version}.jar' -Destination '../../run/enterprise-ops-review.jar'
Set-Location ../..
```

## Windows 本机试用

准备 JDK 17 或更高版本、本机 MySQL 8.0（TCP 3306）和空闲的本机 8080 端口。下列初始化助手使用你自己 MySQL 上有权创建评审库的 `root` 账号。启动器可以输入已获准的其他数据库账号。已在制作机器上用 JDK 25 和 MySQL 8.0.46 构建并核对连接，JDK 17 实际运行待组员复核。

完成上面的构建后，在本项目根目录打开 **命令提示符（CMD）**。首次使用，先运行：

```bat
review-db.cmd init
start-review.cmd --init-admin
```

1. `review-db.cmd init` 用你的本机 MySQL 密码创建独立评审库 `enterprise_ops_course_20261123_s1_20261125`，再导入空表结构。创建和导入各会提示一次 MySQL 密码。若同名库已经存在，脚本会中止初始化。已成功初始化过的同学从启动步骤继续。
2. `start-review.cmd --init-admin` 先问 MySQL 用户名（直接回车使用 `root`）和 MySQL 密码，再让你为**网页账号** `course-admin` 自设密码。网页密码至少 10 个字符、至多 72 个 UTF-8 字节。初次启动完成后，保持启动窗口打开，访问 [本机登录页](http://127.0.0.1:8080/#/login)。
3. 想直接体验订单和图表时，在同一目录另开一个 CMD，运行 `review-db.cmd seed`，按提示输入 MySQL 密码。刷新网页即可查看 12 笔虚构订单。想从空档案开始练习，可以跳过导入。

以后启动双击 `start-review.cmd`，网页继续用你设过的密码登录。试完可以在启动窗口按 Ctrl+C 停止应用。组员各自使用自己电脑上的数据库和账号。


## 评审进度

原评审版记录了 29 项 Java、MockMvc 和 MyBatis 参数绑定测试通过。本机验证过 MySQL 就绪接口。组员环境的首次建库、角色隔离、导出对账和故障恢复仍在评审范围内。
