@echo off
setlocal
pushd "%~dp0" || exit /b 1
if "%~1"=="--help" goto usage
if not "%~1"=="init" if not "%~1"=="seed" goto usage
set "MYSQL=mysql.exe"
where mysql.exe >nul 2>&1
if errorlevel 1 (
  set "MYSQL=%ProgramFiles%\MySQL\MySQL Server 8.0\bin\mysql.exe"
  if not exist "%ProgramFiles%\MySQL\MySQL Server 8.0\bin\mysql.exe" (
    echo mysql.exe was not found. Use your local MySQL 8 client.
    popd
    exit /b 1
  )
)
set "SCHEMA=enterprise_ops_course_20261123_s1_20261125"
if "%~1"=="seed" goto seed
"%MYSQL%" --no-defaults --protocol=TCP --host=127.0.0.1 --port=3306 --user=root --password --execute="CREATE DATABASE %SCHEMA% CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci"
if errorlevel 1 (
  echo Database creation failed. No schema has been imported.
  popd
  exit /b 1
)
"%MYSQL%" --no-defaults --protocol=TCP --host=127.0.0.1 --port=3306 --user=root --password --database=%SCHEMA% --default-character-set=utf8mb4 --batch --skip-reconnect < "source\database\schema.sql"
if errorlevel 1 (
  echo Schema import failed. Do not repeat init against the existing database.
  popd
  exit /b 1
)
echo Review schema initialized. Run start-review.cmd --init-admin.
popd
exit /b 0
:seed
"%MYSQL%" --no-defaults --protocol=TCP --host=127.0.0.1 --port=3306 --user=root --password --database=%SCHEMA% --default-character-set=utf8mb4 --batch --skip-reconnect < "run\sample-data.sql"
if errorlevel 1 (
  echo Sample data import stopped. Check that the web admin exists and that the batch was not imported before.
  popd
  exit /b 1
)
echo Sample data imported. Refresh the local website.
popd
exit /b 0
:usage
echo Usage: review-db.cmd init ^| seed
popd
exit /b 0
