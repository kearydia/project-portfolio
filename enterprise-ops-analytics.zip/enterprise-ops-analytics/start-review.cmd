@echo off
setlocal
pushd "%~dp0" || exit /b 1
where java.exe >nul 2>&1
if errorlevel 1 (
  echo Java was not found. Use a local JDK 17 or newer.
  popd
  exit /b 1
)
if "%~1"=="" (
  java "run/RunReview.java"
) else if "%~1"=="--init-admin" (
  java "run/RunReview.java" --init-admin
) else if "%~1"=="--help" (
  java "run/RunReview.java" --help
) else (
  echo Usage: start-review.cmd [--init-admin]
  popd
  exit /b 1
)
set "RESULT=%ERRORLEVEL%"
popd
if not "%RESULT%"=="0" if "%~1"=="" pause
exit /b %RESULT%
