-- Run without --force, on the local course schema only.
-- A failed assertion raises 1242 and the client exits without committing the transaction.
SET @schema_guard = IF(BINARY DATABASE() = BINARY 'enterprise_ops_course_20261123_s1_20261125',
                       1, (SELECT 1 UNION ALL SELECT 2));
SET @prefix = 'DEMO-261125-';
SET @prefix_like = CONCAT(@prefix, '%');

START TRANSACTION;

SET @void_actor = (SELECT id FROM users WHERE username = 'course-admin' AND role = 'ADMIN' AND enabled = 1);
SET @batch_guard = IF(@void_actor IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM departments WHERE name IN ('课程演示·东区', '课程演示·西区'))
    AND NOT EXISTS (SELECT 1 FROM employees WHERE employee_no LIKE @prefix_like)
    AND NOT EXISTS (SELECT 1 FROM customers WHERE name LIKE '课程演示·%')
    AND NOT EXISTS (SELECT 1 FROM products WHERE sku LIKE @prefix_like)
    AND NOT EXISTS (SELECT 1 FROM sales_orders WHERE order_no LIKE @prefix_like),
    1, (SELECT 1 UNION ALL SELECT 2));

INSERT INTO departments (name, enabled)
VALUES ('课程演示·东区', 1), ('课程演示·西区', 1);

INSERT INTO employees (employee_no, name, department_id, status)
SELECT CONCAT(@prefix, demo.code), demo.name, d.id, 'ACTIVE'
FROM (
    SELECT 'E01' AS code, '课程演示·陈晨' AS name, '课程演示·东区' AS department_name
    UNION ALL SELECT 'E02', '课程演示·林琪', '课程演示·西区'
    UNION ALL SELECT 'E03', '课程演示·周宁', '课程演示·东区'
) demo
JOIN departments d ON d.name = demo.department_name;

INSERT INTO customers (name, owner_id, enabled)
SELECT demo.name, e.id, 1
FROM (
    SELECT '课程演示·青禾科技' AS name, 'E01' AS employee_code
    UNION ALL SELECT '课程演示·远桥商贸', 'E02'
    UNION ALL SELECT '课程演示·云杉设计', 'E03'
    UNION ALL SELECT '课程演示·海岚文创', 'E02'
) demo
JOIN employees e ON e.employee_no = CONCAT(@prefix, demo.employee_code);

INSERT INTO products (sku, name, unit_price, enabled)
VALUES (CONCAT(@prefix, 'P01'), '课程演示·文件归档盒', 129.00, 1),
       (CONCAT(@prefix, 'P02'), '课程演示·便携订书器', 48.50, 1),
       (CONCAT(@prefix, 'P03'), '课程演示·桌面扫描仪', 315.00, 1),
       (CONCAT(@prefix, 'P04'), '课程演示·标签补充包', 22.00, 1),
       (CONCAT(@prefix, 'P05'), '课程演示·旧款票夹', 16.00, 0);

INSERT INTO sales_orders (order_no, business_date, customer_id, employee_id, department_id,
                          status, total_amount, version, voided_by, voided_at)
SELECT CONCAT(@prefix, demo.code), demo.business_date, c.id, e.id, e.department_id,
       IF(demo.is_void, 'VOID', 'ACTIVE'), 0, demo.is_void,
       IF(demo.is_void, @void_actor, NULL), IF(demo.is_void, '2026-11-19 15:00:00', NULL)
FROM (
    SELECT '01' AS code, DATE '2026-06-06' AS business_date, '青禾科技' AS customer_name, 0 AS is_void
    UNION ALL SELECT '02', DATE '2026-06-20', '远桥商贸', 0
    UNION ALL SELECT '03', DATE '2026-07-08', '云杉设计', 0
    UNION ALL SELECT '04', DATE '2026-07-22', '海岚文创', 0
    UNION ALL SELECT '05', DATE '2026-08-05', '远桥商贸', 0
    UNION ALL SELECT '06', DATE '2026-08-19', '青禾科技', 0
    UNION ALL SELECT '07', DATE '2026-09-09', '云杉设计', 0
    UNION ALL SELECT '08', DATE '2026-09-23', '海岚文创', 0
    UNION ALL SELECT '09', DATE '2026-10-08', '青禾科技', 0
    UNION ALL SELECT '10', DATE '2026-10-21', '远桥商贸', 0
    UNION ALL SELECT '11', DATE '2026-11-16', '云杉设计', 0
    UNION ALL SELECT '12', DATE '2026-11-19', '海岚文创', 1
) demo
JOIN customers c ON c.name = CONCAT('课程演示·', demo.customer_name)
JOIN employees e ON e.id = c.owner_id;

INSERT INTO sales_order_items (order_id, product_id, display_order, quantity, unit_price, line_amount)
SELECT o.id, p.id, demo.line_number, demo.quantity, p.unit_price, demo.quantity * p.unit_price
FROM (
    SELECT '01' AS order_code, 1 AS line_number, 'P01' AS product_code, 2 AS quantity
    UNION ALL SELECT '01', 2, 'P04', 2
    UNION ALL SELECT '02', 1, 'P02', 4
    UNION ALL SELECT '03', 1, 'P03', 1
    UNION ALL SELECT '03', 2, 'P04', 5
    UNION ALL SELECT '04', 1, 'P01', 3
    UNION ALL SELECT '05', 1, 'P02', 2
    UNION ALL SELECT '05', 2, 'P02', 3
    UNION ALL SELECT '06', 1, 'P04', 10
    UNION ALL SELECT '07', 1, 'P03', 2
    UNION ALL SELECT '08', 1, 'P02', 6
    UNION ALL SELECT '08', 2, 'P04', 4
    UNION ALL SELECT '09', 1, 'P01', 5
    UNION ALL SELECT '10', 1, 'P03', 1
    UNION ALL SELECT '10', 2, 'P02', 2
    UNION ALL SELECT '11', 1, 'P04', 12
    UNION ALL SELECT '11', 2, 'P01', 2
    UNION ALL SELECT '12', 1, 'P03', 2
) demo
JOIN sales_orders o ON o.order_no = CONCAT(@prefix, demo.order_code)
JOIN products p ON p.sku = CONCAT(@prefix, demo.product_code);

UPDATE sales_orders o
JOIN (
    SELECT order_id, SUM(line_amount) AS total
    FROM sales_order_items
    GROUP BY order_id
) items ON items.order_id = o.id
SET o.total_amount = items.total
WHERE o.order_no LIKE @prefix_like;

INSERT INTO operation_logs (actor_id, actor_name, actor_role, action, resource, target_id, before_json, after_json)
SELECT 0, '课程演示导入', 'ADMIN', 'CREATE', demo.resource, demo.id, NULL,
       JSON_OBJECT('batch', @prefix, 'label', demo.label)
FROM (
    SELECT 'DEPARTMENT' AS resource, id, name AS label
    FROM departments WHERE name IN ('课程演示·东区', '课程演示·西区')
    UNION ALL SELECT 'EMPLOYEE', id, employee_no FROM employees WHERE employee_no LIKE @prefix_like
    UNION ALL SELECT 'CUSTOMER', id, name FROM customers WHERE name LIKE '课程演示·%'
    UNION ALL SELECT 'PRODUCT', id, sku FROM products WHERE sku LIKE @prefix_like
    UNION ALL SELECT 'ORDER', id, order_no FROM sales_orders WHERE order_no LIKE @prefix_like
) demo;

INSERT INTO operation_logs (actor_id, actor_name, actor_role, action, resource, target_id, before_json, after_json)
SELECT 0, '课程演示导入', 'ADMIN', 'VOID', 'ORDER', id,
       JSON_OBJECT('batch', @prefix, 'status', 'ACTIVE'),
       JSON_OBJECT('batch', @prefix, 'status', 'VOID', 'reason', '课程演示作废与撤销')
FROM sales_orders WHERE order_no = CONCAT(@prefix, '12');

SET @result_guard = IF(
    (SELECT COUNT(*) FROM departments WHERE name IN ('课程演示·东区', '课程演示·西区')) = 2
    AND (SELECT COUNT(*) FROM employees WHERE employee_no LIKE @prefix_like) = 3
    AND (SELECT COUNT(*) FROM customers WHERE name LIKE '课程演示·%') = 4
    AND (SELECT COUNT(*) FROM products WHERE sku LIKE @prefix_like) = 5
    AND (SELECT COUNT(*) FROM sales_orders WHERE order_no LIKE @prefix_like) = 12
    AND (SELECT COUNT(*) FROM sales_orders WHERE order_no LIKE @prefix_like AND status = 'ACTIVE') = 11
    AND (SELECT SUM(total_amount) FROM sales_orders WHERE order_no LIKE @prefix_like AND status = 'ACTIVE') = 4358.50
    AND (SELECT COUNT(*) FROM sales_order_items i JOIN sales_orders o ON i.order_id = o.id
         WHERE o.order_no LIKE @prefix_like) = 18
    AND (SELECT COUNT(*) FROM operation_logs WHERE actor_name = '课程演示导入'
         AND JSON_UNQUOTE(JSON_EXTRACT(after_json, '$.batch')) = @prefix) = 27,
    1, (SELECT 1 UNION ALL SELECT 2));

COMMIT;
