import java.awt.Desktop;
import java.io.Console;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.net.URI;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;

/** Local group-review launcher. Credentials travel only through the child's standard input. */
public final class RunReview {
    private static final String SCHEMA = "enterprise_ops_course_20261123_s1_20261125";
    private static final String ADMIN = "course-admin";
    private static final URI SITE = URI.create("http://127.0.0.1:8080/");

    public static void main(String[] args) throws Exception {
        if (args.length == 1 && "--help".equals(args[0])) {
            System.out.println("java run/RunReview.java [--init-admin]");
            return;
        }
        boolean initialize = args.length == 1 && "--init-admin".equals(args[0]);
        if (args.length > 0 && !initialize) {
            throw new IllegalArgumentException("Expected --init-admin, --help, or no arguments.");
        }
        if (Runtime.version().feature() < 17) {
            throw new IllegalStateException("JDK 17 or later is required.");
        }
        Console console = System.console();
        if (console == null) {
            throw new IllegalStateException("Open the launcher in a local terminal for masked input.");
        }
        Path jar = Path.of("run", "enterprise-ops-review.jar").toAbsolutePath();
        if (!Files.isRegularFile(jar)) {
            throw new IllegalStateException("Run this command from the extracted review folder.");
        }
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress("127.0.0.1", 8080), 500);
            throw new IllegalStateException("Port 8080 is in use. Close the other local app first.");
        } catch (java.net.ConnectException available) {
            // No service is listening on the designated loopback port.
        }
        System.out.println("Review schema: " + SCHEMA);
        String user = console.readLine("Local MySQL username [root]: ");
        if (user == null) return;
        user = user.isBlank() ? "root" : user.strip();
        if (!user.matches("[A-Za-z0-9_.-]{1,64}")) {
            throw new IllegalArgumentException("Invalid MySQL username.");
        }
        char[] db = console.readPassword("MySQL password (hidden): ");
        char[] admin = null;
        Process app = null;
        try {
            if (db == null) return;
            if (db.length == 0 || db.length > 256) {
                throw new IllegalArgumentException("MySQL password is empty or too long.");
            }
            if (initialize) {
                admin = console.readPassword("Set the course-admin web password (hidden, 10+ characters): ");
                if (admin == null) return;
                if (!validAdminPassword(admin)) {
                    throw new IllegalArgumentException("Web password must be 10+ characters and at most 72 UTF-8 bytes.");
                }
            }
            String executable = System.getProperty("os.name").startsWith("Windows") ? "java.exe" : "java";
            var start = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", executable).toString(),
                    "-jar", jar.toString(), "--course-stdin")
                    .redirectOutput(ProcessBuilder.Redirect.INHERIT)
                    .redirectError(ProcessBuilder.Redirect.INHERIT);
            var environment = start.environment();
            environment.keySet().removeIf(key -> {
                String variable = key.toUpperCase(java.util.Locale.ROOT);
                return variable.startsWith("OPS_") || variable.startsWith("SPRING_")
                        || List.of("JAVA_TOOL_OPTIONS", "_JAVA_OPTIONS", "JDK_JAVA_OPTIONS", "MYSQL_PWD").contains(variable);
            });
            environment.put("OPS_PORT", "8080");
            app = start.start();
            try (var input = new OutputStreamWriter(app.getOutputStream(), StandardCharsets.UTF_8)) {
                input.write(SCHEMA + "\n" + user + "\n");
                input.write(db);
                input.write("\n" + (initialize ? ADMIN : "") + "\n");
                if (initialize) input.write(admin);
                input.write('\n');
            }
            Arrays.fill(db, '\0');
            if (admin != null) Arrays.fill(admin, '\0');
            waitForApp(app);
            int exit = app.waitFor();
            if (exit != 0) throw new IllegalStateException("Application stopped, exit code " + exit);
        } finally {
            if (db != null) Arrays.fill(db, '\0');
            if (admin != null) Arrays.fill(admin, '\0');
            if (app != null && app.isAlive()) app.destroy();
        }
    }

    private static boolean validAdminPassword(char[] password) {
        if (password.length < 10 || password.length > 72
                || CharBuffer.wrap(password).chars().allMatch(Character::isWhitespace)) return false;
        var encoded = StandardCharsets.UTF_8.encode(CharBuffer.wrap(password));
        try {
            return encoded.remaining() <= 72;
        } finally {
            Arrays.fill(encoded.array(), (byte) 0);
        }
    }

    private static void waitForApp(Process app) throws InterruptedException {
        for (int attempt = 0; attempt < 30 && app.isAlive(); attempt++) {
            if (ready()) {
                System.out.println("Open " + SITE + " and sign in as " + ADMIN + ". Keep this window open.");
                if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                    try {
                        Desktop.getDesktop().browse(SITE);
                    } catch (IOException failure) {
                        System.out.println("Open the address manually.");
                    }
                }
                return;
            }
            Thread.sleep(1000);
        }
        if (app.isAlive()) throw new IllegalStateException("App not ready. Check the local MySQL service and startup message.");
    }

    private static boolean ready() {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) SITE.resolve("api/auth/ready").toURL().openConnection(Proxy.NO_PROXY);
            connection.setConnectTimeout(500);
            connection.setReadTimeout(800);
            connection.setInstanceFollowRedirects(false);
            if (connection.getResponseCode() != 200) return false;
            try (var input = connection.getInputStream()) {
                return new String(input.readNBytes(1024), StandardCharsets.UTF_8).contains("\"code\":\"OK\"");
            }
        } catch (IOException unavailable) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }
}
