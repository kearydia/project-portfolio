// 生成 sample_data/ 下的模拟数据（固定种子，可复现）。所有文件均标注“模拟数据”。
// 用法：node tools/gen_sample_data.js [种子]。默认种子 20261114：种子 20261113 下杨氏模量相对误差 2.1%、伏安法判定为“基本一致”、逐差组出现误判，故顺延一位，未做其他挑选。
'use strict';
const fs = require('fs'), path = require('path');
const SEED = Number(process.argv[2] || 20261114);
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const rnd = mulberry32(SEED);
const gauss = () => { let u = 0, v = 0; while (u === 0) u = rnd(); while (v === 0) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const r = (x, d) => Number(x.toFixed(d));
const dir = path.join(__dirname, '..', 'sample_data'); fs.mkdirSync(dir, { recursive: true });
const out = {};
function write(name, head, header, rows) {
  const text = head.map(h => '# ' + h).join('\n') + '\n' + header.join(',') + '\n' + rows.map(x => x.join(',')).join('\n') + '\n';
  fs.writeFileSync(path.join(dir, name), text, 'utf8'); out[name] = text;
}
const G = 9.797, R0 = 100.0, E0 = 2.00e11, L = 1.0, D = 1.5, b = 0.05, d = 0.0005, g = 9.80;
const kYoung = 8 * L * D / (Math.PI * d * d * b * E0); // m/N
// 1 单摆图线法：18 个摆长，周期相对噪声 0.3%，第 10 点人为加入异常（+0.12 s）
{ const rows = []; for (let i = 0; i < 18; i++) { const Li = 0.40 + 0.04 * i; let T = 2 * Math.PI * Math.sqrt(Li / G) * (1 + 0.003 * gauss()); if (i === 9) T += 0.12; rows.push([r(Li, 3), r(T, 4), i === 9 ? '模拟数据（含人为异常点）' : '模拟数据']); }
  write('pendulum_fit_模拟数据.csv', ['模拟数据：由 tools/gen_sample_data.js 生成，种子 ' + SEED + '，真值 g=' + G + ' m/s²，周期相对噪声 0.3%，第 10 行为人为异常点'], ['L(m)', 'T(s)', '备注'], rows); }
// 2 单摆单摆长法：L=0.800 m，12 次周期，噪声 σ=0.006 s，第 6 次人为异常（+0.15 s）
{ const T0 = 2 * Math.PI * Math.sqrt(0.8 / G), rows = []; for (let i = 0; i < 12; i++) { let T = T0 + 0.006 * gauss(); if (i === 5) T += 0.15; rows.push([i + 1, r(T, 3), i === 5 ? '模拟数据（含人为异常点）' : '模拟数据']); }
  write('pendulum_single_模拟数据.csv', ['模拟数据：由 tools/gen_sample_data.js 生成，种子 ' + SEED + '，L=0.800 m，真值 g=' + G + ' m/s²，计时噪声 σ=0.006 s，第 6 行为人为异常点'], ['序号', 'T(s)', '备注'], rows); }
// 3 伏安法：I=4..38 mA，电压相对噪声 0.5%，第 9 点人为异常（×1.3）
{ const rows = []; for (let i = 0; i < 18; i++) { const I = 4 + 2 * i; let U = R0 * I / 1000 * (1 + 0.005 * gauss()); if (i === 8) U *= 1.3; rows.push([I, r(U, 3), i === 8 ? '模拟数据（含人为异常点）' : '模拟数据']); }
  write('ohm_fit_模拟数据.csv', ['模拟数据：由 tools/gen_sample_data.js 生成，种子 ' + SEED + '，真值 R=' + R0 + ' Ω，电压相对噪声 0.5%，第 9 行为人为异常点'], ['I(mA)', 'U(V)', '备注'], rows); }
// 4 杨氏模量图线法：m=0.10..0.95 kg，读数噪声 σ=0.025 cm，第 9 点人为异常（+0.20 cm）
{ const rows = []; for (let i = 0; i < 18; i++) { const m = 0.10 + 0.05 * i; let n = 2.00 + kYoung * m * g * 100 + 0.025 * gauss(); if (i === 8) n += 0.20; rows.push([r(m, 2), r(n, 3), i === 8 ? '模拟数据（含人为异常点）' : '模拟数据']); }
  write('young_fit_模拟数据.csv', ['模拟数据：由 tools/gen_sample_data.js 生成，种子 ' + SEED + '，真值 E=2.00e11 Pa（L=1.000 m, D=1.500 m, b=0.0500 m, d=0.500 mm），读数噪声 σ=0.025 cm，第 9 行为人为异常点'], ['m(kg)', 'n(cm)', '备注'], rows); }
// 5 杨氏模量逐差法：m=1..10 kg（每次加 1 kg），读数噪声 σ=0.02 cm，无人为异常
{ const rows = []; for (let i = 0; i < 10; i++) { const m = 1 + i; const n = 1.00 + kYoung * m * g * 100 + 0.02 * gauss(); rows.push([m, r(n, 3), '模拟数据']); }
  write('young_diff_模拟数据.csv', ['模拟数据：由 tools/gen_sample_data.js 生成，种子 ' + SEED + '，真值 E=2.00e11 Pa（参数同上），每次加 1 kg，读数噪声 σ=0.02 cm，本组无人为异常点'], ['m(kg)', 'n(cm)', '备注'], rows); }
// 6 手算验证数据（小数据集，期望值由独立 Python 脚本计算，见 过程证据/03_运行验证/handref_independent.py；非教材例题）
write('手算验证数据_pendulum_single.csv', ['手算验证数据（非实验数据、非教材例题）：L=0.800 m，ΔT=0.01 s，ΔL=0.001 m'], ['序号', 'T(s)'], [[1, 1.80], [2, 1.82], [3, 1.79], [4, 1.81], [5, 1.78]]);
write('手算验证数据_pendulum_fit.csv', ['手算验证数据（非实验数据、非教材例题）'], ['L(m)', 'T(s)'], [[0.40, 1.27], [0.60, 1.55], [0.80, 1.80], [1.00, 2.01]]);
write('手算验证数据_ohm_fit.csv', ['手算验证数据（非实验数据、非教材例题）'], ['I(mA)', 'U(V)'], [[10, 1.02], [20, 1.98], [30, 3.01], [40, 4.00], [50, 5.02]]);
write('手算验证数据_young_fit.csv', ['手算验证数据（非实验数据、非教材例题）：L=1.000 m, D=1.500 m, b=0.0500 m, d=0.500 mm, g=9.80'], ['m(kg)', 'n(cm)'], [[0.5, 0.75], [1.0, 1.52], [1.5, 2.26], [2.0, 3.01], [2.5, 3.77]]);
// 7 脏数据示例（演示中文报错）
fs.writeFileSync(path.join(dir, '脏数据示例_模拟数据.csv'), '# 模拟数据：故意包含空单元格与非数字，用于演示报错（单摆图线法）\nL(m),T(s),备注\n0.40,1.27,模拟数据\n0.60,,模拟数据（空值）\n0.80,1.8a,模拟数据（非数字）\n1.00,2.01,模拟数据\n', 'utf8');
out['脏数据示例_模拟数据.csv'] = fs.readFileSync(path.join(dir, '脏数据示例_模拟数据.csv'), 'utf8');
fs.writeFileSync(path.join(dir, 'samples.js'), '// 自动生成：sample_data 下 CSV 的内嵌副本，保证 file:// 下“加载示例数据”可用。均为模拟数据或手算验证数据。\n(globalThis.SAMPLE_DATA ||= {});\nObject.assign(globalThis.SAMPLE_DATA, ' + JSON.stringify(out, null, 1) + ');\nif (typeof module === "object" && module.exports) module.exports = globalThis.SAMPLE_DATA;\n', 'utf8');
console.log('已生成 ' + Object.keys(out).length + ' 个文件，种子 ' + SEED);
