'use strict';
const fs = require('node:fs'), path = require('node:path');
const { writeWithBackup } = require('./gen_oscilloscope_data.js');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function generateSample() {
  const seed = 20261117, rnd = mulberry32(seed);
  // 一次取样，不筛选种子或噪声；电位保留六位小数，减小 CSV 修约对独立验算的影响。
  const rows = [12, 16, 20, 24, 28, 32, 36, 40, 44].map((r, i) =>
    r + ',' + (5 * Math.log(50 / r) / Math.log(50 / 10) + (2 * rnd() - 1) * 0.010 + (i === 5 ? 0.10 : 0)).toFixed(6));
  return '# 模拟数据（非真实测量）| 模板 electrostatic_field | 固定种子 ' + seed + '（mulberry32）| 全部真值 Ua=5.00 V, Ra=10 mm, Rb=50 mm；U=Ua·ln(Rb/r)/ln(Rb/Ra) | 电位加独立均匀噪声 ±0.010 V；第 6 行 U 人为加 0.10 V；保留 6 位小数\nr,U\n' + rows.join('\n') + '\n';
}
if (require.main === module) {
  const root = path.join(__dirname, '..'), csv = generateSample();
  writeWithBackup(path.join(root, 'sample_data/electrostatic_field_模拟数据.csv'), csv);
  const file = path.join(root, 'templates/electrostatic_field.js');
  if (fs.existsSync(file)) {
    const source = fs.readFileSync(file, 'utf8');
    if (!/^    sampleCsv: .*,$/m.test(source)) throw new Error('模板缺少 sampleCsv 写入位置');
    writeWithBackup(file, source.replace(/^    sampleCsv: .*,$/m, () => '    sampleCsv: ' + JSON.stringify(csv) + ','));
  }
  console.log('已生成静电场模拟数据，固定种子 20261117。');
}
module.exports = { generateSample };
