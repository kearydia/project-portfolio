# 示波器模板验收

- 主结果：对固定时基下的完整周期水平格数求平均，T̄=n̄_div×时基，f=1/T̄。频率不是逐次频率的算术平均；其 A 类不确定度按倒数关系一阶传递。
- 峰峰值：V̄pp=v̄_div×垂直灵敏度×探头衰减倍率。×10 探头填 10；若刻度已补偿，倍率填 1。
- 所有重复读数均显示均值、样本标准差及 A/B 类不确定度；周期、频率、峰峰值的 A 类结果沿用页面 t 因子设置。时基、垂直灵敏度和校准因子的误差视为全组共有，不随测量次数增加而除以 √N。默认各输入独立。
- 频率主结果使用已有公认值输入框（默认发生器标称 1000 Hz）；峰峰值步骤使用参数 VppNominal（默认 2 V）。两者均为可替换的仪器标称值，不是自然常数，不计参考值不确定度。
- 校准默认关闭；开启时 T 乘 kt、f 除以 kt、Vpp 乘 kv。因子定义为校准真值/未修正值。默认值与不确定度为假设值，应替换成独立校准结果。本次未加入可选李萨如图。
- 模拟数据：固定种子 20261116、mulberry32，10 次测量，无人为异常点，文件首行和页面均标注模拟数据。

测量方法参考：[Tektronix 刻度测量说明](https://www.tek.com/en/blog/basic-time-and-amplitude-measurements-tbs2000-oscilloscope-part-3-3-xyzs-series)。运行时不请求外部资源。

复现命令：

```text
node tools/gen_oscilloscope_data.js
node tools/run_oscilloscope.js
python tools/python/verify_oscilloscope.py
npm test
node tools/run_all.js
```

Python 只读取 CSV，用标准库和解析偏导独立计算；Node 频率不确定度来自通用引擎的数值偏导。手算、手算校准、模拟数据、模拟数据校准共 4 组，每组 9 个量，36 项比较最大相对差 3.817×10⁻¹¹（容差 10⁻⁸）。

`run_all.js` 源文件未修改。删除新增示波器输出行后，全部输出与 `run_all_before_oscilloscope.txt` 逐字节相同，SHA256 为 `df3dfb2334cc0afd9b9233929e65c5b85a0f8d6a3f910c39eb96b35b51070872`；原有 25 个实验行也逐行按 UTF-8 字节与 `run_all_v13.txt` 比较通过。25 个旧实验在默认和启用 t 因子两种设置下的值与不确定度均与原引擎严格相等。

兼容性追加：`result.steps(ctx, details)` 的 details 新增 `typeA`（按输入 key 索引的已有 A 类结果）和 `rows`（保留行数值的副本），不改变既有计算；`tests/index.js` 追加自动发现测试，避免当前 Node 仅加载目录入口时漏跑测试；两个旧输出测试增加识别示波器行的处理，旧行仍做逐字节断言。已有文件修改前均保留了 `.bak` 副本。
