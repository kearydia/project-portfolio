'use strict';
// Generates reviewable evidence with Node only; never starts a browser or Office.
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..'), output = path.join(root, 'outputs');
fs.mkdirSync(output, { recursive: true });
function save(name, content) {
  const file = path.join(output, name);
  if (fs.existsSync(file)) { let bak = file + '.bak', i = 1; while (fs.existsSync(bak)) bak = file + '.' + i++ + '.bak'; fs.copyFileSync(file, bak); }
  fs.writeFileSync(file, content, 'utf8');
}
for (const [args, name] of [[['--test', 'tests/'], 'test-results.txt'], [['tools/run_samples.js'], 'sample-results.txt']]) {
  const run = spawnSync(process.execPath, args, { cwd: root, encoding: 'utf8' });
  const log = '$ node ' + args.join(' ') + '\nNode ' + process.version + '\n' + run.stdout + run.stderr;
  save(name, log); process.stdout.write(log);
  if (run.status !== 0 || run.error) { process.exitCode = 1; console.error(run.error || '验收失败'); }
}
if (!process.exitCode) {
  const E = require('../src/experiments.js'), Report = require('../src/report.js'), AI = require('../src/ai.js'), samples = require('../samples/samples.js');
  for (const sample of samples) {
    const { rows } = E.parseCSV(sample.csv, sample.type, sample.params), before = E.process(sample.type, rows, sample.params);
    before.outlierIndices.forEach(i => { rows[i].excluded = true; rows[i].note += '；验收脚本剔除已检出的预设异常点'; });
    const result = E.process(sample.type, rows, sample.params);
    const html = Report.build({ result, rows, columns: E.columns(sample.type, result.params), explanation: AI.explain(result), simulated: true, source: sample.name + '.csv' });
    save(sample.name + '_验收报告.html', html);
    if (sample.id === 'pendulum_single') save(sample.name + '_验收报告.doc', '\ufeff' + html);
  }
  console.log('\n验收日志与四份 HTML 报告、一份 HTML-Word 报告已写入 project/outputs/。');
}
