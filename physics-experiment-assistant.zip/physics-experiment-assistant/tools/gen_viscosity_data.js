// 仅生成 v1.3 落球法数据；沿用 gen_sample_data.js 的 mulberry32，既有示例不重写。
'use strict';
const fs = require('node:fs'), path = require('node:path');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function generateSample() {
  const seed = 20261113, rnd = mulberry32(seed);
  const eta = 0.986, rho = 7800, rho0 = 960, g = 9.80, d = 0.002, D = 0.040, H = 0.250, L = 0.100;
  const wall = 1 + 2.4 * d / D, bottom = 1 + 3.3 * d / (2 * H);
  const time = 18 * L * eta * wall * bottom / ((rho - rho0) * g * d * d);
  const rows = Array.from({ length: 12 }, (_, i) => {
    const t = time + (2 * rnd() - 1) * 0.03 + (i === 5 ? 1.5 : 0);
    const diameter = 2 + (2 * rnd() - 1) * 0.002;
    return [t.toFixed(4), diameter.toFixed(4), i === 0 ? L.toFixed(3) : ''].join(',');
  });
  return '# 模拟数据（非真实测量）| 模板 viscosity_falling_ball | 固定种子 ' + seed + '（mulberry32）| 生成真值 η=0.986 Pa·s, ρ=7800 kg/m³, ρ₀=960 kg/m³, g=9.80 m/s², d=2 mm, L=0.100 m, D=0.040 m, H=0.250 m | 时间含管壁和管底效应：t=18Lη(1+2.4d/D)(1+3.3d/(2H))/((ρ−ρ₀)gd²)；独立均匀噪声 t±0.03 s、d±0.002 mm；第 6 行时间人为加 1.5 s\nt,d,L\n' + rows.join('\n') + '\n';
}
// 每次覆盖都保留原文件；不删除旧备份。
function writeWithBackup(file, text) {
  if (fs.existsSync(file)) {
    let backup = file + '.bak13', i = 1;
    while (fs.existsSync(backup)) backup = file + '.bak13.' + i++;
    fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
  }
  fs.writeFileSync(file, text, 'utf8');
}
if (require.main === module) {
  const root = path.join(__dirname, '..'), csv = generateSample();
  writeWithBackup(path.join(root, 'sample_data/templates_work/viscosity_falling_ball_模拟数据.csv'), csv);
  const template = path.join(root, 'templates/viscosity_falling_ball.js');
  const source = fs.readFileSync(template, 'utf8');
  if (!/^    sampleCsv: .*,$/m.test(source) && !/^    sampleCsv: .*?, \/\//m.test(source)) throw new Error('模板缺少 sampleCsv 写入位置');
  writeWithBackup(template, source.replace(/^    sampleCsv: .*$/m, () => '    sampleCsv: ' + JSON.stringify(csv) + ','));
  console.log('已生成落球法模拟数据及模板内嵌副本，固定种子 20261113。');
}
module.exports = { generateSample };
