'use strict';
const E = require('../src/engine.js'), tpl = require('../templates/oscilloscope.js');
const { writeWithBackup } = require('./gen_oscilloscope_data.js');
const path = require('node:path');
function measure(rows, options = {}) {
  const result = E.process(tpl, rows, options);
  const byKey = Object.fromEntries(result.items.map(i => [i.key, i.value]));
  const { u } = E.paramValues(tpl, options.params || {});
  const details = {
    rows: rows.filter(r => !r.excluded).map(r => r.values),
    typeA: { n_div: byKey['uA.n_div'], v_div: byKey['uA.v_div'] },
    uncertainties: { 'mean.n_div': byKey['uC.n_div'], 'mean.v_div': byKey['uC.v_div'],
      ...Object.fromEntries(Object.entries(u).map(([key, value]) => ['params.' + key, value])) }
  };
  const values = tpl.measurements({ mean: { n_div: byKey['mean.n_div'], v_div: byKey['mean.v_div'] }, params: result.params }, details);
  // 保留通用引擎数值偏导的频率不确定度，供 Python 与解析值交叉比较。
  values.f = result.value; values.uf = result.uncertainty;
  return values;
}
function cases() {
  const sample = E.parseCSV(tpl.sampleCsv, tpl);
  if (!sample.ok) throw new Error(sample.errors.join(';'));
  const hand = [4, 5, 6].map((n, i) => ({ values: { n_div: n, v_div: 3 + i }, excluded: false }));
  return { hand: measure(hand), hand_corrected: measure(hand, { params: { calibration: 1 } }),
    sample: measure(sample.rows), sample_corrected: measure(sample.rows, { params: { calibration: 1 } }) };
}
if (require.main === module) {
  const result = cases();
  writeWithBackup(path.join(__dirname, 'oscilloscope_results.json'), JSON.stringify(result, null, 2) + '\n');
  console.log('模拟数据与手算验证数据：示波器 4 组结果已写入 tools/oscilloscope_results.json。');
}
module.exports = { measure, cases };
