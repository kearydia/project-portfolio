'use strict';
const fs = require('node:fs');
function write(file, content) {
  if (fs.existsSync(file)) {
    let backup = file + '.bak', n = 2;
    while (fs.existsSync(backup)) backup = file + '.bak' + n++;
    fs.copyFileSync(file, backup);
  }
  fs.writeFileSync(file, content, 'utf8');
}
function edit(file, transform) { write(file, transform(fs.readFileSync(file, 'utf8'))); }
module.exports = { write, edit };
