'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
function mulberry32(a) { return function () { let t = a += 0x6D2B79F5; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const seed = 20261113, rng = mulberry32(seed), noise = amplitude => (rng() - 0.5) * 2 * amplitude;
const samples = [];
function add(id, name, type, params, truth, headers, rows) {
  const csv = '# 模拟数据：由 tools/gen_samples.js 生成，种子' + seed + '，真值' + truth + '\n' + headers.join(',') + ',备注\n' + rows.map(r => r.map(n => Number(n.toPrecision(12))).join(',') + ',模拟数据').join('\n') + '\n';
  samples.push({ id, name, type, params, truth, csv });
}
const pend = Array.from({ length: 18 }, (_, i) => { const L = 0.35 + i * 0.04; return [L, Math.sqrt(4 * Math.PI ** 2 * L / 9.8 + noise(0.003)) + (i === 9 ? 0.2 : 0)]; });
add('pendulum_fit', '单摆_模拟数据', 'pendulum', { mode: 'fit', timeMode: 'period' }, 9.8, ['L(m)', 'T(s)'], pend);
const single = Array.from({ length: 12 }, (_, i) => [i + 1, 2 * Math.PI * Math.sqrt(0.8 / 9.8) + noise(0.0015) + (i === 5 ? 0.14 : 0)]);
add('pendulum_single', '单摆_单摆长法_模拟数据', 'pendulum', { mode: 'single', timeMode: 'period', length: 0.8, deltaL: 0.001, deltaT: 0.002 }, 9.8, ['序号', 'T(s)'], single);
const resistance = Array.from({ length: 18 }, (_, i) => { const I = 4 + i * 2; return [I, 100 * I / 1000 + 0.006 + noise(0.003) + (i === 8 ? 0.65 : 0)]; });
add('resistance', '伏安法_模拟数据', 'resistance', { currentUnit: 'mA', correction: 'none' }, 100, ['I(mA)', 'U(V)'], resistance);
const k = 8 * 1 * 1.5 / (Math.PI * 0.0005 ** 2 * 0.05 * 2e11);
const young = Array.from({ length: 18 }, (_, i) => { const m = 0.1 + i * 0.05; return [m, (0.001 + k * m * 9.8 + noise(0.000003) + (i === 8 ? 0.0012 : 0)) * 100]; });
add('young', '杨氏模量_模拟数据', 'young', { forceUnit: 'kg', readingUnit: 'cm' }, 2e11, ['m(kg)', 'n(cm)'], young);
fs.mkdirSync(path.join(root, 'samples'), { recursive: true });
function write(relative, content) {
  const file = path.join(root, relative);
  if (fs.existsSync(file)) { let backup = file + '.bak', i = 1; while (fs.existsSync(backup)) backup = file + '.' + i++ + '.bak'; fs.copyFileSync(file, backup); }
  fs.writeFileSync(file, content, 'utf8');
}
samples.forEach(s => write('samples/' + s.name + '.csv', s.csv));
write('samples/samples.js', '(function(root){\n  const samples = ' + JSON.stringify(samples, null, 2) + ';\n  if(typeof module === "object" && module.exports) module.exports = samples;\n  else root.PhysSamples = samples;\n})(typeof globalThis !== "undefined" ? globalThis : this);\n');
console.log('已生成 4 组模拟数据，固定种子 ' + seed + '；已有文件均先备份。');
