'use strict';
const fs = require('node:fs'), path = require('node:path');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function generateSample() {
  const seed = 20261114, rnd = mulberry32(seed);
  const c0 = 4180, m0 = 0.200, m1 = 0.060, c1 = 900, Cs = 20, U = 6, I = 1.5, theta = 20, T0 = 20, K = 1.5e-4;
  const C = c0 * m0 + c1 * m1 + Cs, P = U * I;
  const rows = Array.from({ length: 16 }, (_, i) => {
    const t = i * 60, decay = Math.exp(-K * t);
    const T = theta + (T0 - theta) * decay + P / (C * K) * (1 - decay) + (2 * rnd() - 1) * 0.05 + (i === 8 ? 0.8 : 0);
    return [t, T.toFixed(2), i === 0 ? '6.00,1.50,0.200,0.060' : ',,,'].join(',');
  });
  return '# 模拟数据（非真实测量）| 模板 specific_heat_water | 固定种子 ' + seed + '（mulberry32）| 全部真值 c0=4180 J/(kg·K), m0=0.200 kg, m1=0.060 kg, c1=900 J/(kg·K), Cs=20 J/K, U=6.00 V, I=1.50 A, θ=20.0 °C, T0=20.0 °C, K=1.5e-4 /s, C=910 J/K, P=9 W | 牛顿冷却解析解 T(t)=θ+(T0−θ)exp(−Kt)+P/(CK)(1−exp(−Kt))；t=0,60,…,900 s；温度独立均匀噪声 ±0.05 °C，保留 2 位小数；第 9 行温度人为加 0.8 °C\nt,T,U,I,m0,m1\n' + rows.join('\n') + '\n';
}
function writeWithBackup(file, text) {
  if (fs.existsSync(file)) {
    let backup = file + '.bakSH', i = 1;
    while (fs.existsSync(backup)) backup = file + '.' + i++ + '.bakSH';
    fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
  }
  fs.writeFileSync(file, text, 'utf8');
}
if (require.main === module) {
  const root = path.join(__dirname, '..'), csv = generateSample();
  const template = path.join(root, 'templates/specific_heat_water.js');
  const source = fs.readFileSync(template, 'utf8');
  if (!/^    sampleCsv: .*,$/m.test(source)) throw new Error('模板缺少 sampleCsv 写入位置');
  writeWithBackup(path.join(root, 'sample_data/templates_work/specific_heat_water_模拟数据.csv'), csv);
  writeWithBackup(template, source.replace(/^    sampleCsv: .*,$/m, () => '    sampleCsv: ' + JSON.stringify(csv) + ','));
  const truthFile = path.join(root, 'sample_data/templates_work/truth.json');
  const truth = fs.readFileSync(truthFile, 'utf8');
  // 保留已有条目的数值和写法；重复运行不重复插入。
  if (!Object.hasOwn(JSON.parse(truth), 'specific_heat_water'))
    writeWithBackup(truthFile, truth.replace(/\s*}\s*$/, ',\n "specific_heat_water": 4.18\n}\n'));
  console.log('已生成比热容模拟数据、模板内嵌副本及真值，固定种子 20261114。');
}
module.exports = { generateSample };
