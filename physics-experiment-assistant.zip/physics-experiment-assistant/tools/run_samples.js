'use strict';
const fs = require('node:fs');
const path = require('node:path');
const E = require('../src/experiments.js');
const samples = require('../samples/samples.js');
for (const sample of samples) {
  const csv = fs.readFileSync(path.join(__dirname, '..', 'samples', sample.name + '.csv'), 'utf8');
  const { rows, hints } = E.parseCSV(csv, sample.type, sample.params);
  const p = { ...sample.params, ...hints }, before = E.process(sample.type, rows, p);
  before.outlierIndices.forEach(i => { rows[i].excluded = true; });
  const result = E.process(sample.type, rows, p), tolerance = sample.type === 'pendulum' ? 1 : 2;
  console.log('\n' + sample.name + '（模拟数据）');
  console.log('检出并剔除行号：' + before.outlierIndices.map(i => i + 1).join(', ') + '；保留 ' + result.count + ' 点');
  console.log(result.symbol + ' = ' + result.formatted);
  console.log('未修约结果=' + result.value + '；u=' + result.uncertainty);
  console.log('公认值=' + result.params.reference + ' ' + result.unit + '；相对误差=' + result.comparison.relativeError.toFixed(6) + '%；' + result.comparison.verdict);
  if (!before.outlierIndices.length || result.comparison.relativeError >= tolerance) { process.exitCode = 1; console.error('样例验收未通过'); }
}
