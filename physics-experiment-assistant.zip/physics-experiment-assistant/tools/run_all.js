// 对每个已注册模板的示例数据运行完整流程（默认剔除格拉布斯检出点），打印结果与公认值比较。用法：node tools/run_all.js
'use strict';
const fs = require('fs'), path = require('path');
const E = require('../src/engine.js'), S = require('../sample_data/samples.js');
const root = path.join(__dirname, '..');
const ids = fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/templates\/[\w-]+\.js/g).map(s => s.slice(10, -3));
console.log('模板 | 分类 | 结果 | 公认值 | 相对误差 | 判定 | 格拉布斯检出行（剔除） | 使用点数');
for (const id of ids) {
  const t = require(path.join(root, 'templates', id + '.js'));
  const p = E.parseCSV(E.sampleText(t, S), t);
  if (!p.ok) { console.log(id + ' | 解析失败：' + p.errors.join('；')); continue; }
  const a = E.autoExclude(t, p.rows), r = E.process(t, a.rows);
  console.log([t.name, t.category, t.result.key + ' = ' + r.formatted, r.reference + ' ' + t.result.unit, r.comparison.relativeErrorPercent.toFixed(3) + '%', r.comparison.verdict,
    a.outlier.indices.length ? a.outlier.indices.map(i => i + 1).join(',') + (a.outlier.flagOnly ? '（仅提示）' : '（已剔除）') : '无', r.included + '/' + r.total].join(' | '));
}
console.log('（全部为模拟数据）');
