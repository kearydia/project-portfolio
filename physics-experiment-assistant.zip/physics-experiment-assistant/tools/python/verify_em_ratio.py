# -*- coding: utf-8 -*-
"""电子荷质比（纵向磁场聚焦法）独立参考：只读 CSV，不读取或调用 JS；仅使用 Python 标准库。

e/m = 8π²n²(L²+D²)/(μ₀²N²l²k)，k 为 I²–U 最小二乘斜率。
u_A(k)=sqrt(SSE/(n−2)/Sxx)；u_B(k)=u_B(I²)/√Sxx，其中 u_B(I²)=2I·(0.01/√3) 取各保留点的方均根；U 列不计误差。
N、n、μ₀ 不计不确定度；L、D、l 的标准不确定度为假设值 0.001、0.0005、0.001 m。
格拉布斯检验对拟合残差做单轮检验（与项目既有临界值表一致），不迭代。
"""
import csv
import json
import math
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
CSV = ROOT / 'sample_data' / 'templates_work' / 'em_ratio_focusing_模拟数据.csv'
REF = 1.75882e11
MU0 = 4 * math.pi * 1e-7
CRIT = {3: 1.153, 4: 1.463, 5: 1.672, 6: 1.822, 7: 1.938, 8: 2.032, 9: 2.110, 10: 2.176,
        11: 2.234, 12: 2.285, 13: 2.331, 14: 2.371, 15: 2.409, 16: 2.443}


def fit(rows):
    xs = [r['U'] for r in rows]
    ys = [r['I'] ** 2 for r in rows]
    n = len(rows)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    k = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    a = my - k * mx
    res = [y - (a + k * x) for x, y in zip(xs, ys)]
    ua = math.sqrt(sum(e * e for e in res) / (n - 2) / sxx)
    uby = math.sqrt(sum((2 * r['I'] * 0.01 / math.sqrt(3)) ** 2 for r in rows) / n)
    ub = uby / math.sqrt(sxx)
    return dict(slope=k, intercept=a, Sxx=sxx, residuals=res, uA=ua, uB=ub, u=math.hypot(ua, ub))


def grubbs(rows):
    res = fit(rows)['residuals']
    n = len(res)
    m = sum(res) / n
    s = math.sqrt(sum((e - m) ** 2 for e in res) / (n - 1))
    i = max(range(n), key=lambda j: abs(res[j] - m))
    g = abs(res[i] - m) / s
    out = [i] if g > CRIT[n] else []
    return [r for j, r in enumerate(rows) if j not in out], dict(excluded_indices=out, statistic=g, critical=CRIT[n])


def calculate(rows, N=526.0, L=0.234, D=0.090, l=0.145, n=1):
    f = fit(rows)
    k = f['slope']
    em = 8 * math.pi ** 2 * n ** 2 * (L ** 2 + D ** 2) / (MU0 ** 2 * N ** 2 * l ** 2 * k)
    partials = {'slope': -em / k, 'L': em * 2 * L / (L ** 2 + D ** 2),
                'D': em * 2 * D / (L ** 2 + D ** 2), 'l': -2 * em / l}
    unc = {'slope': f['u'], 'L': 0.001, 'D': 0.0005, 'l': 0.001}
    terms = {key: partials[key] * unc[key] for key in partials}
    u = math.sqrt(sum(t * t for t in terms.values()))
    err = abs(em - REF)
    return dict(value=em, u=u, fit=f, partials=partials, contributions=terms,
                verdict='一致' if err <= 2 * u else '基本一致' if err <= 3 * u else '偏差显著')


def write_with_backup(file, content):
    if file.exists():
        backup, i = Path(str(file) + '.bakEM'), 1
        while backup.exists():
            backup = Path(str(file) + f'.{i}.bakEM')
            i += 1
        shutil.copy2(file, backup)
    file.write_text(content, encoding='utf-8')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    with CSV.open(encoding='utf-8') as stream:
        rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(l for l in stream if not l.startswith('#'))]
    kept, outlier = grubbs(rows)
    sample = calculate(kept)
    # 手算：U=[800,900,1000] V，I² 正好 = 3e-3·U（k=0.003 A²/V），e/m=8π²(L²+D²)/(μ₀²N²l²·0.003)。
    hand_rows = [{'U': u, 'I': math.sqrt(0.003 * u)} for u in (800.0, 900.0, 1000.0)]
    hand = calculate(hand_rows)
    hand_n2 = calculate(hand_rows, n=2)
    out = dict(**outlier, included=len(kept), total=len(rows), sample=sample, hand=hand, hand_n2=hand_n2)
    lines = ['电子荷质比（纵向磁场聚焦法）独立 Python 参考；不调用 JS；单位 C/kg。',
             f"模拟数据单轮格拉布斯：G={outlier['statistic']:.6f}，临界值 {outlier['critical']}，剔除行（从 0 计）{outlier['excluded_indices']}，保留 {len(kept)}/{len(rows)}。",
             'N=526、n=1 为假设值且不计不确定度；L、D、l 的 u 为假设值。']
    for key in ('sample', 'hand', 'hand_n2'):
        r = out[key]
        lines.append(f"{key}: e/m={r['value']:.15g}, u={r['u']:.15g}, k={r['fit']['slope']:.15g}, u(k)={r['fit']['u']:.15g}, "
                     f"判定={r['verdict']}, 相对参考值偏差={abs(r['value'] - REF) / REF:.6%}")
        lines.append('  偏导×标准不确定度: ' + json.dumps(r['contributions'], ensure_ascii=False))
    report = '\n'.join(lines) + '\n'
    write_with_backup(ROOT / 'tests/templates_work_ref/python_reference_em_ratio.json', json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    write_with_backup(ROOT / 'tools/python/verify_em_ratio_output.txt', report)
    print(report, end='')


if __name__ == '__main__':
    main()
