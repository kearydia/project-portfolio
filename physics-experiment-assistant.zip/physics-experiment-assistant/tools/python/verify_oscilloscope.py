# -*- coding: utf-8 -*-
"""独立 Python 标准库验算：仅读取 CSV，解析偏导传递，不导入或执行 JavaScript。

频率采用平均周期的倒数，u_A(f) 为一阶传递；各次频率的算术平均不是本模板估计量。
默认不启用 t 因子。校准因子及量程的不确定度为全组共有。
"""
import csv
import json
import math
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[2]


def calculate(rows, calibration=False):
    n = len(rows)
    means = {key: sum(r[key] for r in rows) / n for key in ('n_div', 'v_div')}
    ua = {key: math.sqrt(sum((r[key] - means[key]) ** 2 for r in rows) / (n * (n - 1))) for key in means}
    uc = {key: math.hypot(ua[key], 0.02 / math.sqrt(3)) for key in means}
    kt, kv = (1.002, 0.99) if calibration else (1, 1)
    period = means['n_div'] * 0.0002 * kt
    voltage = means['v_div'] * 0.05 * 10 * kv
    up = period * math.sqrt((uc['n_div'] / means['n_div']) ** 2 + (0.000001 / 0.0002) ** 2 + ((0.001 / kt) ** 2 if calibration else 0))
    uv = voltage * math.sqrt((uc['v_div'] / means['v_div']) ** 2 + (0.0005 / 0.05) ** 2 + ((0.002 / kv) ** 2 if calibration else 0))
    return dict(T=period, f=1 / period, Vpp=voltage, uAT=0.0002 * kt * ua['n_div'],
                uAf=0.0002 * kt * ua['n_div'] / period ** 2, uAVpp=0.05 * 10 * kv * ua['v_div'],
                uT=up, uf=up / period ** 2, uVpp=uv)


def references():
    with (ROOT / 'sample_data/oscilloscope_模拟数据.csv').open(encoding='utf-8') as stream:
        rows = [{k: float(v) for k, v in r.items()} for r in csv.DictReader(line for line in stream if not line.startswith('#'))]
    hand = [dict(n_div=n, v_div=v) for n, v in zip([4, 5, 6], [3, 4, 5])]
    return {name: calculate(data, enabled) for name, data, enabled in [
        ('hand', hand, False), ('hand_corrected', hand, True),
        ('sample', rows, False), ('sample_corrected', rows, True)]}


if __name__ == '__main__':
    target = ROOT / 'tests/templates_work_ref/python_reference_oscilloscope.json'
    text = json.dumps(references(), ensure_ascii=False, indent=2) + '\n'
    if not target.exists() or target.read_text(encoding='utf-8') != text:
        if target.exists():
            backup, i = Path(str(target) + '.bak'), 1
            while backup.exists():
                backup, i = Path(str(target) + f'.{i}.bak'), i + 1
            shutil.copyfile(target, backup)
        target.write_text(text, encoding='utf-8', newline='\n')
    print('Python reference: 4 cases, 9 quantities each; analytic propagation; fixture generated.')
    # 与 Node 输出做真实的双向独立计算比较；不存在时仍可先生成参考文件。
    actual_file = ROOT / 'tools/oscilloscope_results.json'
    if actual_file.exists():
        actual = json.loads(actual_file.read_text(encoding='utf-8'))
        largest = 0.0
        for case, expected in references().items():
            for key, value in expected.items():
                difference = abs(actual[case][key] - value) / abs(value)
                largest = max(largest, difference)
                assert difference < 1e-8, (case, key, actual[case][key], value)
        print(f'PASS: 36 comparisons; maximum relative difference = {largest:.3e}')
