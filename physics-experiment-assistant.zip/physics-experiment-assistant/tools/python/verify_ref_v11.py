# -*- coding: utf-8 -*-
"""独立 Python 参考实现：不读取、不调用任何 JS 模板代码。
仪器允差/参数按 TEMPLATE_NOTES.md 的规格在此独立写一遍；不确定度用解析偏导（JS 端用数值偏导），两者互为交叉验证。
v1.1 约定：拟合斜率/截距为 A 类与 B 类合成，B 类由 y 列仪器误差 u_B(y)=Δy/√3 经解析导数换算到 y'，取各点方均根 u_B(y')，
u_B(k)=u_B(y')/√Sxx，u_B(b0)=u_B(y')·√(1/n+x̄²/Sxx)；x 列仪器误差不计入；g 取 9.80，u(g)=0.005（假设）；钠光 λ 的 u=1.7e-7 mm。
原约定：A类 uA=s/√n（s 为 n-1 标准差）；B类 uB=Δ/√3；合成 u=√(uA²+uB²)；拟合斜率 u(k)=√(Σε²/(n-2)/Σ(x-x̄)²)；
逐差：k=n/2，δ_i=y_{i+k}-y_i，取均值，u=√((s_δ/√k)²+(Δ/√3)²)。"""
import csv, math, os, json, sys
S3 = math.sqrt(3)
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', '..', 'sample_data', 'templates_work')

def load(tid):
    with open(os.path.join(DATA, f'{tid}_模拟数据.csv'), encoding='utf-8') as f:
        rows = [r for r in csv.reader(l for l in f if not l.startswith('#'))]
    head, body = rows[0], rows[1:]
    cols = {k: [float(r[i]) for r in body if i < len(r) and r[i].strip() != ''] for i, k in enumerate(head)}
    return cols

def rep(v, inst):
    n = len(v); m = sum(v) / n
    s = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
    return m, math.hypot(s / math.sqrt(n), inst / S3)

def single(v, inst):
    return v[0], inst / S3

def fit(x, y, uy=None):
    """uy: 各点 y' 的 B 类标准不确定度列表（已按解析导数换算）"""
    n = len(x); mx = sum(x) / n; my = sum(y) / n
    sxx = sum((a - mx) ** 2 for a in x); sxy = sum((a - mx) * (b - my) for a, b in zip(x, y))
    k = sxy / sxx; b0 = my - k * mx
    res = sum((b - (k * a + b0)) ** 2 for a, b in zip(x, y))
    uA = math.sqrt(res / (n - 2) / sxx)
    uBy = math.sqrt(sum(u * u for u in uy) / len(uy)) if uy else 0.0
    return k, math.hypot(uA, uBy / math.sqrt(sxx)), b0

def sdiff(v, inst):
    k = len(v) // 2
    d = [v[i + k] - v[i] for i in range(k)]
    m = sum(d) / k
    s = math.sqrt(sum((a - m) ** 2 for a in d) / (k - 1)) if k > 1 else 0.0
    return m, math.hypot(s / math.sqrt(k), inst / S3)

def rq(*pairs):  # 相对不确定度平方和: (power, value, u)
    return math.sqrt(sum((p * u / v) ** 2 for p, v, u in pairs))

def calc(tid):
    c = load(tid); g = 9.80
    if tid == 'youngs_modulus':
        k, uk, _ = fit(c['m'], [n / 1000 for n in c['n']], [0.5 / S3 / 1000] * len(c['n']))
        L, uL = single(c['L'], 0.0005); D, uD = single(c['D'], 0.0005); b, ub = single(c['b'], 0.00002)
        d, ud = rep(c['d'], 0.004)
        E = 8 * L * D * g / (math.pi * (d / 1000) ** 2 * b * k)
        return E, E * rq((1, k, uk), (1, L, uL), (1, D, uD), (1, b, ub), (2, d, ud), (1, g, 0.005))
    if tid == 'trifilar_inertia':
        T, uT = rep(c['T'], 0.001); R, uR = single(c['R'], 2e-5); r, ur = single(c['r'], 2e-5); H, uH = single(c['H'], 0.0005)
        m0, um = 0.500, 0.0005
        I = m0 * g * R * r * T * T / (4 * math.pi ** 2 * H)
        return I, I * rq((2, T, uT), (1, R, uR), (1, r, ur), (1, H, uH), (1, m0, um))
    if tid == 'gamma_air':
        p0, u0 = single(c['p0'], 0.01); p1, u1 = rep(c['p1'], 0.01); p2, u2 = rep(c['p2'], 0.01)
        a, bb = math.log(p1 / p0), math.log(p1 / p2); G = a / bb
        d0 = -1 / (p0 * bb); d2 = a / (bb * bb * p2); d1 = 1 / (p1 * bb) - a / (bb * bb * p1)
        return G, math.sqrt((d0 * u0) ** 2 + (d1 * u1) ** 2 + (d2 * u2) ** 2)
    if tid == 'linear_expansion':
        k, uk, _ = fit(c['T'], c['dL'], [0.005 / S3] * len(c['dL'])); L0, uL = single(c['L0'], 0.5)
        a = k / L0; return a, a * rq((1, k, uk), (1, L0, uL))
    if tid == 'surface_tension':
        U1, u1 = rep(c['U1'], 0.1); U2, u2 = rep(c['U2'], 0.1); D1, ud1 = single(c['D1'], 2e-5); D2, ud2 = single(c['D2'], 2e-5)
        K, uK = 3000.0, 3.0; dU = U1 - U2; sD = D1 + D2
        s = dU / (K * math.pi * sD)
        return s, s * math.sqrt((math.hypot(u1, u2) / dU) ** 2 + (math.hypot(ud1, ud2) / sD) ** 2 + (uK / K) ** 2)
    if tid == 'wheatstone_bridge':
        a, ua = rep(c['Rs'], 0.2); b, ub = rep(c['Rs2'], 0.2)
        Rx = math.sqrt(a * b); return Rx, Rx * rq((0.5, a, ua), (0.5, b, ub))
    if tid == 'potentiometer':
        Ls, uls = rep(c['Ls'], 0.0005); Lx, ulx = rep(c['Lx'], 0.0005); Es, ue = 1.01860, 0.00005
        E = Es * Lx / Ls; return E, E * rq((1, Ls, uls), (1, Lx, ulx), (1, Es, ue))
    if tid == 'hall_effect':
        k, uk, _ = fit(c['I'], c['UH'], [0.05 / S3] * len(c['UH'])); B, uB = 0.100, 0.0005
        K = k / B; return K, K * rq((1, k, uk), (1, B, uB))
    if tid == 'thin_lens_conjugate':
        D, uD = single(c['D'], 0.05); x1, u1 = rep(c['x1'], 0.05); x2, u2 = rep(c['x2'], 0.05)
        d = x2 - x1; f = (D * D - d * d) / (4 * D)
        dfdD = (D * D + d * d) / (4 * D * D); dfdd = -d / (2 * D)
        return f, math.sqrt((dfdD * uD) ** 2 + (dfdd * u1) ** 2 + (dfdd * u2) ** 2)
    if tid == 'newton_rings':
        k, uk, _ = fit(c['m'], [x * x for x in c['Dm']], [2 * x * 0.005 / S3 for x in c['Dm']]); lam, ulam = 5.893e-4, 1.7e-7
        R = k / (4 * lam) / 1000; return R, R * rq((1, k, uk), (1, lam, ulam))
    if tid == 'grating':
        th, ut = rep(c['theta'], 0.0167); dg = 0.00333333
        lam = dg * math.sin(math.radians(th)) * 1e6
        return lam, dg * math.cos(math.radians(th)) * math.radians(ut) * 1e6
    if tid == 'michelson':
        dd, ud = sdiff(c['d'], 0.00005); dN, _ = sdiff(c['N'], 0)
        lam = 2 * dd / dN * 1e6; return lam, lam * ud / dd
    if tid == 'sound_speed':
        dx, ux = sdiff(c['x'], 0.01); di, _ = sdiff(c['i'], 0); f, uf = 35000.0, 1.0
        v = f * 2 * dx / di / 1000; return v, v * rq((1, dx, ux), (1, f, uf))
    if tid == 'string_vibration':
        k, uk, _ = fit(c['n'], c['f'], [0.1 / S3] * len(c['f'])); L, uL = single(c['L'], 0.0005); M, uM = 1.000, 0.001
        rho = M * g / (2 * L * k) ** 2; return rho, rho * rq((2, k, uk), (2, L, uL), (1, M, uM), (1, g, 0.005))
    if tid == 'photoelectric_planck':
        cl, e = 299792458.0, 1.602176634e-19
        k, uk, _ = fit([cl / (l * 1e-9) / 1e14 for l in c['lam']], c['Ua'], [0.005 / S3] * len(c['Ua']))
        h = e * k * 1e-14; return h, h * uk / k
    if tid == 'prism_min_deviation':
        A, uA = rep(c['A'], 0.0167); dl, udl = rep(c['delta'], 0.0167)
        a, s = math.radians(A), math.radians(dl)
        n = math.sin((a + s) / 2) / math.sin(a / 2)
        dn_ds = math.cos((a + s) / 2) / (2 * math.sin(a / 2))
        dn_da = dn_ds - math.sin((a + s) / 2) * math.cos(a / 2) / (2 * math.sin(a / 2) ** 2)
        return n, math.hypot(dn_da * math.radians(uA), dn_ds * math.radians(udl))
    if tid == 'thin_lens_uv':
        x = [1 / u for u in c['u']]; y = [1 / v for v in c['v']]
        k, uk, b0 = fit(x, y, [0.05 / S3 / v ** 2 for v in c['v']])
        ub = uk * math.sqrt(sum(a * a for a in x) / len(x))
        f = 1 / b0; return f, ub / b0 ** 2
    raise KeyError(tid)

IDS = ['youngs_modulus', 'trifilar_inertia', 'linear_expansion', 'wheatstone_bridge', 'hall_effect',
       'thin_lens_conjugate', 'newton_rings', 'grating', 'michelson', 'sound_speed', 'string_vibration',
       'photoelectric_planck', 'gamma_air', 'surface_tension', 'potentiometer', 'prism_min_deviation', 'thin_lens_uv']

if __name__ == '__main__':
    truth = json.load(open(os.path.join(DATA, 'truth.json'), encoding='utf-8'))
    out = {}
    print(f"{'id':24s} {'result':>14s} {'u':>12s} {'true':>14s} {'rel_err_vs_true':>16s} {'|z|':>6s}")
    for t in IDS:
        v, u = calc(t); tv = truth[t]
        out[t] = {'value': v, 'u': u, 'true': tv}
        print(f"{t:24s} {v:14.6g} {u:12.4g} {tv:14.6g} {abs(v-tv)/abs(tv):16.3%} {abs(v-tv)/u:6.2f}")
    json.dump(out, open(os.path.join(HERE, '..', '..', 'tests', 'templates_work_ref', 'python_reference.json'), 'w', encoding='utf-8'), indent=1)
