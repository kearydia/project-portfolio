# -*- coding: utf-8 -*-
"""纯 Python 标准库独立验算：只读 CSV，不导入或调用 JavaScript。

以 ln(r/1 m) 为横坐标；r 以 mm 输入。斜率合成 A/B，解析偏导独立验证
JavaScript 的数值偏导；Ra、Rb 只定义标称比较值，不参与不确定度传递。
"""
import csv
import json
import math
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
REFERENCE = math.log(50 / 10)


def calculate(rows, Ua=5.0, deltaU=0.005, deltaUa=0.01):
    n = len(rows)
    if n < 3:
        raise ValueError('拟合至少需要三个点')
    xs = [math.log(row['r'] / 1000) for row in rows]
    ys = [row['U'] for row in rows]
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    slope = sxy / sxx
    intercept = my - slope * mx
    residuals = [y - intercept - slope * x for x, y in zip(xs, ys)]
    se = math.sqrt(sum(e * e for e in residuals) / (n - 2))
    ua = se / math.sqrt(sxx)
    ub = deltaU / math.sqrt(3 * sxx)
    uslope = math.hypot(ua, ub)
    uintercept = math.hypot(se, deltaU / math.sqrt(3)) * math.sqrt(1 / n + mx * mx / sxx)
    lnRatio = -Ua / slope
    db, dUa = Ua / slope ** 2, -1 / slope
    uncertainty = math.hypot(db * uslope, dUa * deltaUa / math.sqrt(3))
    error = abs(lnRatio - REFERENCE)
    return dict(n=n, slope=slope, intercept=intercept, r=sxy / math.sqrt(sxx * syy),
                residuals=residuals, Sxx=sxx, uAslope=ua, uBslope=ub, uslope=uslope,
                uintercept=uintercept, lnRatio=lnRatio, uncertainty=uncertainty,
                relativeErrorPercent=100 * error / REFERENCE,
                partialSlope=db, partialUa=dUa,
                verdict='一致' if error <= 2 * uncertainty else '基本一致' if error <= 3 * uncertainty else '偏差显著')


def save(file, text):
    if file.exists():
        if file.read_text(encoding='utf-8') == text:
            return
        backup = Path(str(file) + '.bakES')
        i = 1
        while backup.exists():
            backup = Path(str(file) + f'.{i}.bakES')
            i += 1
        shutil.copyfile(file, backup)
    file.write_text(text, encoding='utf-8', newline='\n')


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    with (ROOT / 'sample_data/electrostatic_field_模拟数据.csv').open(encoding='utf-8') as stream:
        rows = [{k: float(v) for k, v in row.items()} for row in csv.DictReader(line for line in stream if not line.startswith('#'))]
    before = calculate(rows)
    residuals = before['residuals']
    m = sum(residuals) / len(residuals)
    sd = math.sqrt(sum((e - m) ** 2 for e in residuals) / (len(residuals) - 1))
    index = max(range(len(rows)), key=lambda i: abs(residuals[i] - m))
    statistic = abs(residuals[index] - m) / sd
    # 对照项目既有 n=9 临界值；另列双侧 alpha=0.05 表值，二者均检出第六行。
    critical_project, critical_two_sided = 2.110, 2.215
    assert index == 5 and statistic > max(critical_project, critical_two_sided)
    kept = [row for i, row in enumerate(rows) if i != index]
    after = calculate(kept)
    assert after['verdict'] == '一致', '剔除后没有满足两倍标准不确定度判据'
    result = dict(reference=REFERENCE, theoreticalSlope=-5 / REFERENCE,
                  theoreticalIntercept=5 * math.log(0.050) / REFERENCE,
                  excluded_indices=[index], statistic=statistic,
                  critical_project=critical_project, critical_two_sided=critical_two_sided,
                  before=before, after=after, Ua6=calculate(kept, Ua=6.0))
    save(ROOT / 'tests/templates_work_ref/python_reference_electrostatic.json', json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    save(ROOT / 'tests/templates_work_ref/before_electrostatic.json', json.dumps(before, ensure_ascii=False, indent=2) + '\n')
    lines = ['静电场模拟数据独立 Python 验算；纯 Python，不调用 JS。',
             f'单轮残差格拉布斯 G={statistic:.12g}；项目 n=9 表值={critical_project}；双侧表值={critical_two_sided}；两者均剔除第 6 行。',
             f'理论斜率={result["theoreticalSlope"]:.15g} V；标称 ln(Rb/Ra)={REFERENCE:.15g}（无量纲）。']
    for label, data in [('剔除前', before), ('剔除后', after)]:
        lines.append(f'{label}：n={data["n"]}, b={data["slope"]:.15g} V, a={data["intercept"]:.15g} V, u(b)={data["uslope"]:.15g} V, lnRatio={data["lnRatio"]:.15g}, u={data["uncertainty"]:.15g}, 判定={data["verdict"]}')
    report = '\n'.join(lines) + '\n'
    save(ROOT / 'tools/python/verify_electrostatic_output.txt', report)
    print(report, end='')


if __name__ == '__main__':
    main()
