# -*- coding: utf-8 -*-
"""v1.1 手算验证期望值（纯 Python，不调用项目代码）。
拟合斜率不确定度 u(k)=√(u_A²+u_B²)，u_A=s_e/√Sxx，u_B=u_B(y')/√Sxx，u_B(y') 为各点 |dy'/dy|·Δy/√3 的方均根。"""
import math
S3 = math.sqrt(3)
def fit(x, y, uy):
    n = len(x); mx = sum(x)/n; my = sum(y)/n
    sxx = sum((a-mx)**2 for a in x); sxy = sum((a-mx)*(b-my) for a, b in zip(x, y)); syy = sum((b-my)**2 for b in y)
    b = sxy/sxx; a = my-b*mx; se = math.sqrt(sum((yy-a-b*xx)**2 for xx, yy in zip(x, y))/(n-2))
    uA = se/math.sqrt(sxx); uBy = math.sqrt(sum(u*u for u in uy)/len(uy)); uB = uBy/math.sqrt(sxx)
    return dict(a=a, b=b, uA=uA, uB=uB, u=math.hypot(uA, uB), r=sxy/math.sqrt(sxx*syy), sxx=sxx, uBy=uBy)
print("B 单摆 T²–L 拟合 L=[0.40,0.60,0.80,1.00] m, T=[1.27,1.55,1.80,2.01] s, ΔT=0.002 s → u_B(T²)=2T·ΔT/√3")
L=[.4,.6,.8,1.0]; T=[1.27,1.55,1.80,2.01]
f=fit(L,[t*t for t in T],[2*t*0.002/S3 for t in T]); g=4*math.pi**2/f['b']
print(f" slope={f['b']:.10g} uA={f['uA']:.10g} uB={f['uB']:.10g} u={f['u']:.10g} g={g:.10g} ug(仅斜率)={g*f['u']/f['b']:.10g}")
print("D 杨氏模量 n–m 拟合 m=[0.5..2.5] kg, n=[0.75,1.52,2.26,3.01,3.77] cm, Δn=0.05 cm, g=9.80±0.005")
m=[.5,1,1.5,2,2.5]; N=[x/100 for x in [.75,1.52,2.26,3.01,3.77]]
f=fit(m,N,[0.0005/S3]*5); E=8*1.0*1.5*9.8/(math.pi*0.0005**2*0.05*f['b'])
print(f" k={f['b']:.10g} m/kg uA={f['uA']:.10g} uB={f['uB']:.10g} u={f['u']:.10g} r={f['r']:.10g} E={E:.10g}")
print("C 伏安法 U–I 拟合 I=[10..50] mA, U=[1.02,1.98,3.01,4.00,5.02] V, ΔU=0.005 V")
f=fit([0.01,0.02,0.03,0.04,0.05],[1.02,1.98,3.01,4.00,5.02],[0.005/S3]*5)
print(f" R={f['b']:.10g} uA={f['uA']:.10g} uB={f['uB']:.10g} u={f['u']:.10g}")
print("E 手算 u_B(k)：x=[1,2,3,4,5]，Δy=0.03 → u_B(y)=0.03/√3=0.017320508，Sxx=10，u_B(k)=0.017320508/√10")
print(f" uB(k)={0.03/S3/math.sqrt(10):.10g}")
