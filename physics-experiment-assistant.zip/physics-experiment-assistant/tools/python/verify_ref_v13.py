# -*- coding: utf-8 -*-
"""v1.3 独立参考：只读 CSV，不读取或调用 JS；仅使用 Python 标准库。

重复测量 u_A=s/√n，u_B=Δ/√3；L 单次测量 u_A=0。
钢球/液体密度、g 的值及标准不确定度均为任务规定的假设值。
解析求导时 d 以米计，重复测量直径与其不确定度由 mm 换算到 m。
采用项目既有的单轮格拉布斯临界表（本组 n=12，临界值 2.285），
按行剔除检出的第 6 行，t 和 d 均使用剩余 11 行；不迭代筛选。
"""
import csv
import json
import math
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / 'sample_data' / 'templates_work'
TRUE = 0.986


def stats(values, delta):
    n = len(values)
    mean = sum(values) / n
    s = math.sqrt(sum((v - mean) ** 2 for v in values) / (n - 1)) if n > 1 else 0.0
    ua, ub = s / math.sqrt(n), delta / math.sqrt(3)
    return {'mean': mean, 's': s, 'uA': ua, 'uB': ub, 'u': math.hypot(ua, ub), 'n': n}


def calculate(rows, wall=False, bottom=False):
    direct = {
        't': stats([r['t'] for r in rows], 0.01),
        'd': stats([r['d'] / 1000 for r in rows], 0.004 / 1000),
        'L': stats([next(r['L'] for r in rows if r['L'] is not None)], 0.001),
    }
    t, d, length = (direct[k]['mean'] for k in ('t', 'd', 'L'))
    rho, rho0, g, diameter, height = 7800.0, 960.0, 9.80, 0.040, 0.250
    a = 2.4 / diameter if wall else 0.0
    b = 3.3 / (2 * height) if bottom else 0.0
    fw, fb = 1 + a * d, 1 + b * d
    eta = (rho - rho0) * g * d ** 2 * t / (18 * length) / fw / fb
    # ln η 对 d 求导 = 2/d − a/(1+ad) − b/(1+bd)。
    partials = {
        't': eta / t,
        'd': eta * (2 / d - a / fw - b / fb),
        'L': -eta / length,
        'rho': eta / (rho - rho0),
        'rho0': -eta / (rho - rho0),
        'g': eta / g,
    }
    uncertainty = {k: direct[k]['u'] for k in direct}
    uncertainty.update(rho=10.0, rho0=5.0, g=0.005)
    if wall:
        partials['D'] = eta * 2.4 * d / (diameter ** 2 * fw)
        uncertainty['D'] = 0.001 / math.sqrt(3)
    if bottom:
        partials['H'] = eta * 3.3 * d / (2 * height ** 2 * fb)
        uncertainty['H'] = 0.001 / math.sqrt(3)
    terms = {k: partials[k] * uncertainty[k] for k in partials}
    u = math.sqrt(sum(x * x for x in terms.values()))
    error = abs(eta - TRUE)
    return {
        'value': eta, 'u': u, 'true': TRUE,
        'verdict': '一致' if error <= 2 * u else '基本一致' if error <= 3 * u else '偏差显著',
        'wallCorr': int(wall), 'bottomCorr': int(bottom), 'wallFactor': fw, 'bottomFactor': fb,
        'direct_SI': direct, 'partials_SI': partials, 'contributions': terms,
    }


def load_sample():
    with (DATA / 'viscosity_falling_ball_模拟数据.csv').open(encoding='utf-8') as stream:
        return [{k: float(v) if v else None for k, v in r.items()}
                for r in csv.DictReader(line for line in stream if not line.startswith('#'))]


def exclude_outlier(rows):
    assert len(rows) == 12, '本参考仅为固定 12 行示例核对单轮异常检验'
    excluded = []
    for key in ('t', 'd'):
        values = [r[key] for r in rows]
        st = stats(values, 0)
        i = max(range(len(values)), key=lambda n: abs(values[n] - st['mean']))
        statistic = abs(values[i] - st['mean']) / st['s'] if st['s'] else 0
        if statistic > 2.285:
            excluded = [i]
            break
    assert excluded == [5], f'预设的人为异常行检验失败：{excluded}'
    return [r for i, r in enumerate(rows) if i not in excluded], excluded


def write_with_backup(file, content):
    if file.exists():
        backup, i = Path(str(file) + '.bakSH'), 1
        while backup.exists():
            backup = Path(str(file) + f'.{i}.bakSH')
            i += 1
        shutil.copy2(file, backup)
    file.write_text(content, encoding='utf-8')


def heat_fit(rows):
    """独立最小二乘；温度列 Δ=0.1 °C，时间列不计误差。"""
    n = len(rows)
    mx = sum(r['t'] for r in rows) / n
    my = sum(r['T'] for r in rows) / n
    sxx = sum((r['t'] - mx) ** 2 for r in rows)
    slope = sum((r['t'] - mx) * (r['T'] - my) for r in rows) / sxx
    intercept = my - slope * mx
    residuals = [r['T'] - (intercept + slope * r['t']) for r in rows]
    ua = math.sqrt(sum(e * e for e in residuals) / (n - 2) / sxx)
    ub = (0.1 / math.sqrt(3)) / math.sqrt(sxx)
    return dict(slope=slope, intercept=intercept, xMean=mx, yMean=my,
                Sxx=sxx, residuals=residuals, uA=ua, uB=ub, u=math.hypot(ua, ub))


def heat_exclude_outlier(rows):
    # 与项目既有单轮表一致，独立对拟合残差求均值、样本标准差及 G。
    critical_table = {3: 1.153, 4: 1.463, 5: 1.672, 6: 1.822, 7: 1.938,
                      8: 2.032, 9: 2.110, 10: 2.176, 11: 2.234, 12: 2.285,
                      13: 2.331, 14: 2.371, 15: 2.409, 16: 2.443,
                      17: 2.475, 18: 2.504, 19: 2.532, 20: 2.557}
    residuals = heat_fit(rows)['residuals']
    st = stats(residuals, 0)
    candidate = max(range(len(rows)), key=lambda i: abs(residuals[i] - st['mean']))
    g = abs(residuals[candidate] - st['mean']) / st['s'] if st['s'] else 0
    critical = critical_table[len(rows)]
    excluded = [candidate] if g > critical else []
    return [r for i, r in enumerate(rows) if i not in excluded], dict(
        excluded_indices=excluded, statistic=g, critical=critical)


def heat_calculate(rows, heat_loss=False):
    f = heat_fit(rows)
    single = {key: stats([next(r[key] for r in rows if r[key] is not None)], delta)
              for key, delta in [('U', 0.02), ('I', 0.01), ('m0', 0.0001), ('m1', 0.0001)]}
    voltage, current, m0, m1 = (single[key]['mean'] for key in ('U', 'I', 'm0', 'm1'))
    c1, cs, cooling, theta = 900.0, 20.0, 1.5e-4, 20.0
    power = voltage * current
    rate = f['slope'] + (cooling * (f['yMean'] - theta) if heat_loss else 0)
    value = (power / rate - c1 * m1 - cs) / m0 / 1000
    # 对最终 kJ/(kg·K) 结果解析求导；T̄ 固定，不随 slope 扰动，不计其不确定度。
    partials = {'slope': -power / (m0 * rate ** 2) / 1000,
                'U': current / (m0 * rate) / 1000,
                'I': voltage / (m0 * rate) / 1000,
                'm0': -value / m0, 'm1': -c1 / m0 / 1000,
                'c1': -m1 / m0 / 1000, 'Cs': -1 / m0 / 1000}
    uncertainty = {key: st['u'] for key, st in single.items()}
    uncertainty.update(slope=f['u'], c1=10.0, Cs=5.0)
    if heat_loss:
        partials['K'] = -power * (f['yMean'] - theta) / (m0 * rate ** 2) / 1000
        partials['theta'] = power * cooling / (m0 * rate ** 2) / 1000
        uncertainty.update(K=0.15e-4, theta=0.1 / math.sqrt(3))
    terms = {key: partials[key] * uncertainty[key] for key in partials}
    u = math.sqrt(sum(term * term for term in terms.values()))
    error = abs(value - 4.18)
    return dict(value=value, u=u, true=4.18, unit='kJ/(kg·K)', heatLoss=int(heat_loss),
                verdict='一致' if error <= 2 * u else '基本一致' if error <= 3 * u else '偏差显著',
                fit=f, single=single, power=power, effective_rate=rate,
                partials=partials, contributions=terms)


def heat_reference():
    with (DATA / 'specific_heat_water_模拟数据.csv').open(encoding='utf-8') as stream:
        rows = [{key: float(value) if value else None for key, value in r.items()}
                for r in csv.DictReader(line for line in stream if not line.startswith('#'))]
    rows, outlier = heat_exclude_outlier(rows)
    assert outlier['excluded_indices'] == [8], outlier
    # 小数据：t=[0,100,200]，T=[20,21,22]；k=0.01，T̄=21；C=900（关）。
    hand = [dict(t=i * 100.0, T=20.0 + i, U=6.0 if i == 0 else None,
                 I=1.5 if i == 0 else None, m0=0.2 if i == 0 else None,
                 m1=0.06 if i == 0 else None) for i in range(3)]
    return dict(**outlier, included=len(rows), sample_off=heat_calculate(rows),
                sample_on=heat_calculate(rows, True), hand_off=heat_calculate(hand),
                hand_on=heat_calculate(hand, True))


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    rows, excluded = exclude_outlier(load_sample())
    # 手算：t=10 s 三次、d=2 mm 三次、L=0.1 m；η0=1.4896 Pa·s。
    hand = [{'t': 10.0, 'd': 2.0, 'L': 0.1 if i == 0 else None} for i in range(3)]
    out = {'excluded_indices': excluded, 'included': len(rows),
           'sample_off': calculate(rows), 'sample_on': calculate(rows, True, True),
           'hand_off': calculate(hand), 'hand_on': calculate(hand, True, True)}
    lines = ['独立 Python 解析偏导参考；不调用 JS；u_A=s/√n，u_B=Δ/√3；单位 Pa·s。',
             '模拟数据按项目既有格拉布斯表单轮检验，剔除第 6 行，保留 11/12 行。',
             '密度及 g 的值和标准不确定度为假设值；D=0.040 m、H=0.250 m，ΔD=ΔH=0.001 m。',
             '手算数据：t=[10,10,10] s，d=[2,2,2] mm，L=0.1 m；未修正 η=1.4896 Pa·s。']
    for key in ('sample_off', 'sample_on', 'hand_off', 'hand_on'):
        r = out[key]
        lines.append(f"{key}: eta={r['value']:.15g}, u={r['u']:.15g}, 判定={r['verdict']}, "
                     f"相对参考值偏差={abs(r['value']-TRUE)/TRUE:.9%}")
        lines.append('  解析偏导(SI): ' + json.dumps(r['partials_SI'], ensure_ascii=False))
        lines.append('  偏导×标准不确定度: ' + json.dumps(r['contributions'], ensure_ascii=False))
    # 保留上方粘滞系数计算及条目，新增独立的比热容命名空间。
    out['specific_heat_water'] = heat_reference()
    lines.extend(['', '水的比热容（电热法）：独立最小二乘、单轮格拉布斯及解析偏导；单位 kJ/(kg·K)。',
                  '剔除第 9 行，保留 15/16 点；u_A(b)=sqrt(SSE/(n−2)/Sxx)，u_B(b)=(0.1/√3)/√Sxx。',
                  'c1、Cs、K、θ 为假设值；牛顿冷却，k 近似取在 T̄ 处，T̄ 不计不确定度。',
                  '手算：t=[0,100,200] s，T=[20,21,22] °C；U=6 V，I=1.5 A，m0=0.2 kg，m1=0.06 kg；关闭 c0=4.13。'])
    for key in ('sample_off', 'sample_on', 'hand_off', 'hand_on'):
        r = out['specific_heat_water'][key]
        lines.append(f"specific_heat_water.{key}: c0={r['value']:.15g}, u={r['u']:.15g}, 判定={r['verdict']}, "
                     f"相对参考值偏差={abs(r['value']-4.18)/4.18:.9%}")
        lines.append('  解析偏导（结果单位 kJ/(kg·K)）: ' + json.dumps(r['partials'], ensure_ascii=False))
        lines.append('  偏导×标准不确定度: ' + json.dumps(r['contributions'], ensure_ascii=False))
    report = '\n'.join(lines) + '\n'
    write_with_backup(ROOT / 'tests/templates_work_ref/python_reference_v13.json', json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    write_with_backup(ROOT / 'tools/python/verify_ref_v13_output.txt', report)
    print(report, end='')


if __name__ == '__main__':
    main()
