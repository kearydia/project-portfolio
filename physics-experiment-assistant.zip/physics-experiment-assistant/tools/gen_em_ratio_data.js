'use strict';
const fs = require('node:fs'), path = require('node:path');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function generateSample() {
  const seed = 20261115, rnd = mulberry32(seed);
  const em = 1.75882001076e11, N = 526, L = 0.234, D = 0.090, l = 0.145, n = 1, mu0 = 4 * Math.PI * 1e-7;
  const k = 8 * Math.PI ** 2 * n ** 2 * (L ** 2 + D ** 2) / (mu0 ** 2 * N ** 2 * l ** 2 * em);
  const rows = Array.from({ length: 9 }, (_, i) => {
    const U = 700 + i * 50, I = Math.sqrt(k * U) + (2 * rnd() - 1) * 0.004 + (i === 4 ? 0.06 : 0);
    return U + ',' + I.toFixed(3);
  });
  return '# 模拟数据（非真实测量）| 模板 em_ratio_focusing | 固定种子 ' + seed + '（mulberry32）| 全部真值 e/m=1.75882001076e11 C/kg, N=526, L=0.234 m, D=0.090 m, l=0.145 m, n=1, μ₀=4π×10⁻⁷ N/A² | U=700,750,…,1100 V（9 点）；I 由聚焦公式反算，加独立均匀噪声 ±0.004 A，保留 3 位小数；第 5 行电流人为加 0.06 A\nU,I\n' + rows.join('\n') + '\n';
}
function writeWithBackup(file, text) {
  if (fs.existsSync(file)) {
    let backup = file + '.bakEM', i = 1;
    while (fs.existsSync(backup)) backup = file + '.' + i++ + '.bakEM';
    fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
  }
  fs.writeFileSync(file, text, 'utf8');
}
if (require.main === module) {
  const root = path.join(__dirname, '..'), csv = generateSample();
  const template = path.join(root, 'templates/em_ratio_focusing.js'), source = fs.readFileSync(template, 'utf8');
  if (!/^    sampleCsv: .*,$/m.test(source)) throw new Error('模板缺少 sampleCsv 写入位置');
  writeWithBackup(path.join(root, 'sample_data/templates_work/em_ratio_focusing_模拟数据.csv'), csv);
  writeWithBackup(template, source.replace(/^    sampleCsv: .*,$/m, () => '    sampleCsv: ' + JSON.stringify(csv) + ','));
  const truthFile = path.join(root, 'sample_data/templates_work/truth.json'), truth = fs.readFileSync(truthFile, 'utf8');
  if (!Object.hasOwn(JSON.parse(truth), 'em_ratio_focusing'))
    writeWithBackup(truthFile, truth.replace(/\s*}\s*$/, ',\n "em_ratio_focusing": 1.75882e11\n}\n'));
  console.log('已生成荷质比模拟数据、模板内嵌副本及真值，固定种子 20261115。');
}
module.exports = { generateSample };
