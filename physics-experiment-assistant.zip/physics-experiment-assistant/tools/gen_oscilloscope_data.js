'use strict';
const fs = require('node:fs'), path = require('node:path');
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function generateSample() {
  const seed = 20261116, rnd = mulberry32(seed);
  const rows = Array.from({ length: 10 }, () => [(5 + (2 * rnd() - 1) * 0.03).toFixed(3), (4 + (2 * rnd() - 1) * 0.04).toFixed(3)].join(','));
  return '# 模拟数据（非真实测量）| 模板 oscilloscope | 固定种子 ' + seed + '（mulberry32）| 全部真值 f=1000 Hz, T=0.001 s, Vpp=2 V, 时基=0.0002 s/div, 垂直灵敏度=0.05 V/div, 探头倍率=10；校准关闭 | 水平格数=5、垂直格数=4，分别加独立均匀噪声 ±0.03 div、±0.04 div；保留 3 位小数；10 次测量，无人为异常点\nn_div,v_div\n' + rows.join('\n') + '\n';
}
function writeWithBackup(file, text) {
  if (fs.existsSync(file)) {
    if (fs.readFileSync(file, 'utf8') === text) return;
    let backup = file + '.bak', i = 1;
    while (fs.existsSync(backup)) backup = file + '.' + i++ + '.bak';
    fs.copyFileSync(file, backup, fs.constants.COPYFILE_EXCL);
  }
  fs.writeFileSync(file, text, 'utf8');
}
if (require.main === module) {
  const root = path.join(__dirname, '..'), csv = generateSample();
  const template = path.join(root, 'templates/oscilloscope.js'), source = fs.readFileSync(template, 'utf8');
  if (!/^    sampleCsv: .*,$/m.test(source)) throw new Error('模板缺少 sampleCsv 写入位置');
  writeWithBackup(path.join(root, 'sample_data/oscilloscope_模拟数据.csv'), csv);
  writeWithBackup(template, source.replace(/^    sampleCsv: .*,$/m, () => '    sampleCsv: ' + JSON.stringify(csv) + ','));
  console.log('已生成示波器模拟数据与模板内嵌副本，固定种子 20261116。');
}
module.exports = { generateSample, writeWithBackup };
