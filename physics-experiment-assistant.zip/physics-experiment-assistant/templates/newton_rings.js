// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'newton_rings', name: '牛顿环测曲率半径', category: '光学',
  summary: '测各级暗环直径，D_m²–m 拟合（等价逐差）求平凸透镜曲率半径。', method: 'linear_fit',
  inputs: [
    { key: 'm', label: '暗环级数', unit: '1', instrumentError: 0, kind: 'column_x' },
    { key: 'Dm', label: '第m级暗环直径', unit: 'mm', instrumentError: 0.005, kind: 'column_y' }
  ],
  params: [{ key: 'lambda', label: '钠光波长', unit: 'mm', default: 5.893e-4, uncertainty: 1.7e-7, note: '钠双线 589.0/589.6 nm 取平均 589.3 nm，u(λ)=0.3 nm/√3≈0.17 nm' }],
  transform: { x: (row) => row.m, y: (row) => row.Dm * row.Dm, xLabel: 'm', yLabel: 'D_m² / mm²' },
  result: {
    key: 'R', label: '曲率半径', unit: 'm',
    formulaTex: 'D_m^2-D_n^2=4(m-n)R\\lambda\\Rightarrow R=\\frac{k}{4\\lambda}',
    compute: (c) => c.fit.slope / (4 * c.params.lambda) / 1000,
    uncertaintyInputs: ['fit.slope', 'params.lambda']
  },
  accepted: { value: 1.000, unit: 'm', note: '平凸透镜标称曲率半径 1.000 m' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 newton_rings | 生成真值 1.0 | 噪声: Dm±0.004 mm; 含接触点形变常数项 0.15 mm²\nm,Dm\n5.0,3.453\n6.0,3.783\n7.0,4.088\n8.0,4.364\n9.0,4.621\n10.0,4.868\n11.0,5.104\n12.0,5.34\n13.0,5.545\n14.0,5.761\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
