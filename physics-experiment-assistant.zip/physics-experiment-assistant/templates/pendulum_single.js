// 模板：单摆测重力加速度（固定摆长、多次测周期，直接测量 + 不确定度传递）。
(function () {
  const tpl = {
    id: 'pendulum_single', name: '单摆测重力加速度（单摆长多次测量）', category: '力学', keywords: ['单摆', '重力加速度', 'g', '周期', '直接测量'],
    summary: '固定摆长 L，多次测周期 T，g = 4π²L/T̄²，A/B 类合成后传递不确定度。',
    method: 'direct',
    inputs: [{ key: 'T', label: '周期 T', unit: 's', instrumentError: 0.01, kind: 'repeated', aliases: ['周期'] }],
    params: [{ key: 'L', label: '摆长 L', unit: 'm', default: 0.8, instrumentError: 0.001 }],
    result: {
      key: 'g', label: '重力加速度 g', unit: 'm/s²', formulaTex: 'g = 4π²L / T̄²',
      compute: ctx => 4 * Math.PI * Math.PI * ctx.params.L / (ctx.mean.T * ctx.mean.T),
      uncertaintyInputs: ['mean.T', 'params.L']
    },
    accepted: { value: 9.797, unit: 'm/s²', note: '西安地区 g≈9.797 m/s²（按纬度公式估算），可在页面修改' },
    errorSources: ['秒表启停的反应时间', '摆长测量误差', '摆角过大', '数周期时计数错误'],
    suggestions: ['以摆球经过最低点时开始/停止计时', '测多个周期的总时间再除以周期数', '增加测量次数以减小 A 类不确定度'],
    sampleCsv: 'sample_data/pendulum_single_模拟数据.csv',
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
