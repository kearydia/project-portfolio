// 模板：单摆测重力加速度（T²–L 图线法）。核心计算采用码道 CodeArts 生成的 pendulumGravity（含摆长 B 类分量）。
(function () {
  const tpl = {
    id: 'pendulum_fit', name: '单摆测重力加速度（T²–L 图线法）', category: '力学', keywords: ['单摆', '重力加速度', 'g', '周期'],
    summary: '改变摆长 L 测周期 T，作 T²–L 最小二乘拟合，g = 4π²/斜率。',
    method: 'linear_fit',
    inputs: [
      { key: 'L', label: '摆长 L', unit: 'm', instrumentError: 0.001, kind: 'column_x', aliases: ['摆长'] },
      { key: 'T', label: '周期 T', unit: 's', instrumentError: 0.002, kind: 'column_y', aliases: ['周期'] }
    ],
    params: [],
    transform: { x: 'L', y: r => r.T * r.T, xLabel: '摆长 L (m)', yLabel: '周期平方 T² (s²)', slopeUnit: 's²/m', interceptUnit: 's²' },
    result: {
      key: 'g', label: '重力加速度 g', unit: 'm/s²', formulaTex: 'g = 4π² / b（b 为 T²–L 斜率）',
      compute: ctx => 4 * Math.PI * Math.PI / ctx.fit.slope,
      uncertaintyInputs: ['fit.slope'],
      core: ({ rows, deltas, K }) => { const r = K.pendulumGravity({ lengths: rows.map(x => x.L), periods: rows.map(x => x.T), lengthDelta: deltas.L }); return { value: r.g, uncertainty: r.uG, steps: r.steps }; }
    },
    accepted: { value: 9.797, unit: 'm/s²', note: '西安地区 g≈9.797 m/s²（按纬度公式估算），可在页面修改' },
    errorSources: ['摆长未量到摆球球心', '摆角过大（应 <5°）', '计时起止的人为反应误差', '摆线质量与空气阻力'],
    suggestions: ['测 20~50 个周期取平均以减小计时误差', '每个摆长重复测量并取平均', '摆长范围尽量拉开以提高斜率精度'],
    sampleCsv: 'sample_data/pendulum_fit_模拟数据.csv',
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
