// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'photoelectric_planck', name: '光电效应测普朗克常量', category: '近代物理',
  summary: '测不同频率光的截止电压，U_a–ν 拟合，h=e·斜率。', method: 'linear_fit',
  inputs: [
    { key: 'lam', label: '滤光片波长', unit: 'nm', instrumentError: 0, kind: 'column_x' },
    { key: 'Ua', label: '截止电压', unit: 'V', instrumentError: 0.005, kind: 'column_y' }
  ],
  params: [
    { key: 'c', label: '光速', unit: 'm/s', default: 299792458, uncertainty: 0 },
    { key: 'e', label: '元电荷', unit: 'C', default: 1.602176634e-19, uncertainty: 0 }
  ],
  transform: { x: (row, p) => p.c / (row.lam * 1e-9) / 1e14, y: (row) => row.Ua, xLabel: 'ν / 10¹⁴ Hz', yLabel: 'U_a / V' },
  result: {
    key: 'h', label: '普朗克常量', unit: 'J·s',
    formulaTex: 'eU_a=h\\nu-W\\Rightarrow h=e\\,k',
    compute: (c) => c.params.e * c.fit.slope * 1e-14,
    uncertaintyInputs: ['fit.slope']
  },
  accepted: { value: 6.62607015e-34, unit: 'J·s', note: 'CODATA 2018 精确值' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 photoelectric_planck | 生成真值 6.62607015e-34 | 理想爱因斯坦关系+噪声 Ua±0.003 V; 逸出功 2.0 eV\nlam,Ua\n365.0,1.401\n404.7,1.067\n435.8,0.845\n546.1,0.269\n577.0,0.148\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
