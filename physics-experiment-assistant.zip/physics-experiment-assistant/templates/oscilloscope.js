// 固定量程下重复读格数；先平均周期，再取倒数求频率。
(function () {
  'use strict';
  const positive = (x, label) => {
    if (!Number.isFinite(x) || x <= 0) throw new Error(label + '必须为正的有限数');
    return x;
  };
  function scales(p) {
    const time = positive(p.timebase, '时基') * (p.calibration ? positive(p.kt, '时基校准因子') : 1);
    const voltage = positive(p.sensitivity, '垂直灵敏度') * positive(p.probe, '探头衰减倍率') *
      (p.calibration ? positive(p.kv, '电压校准因子') : 1);
    return { time, voltage };
  }
  function measurements(c, details) {
    const p = c.params, { time, voltage } = scales(p), u = details.uncertainties, a = details.typeA;
    for (const row of details.rows) {
      positive(row.n_div, '每行周期水平格数'); positive(row.v_div, '每行峰峰垂直格数');
    }
    const n = positive(c.mean.n_div, '周期水平格数'), v = positive(c.mean.v_div, '峰峰垂直格数');
    const T = n * time, Vpp = v * voltage, f = 1 / T;
    const uT = T * Math.hypot(u['mean.n_div'] / n, u['params.timebase'] / p.timebase,
      p.calibration ? u['params.kt'] / p.kt : 0);
    const uVpp = Vpp * Math.hypot(u['mean.v_div'] / v, u['params.sensitivity'] / p.sensitivity,
      u['params.probe'] / p.probe, p.calibration ? u['params.kv'] / p.kv : 0);
    return { T, f, Vpp, uAT: time * a.n_div, uAf: time * a.n_div / T ** 2,
      uAVpp: voltage * a.v_div, uT, uf: uT / T ** 2, uVpp };
  }
  const tpl = {
    id: 'oscilloscope', name: '示波器的使用（测频率、周期与峰峰值）', category: '电磁学',
    summary: '固定时基和垂直灵敏度，多次读格求平均周期、频率及峰峰值，与信号发生器标称值比较；可选仪器校准修正。',
    keywords: ['示波器', '周期', '频率', '峰峰值', '探头'], method: 'direct',
    inputs: [
      { key: 'n_div', label: '一个完整周期的水平格数', unit: 'div', instrumentError: 0.02, kind: 'repeated' },
      { key: 'v_div', label: '波峰至波谷的垂直格数', unit: 'div', instrumentError: 0.02, kind: 'repeated' }
    ],
    params: [
      { key: 'timebase', label: '时基（假设值，0.2 ms/div 填 0.0002）', unit: 's/div', default: 0.0002, uncertainty: 0.000001 },
      { key: 'sensitivity', label: '垂直灵敏度（假设值）', unit: 'V/div', default: 0.05, uncertainty: 0.0005 },
      { key: 'probe', label: '探头衰减倍率（×10 填 10）', unit: '', default: 10, uncertainty: 0,
        note: '若示波器显示的 V/div 已包含探头倍率，填 1；否则 ×10 探头填 10。默认不计倍率不确定度。' },
      { key: 'VppNominal', label: '信号发生器标称峰峰值（假设值）', unit: 'V', default: 2, uncertainty: 0,
        note: '按实际负载设置填写 Vpp，不能把有效值或单边幅值当峰峰值；标称值只作比较，不计其不确定度。' },
      { key: 'calibration', label: '仪器校准修正', type: 'switch', default: 0,
        note: '开启后 T 乘 kt、Vpp 乘 kv，f 除以 kt。因子定义为校准真值/未修正读数，须用独立校准结果替换假设值；关闭时因子及其不确定度不参与计算。' },
      { key: 'kt', label: '时基校准因子 kt（假设值）', unit: '', default: 1.002, uncertainty: 0.001, enabledBy: 'calibration' },
      { key: 'kv', label: '电压校准因子 kv（假设值）', unit: '', default: 0.99, uncertainty: 0.002, enabledBy: 'calibration' }
    ],
    result: {
      key: 'f', label: '由平均周期得到的信号频率 f', unit: 'Hz',
      formulaTex: 'Tᵢ=n_div,ᵢ×时基；T̄=n̄_div×时基；f=1/T̄；Vppᵢ=v_div,ᵢ×垂直灵敏度×探头倍率；校准开启时 T 乘 kt、Vpp 乘 kv',
      compute: c => 1 / (positive(c.mean.n_div, '周期水平格数') * scales(c.params).time),
      uncertaintyInputs: ['mean.n_div', 'params.timebase', 'params.kt'],
      steps: (c, details) => {
        const m = measurements(c, details), p = c.params, scale = scales(p);
        const nominal = positive(p.VppNominal, '标称峰峰值'), error = m.Vpp - nominal;
        const verdict = Math.abs(error) <= 2 * m.uVpp ? '一致' : Math.abs(error) <= 3 * m.uVpp ? '基本一致' : '偏差显著';
        return [
          { title: '测量约定与校准状态', formula: '每次读一个完整周期；整组测量保持时基、垂直灵敏度和探头倍率不变',
            substitution: 'calibration=' + p.calibration + '；时基=' + p.timebase + ' s/div；灵敏度=' + p.sensitivity + ' V/div；倍率=' + p.probe,
            result: p.calibration ? '开启：kt=' + p.kt + '，kv=' + p.kv : '关闭：kt、kv 不参与计算及不确定度传递' },
          { title: '平均周期', formula: 'T̄=ΣTᵢ/N=n̄_div×时基×kt（关闭时 kt=1）',
            substitution: c.mean.n_div + '×' + scale.time, result: m.T + ' s' },
          { title: '由平均周期求频率', formula: 'f=1/T̄；本模板采用周期先平均后取倒数，不采用各次频率的算术平均',
            substitution: '1/' + m.T, result: m.f + ' Hz' },
          { title: '平均峰峰值', formula: 'V̄pp=v̄_div×垂直灵敏度×探头倍率×kv（关闭时 kv=1）',
            substitution: c.mean.v_div + '×' + scale.voltage, result: m.Vpp + ' V' },
          { title: '周期的 A 类不确定度', formula: 'u_A(x̄)=s(x)/√N；u_A(T̄)=时基×kt×u_A(n̄_div)；沿用页面 t 因子设置',
            substitution: scale.time + '×' + details.typeA.n_div, result: m.uAT + ' s' },
          { title: '频率的 A 类不确定度', formula: 'u_A(f)=u_A(T̄)/T̄²（一阶传递）',
            substitution: m.uAT + '/' + m.T + '²', result: m.uAf + ' Hz' },
          { title: '峰峰值的 A 类不确定度', formula: 'u_A(V̄pp)=垂直灵敏度×探头倍率×kv×u_A(v̄_div)',
            substitution: scale.voltage + '×' + details.typeA.v_div, result: m.uAVpp + ' V' },
          { title: '周期的合成不确定度', formula: 'u(T̄)/T̄=√[(u(n̄)/n̄)²+(u(时基)/时基)²+(u(kt)/kt)²]；关闭时去掉 kt 项',
            substitution: '读格 A/B 合成；时基和校准因子为全组共有，不除以 √N', result: m.uT + ' s' },
          { title: '峰峰值的合成不确定度', formula: 'u(V̄pp)/V̄pp=√[(u(v̄)/v̄)²+(u(S)/S)²+(u(P)/P)²+(u(kv)/kv)²]；各输入独立，关闭时去掉 kv 项',
            substitution: 'S=' + p.sensitivity + ' V/div，P=' + p.probe + '；读格 A/B 合成', result: m.uVpp + ' V' },
          { title: '峰峰值与信号发生器标称值比较', formula: '相对误差=(V̄pp−Vpp标称)/Vpp标称×100%；|差值|≤2u 判为一致，≤3u 基本一致',
            substitution: '(' + m.Vpp + '−' + nominal + ')/' + nominal + '×100%', result: error / nominal * 100 + '%；' + verdict }
        ];
      }
    },
    accepted: { value: 1000, unit: 'Hz', note: '示例信号发生器标称 1000 Hz（假设值），不是普适物理常数；实际使用请在公认值输入框填写发生器频率，不计参考值不确定度。' },
    errorSources: ['读格分辨率与触发抖动影响周期和峰峰值', '时基与垂直增益校准误差为全组共有', '探头倍率重复换算或探头补偿不当', '发生器负载设置与实际输入阻抗不同导致幅值偏差'],
    suggestions: ['先补偿探头并稳定触发，读取同相位两点间一个完整周期', '整组保持量程不变；改变量程后另开一组', '确认垂直刻度是否已补偿探头倍率', '核对发生器频率、峰峰值和负载设置；只用独立校准值开启修正'],
    sampleCsv: "# 模拟数据（非真实测量）| 模板 oscilloscope | 固定种子 20261116（mulberry32）| 全部真值 f=1000 Hz, T=0.001 s, Vpp=2 V, 时基=0.0002 s/div, 垂直灵敏度=0.05 V/div, 探头倍率=10；校准关闭 | 水平格数=5、垂直格数=4，分别加独立均匀噪声 ±0.03 div、±0.04 div；保留 3 位小数；10 次测量，无人为异常点\nn_div,v_div\n4.985,3.968\n4.999,3.991\n5.001,4.029\n4.976,4.003\n5.023,4.037\n5.005,3.988\n4.984,4.012\n4.976,3.964\n5.021,4.014\n4.978,4.010\n",
    verified: true,
    measurements
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
