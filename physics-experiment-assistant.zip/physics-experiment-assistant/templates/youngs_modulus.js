// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'youngs_modulus', name: '杨氏模量（拉伸法·光杠杆）', category: '力学',
  summary: '逐次加砝码读光杠杆标尺，F–n 线性拟合求钢丝杨氏模量。', method: 'linear_fit',
  inputs: [
    { key: 'm', label: '砝码质量', unit: 'kg', instrumentError: 0, kind: 'column_x' },
    { key: 'n', label: '标尺读数', unit: 'mm', instrumentError: 0.5, kind: 'column_y' },
    { key: 'L', label: '钢丝长度', unit: 'm', instrumentError: 0.0005, kind: 'single' },
    { key: 'D', label: '镜尺距离', unit: 'm', instrumentError: 0.0005, kind: 'single' },
    { key: 'b', label: '光杠杆臂长', unit: 'm', instrumentError: 0.00002, kind: 'single' },
    { key: 'd', label: '钢丝直径', unit: 'mm', instrumentError: 0.004, kind: 'repeated' }
  ],
  params: [{ key: 'g', label: '重力加速度', unit: 'm/s²', default: 9.80, uncertainty: 0.005, note: '取 9.80 m/s²，u(g)=0.005 m/s² 为假设值（覆盖与西安当地 g≈9.797 的差异）' }],
  transform: { x: (row) => row.m, y: (row, p) => row.n / 1000, xLabel: 'm / kg', yLabel: 'n / m' },
  result: {
    key: 'E', label: '杨氏模量', unit: 'Pa',
    formulaTex: 'E=\\frac{8LDg}{\\pi d^2 b\\,k},\\quad k=\\frac{\\Delta n}{\\Delta m}',
    compute: (c) => 8 * c.mean.L * c.mean.D * c.params.g / (Math.PI * Math.pow(c.mean.d / 1000, 2) * c.mean.b * c.fit.slope),
    uncertaintyInputs: ['fit.slope', 'mean.L', 'mean.D', 'mean.b', 'mean.d', 'params.g']
  },
  accepted: { value: 2.00e11, unit: 'Pa', note: '钢的典型值（约2.0×10¹¹ Pa）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 youngs_modulus | 生成真值 200000000000.0 | 噪声: n±0.15 mm, d±0.002 mm; L=0.800 D=1.500 b=0.0700\nm,n,L,D,b,d\n1.0,28.68,0.8,1.5,0.07,0.501\n2.0,37.37,,,,0.5\n3.0,45.53,,,,0.499\n4.0,54.39,,,,0.502\n5.0,62.84,,,,0.497\n6.0,71.34,,,,0.5\n7.0,79.92,,,,\n8.0,88.48,,,,\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
