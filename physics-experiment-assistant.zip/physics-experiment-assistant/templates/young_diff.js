// 模板：拉伸法测钢丝杨氏模量（光杠杆，n–F 图线法）。
(function () {
  const tpl = {
    id: 'young_diff', name: '杨氏模量（拉伸法·光杠杆，逐差法）', category: '力学', keywords: ['杨氏模量', '光杠杆', '拉伸法', '弹性模量'],
    summary: '逐次加砝码读标尺 n，用逐差法求每增加 kΔF 的平均读数变化，得 k，E = 8LD/(πd²bk)。',
    method: 'successive_diff',
    inputs: [
      { key: 'm', label: '砝码质量 m', unit: 'kg', instrumentError: 0.0005, kind: 'column_x', aliases: ['质量', '砝码'] },
      { key: 'n', label: '标尺读数 n', unit: 'cm', instrumentError: 0.05, kind: 'column_y', aliases: ['读数', '标尺'] }
    ],
    params: [
      { key: 'L', label: '钢丝长 L', unit: 'm', default: 1.000, instrumentError: 0.001 },
      { key: 'D', label: '镜尺距离 D', unit: 'm', default: 1.500, instrumentError: 0.002 },
      { key: 'b', label: '光杠杆臂长 b', unit: 'm', default: 0.0500, instrumentError: 0.0002 },
      { key: 'd', label: '钢丝直径 d', unit: 'mm', default: 0.500, instrumentError: 0.004 },
      { key: 'g', label: '重力加速度 g', unit: 'm/s²', default: 9.80, uncertainty: 0.005, note: '取 9.80 m/s²，u(g)=0.005 m/s² 为假设值（覆盖与西安当地 g≈9.797 的差异）' }
    ],
    transform: { x: r => r.m, y: r => r.n / 100, yInstrumentError: d => d / 100, yUnit: 'm', xLabel: '砝码质量 m (kg)', yLabel: '标尺读数 n (m)', slopeUnit: 'm/kg', interceptUnit: 'm' },
    result: {
      key: 'E', label: '杨氏模量 E', unit: 'Pa', formulaTex: 'E = 8LDg / (π d² b k)（k 为 n–m 逐差法斜率，d 换算为 m）',
      compute: ctx => { const p = ctx.params, d = p.d / 1000; return 8 * p.L * p.D * p.g / (Math.PI * d * d * p.b * ctx.fit.slope); },
      uncertaintyInputs: ['fit.slope', 'params.L', 'params.D', 'params.b', 'params.d', 'params.g']
    },
    accepted: { value: 2.00e11, unit: 'Pa', note: '钢的杨氏模量典型值约 2.0×10¹¹ Pa' },
    errorSources: ['钢丝直径测量（平方关系，影响最大）', '光杠杆臂长 b 的测量', '钢丝未拉直或夹持松动', '加减砝码时的振动'],
    suggestions: ['在钢丝不同位置、不同方向多次测直径', '实验前先加预载砝码把钢丝拉直', '加、减砝码各读一次取平均'],
    sampleCsv: 'sample_data/young_diff_模拟数据.csv',
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
