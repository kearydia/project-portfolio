// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'thin_lens_conjugate', name: '薄透镜焦距（共轭法/二次成像法）', category: '光学',
  summary: '物屏间距固定，移动透镜两次成像，由两位置间距求焦距。', method: 'direct',
  inputs: [
    { key: 'D', label: '物屏间距', unit: 'cm', instrumentError: 0.05, kind: 'single' },
    { key: 'x1', label: '成放大像时透镜位置', unit: 'cm', instrumentError: 0.05, kind: 'repeated' },
    { key: 'x2', label: '成缩小像时透镜位置', unit: 'cm', instrumentError: 0.05, kind: 'repeated' }
  ],
  params: [],
  result: {
    key: 'f', label: '焦距', unit: 'cm',
    formulaTex: 'f=\\frac{D^2-d^2}{4D},\\quad d=x_2-x_1',
    compute: (c) => { const d = c.mean.x2 - c.mean.x1; return (c.mean.D ** 2 - d ** 2) / (4 * c.mean.D); },
    uncertaintyInputs: ['mean.D', 'mean.x1', 'mean.x2']
  },
  accepted: { value: 15.0, unit: 'cm', note: '透镜标称焦距 15.0 cm' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 thin_lens_conjugate | 生成真值 15.0 | 物在 0 cm、屏在 80.00 cm; 噪声 ±0.15 cm（成像清晰位置判断）\nD,x1,x2\n80.0,19.86,59.92\n,20.24,59.84\n,20.08,60.23\n,20.09,60.31\n,20.07,60.09\n,20.01,60.12\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
