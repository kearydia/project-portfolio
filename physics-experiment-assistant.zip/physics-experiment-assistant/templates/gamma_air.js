// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'gamma_air', name: '空气比热容比（绝热膨胀法）', category: '热学',
  summary: '充气—绝热放气—等容回升，由三个压强求 γ=Cp/Cv。', method: 'direct',
  inputs: [
    { key: 'p0', label: '环境大气压', unit: 'kPa', instrumentError: 0.01, kind: 'single' },
    { key: 'p1', label: '充气稳定后气压', unit: 'kPa', instrumentError: 0.01, kind: 'repeated' },
    { key: 'p2', label: '放气后回升稳定气压', unit: 'kPa', instrumentError: 0.01, kind: 'repeated' }
  ],
  params: [],
  result: {
    key: 'gamma', label: '比热容比 γ', unit: '1',
    formulaTex: '\\gamma=\\frac{\\ln(p_1/p_0)}{\\ln(p_1/p_2)}',
    compute: (c) => Math.log(c.mean.p1 / c.mean.p0) / Math.log(c.mean.p1 / c.mean.p2),
    uncertaintyInputs: ['mean.p0', 'mean.p1', 'mean.p2']
  },
  accepted: { value: 1.402, unit: '1', note: '干燥空气典型值（约1.40）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 gamma_air | 生成真值 1.4 | 噪声: p1,p2 ±0.005 kPa\np0,p1,p2\n101.3,104.992,102.345\n,105.001,102.342\n,104.996,102.335\n,105.007,102.345\n,105.002,102.337\n,105.002,102.349\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
