// 模板：伏安法测电阻（U–I 图线法）。核心计算采用码道 CodeArts 生成的 ohmsLawResistance。
(function () {
  const tpl = {
    id: 'ohm_fit', name: '伏安法测电阻（U–I 图线法）', category: '电磁学', keywords: ['伏安法', '电阻', '欧姆定律', 'U-I'],
    summary: '测多组电流 I、电压 U，作 U–I 最小二乘拟合，R = 斜率。',
    method: 'linear_fit',
    inputs: [
      { key: 'I', label: '电流 I', unit: 'mA', instrumentError: 0.05, kind: 'column_x', aliases: ['电流'] },
      { key: 'U', label: '电压 U', unit: 'V', instrumentError: 0.005, kind: 'column_y', aliases: ['电压'] }
    ],
    params: [],
    transform: { x: r => r.I / 1000, y: 'U', xLabel: '电流 I (A)', yLabel: '电压 U (V)', slopeUnit: 'Ω', interceptUnit: 'V' },
    result: {
      key: 'R', label: '电阻 R', unit: 'Ω', formulaTex: 'R = b（U–I 图线斜率）',
      compute: ctx => ctx.fit.slope,
      uncertaintyInputs: ['fit.slope'],
      core: ({ rows, K }) => { const r = K.ohmsLawResistance({ voltages: rows.map(x => x.U), currents: rows.map(x => x.I / 1000) }); return { value: r.resistance, uncertainty: r.uR, steps: r.steps }; }
    },
    accepted: { value: 100.0, unit: 'Ω', note: '待测电阻标称值 100.0 Ω（模拟实验设定）' },
    errorSources: ['电表内阻引起的接入误差（内接/外接）', '电表读数与量程误差', '通电发热导致电阻变化'],
    suggestions: ['R 远大于电流表内阻时用内接法，远小于电压表内阻时用外接法', '选择合适量程使指针偏转过半', '测量时间短、电流不宜过大以减小发热'],
    sampleCsv: 'sample_data/ohm_fit_模拟数据.csv',
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
