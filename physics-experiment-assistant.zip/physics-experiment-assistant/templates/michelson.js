// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'michelson', name: '迈克尔逊干涉仪测波长（逐差法）', category: '光学',
  summary: '每吞吐50条条纹记一次动镜位置，逐差法求激光波长。', method: 'successive_diff',
  inputs: [
    { key: 'N', label: '累计吞吐条纹数', unit: '1', instrumentError: 0, kind: 'column_x' },
    { key: 'd', label: '动镜位置', unit: 'mm', instrumentError: 0.00005, kind: 'column_y' }
  ],
  params: [],
  result: {
    key: 'lambda', label: '波长', unit: 'nm',
    formulaTex: '\\lambda=\\frac{2\\Delta d}{\\Delta N}',
    compute: (c) => 2 * c.diff.d / c.diff.N * 1e6,
    uncertaintyInputs: ['diff.d']
  },
  accepted: { value: 632.8, unit: 'nm', note: 'He-Ne 激光公认值' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 michelson | 生成真值 632.8 | 噪声: d±0.0002 mm; 起点 30.12000 mm\nN,d\n0.0,30.11983\n50.0,30.13574\n100.0,30.15188\n150.0,30.16734\n200.0,30.18326\n250.0,30.19906\n300.0,30.21487\n350.0,30.23053\n400.0,30.24649\n450.0,30.26228\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
