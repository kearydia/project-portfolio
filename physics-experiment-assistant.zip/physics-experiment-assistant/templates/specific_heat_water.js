// 电热法：所有输入采用 SI 单位，最终比热容由 J/(kg·K) 除以 1000。
(function () {
  const rate = c => c.fit.slope + (c.params.heatLoss ? c.params.K * (c.fit.yMean - c.params.theta) : 0);
  const tpl = {
    id: 'specific_heat_water', name: '水的比热容（电热法）', category: '热学',
    summary: '恒功率电热法：拟合温度–时间求水的比热容，可选牛顿冷却散热修正。混合法主要测固体比热容并以水的比热容为已知量，测水本身采用电热法。',
    keywords: ['量热器', '牛顿冷却', '散热', '比热'], method: 'linear_fit',
    inputs: [
      { key: 't', label: '加热时间 t', unit: 's', instrumentError: 0, kind: 'column_x' },
      { key: 'T', label: '水温 T（数字温度计）', unit: '°C', instrumentError: 0.1, kind: 'column_y' },
      { key: 'U', label: '加热电压 U', unit: 'V', instrumentError: 0.02, kind: 'single' },
      { key: 'I', label: '加热电流 I', unit: 'A', instrumentError: 0.01, kind: 'single' },
      { key: 'm0', label: '水的质量 m₀', unit: 'kg', instrumentError: 0.0001, kind: 'single' },
      { key: 'm1', label: '量热器内筒质量 m₁', unit: 'kg', instrumentError: 0.0001, kind: 'single' }
    ],
    params: [
      { key: 'c1', label: '铝内筒比热容 c₁（假设值，u=10）', unit: 'J/(kg·K)', default: 900, uncertainty: 10 },
      { key: 'Cs', label: '搅拌器、加热丝、温度计等热容 Cₛ（假设值，u=5）', unit: 'J/K', default: 20, uncertainty: 5 },
      { key: 'heatLoss', label: '散热修正', type: 'switch', default: 0,
        note: '假设牛顿冷却：C·dT/dt=UI−C·K·(T−θ)，拟合斜率 k 近似取在保留点平均温度 T̄ 处；T̄ 不计不确定度。c₁、Cₛ、K、θ 均为假设值。K 应由断电后另测冷却曲线 ln(T−θ)–t 求得；此处为假设值。勾选后用 k+K(T̄−θ)；关闭时 K、θ 不参与计算和传递。' },
      { key: 'K', label: '冷却常数 K（假设值，u=0.15×10⁻⁴）', unit: '1/s', default: 1.5e-4, uncertainty: 0.15e-4, enabledBy: 'heatLoss',
        note: '断电后另测一段冷却曲线 ln(T−θ)–t 求得；此处为假设值' },
      { key: 'theta', label: '室温 θ（假设值）', unit: '°C', default: 20.0, instrumentError: 0.1, enabledBy: 'heatLoss' }
    ],
    transform: { x: 't', y: 'T', xLabel: 't / s', yLabel: 'T / °C', slopeUnit: 'K/s', interceptUnit: '°C' },
    result: {
      key: 'c0', label: '水的比热容 c₀', unit: 'kJ/(kg·K)',
      formulaTex: '关闭：UI=(c₀m₀+c₁m₁+Cₛ)k，c₀=(UI/k−c₁m₁−Cₛ)/m₀；开启：以 k+K(T̄−θ) 替代 k；以上为 J/(kg·K)，再除以 1000 得 kJ/(kg·K)',
      compute: c => {
        if (!(c.mean.U > 0 && c.mean.I > 0 && c.mean.m0 > 0 && c.mean.m1 > 0 && c.fit.slope > 0))
          throw new Error('加热电压、电流、水和内筒质量、升温斜率必须为正');
        if (!(c.params.c1 > 0 && c.params.Cs >= 0)) throw new Error('内筒比热容必须为正，附属热容不能为负');
        if (c.params.heatLoss && !(c.params.K >= 0 && Number.isFinite(c.fit.yMean))) throw new Error('冷却常数不能为负，平均温度必须有效');
        const k = rate(c);
        if (!(k > 0)) throw new Error('修正后的升温速率必须为正');
        return (c.mean.U * c.mean.I / k - c.params.c1 * c.mean.m1 - c.params.Cs) / c.mean.m0 / 1000;
      },
      uncertaintyInputs: ['fit.slope', 'mean.U', 'mean.I', 'mean.m0', 'mean.m1', 'params.c1', 'params.Cs', 'params.K', 'params.theta'],
      steps: c => {
        const power = c.mean.U * c.mean.I, k = rate(c), capacity = power / k;
        const steps = [
          { title: '电加热功率', formula: 'P=UI', substitution: c.mean.U + '×' + c.mean.I, result: power + ' W' },
          { title: '散热修正状态与假设', formula: '牛顿冷却；k 近似取在 T̄ 处；T̄ 不计不确定度；c₁、Cₛ、K、θ 均为假设值', substitution: 'heatLoss=' + c.params.heatLoss,
            result: c.params.heatLoss ? '开启：K、θ 参与传递' : '关闭：严格采用基本公式，K、θ 不参与计算和传递' }
        ];
        if (c.params.heatLoss) steps.push(
          { title: '保留拟合点的平均温度', formula: 'T̄=ΣTᵢ/n=a+b·t̄；T̄ 不计不确定度', substitution: c.fit.intercept + '+' + c.fit.slope + '×' + c.fit.xMean, result: c.fit.yMean + ' °C' },
          { title: '散热对应的升温速率', formula: 'δk=K(T̄−θ)', substitution: c.params.K + '×(' + c.fit.yMean + '−' + c.params.theta + ')', result: (k - c.fit.slope) + ' K/s' },
          { title: '修正后的升温速率', formula: 'k修正=k+K(T̄−θ)', substitution: c.fit.slope + '+' + c.params.K * (c.fit.yMean - c.params.theta), result: k + ' K/s' }
        );
        steps.push(
          { title: '总热容及其组成', formula: 'C=P/k有效=c₀m₀+c₁m₁+Cₛ（c₀ 用 J/(kg·K)）', substitution: power + '/' + k + '；c₁m₁+Cₛ=' + c.params.c1 + '×' + c.mean.m1 + '+' + c.params.Cs, result: capacity + ' J/K' },
          { title: '水的比热容与单位换算', formula: 'c₀=(C−c₁m₁−Cₛ)/m₀；J/(kg·K) 除以 1000 → kJ/(kg·K)', substitution: '(' + capacity + '−' + c.params.c1 * c.mean.m1 + '−' + c.params.Cs + ')/' + c.mean.m0 + '/1000', result: tpl.result.compute(c) + ' kJ/(kg·K)' }
        );
        return steps;
      }
    },
    accepted: { value: 4.18, unit: 'kJ/(kg·K)', note: '水在 20 °C 附近的比热容约 4.18 kJ/(kg·K)（CRC Handbook of Chemistry and Physics：20 °C 时 4.182 kJ/(kg·K)）' },
    errorSources: ['向周围散热会使未修正的结果偏大', '搅拌不均使温度计读数不能代表全部水温', '温度计滞后', '电压电流波动使加热功率不恒定', '假设热容或冷却常数与实际装置不同'],
    suggestions: ['加盖保温并缓慢均匀搅拌', '记录并稳定加热电压和电流', '选择温度变化较小且升温平稳的拟合区间', '另测断电后的冷却曲线和室温，替换假设值', '核对内筒和附属部件热容'],
    sampleCsv: "# 模拟数据（非真实测量）| 模板 specific_heat_water | 固定种子 20261114（mulberry32）| 全部真值 c0=4180 J/(kg·K), m0=0.200 kg, m1=0.060 kg, c1=900 J/(kg·K), Cs=20 J/K, U=6.00 V, I=1.50 A, θ=20.0 °C, T0=20.0 °C, K=1.5e-4 /s, C=910 J/K, P=9 W | 牛顿冷却解析解 T(t)=θ+(T0−θ)exp(−Kt)+P/(CK)(1−exp(−Kt))；t=0,60,…,900 s；温度独立均匀噪声 ±0.05 °C，保留 2 位小数；第 9 行温度人为加 0.8 °C\nt,T,U,I,m0,m1\n0,19.96,6.00,1.50,0.200,0.060\n60,20.58,,,,\n120,21.20,,,,\n180,21.73,,,,\n240,22.31,,,,\n300,22.87,,,,\n360,23.49,,,,\n420,24.02,,,,\n480,25.41,,,,\n540,25.10,,,,\n600,25.63,,,,\n660,26.17,,,,\n720,26.71,,,,\n780,27.28,,,,\n840,27.81,,,,\n900,28.36,,,,\n",
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
