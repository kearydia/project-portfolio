// 落球法：直径输入 mm，其余长度输入 m；先换算为 SI 单位。
(function () {
  const factors = c => ({
    wall: c.params.wallCorr ? 1 + 2.4 * (c.mean.d / 1000) / c.params.D : 1,
    bottom: c.params.bottomCorr ? 1 + 3.3 * (c.mean.d / 1000) / (2 * c.params.H) : 1
  });
  const tpl = {
    id: 'viscosity_falling_ball', name: '液体粘滞系数（落球法）', category: '力学',
    summary: '测量小球匀速下落时间，计算液体粘滞系数，可选择管壁和管底修正。',
    keywords: ['黏度', '粘度', '蓖麻油', '斯托克斯'], method: 'direct',
    inputs: [
      { key: 't', label: '下落时间 t', unit: 's', instrumentError: 0.01, kind: 'repeated' },
      { key: 'd', label: '小球直径 d', unit: 'mm', instrumentError: 0.004, kind: 'repeated' },
      { key: 'L', label: '标记线间距 L', unit: 'm', instrumentError: 0.001, kind: 'single' }
    ],
    params: [
      { key: 'rho', label: '钢球密度 ρ（假设值，u=10 kg/m³）', unit: 'kg/m³', default: 7800, uncertainty: 10 },
      { key: 'rho0', label: '液体密度 ρ₀（假设值，u=5 kg/m³）', unit: 'kg/m³', default: 960, uncertainty: 5 },
      { key: 'g', label: '重力加速度（假设值，u=0.005 m/s²）', unit: 'm/s²', default: 9.80, uncertainty: 0.005,
        note: '取 9.80 m/s²，u(g)=0.005 m/s² 为假设值，与现有模板一致' },
      { key: 'wallCorr', label: '管壁修正', type: 'switch', default: 0,
        note: 'η 除以 (1 + 2.4 d/D)，d 与 D 均用米；只有勾选后才改变结果，D 及其仪器误差才参与计算。' },
      { key: 'D', label: '量筒内径 D（仅管壁修正开启时使用）', unit: 'm', default: 0.040, instrumentError: 0.001, enabledBy: 'wallCorr' },
      { key: 'bottomCorr', label: '管底修正', type: 'switch', default: 0,
        note: 'η 除以 (1 + 3.3 d/(2H))，d 与 H 均用米；只有勾选后才改变结果，H 及其仪器误差才参与计算。' },
      { key: 'H', label: '液柱高度 H（仅管底修正开启时使用）', unit: 'm', default: 0.250, instrumentError: 0.001, enabledBy: 'bottomCorr' }
    ],
    result: {
      key: 'η', label: '液体粘滞系数', unit: 'Pa·s',
      formulaTex: 'η=(ρ−ρ₀)g(d/1000)²t/(18L·F壁·F底)；d 输入 mm；关闭的修正因子取 1',
      compute: c => {
        if (!(c.mean.t > 0 && c.mean.d > 0 && c.mean.L > 0 && c.params.g > 0 && c.params.rho > c.params.rho0 && c.params.rho0 > 0))
          throw new Error('时间、直径、间距、g 和液体密度必须为正，且小球密度必须大于液体密度');
        if (c.params.wallCorr && !(c.params.D > c.mean.d / 1000)) throw new Error('管壁修正要求量筒内径 D 大于小球直径');
        if (c.params.bottomCorr && !(c.params.H > 0)) throw new Error('管底修正要求液柱高度 H 大于 0');
        const f = factors(c);
        const base = (c.params.rho - c.params.rho0) * c.params.g * (c.mean.d / 1000) ** 2 * c.mean.t / (18 * c.mean.L);
        return base / f.wall / f.bottom;
      },
      uncertaintyInputs: ['mean.t', 'mean.d', 'mean.L', 'params.rho', 'params.rho0', 'params.g', 'params.D', 'params.H'],
      steps: (c, details) => {
        const f = factors(c), steps = [
          { title: '直径单位换算', formula: 'd_m=d_mm/1000', substitution: c.mean.d + '/1000', result: c.mean.d / 1000 },
          { title: 'L 的单次测量不确定度', formula: '单次测量无法估计 A 类，取 u_A(L)=0；u_C(L)=u_B(L)=ΔL/√3',
            substitution: 'u_A=0，u_B=' + details.uncertainties['mean.L'], result: details.uncertainties['mean.L'] },
          { title: '修正状态', formula: '关闭的修正因子为 1，对应 D/H 不参与传递；开关本身 u=0',
            substitution: 'wallCorr=' + c.params.wallCorr + '，bottomCorr=' + c.params.bottomCorr, result: 'F壁=' + f.wall + '，F底=' + f.bottom }
        ];
        if (c.params.wallCorr) steps.push({ title: '管壁修正因子', formula: 'F壁=1+2.4d_m/D', substitution: '1+2.4×' + c.mean.d / 1000 + '/' + c.params.D, result: f.wall });
        if (c.params.bottomCorr) steps.push({ title: '管底修正因子', formula: 'F底=1+3.3d_m/(2H)', substitution: '1+3.3×' + c.mean.d / 1000 + '/(2×' + c.params.H + ')', result: f.bottom });
        return steps;
      }
    },
    accepted: { value: 0.986, unit: 'Pa·s', note: '模拟数据所用的名义参考值（蓖麻油粘度随温度变化很大）：20 °C 时约 0.986 Pa·s' },
    errorSources: ['液体温度变化', '小球未达到匀速便开始计时', '计时及直径读数误差', '未启用修正时管壁和管底效应使结果偏大'],
    suggestions: ['记录并稳定液体温度', '确认小球在两标记线间匀速下落', '检查量筒内径与液柱高度后选择相应修正'],
    sampleCsv: "# 模拟数据（非真实测量）| 模板 viscosity_falling_ball | 固定种子 20261113（mulberry32）| 生成真值 η=0.986 Pa·s, ρ=7800 kg/m³, ρ₀=960 kg/m³, g=9.80 m/s², d=2 mm, L=0.100 m, D=0.040 m, H=0.250 m | 时间含管壁和管底效应：t=18Lη(1+2.4d/D)(1+3.3d/(2H))/((ρ−ρ₀)gd²)；独立均匀噪声 t±0.03 s、d±0.002 mm；第 6 行时间人为加 1.5 s\nt,d,L\n7.5292,1.9991,0.100\n7.5181,2.0018,\n7.4916,2.0012,\n7.4824,2.0011,\n7.5242,1.9987,\n9.0124,1.9982,\n7.5290,1.9992,\n7.5182,1.9986,\n7.5378,1.9992,\n7.5089,1.9996,\n7.4865,2.0007,\n7.5334,1.9998,\n",
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
