// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'hall_effect', name: '霍尔效应（测霍尔元件灵敏度）', category: '电磁学',
  summary: '恒定磁场下改变工作电流测霍尔电压，U_H–I 拟合求 K_H。', method: 'linear_fit',
  inputs: [
    { key: 'I', label: '工作电流', unit: 'mA', instrumentError: 0, kind: 'column_x' },
    { key: 'UH', label: '霍尔电压（四次换向平均）', unit: 'mV', instrumentError: 0.05, kind: 'column_y' }
  ],
  params: [{ key: 'B', label: '磁感应强度', unit: 'T', default: 0.100, uncertainty: 0.0005 }],
  transform: { x: (row) => row.I, y: (row) => row.UH, xLabel: 'I / mA', yLabel: 'U_H / mV' },
  result: {
    key: 'KH', label: '霍尔灵敏度', unit: 'mV/(mA·T)',
    formulaTex: 'U_H=K_H I B\\Rightarrow K_H=\\frac{k}{B}',
    compute: (c) => c.fit.slope / c.params.B,
    uncertaintyInputs: ['fit.slope', 'params.B']
  },
  accepted: { value: 150, unit: 'mV/(mA·T)', note: '元件标称值（模拟实验设定）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 hall_effect | 生成真值 150.0 | 噪声: UH±0.05 mV; B=0.100 T\nI,UH\n1.0,14.98\n2.0,29.96\n3.0,45.1\n4.0,59.92\n5.0,74.9\n6.0,90.07\n7.0,105.0\n8.0,120.0\n9.0,134.95\n10.0,150.01\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
