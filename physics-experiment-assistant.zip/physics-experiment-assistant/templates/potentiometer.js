// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'potentiometer', name: '电位差计测电动势（十一线板式）', category: '电磁学',
  summary: '用标准电池定标，比较补偿长度求待测电动势。', method: 'direct',
  inputs: [
    { key: 'Ls', label: '标准电池补偿长度', unit: 'm', instrumentError: 0.0005, kind: 'repeated' },
    { key: 'Lx', label: '待测电池补偿长度', unit: 'm', instrumentError: 0.0005, kind: 'repeated' }
  ],
  params: [{ key: 'Es', label: '标准电池电动势', unit: 'V', default: 1.01860, uncertainty: 0.00005 }],
  result: {
    key: 'Ex', label: '待测电动势', unit: 'V',
    formulaTex: 'E_x=E_s\\frac{L_x}{L_s}',
    compute: (c) => c.params.Es * c.mean.Lx / c.mean.Ls,
    uncertaintyInputs: ['mean.Ls', 'mean.Lx', 'params.Es']
  },
  accepted: { value: 1.500, unit: 'V', note: '新干电池电动势典型值（约1.5 V）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 potentiometer | 生成真值 1.5 | 工作电流使导线 0.2000 V/m; 噪声 ±0.8 mm\nLs,Lx\n5.0931,7.4994\n5.0927,7.5011\n5.092,7.4989\n5.0929,7.5004\n5.0929,7.4999\n5.0942,7.4979\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
