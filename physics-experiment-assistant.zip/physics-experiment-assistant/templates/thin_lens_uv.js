// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'thin_lens_uv', name: '薄透镜焦距（物距像距法）', category: '光学',
  summary: '测多组物距 u、像距 v，1/v–1/u 线性拟合，截距的倒数为焦距。', method: 'linear_fit',
  inputs: [
    { key: 'u', label: '物距', unit: 'cm', instrumentError: 0, kind: 'column_x' },
    { key: 'v', label: '像距', unit: 'cm', instrumentError: 0.05, kind: 'column_y' }
  ],
  params: [],
  transform: { x: (row) => 1 / row.u, y: (row) => 1 / row.v, xLabel: '1/u / cm⁻¹', yLabel: '1/v / cm⁻¹' },
  result: {
    key: 'f', label: '焦距', unit: 'cm',
    formulaTex: '\\frac{1}{u}+\\frac{1}{v}=\\frac{1}{f}\\Rightarrow \\frac{1}{v}=-\\frac{1}{u}+\\frac{1}{f},\\ f=\\frac{1}{b}',
    compute: (c) => 1 / c.fit.intercept,
    uncertaintyInputs: ['fit.intercept']
  },
  accepted: { value: 15.0, unit: 'cm', note: '透镜标称焦距 15.0 cm' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 thin_lens_uv | 生成真值 15.0 | 噪声: v±0.10 cm（成像清晰位置判断）\nu,v\n20.0,60.04\n22.0,46.91\n25.0,37.42\n28.0,32.16\n32.0,28.08\n36.0,25.72\n40.0,23.92\n45.0,22.52\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
