// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'sound_speed', name: '声速测量（驻波共振法·逐差法）', category: '力学',
  summary: '记录相邻接收极大位置（间隔 λ/2），逐差求波长，v=fλ。', method: 'successive_diff',
  inputs: [
    { key: 'i', label: '极大值序号', unit: '1', instrumentError: 0, kind: 'column_x' },
    { key: 'x', label: '接收器位置', unit: 'mm', instrumentError: 0.01, kind: 'column_y' }
  ],
  params: [{ key: 'f', label: '信号频率', unit: 'Hz', default: 35000, uncertainty: 1 }],
  result: {
    key: 'v', label: '声速', unit: 'm/s',
    formulaTex: 'v=f\\lambda,\\quad \\lambda=\\frac{2\\Delta x}{\\Delta i}',
    compute: (c) => c.params.f * (2 * c.diff.x / c.diff.i) / 1000,
    uncertaintyInputs: ['diff.x', 'params.f']
  },
  accepted: { value: 346.3, unit: 'm/s', note: '25 °C 干燥空气理论值 v=331.45·√(1+t/273.15)' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 sound_speed | 生成真值 346.28591544910125 | 25 °C; 噪声: x±0.03 mm; f=35000 Hz\ni,x\n1.0,59.99\n2.0,64.96\n3.0,69.9\n4.0,74.86\n5.0,79.77\n6.0,84.77\n7.0,89.71\n8.0,94.62\n9.0,99.53\n10.0,104.52\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
