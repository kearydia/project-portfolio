// 静电场模拟描绘：沿用通用拟合模板接口，调用码道生成的计算核心。
(function () {
  'use strict';
  const tpl = {
    id: 'electrostatic_field', name: '静电场模拟描绘（同轴圆柱电极，U–ln r 图线法）', category: '电磁学',
    summary: '用稳恒电流场模拟静电场，拟合 U–ln r 图线，由斜率求实测 ln(Rb/Ra)。',
    keywords: ['静电场', '同轴圆柱电极', '等位线', '电位'], method: 'linear_fit',
    inputs: [
      { key: 'r', label: '等位点半径', unit: 'mm', kind: 'column_x', instrumentError: 0 },
      { key: 'U', label: '电位', unit: 'V', kind: 'column_y', instrumentError: 0.005 }
    ],
    params: [
      { key: 'Ua', label: '内电极电位（假设值，实际使用改为仪器标称值）', unit: 'V', default: 5.00, instrumentError: 0.01 },
      { key: 'Ra', label: '内电极半径（假设值，实际使用改为仪器标称值）', unit: 'mm', default: 10.0, uncertainty: 0.1 },
      { key: 'Rb', label: '外电极半径（假设值，实际使用改为仪器标称值）', unit: 'mm', default: 50.0, uncertainty: 0.1 }
    ],
    transform: {
      x: (row) => Math.log(row.r / 1000), y: (row) => row.U,
      xLabel: 'ln(r/m)', yLabel: 'U / V', slopeUnit: 'V', interceptUnit: 'V'
    },
    result: {
      key: 'lnRatio', label: '实测 ln(Rb/Ra)', unit: '',
      formulaTex: 'U=Ua·ln(Rb/r)/ln(Rb/Ra) ⇒ ln(Rb/Ra)=-Ua/b',
      compute: (c) => -c.params.Ua / c.fit.slope,
      uncertaintyInputs: ['fit.slope', 'params.Ua'],
      core: ({ rows, params, pu, deltas }) => {
        const core = typeof module === 'object' && module.exports
          ? require('../src/electrostatic_codearts.js') : globalThis.ElectrostaticCore;
        const uUa = pu && pu.Ua !== undefined ? pu.Ua : 0.01 / Math.sqrt(3);
        const prof = core.analyzeProfile({
          radiiMm: rows.map(x => x.r), potentialsV: rows.map(x => x.U),
          Ua: params.Ua, Ra: params.Ra, Rb: params.Rb,
          instrumentErrorU: deltas.U,
          instrumentErrorUa: uUa * Math.sqrt(3)
        });
        const b = prof.fit.slope, Ua = params.Ua;
        // 引擎会补入斜率 B 类分量，这里只传递斜率 A 类和电源电位的不确定度。
        const uOnlyA = Math.hypot((Ua / (b * b)) * prof.slopeUncertainty.uA, (-1 / b) * uUa);
        return { value: prof.lnRatio.value, uncertainty: uOnlyA, steps: prof.lnRatio.steps };
      }
    },
    accepted: { value: Math.log(5), unit: '', note: '按假设仪器参数 Ra=10.0 mm、Rb=50.0 mm 计算，不是普适常数' },
    errorSources: ['导电介质不均匀与接触电阻', '探针定位误差', '电极偏心', '电源电压不稳定'],
    suggestions: ['多次改变探针位置测量并取平均', '检查电极同心与接触情况', '保持电压稳定', '记录介质状态并核对仪器标称参数'],
    sampleCsv: "# 模拟数据（非真实测量）| 模板 electrostatic_field | 固定种子 20261117（mulberry32）| 全部真值 Ua=5.00 V, Ra=10 mm, Rb=50 mm；U=Ua·ln(Rb/r)/ln(Rb/Ra) | 电位加独立均匀噪声 ±0.010 V；第 6 行 U 人为加 0.10 V；保留 6 位小数\nr,U\n12,4.441107\n16,3.531584\n20,2.856574\n24,2.270334\n28,1.795232\n32,1.479581\n36,1.023719\n40,0.695776\n44,0.390096\n",
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
