// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'linear_expansion', name: '金属线胀系数', category: '热学',
  summary: '逐点升温读伸长量，ΔL–T 线性拟合求线胀系数。', method: 'linear_fit',
  inputs: [
    { key: 'T', label: '温度', unit: '°C', instrumentError: 0, kind: 'column_x' },
    { key: 'dL', label: '伸长量读数', unit: 'mm', instrumentError: 0.005, kind: 'column_y' },
    { key: 'L0', label: '室温原长', unit: 'mm', instrumentError: 0.5, kind: 'single' }
  ],
  params: [],
  transform: { x: (row) => row.T, y: (row) => row.dL, xLabel: 'T / °C', yLabel: 'ΔL / mm' },
  result: {
    key: 'alpha', label: '线胀系数 α', unit: '1/°C',
    formulaTex: '\\alpha=\\frac{1}{L_0}\\frac{\\mathrm{d}(\\Delta L)}{\\mathrm{d}T}=\\frac{k}{L_0}',
    compute: (c) => c.fit.slope / c.mean.L0,
    uncertaintyInputs: ['fit.slope', 'mean.L0']
  },
  accepted: { value: 1.7e-5, unit: '1/°C', note: '铜的典型值（约1.7×10⁻⁵ /°C）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 linear_expansion | 生成真值 1.7e-05 | 噪声: dL±0.002 mm; L0=500.0 mm\nT,dL,L0\n30.0,-0.0,500.0\n35.0,0.043,\n40.0,0.082,\n45.0,0.129,\n50.0,0.169,\n55.0,0.214,\n60.0,0.255,\n65.0,0.299,\n70.0,0.341,\n75.0,0.383,\n80.0,0.427,\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
