// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'string_vibration', name: '弦振动（驻波法测线密度）', category: '力学',
  summary: '固定张力与弦长，测不同波腹数的共振频率，f–n 拟合求线密度。', method: 'linear_fit',
  inputs: [
    { key: 'n', label: '波腹数', unit: '1', instrumentError: 0, kind: 'column_x' },
    { key: 'f', label: '共振频率', unit: 'Hz', instrumentError: 0.1, kind: 'column_y' },
    { key: 'L', label: '弦长', unit: 'm', instrumentError: 0.0005, kind: 'single' }
  ],
  params: [
    { key: 'M', label: '砝码质量', unit: 'kg', default: 1.000, uncertainty: 0.001 },
    { key: 'g', label: '重力加速度', unit: 'm/s²', default: 9.80, uncertainty: 0.005, note: '取 9.80 m/s²，u(g)=0.005 m/s² 为假设值（覆盖与西安当地 g≈9.797 的差异）' }
  ],
  transform: { x: (row) => row.n, y: (row) => row.f, xLabel: 'n', yLabel: 'f / Hz' },
  result: {
    key: 'rho', label: '线密度', unit: 'kg/m',
    formulaTex: 'f=\\frac{n}{2L}\\sqrt{\\frac{T}{\\rho}}\\Rightarrow\\rho=\\frac{Mg}{(2Lk)^2}',
    compute: (c) => c.params.M * c.params.g / (2 * c.mean.L * c.fit.slope) ** 2,
    uncertaintyInputs: ['fit.slope', 'mean.L', 'params.M', 'params.g']
  },
  accepted: { value: 5.00e-4, unit: 'kg/m', note: '称量法标称线密度（模拟实验设定）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 string_vibration | 生成真值 0.0005 | 噪声: f±0.2 Hz; M=1.000 kg L=0.700 m\nn,f,L\n1.0,99.9,0.7\n2.0,200.0,\n3.0,300.1,\n4.0,399.8,\n5.0,499.5,\n6.0,600.0,\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
