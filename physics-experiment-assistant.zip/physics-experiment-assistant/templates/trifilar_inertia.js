// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'trifilar_inertia', name: '刚体转动惯量（三线摆）', category: '力学',
  summary: '测三线摆下盘扭转周期，求圆盘对中心轴的转动惯量。', method: 'direct',
  inputs: [
    { key: 'T', label: '摆动周期', unit: 's', instrumentError: 0.001, kind: 'repeated' },
    { key: 'R', label: '下盘悬点到中心距离', unit: 'm', instrumentError: 0.00002, kind: 'single' },
    { key: 'r', label: '上盘悬点到中心距离', unit: 'm', instrumentError: 0.00002, kind: 'single' },
    { key: 'H', label: '上下盘间垂直距离', unit: 'm', instrumentError: 0.0005, kind: 'single' }
  ],
  params: [
    { key: 'm0', label: '下圆盘质量', unit: 'kg', default: 0.500, uncertainty: 0.0005 },
    { key: 'g', label: '重力加速度', unit: 'm/s²', default: 9.80, uncertainty: 0 },
    { key: 'Rd', label: '下圆盘几何半径', unit: 'm', default: 0.0800, uncertainty: 0.00002 }
  ],
  result: {
    key: 'I0', label: '转动惯量', unit: 'kg·m²',
    formulaTex: 'I_0=\\frac{m_0 g R r}{4\\pi^2 H}T_0^2',
    compute: (c) => c.params.m0 * c.params.g * c.mean.R * c.mean.r * c.mean.T ** 2 / (4 * Math.PI ** 2 * c.mean.H),
    uncertaintyInputs: ['mean.T', 'mean.R', 'mean.r', 'mean.H', 'params.m0']
  },
  accepted: { value: 0.0016, unit: 'kg·m²', note: '理论值 I=½·m0·Rd²（m0=0.500 kg, Rd=0.0800 m）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 trifilar_inertia | 生成真值 0.0016 | 噪声: T±0.002 s\nT,R,r,H\n1.6924,0.075,0.03,0.5\n1.6895,,,\n1.6877,,,\n1.6924,,,\n1.6961,,,\n1.6919,,,\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
