// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'surface_tension', name: '液体表面张力系数（拉脱法）', category: '力学',
  summary: '力敏传感器测吊环拉脱液膜前后读数差，求表面张力系数。', method: 'direct',
  inputs: [
    { key: 'U1', label: '液膜拉断前瞬间读数', unit: 'mV', instrumentError: 0.1, kind: 'repeated' },
    { key: 'U2', label: '拉断后读数', unit: 'mV', instrumentError: 0.1, kind: 'repeated' },
    { key: 'D1', label: '吊环内径', unit: 'm', instrumentError: 0.00002, kind: 'single' },
    { key: 'D2', label: '吊环外径', unit: 'm', instrumentError: 0.00002, kind: 'single' }
  ],
  params: [{ key: 'K', label: '力敏传感器灵敏度', unit: 'mV/N', default: 3000, uncertainty: 3 }],
  result: {
    key: 'sigma', label: '表面张力系数 σ', unit: 'N/m',
    formulaTex: '\\sigma=\\frac{U_1-U_2}{K\\pi(D_1+D_2)}',
    compute: (c) => (c.mean.U1 - c.mean.U2) / (c.params.K * Math.PI * (c.mean.D1 + c.mean.D2)),
    uncertaintyInputs: ['mean.U1', 'mean.U2', 'mean.D1', 'mean.D2', 'params.K']
  },
  accepted: { value: 0.0720, unit: 'N/m', note: '25 °C 纯水典型值（约0.072 N/m）' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 surface_tension | 生成真值 0.072 | 噪声: U±0.3 mV; U2 基线约 12 mV\nU1,U2,D1,D2\n58.59,11.98,0.0331,0.035\n58.28,11.91,,\n58.11,11.82,,\n59.02,11.72,,\n58.08,12.53,,\n57.92,12.02,,\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
