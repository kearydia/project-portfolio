// 纵向磁场聚焦法：电流平方对加速电压拟合，全部采用 SI 单位。
(function () {
  const mu0 = 4 * Math.PI * 1e-7;
  const tpl = {
    id: 'em_ratio_focusing', name: '电子荷质比（纵向磁场聚焦法）', category: '近代物理',
    summary: '电子束在螺线管纵向磁场中做螺旋运动，拟合 I²–U 求电子荷质比。',
    keywords: ['电子', '荷质比', '螺旋线法', '螺线管', '聚焦'], method: 'linear_fit',
    inputs: [
      { key: 'U', label: '加速电压 U', unit: 'V', instrumentError: 0, kind: 'column_x' },
      { key: 'I', label: '第 n 次聚焦时的励磁电流 I', unit: 'A', instrumentError: 0.01, kind: 'column_y' }
    ],
    params: [
      { key: 'N', label: '螺线管匝数 N（假设值）', unit: '', default: 526, uncertainty: 0 },
      { key: 'L', label: '螺线管长度 L（假设值，u=0.001 m）', unit: 'm', default: 0.234, uncertainty: 0.001 },
      { key: 'D', label: '螺线管直径 D（假设值，u=0.0005 m）', unit: 'm', default: 0.090, uncertainty: 0.0005 },
      { key: 'l', label: '电子束交叉点到荧光屏距离 l（假设值，u=0.001 m）', unit: 'm', default: 0.145, uncertainty: 0.001 },
      { key: 'n', label: '聚焦次数 n', unit: '', default: 1, uncertainty: 0,
        note: '表中电流是第几次聚焦时读的就填几，一般为 1、2 或 3' }
    ],
    transform: { x: 'U', y: r => r.I * r.I, xLabel: '加速电压 U (V)', yLabel: '励磁电流平方 I² (A²)', slopeUnit: 'A²/V', interceptUnit: 'A²' },
    result: {
      key: 'e/m', label: '电子荷质比 e/m', unit: 'C/kg',
      formulaTex: 'e/m=8π²n²(L²+D²)/(μ₀²N²l²k)，k 为 I²–U 拟合斜率',
      compute: c => {
        const { N, L, D, l, n } = c.params, k = c.fit.slope;
        if (!Number.isFinite(k) || k <= 0) throw new Error('电流平方–电压拟合斜率 k 必须为正的有限数');
        if (![N, L, D, l].every(v => Number.isFinite(v) && v > 0))
          throw new Error('螺线管匝数 N、长度 L、直径 D 和交叉点到屏距离 l 必须为正的有限数');
        if (!Number.isInteger(n) || n <= 0) throw new Error('聚焦次数 n 必须为正整数');
        return 8 * Math.PI ** 2 * n ** 2 * (L ** 2 + D ** 2) / (mu0 ** 2 * N ** 2 * l ** 2 * k);
      },
      uncertaintyInputs: ['fit.slope', 'params.L', 'params.D', 'params.l'],
      steps: c => {
        const { N, L, D, l, n } = c.params, length = Math.hypot(L, D), factor = mu0 * N / length;
        return [
          { title: '常数与仪器参数约定', formula: 'μ₀=4π×10⁻⁷ N/A² 为本模板采用的定义值，不计不确定度；N、n 不计不确定度；N、L、D、l 是假设的仪器参数，实际使用时应改成所用仪器的标称值',
            substitution: 'N=' + N + '，n=' + n + '，L=' + L + ' m，D=' + D + ' m，l=' + l + ' m', result: 'μ₀=4π×10⁻⁷ N/A²；只传递斜率 k 和 L、D、l 的不确定度' },
          { title: '有限长螺线管的几何长度', formula: 's=√(L²+D²)', substitution: '√(' + L + '²+' + D + '²)', result: length + ' m' },
          { title: '磁场与励磁电流的关系', formula: 'B=μ₀NI/√(L²+D²)；采用有限长螺线管中心磁场近似',
            substitution: 'B/I=4π×10⁻⁷×' + N + '/' + length, result: 'B/I=' + factor + ' T/A' },
          { title: '第 n 次聚焦条件', formula: 'h=2πmv/(eB)，l=n·h；e/m=8π²n²U/(B²l²)',
            substitution: 'h=l/n=' + l + '/' + n, result: 'h=' + l / n + ' m' },
          { title: '拟合斜率代入荷质比', formula: 'I²=a+kU；e/m=8π²n²(L²+D²)/(μ₀²N²l²k)',
            substitution: '8×π²×' + n + '²×(' + L + '²+' + D + '²)/((4π×10⁻⁷)²×' + N + '²×' + l + '²×' + c.fit.slope + ')',
            result: tpl.result.compute(c) + ' C/kg' }
        ];
      }
    },
    accepted: { value: 1.75882e11, unit: 'C/kg', note: 'CODATA 2018 推荐值 1.75882001076×10¹¹ C/kg' },
    errorSources: ['地磁场和杂散磁场影响电子束运动', '聚焦判断有主观性', '螺线管中心磁场公式只是近似，交叉点到屏的磁场不完全均匀', '电压表和电流表的读数误差'],
    suggestions: ['远离磁性物体和杂散磁场源', '反复调节并记录最清晰的聚焦位置', '用所用仪器的 N、L、D、l 标称值替换模板里的假设值', '稳定加速电压，核对电压表和电流表读数', '可分别记录正、反向励磁电流取平均以减小地磁场影响（本模板未单列此项，见 README）'],
    sampleCsv: "# 模拟数据（非真实测量）| 模板 em_ratio_focusing | 固定种子 20261115（mulberry32）| 全部真值 e/m=1.75882001076e11 C/kg, N=526, L=0.234 m, D=0.090 m, l=0.145 m, n=1, μ₀=4π×10⁻⁷ N/A² | U=700,750,…,1100 V（9 点）；I 由聚焦公式反算，加独立均匀噪声 ±0.004 A，保留 3 位小数；第 5 行电流人为加 0.06 A\nU,I\n700,1.465\n750,1.520\n800,1.564\n850,1.613\n900,1.721\n950,1.706\n1000,1.757\n1050,1.800\n1100,1.840\n",
    verified: true
  };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
