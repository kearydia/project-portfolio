// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'prism_min_deviation', name: '分光计测三棱镜折射率（最小偏向角法）', category: '光学',
  summary: '测三棱镜顶角与最小偏向角，求玻璃折射率。', method: 'direct',
  inputs: [
    { key: 'A', label: '三棱镜顶角', unit: '°', instrumentError: 0.0167, kind: 'repeated' },
    { key: 'delta', label: '最小偏向角', unit: '°', instrumentError: 0.0167, kind: 'repeated' }
  ],
  params: [],
  result: {
    key: 'n', label: '折射率', unit: '1',
    formulaTex: 'n=\\frac{\\sin\\frac{A+\\delta_{\\min}}{2}}{\\sin\\frac{A}{2}}',
    compute: (c) => Math.sin((c.mean.A + c.mean.delta) / 2 * Math.PI / 180) / Math.sin(c.mean.A / 2 * Math.PI / 180),
    uncertaintyInputs: ['mean.A', 'mean.delta']
  },
  accepted: { value: 1.5163, unit: '1', note: 'K9 玻璃对钠黄光 n_D 典型值' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 prism_min_deviation | 生成真值 1.5163 | 噪声: A,δ ±0.01°\nA,delta\n59.9908,38.6068\n59.9911,38.6156\n60.0014,38.5864\n60.0011,38.5996\n59.9957,38.6117\n59.9927,38.6126\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
