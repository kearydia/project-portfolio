// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'grating', name: '光栅衍射测波长', category: '光学',
  summary: '分光计测一级衍射角，由光栅方程求谱线波长。', method: 'direct',
  inputs: [{ key: 'theta', label: '一级衍射角', unit: '°', instrumentError: 0.0167, kind: 'repeated' }],
  params: [
    { key: 'dg', label: '光栅常数', unit: 'mm', default: 0.00333333, uncertainty: 0 },
    { key: 'k', label: '衍射级次', unit: '1', default: 1, uncertainty: 0 }
  ],
  result: {
    key: 'lambda', label: '波长', unit: 'nm',
    formulaTex: 'd\\sin\\theta=k\\lambda\\Rightarrow\\lambda=\\frac{d\\sin\\theta}{k}',
    compute: (c) => c.params.dg * Math.sin(c.mean.theta * Math.PI / 180) / c.params.k * 1e6,
    uncertaintyInputs: ['mean.theta']
  },
  accepted: { value: 546.07, unit: 'nm', note: '汞灯绿线公认值' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 grating | 生成真值 546.07 | 噪声: θ±0.01°; d=1/300 mm\ntheta\n9.4297\n9.435\n9.4316\n9.433\n9.4216\n9.4244\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
