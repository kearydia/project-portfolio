// 来自模板库 templates_work（已验证）；接入时仅包裹为 IIFE，避免多个 <script> 共享全局作用域时 const tpl 重复声明。
(function () {
const tpl = {
  id: 'wheatstone_bridge', name: '惠斯通电桥（交换法）', category: '电磁学',
  summary: '交换被测电阻与比较臂位置各平衡一次，消除比例臂误差。', method: 'direct',
  inputs: [
    { key: 'Rs', label: '比较臂读数', unit: 'Ω', instrumentError: 0.2, kind: 'repeated' },
    { key: 'Rs2', label: '交换后比较臂读数', unit: 'Ω', instrumentError: 0.2, kind: 'repeated' }
  ],
  params: [],
  result: {
    key: 'Rx', label: '被测电阻', unit: 'Ω',
    formulaTex: 'R_x=\\sqrt{R_s R_s\'}',
    compute: (c) => Math.sqrt(c.mean.Rs * c.mean.Rs2),
    uncertaintyInputs: ['mean.Rs', 'mean.Rs2']
  },
  accepted: { value: 1000, unit: 'Ω', note: '被测电阻标称值 1000 Ω' },
  sampleCsv: "# 模拟数据（非真实测量）| 模板 wheatstone_bridge | 生成真值 1000.0 | 比例臂 R1/R2=1.01（故意不等，交换法消除）; 噪声 ±0.3 Ω\nRs,Rs2\n989.5,1009.6\n990.3,1010.2\n990.0,1009.9\n989.7,1009.9\n989.8,1010.0\n", verified: true
};
(globalThis.EXP_TEMPLATES ||= []).push(tpl);
if (typeof module !== "undefined") module.exports = tpl;
})();
