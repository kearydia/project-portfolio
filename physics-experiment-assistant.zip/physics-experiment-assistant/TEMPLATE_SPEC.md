# 实验模板接口（TEMPLATE_SPEC）

每个实验是 `templates/<id>.js` 中的一个普通 JS 文件，浏览器下通过 `<script>` 加载，Node 下可 `require`：

```js
(function () {
  const tpl = { /* 字段见下 */ };
  (globalThis.EXP_TEMPLATES ||= []).push(tpl);
  if (typeof module === 'object' && module.exports) module.exports = tpl;
})();
```

| 字段 | 说明 |
|---|---|
| id | 唯一 id，与文件名一致 |
| name / summary | 名称、一句话简介（用于搜索） |
| category | `力学` `热学` `电磁学` `光学` `近代物理` 之一 |
| keywords | 可选，搜索关键词数组 |
| method | `direct`（多次直接测量）、`linear_fit`（一元线性最小二乘，可配线性化变换）、`successive_diff`（逐差法）、`formula`（同 direct） |
| inputs | 数据表列：`{key,label,unit,instrumentError(Δ仪,同单位),kind:'repeated'|'single'|'column_x'|'column_y',aliases?}`。CSV 表头按 key/label/aliases 匹配（可带括号单位，如 `L(m)`） |
| params | 参数面板：`{key,label,unit,default,instrumentError?,uncertainty?}`。给 `uncertainty` 视为标准不确定度；否则 u=instrumentError/√3 |
| transform | linear_fit / successive_diff 必填：`{x,y,xLabel,yLabel,slopeUnit,interceptUnit,yUnit?,yInstrumentError?}`；x/y 可为列名字符串或 `(row, params) => number`（线性化变换，如 y=T²） |
| result | `{key,label,unit,formulaTex,compute(ctx),uncertaintyInputs,core?}`。`ctx={mean:{key:均值},fit:{slope,intercept,r},diff:{slope,meanDelta,k,dx},params:{key:值},n}`；`uncertaintyInputs` 是 ctx 路径列表（如 `'fit.slope'`、`'mean.T'`、`'params.L'`），引擎用数值偏导按“输入互不相关”传递，并在步骤中列出每个偏导项。可选 `core(ctx2)` 返回 `{value,uncertainty,steps}`，用作权威结果（如调用码道核心），引擎会与通用结果交叉校验 |
| accepted | `{value,unit,note}` 公认值与出处说明 |
| errorSources / suggestions | 规则生成的“误差解释”使用的文字 |
| sampleCsv | `sample_data/<id>_模拟数据.csv` |
| verified | `true` 才可选用；否则界面显示为灰色「待验证」 |

## 新增模板的步骤
1. 把已验证的模板文件复制到 `templates/`（例如来自 `templates_work/`），示例 CSV 复制到 `sample_data/`。
2. 在 `index.html` 中标记 `<!-- 模板列表 -->` 的位置加一行 `<script src="templates/<id>.js"></script>`。
3. 运行 `node tools/gen_sample_data.js`（仅当需要重新生成内嵌示例）并 `node --test tests/`。`tests/engine.test.js` 会自动校验 templates/ 下每个模板的接口，并对 verified 模板检查示例数据结果与公认值的偏差。


## v1.1 补充：拟合不确定度

linear_fit 的 `fit.slope`、`fit.intercept` 不确定度为 A 类与 B 类合成。B 类由 column_y 的 instrumentError 得到 u_B(y)=Δ/√3，引擎对 transform.y 数值求导换算到 y′（各点取方均根），u_B(b)=u_B(y′)/√Sxx，u_B(a)=u_B(y′)·√(1/n+x̄²/Sxx)。column_x 的 instrumentError 不计入。结果项中分别给出 `fit.uAslope`、`fit.uBslope`、`fit.uslope`。模板若提供 `result.core`，引擎在核心函数的不确定度上再合成 |∂f/∂b|·u_B(b)。

参数 `uncertainty` 大于 0 且列在 `uncertaintyInputs`（如 `'params.g'`）时参与传递。

## v1.3 补充：开关参数与条件参数

参数可声明为开关：

```js
{ key: 'wallCorr', label: '管壁修正', type: 'switch', default: 0,
  note: 'η 除以 (1 + 2.4 d/D)，只有勾选后才改变结果。' }
{ key: 'D', label: '量筒内径', unit: 'm', default: 0.040,
  instrumentError: 0.001, enabledBy: 'wallCorr' }
```

- `type:'switch'` 在 UI 中渲染为复选框，并显示 `note`；默认值为 0 或 1。数值、字符串 `'0'/'1'` 和布尔值统一转为数值 0/1，其他值报错。开关的标准不确定度始终为 0，即使被列入 `uncertaintyInputs` 也不参与传递。
- 普通数值参数可用 `enabledBy` 指向同模板的开关 key。开关关闭时不读取该参数的覆盖值或仪器误差，计算上下文保留其默认值、不确定度置零，并从结果传递项中移除；模板公式也必须按开关跳过该项。开启时按原有参数规则读取并传递。无此字段的既有模板保持原行为。
- 结果可提供 `result.steps(ctx, details)`，返回额外步骤数组 `{title, formula, substitution, result}`；`details.uncertainties` 提供按 ctx 路径索引的标准不确定度。引擎将这些步骤插入结果推导中，随后逐项列出数值偏导和合成式。落球法用它说明单次 L 的 A/B/合成关系与启用的修正因子。
- `sampleCsv` 也可直接保存以注释开头的完整 CSV 文本（现有模板库与落球法均如此），无需加入 `sample_data/samples.js`。落球法使用 `tools/gen_viscosity_data.js` 保持 CSV 文件与内嵌文本一致。
