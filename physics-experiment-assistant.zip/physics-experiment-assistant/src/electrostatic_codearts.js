// 华为云码道 CodeArts 生成，原始产出见 过程证据/04_码道CodeArts对话/对话4_静电场模拟描绘/码道原始产出/electrostatic_core.js
'use strict';

/**
 * electrostatic_core.js
 * 「大学物理实验数据处理助手」—— 静电场模拟描绘（同轴圆柱电极）计算核心
 *
 * 物理模型
 *   稳恒电流场模拟静电场，同轴圆柱电极：内半径 Ra、外半径 Rb，
 *   内电极电位 Ua、外电极接地。半径 r 处电位理论值：
 *       U(r) = Ua · ln(Rb / r) / ln(Rb / Ra)
 *   对 ln r 线性化：U = a + b · ln r，
 *   理论斜率 b0 = -Ua / ln(Rb / Ra)，
 *   实测 ln(Rb/Ra) = -Ua / b。
 *
 * 约定
 *   - r 单位 mm（设定值，不计误差），换算成 m 后取自然对数作为 x；
 *   - U 单位 V，数字电压表 Δ仪 = 0.005 V，B 类 u_B(U) = Δ仪 / √3；
 *   - 一元线性最小二乘 y = a + b·x，自由度 n - 2。
 *
 * 运行环境
 *   - 浏览器：挂载到全局 globalThis.ElectrostaticCore；
 *   - Node.js：通过 module.exports 导出。
 *   - 无任何第三方依赖。
 */

const CONSTANTS = Object.freeze({
  /** 数字电压表仪器误差限 Δ仪 / V */
  DEFAULT_INSTRUMENT_ERROR_U: 0.005,
  /** 内电极电位仪器误差限 Δ仪 / V */
  DEFAULT_INSTRUMENT_ERROR_UA: 0.01,
  /** 格拉布斯检验显著性水平 */
  DEFAULT_ALPHA: 0.05,
  /** 标称值 ln(Rb/Ra) = ln(50/10) */
  NOMINAL_LN_RATIO: Math.log(50 / 10),
  /** 线性拟合最小样本量（保证自由度 n-2 ≥ 1） */
  MIN_SAMPLE_SIZE: 3,
  /** 格拉布斯临界值表覆盖的最大样本量 */
  MAX_GRUBBS_SAMPLE_SIZE: 20,
  /** 残差标准差近似为 0 的判定阈值（格拉布斯统计量分母保护） */
  RESIDUAL_STD_EPSILON: 1e-12,
  /**
   * 格拉布斯临界值表 G(α=0.05, n)，n = 3 ~ 20（双侧检验常用教材表值）
   */
  GRUBBS_CRITICAL_ALPHA_005: Object.freeze({
    3: 1.153,
    4: 1.463,
    5: 1.672,
    6: 1.822,
    7: 1.938,
    8: 2.032,
    9: 2.11,
    10: 2.176,
    11: 2.234,
    12: 2.285,
    13: 2.331,
    14: 2.371,
    15: 2.409,
    16: 2.443,
    17: 2.475,
    18: 2.504,
    19: 2.532,
    20: 2.557
  })
});

/* ------------------------------------------------------------------ *
 * 输入校验与格式化工具
 * ------------------------------------------------------------------ */

function assertFiniteNumber(value, name) {
  if (typeof value !== 'number') {
    throw new TypeError(`${name} 必须是数字类型，实际收到 ${typeof value}`);
  }
  if (!Number.isFinite(value)) {
    throw new RangeError(`${name} 必须是有限数值，实际收到 ${String(value)}`);
  }
}

function assertNumericArray(value, name) {
  if (!Array.isArray(value)) {
    throw new TypeError(`${name} 必须是数组，实际收到 ${typeof value}`);
  }
  value.forEach((item, index) => assertFiniteNumber(item, `${name}[${index}]`));
}

function assertPositive(value, name) {
  assertFiniteNumber(value, name);
  if (value <= 0) {
    throw new RangeError(`${name} 必须大于 0，实际收到 ${value}`);
  }
}

/** 将数值格式化为便于阅读的字符串（步骤展示用） */
function fmt(value, digits = 6) {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    return String(value);
  }
  const abs = Math.abs(value);
  if (abs !== 0 && (abs < 1e-4 || abs >= 1e6)) {
    return value.toExponential(Math.max(digits - 1, 1));
  }
  return value.toFixed(digits);
}

function makeStep(name, formula, substitution, result) {
  return { name, formula, substitution, result };
}

function withIndex(steps) {
  return steps.map((step, index) => ({ index: index + 1, ...step }));
}

/* ------------------------------------------------------------------ *
 * 1. 理论电位模型
 * ------------------------------------------------------------------ */

/**
 * 计算同轴圆柱电极间半径 r 处的理论电位。
 *
 * @param {{rMm:number, Ua:number, Ra:number, Rb:number}} options
 * @returns {{value:number, steps:Array}}
 */
function theoryPotential(options = {}) {
  const { rMm, Ua, Ra, Rb } = options;
  assertPositive(rMm, 'rMm');
  assertFiniteNumber(Ua, 'Ua');
  assertPositive(Ra, 'Ra');
  assertPositive(Rb, 'Rb');
  if (Rb <= Ra) {
    throw new RangeError(`外电极半径 Rb=${Rb} mm 必须大于内电极半径 Ra=${Ra} mm`);
  }
  if (rMm <= Ra || rMm >= Rb) {
    throw new RangeError(
      `测量点半径 r=${rMm} mm 必须位于内电极 Ra=${Ra} mm 与外电极 Rb=${Rb} mm 之间（开区间）`
    );
  }

  const ratioRbR = Rb / rMm;
  const ratioRbRa = Rb / Ra;
  const lnRbR = Math.log(ratioRbR);
  const lnRbRa = Math.log(ratioRbRa);
  const value = (Ua * lnRbR) / lnRbRa;

  return {
    value,
    steps: withIndex([
      makeStep(
        '半径比值',
        'Rb / r = ?,  Rb / Ra = ?',
        `Rb/r=${fmt(ratioRbR)}，Rb/Ra=${fmt(ratioRbRa)}`,
        { ratioRbR, ratioRbRa }
      ),
      makeStep(
        '取自然对数',
        'ln(Rb/r) = ?,  ln(Rb/Ra) = ?',
        `ln(${fmt(ratioRbR)})=${fmt(lnRbR)}，ln(${fmt(ratioRbRa)})=${fmt(lnRbRa)}`,
        { lnRbR, lnRbRa }
      ),
      makeStep(
        '理论电位',
        'U(r) = Ua · ln(Rb/r) / ln(Rb/Ra)',
        `U(${fmt(rMm, 2)} mm) = ${fmt(Ua, 2)} × ${fmt(lnRbR)} / ${fmt(lnRbRa)} = ${fmt(value)} V`,
        value
      )
    ])
  };
}

/* ------------------------------------------------------------------ *
 * 2. 数据变换：r(mm) -> r(m) -> x = ln r
 * ------------------------------------------------------------------ */

/**
 * 将半径数组（mm）换算为 x = ln(r / 1000)。
 *
 * @param {number[]} radiiMm
 * @returns {{x:number[], steps:Array}}
 */
function toLogRadiusSeries(radiiMm) {
  assertNumericArray(radiiMm, 'radiiMm');
  if (radiiMm.length < CONSTANTS.MIN_SAMPLE_SIZE) {
    throw new RangeError(
      `半径样本量 n=${radiiMm.length} 少于最小样本量 ${CONSTANTS.MIN_SAMPLE_SIZE}，无法完成一元线性拟合`
    );
  }

  const x = [];
  const steps = [];
  radiiMm.forEach((rMm, index) => {
    if (rMm <= 0) {
      throw new RangeError(`radiiMm[${index}]=${rMm} 必须大于 0（半径不能为非正数）`);
    }
    const rM = rMm / 1000;
    const xi = Math.log(rM);
    x.push(xi);
    steps.push(
      makeStep(
        `第 ${index + 1} 点半径对数化`,
        'r_m = r_mm / 1000;  x = ln(r_m)',
        `r_mm=${fmt(rMm, 3)} mm → r_m=${fmt(rM, 6)} m → x=${fmt(xi)}`,
        xi
      )
    );
  });

  return { x, steps: withIndex(steps) };
}

/* ------------------------------------------------------------------ *
 * 3. 一元线性最小二乘拟合
 * ------------------------------------------------------------------ */

/**
 * 一元线性最小二乘拟合 y = a + b·x。
 *
 * @param {number[]} xs
 * @param {number[]} ys
 * @returns {object} 含 slope(b)、intercept(a)、correlation(r)、残差与步骤
 */
function linearLeastSquares(xs, ys) {
  assertNumericArray(xs, 'xs');
  assertNumericArray(ys, 'ys');
  if (xs.length !== ys.length) {
    throw new RangeError(`xs 与 ys 长度必须一致，实际为 ${xs.length} 与 ${ys.length}`);
  }
  const n = xs.length;
  if (n < CONSTANTS.MIN_SAMPLE_SIZE) {
    throw new RangeError(
      `样本量 n=${n} 少于最小样本量 ${CONSTANTS.MIN_SAMPLE_SIZE}，自由度 n-2 不足`
    );
  }

  const xBar = xs.reduce((sum, value) => sum + value, 0) / n;
  const yBar = ys.reduce((sum, value) => sum + value, 0) / n;

  let sxx = 0;
  let syy = 0;
  let sxy = 0;
  for (let i = 0; i < n; i += 1) {
    const dx = xs[i] - xBar;
    const dy = ys[i] - yBar;
    sxx += dx * dx;
    syy += dy * dy;
    sxy += dx * dy;
  }

  if (sxx === 0) {
    throw new RangeError('所有自变量取值相同（Sxx=0），无法确定唯一的线性拟合斜率');
  }

  const slope = sxy / sxx;
  const intercept = yBar - slope * xBar;
  const residuals = xs.map((x, index) => ys[index] - (intercept + slope * x));
  const sse = residuals.reduce((sum, e) => sum + e * e, 0);
  const standardError = Math.sqrt(sse / (n - 2));
  const degreesOfFreedom = n - 2;
  const correlationDefined = syy > 0;
  const rawCorrelation = correlationDefined ? sxy / Math.sqrt(sxx * syy) : 0;
  const correlation = Math.max(-1, Math.min(1, rawCorrelation));

  const steps = [
    makeStep('样本量与自由度', 'n = ?,  ν = n - 2', `n=${n}，ν=${degreesOfFreedom}`, {
      n,
      degreesOfFreedom
    }),
    makeStep(
      '算术平均',
      'x̄ = Σx_i / n;  ȳ = Σy_i / n',
      `x̄=${fmt(xBar)}，ȳ=${fmt(yBar)} V`,
      { xBar, yBar }
    ),
    makeStep(
      '离差平方和',
      'Sxx = Σ(x_i-x̄)²;  Syy = Σ(y_i-ȳ)²;  Sxy = Σ(x_i-x̄)(y_i-ȳ)',
      `Sxx=${fmt(sxx)}，Syy=${fmt(syy)}，Sxy=${fmt(sxy)}`,
      { sxx, syy, sxy }
    ),
    makeStep(
      '斜率 b',
      'b = Sxy / Sxx',
      `b = ${fmt(sxy)} / ${fmt(sxx)} = ${fmt(slope)} V`,
      slope
    ),
    makeStep(
      '截距 a',
      'a = ȳ - b·x̄',
      `a = ${fmt(yBar)} - (${fmt(slope)}) × ${fmt(xBar)} = ${fmt(intercept)} V`,
      intercept
    ),
    makeStep(
      '相关系数 r',
      correlationDefined ? 'r = Sxy / √(Sxx·Syy)' : 'Syy = 0，r 无定义（取 0）',
      correlationDefined
        ? `r = ${fmt(sxy)} / √(${fmt(sxx)} × ${fmt(syy)}) = ${fmt(correlation)}`
        : '因变量全部相同，相关系数无定义，取 r = 0',
      correlation
    ),
    makeStep(
      '残差',
      'e_i = y_i - (a + b·x_i)',
      residuals.map((e, i) => `e${i + 1}=${fmt(e)}`).join('；'),
      residuals
    ),
    makeStep(
      '回归标准误',
      's_e = √(Σe_i² / (n-2))',
      `s_e = √(${fmt(sse)} / ${degreesOfFreedom}) = ${fmt(standardError)} V`,
      standardError
    )
  ];

  return {
    n,
    degreesOfFreedom,
    xBar,
    yBar,
    sxx,
    syy,
    sxy,
    slope,
    intercept,
    correlation,
    correlationDefined,
    residuals,
    sse,
    standardError,
    steps: withIndex(steps)
  };
}

/* ------------------------------------------------------------------ *
 * 4. 斜率不确定度（A 类 + B 类合成）
 * ------------------------------------------------------------------ */

/**
 * 计算斜率 b 的 A 类、B 类与合成标准不确定度。
 *
 * @param {object} fit linearLeastSquares 的返回值
 * @param {{instrumentErrorU?:number}} [options]
 * @returns {{uA:number, uB:number, uCombined:number, steps:Array}}
 */
function slopeUncertainty(fit, options = {}) {
  if (fit === null || typeof fit !== 'object') {
    throw new TypeError('fit 必须是 linearLeastSquares 返回的拟合结果对象');
  }
  const { instrumentErrorU = CONSTANTS.DEFAULT_INSTRUMENT_ERROR_U } = options;
  assertFiniteNumber(fit.sxx, 'fit.sxx');
  assertFiniteNumber(fit.standardError, 'fit.standardError');
  assertFiniteNumber(fit.degreesOfFreedom, 'fit.degreesOfFreedom');
  assertPositive(instrumentErrorU, 'instrumentErrorU');
  if (fit.sxx <= 0) {
    throw new RangeError(`fit.sxx 必须大于 0，实际收到 ${fit.sxx}`);
  }
  if (fit.standardError < 0) {
    throw new RangeError(`fit.standardError 不能为负，实际收到 ${fit.standardError}`);
  }

  const sqrtSxx = Math.sqrt(fit.sxx);
  const uB_U = instrumentErrorU / Math.sqrt(3);
  const uA = fit.standardError / sqrtSxx;
  const uB = uB_U / sqrtSxx;
  const uCombined = Math.hypot(uA, uB);

  const steps = [
    makeStep(
      '电压 B 类标准不确定度',
      'u_B(U) = Δ仪 / √3',
      `u_B(U) = ${fmt(instrumentErrorU, 4)} / √3 = ${fmt(uB_U)} V`,
      uB_U
    ),
    makeStep(
      '斜率 A 类标准不确定度',
      'u_A(b) = s_e / √Sxx,  ν = n - 2',
      `u_A(b) = ${fmt(fit.standardError)} / √${fmt(fit.sxx)} = ${fmt(uA)} V`,
      uA
    ),
    makeStep(
      '斜率 B 类标准不确定度',
      'u_B(b) = u_B(U) / √Sxx',
      `u_B(b) = ${fmt(uB_U)} / √${fmt(fit.sxx)} = ${fmt(uB)} V`,
      uB
    ),
    makeStep(
      '斜率合成标准不确定度',
      'u(b) = √(u_A²(b) + u_B²(b))',
      `u(b) = √(${fmt(uA)}² + ${fmt(uB)}²) = ${fmt(uCombined)} V`,
      uCombined
    )
  ];

  return {
    instrumentErrorU,
    uB_U,
    sqrtSxx,
    uA,
    uB,
    uCombined,
    degreesOfFreedom: fit.degreesOfFreedom,
    sxx: fit.sxx,
    standardError: fit.standardError,
    steps: withIndex(steps)
  };
}

/* ------------------------------------------------------------------ *
 * 5. lnRatio = -Ua / b
 * ------------------------------------------------------------------ */

/**
 * 由斜率计算实测 ln(Rb/Ra) = -Ua / b。
 *
 * @param {{slope:number, Ua:number}} options
 * @returns {{value:number, steps:Array}}
 */
function lnRatioFromSlope(options = {}) {
  const { slope, Ua } = options;
  assertFiniteNumber(slope, 'slope');
  assertFiniteNumber(Ua, 'Ua');
  if (slope === 0) {
    throw new RangeError('斜率 b 为 0，lnRatio = -Ua/b 无定义');
  }
  if (Ua === 0) {
    throw new RangeError('内电极电位 Ua 为 0，lnRatio = -Ua/b 无定义');
  }

  const value = -Ua / slope;
  return {
    value,
    steps: withIndex([
      makeStep(
        '实测半径比对数',
        'lnRatio = -Ua / b',
        `lnRatio = -(${fmt(Ua, 2)}) / (${fmt(slope)}) = ${fmt(value)}`,
        value
      )
    ])
  };
}

/* ------------------------------------------------------------------ *
 * 6. lnRatio 不确定度传递（数值偏导）
 * ------------------------------------------------------------------ */

/**
 * 数值中心差分偏导。
 */
function numericDerivative(fn, value) {
  const h = Math.max(1e-8, Math.abs(value) * 1e-6);
  return (fn(value + h) - fn(value - h)) / (2 * h);
}

/**
 * 由 b 与 Ua 的不确定度合成 lnRatio = -Ua/b 的不确定度（各输入互不相关）。
 *
 * @param {{slope:number, uSlope:number, Ua:number, uUa:number}} options
 * @returns {{value:number, uncertainty:number, partialSlope:number, partialUa:number, steps:Array}}
 */
function lnRatioUncertainty(options = {}) {
  const { slope, uSlope, Ua, uUa } = options;
  assertFiniteNumber(slope, 'slope');
  assertFiniteNumber(uSlope, 'uSlope');
  assertFiniteNumber(Ua, 'Ua');
  assertFiniteNumber(uUa, 'uUa');
  if (slope === 0) {
    throw new RangeError('斜率 b 为 0，lnRatio 不确定度传递无定义');
  }
  if (uSlope < 0) {
    throw new RangeError(`uSlope 不能为负，实际收到 ${uSlope}`);
  }
  if (uUa < 0) {
    throw new RangeError(`uUa 不能为负，实际收到 ${uUa}`);
  }

  const value = -Ua / slope;
  const partialSlope = numericDerivative((b) => -Ua / b, slope);
  const partialUa = numericDerivative((u) => -u / slope, Ua);
  const contribSlope = partialSlope * uSlope;
  const contribUa = partialUa * uUa;
  const uncertainty = Math.hypot(contribSlope, contribUa);

  const steps = [
    makeStep(
      '主结果',
      'lnRatio = -Ua / b',
      `lnRatio = -(${fmt(Ua, 2)}) / (${fmt(slope)}) = ${fmt(value)}`,
      value
    ),
    makeStep(
      '数值偏导 ∂f/∂b',
      '∂f/∂b = Ua / b²（数值中心差分）',
      `∂f/∂b = ${fmt(partialSlope)} 1/V（解析值 ${fmt(Ua / (slope * slope))} 1/V）`,
      partialSlope
    ),
    makeStep(
      '数值偏导 ∂f/∂Ua',
      '∂f/∂Ua = -1 / b（数值中心差分）',
      `∂f/∂Ua = ${fmt(partialUa)} 1/V（解析值 ${fmt(-1 / slope)} 1/V）`,
      partialUa
    ),
    makeStep(
      '不确定度分量',
      'u_b = |∂f/∂b|·u(b);  u_Ua = |∂f/∂Ua|·u(Ua)',
      `u_b=${fmt(Math.abs(contribSlope))}，u_Ua=${fmt(Math.abs(contribUa))}`,
      { uFromSlope: Math.abs(contribSlope), uFromUa: Math.abs(contribUa) }
    ),
    makeStep(
      '合成标准不确定度',
      'u(lnRatio) = √(u_b² + u_Ua²)（各输入互不相关）',
      `u(lnRatio) = √(${fmt(contribSlope)}² + ${fmt(contribUa)}²) = ${fmt(uncertainty)}`,
      uncertainty
    )
  ];

  return {
    value,
    uncertainty,
    partialSlope,
    partialUa,
    uSlope,
    uUa,
    steps: withIndex(steps)
  };
}

/* ------------------------------------------------------------------ *
 * 7. 与标称值比较（一致性判据）
 * ------------------------------------------------------------------ */

/**
 * 与标称值比较：|x-x0| ≤ 2u 判"一致"，≤ 3u 判"基本一致"，否则"偏差显著"。
 *
 * @param {{value:number, uncertainty:number, nominal?:number}} options
 * @returns {object}
 */
function compareWithNominal(options = {}) {
  const { value, uncertainty } = options;
  const nominal =
    options.nominal === undefined ? CONSTANTS.NOMINAL_LN_RATIO : options.nominal;
  assertFiniteNumber(value, 'value');
  assertFiniteNumber(uncertainty, 'uncertainty');
  assertFiniteNumber(nominal, 'nominal');
  if (uncertainty < 0) {
    throw new RangeError(`不确定度 uncertainty 不能为负，实际收到 ${uncertainty}`);
  }
  if (nominal === 0) {
    throw new RangeError('标称值 nominal 不能为 0（相对误差需要非零参考值）');
  }

  const signedDeviation = value - nominal;
  const deviation = Math.abs(signedDeviation);
  const twoU = 2 * uncertainty;
  const threeU = 3 * uncertainty;
  const absoluteRelativeErrorPercent = (deviation / Math.abs(nominal)) * 100;
  const relativeErrorPercent = (signedDeviation / nominal) * 100;

  let verdict;
  if (uncertainty === 0) {
    verdict = deviation === 0 ? '一致' : '偏差显著';
  } else if (deviation <= twoU) {
    verdict = '一致';
  } else if (deviation <= threeU) {
    verdict = '基本一致';
  } else {
    verdict = '偏差显著';
  }
  const ratioToUncertainty = uncertainty > 0 ? deviation / uncertainty : deviation === 0 ? 0 : Infinity;

  const steps = [
    makeStep('偏差', 'Δ = |x - x0|', `Δ = |${fmt(value)} - ${fmt(nominal)}| = ${fmt(deviation)}`, deviation),
    makeStep(
      '相对误差',
      'E_r = (x - x0) / x0 × 100%',
      `E_r = (${fmt(value)} - ${fmt(nominal)}) / ${fmt(nominal)} × 100% = ${fmt(relativeErrorPercent, 4)}%`,
      relativeErrorPercent
    ),
    makeStep(
      '判据阈值',
      '2u = ?;  3u = ?',
      `2u=${fmt(twoU)}，3u=${fmt(threeU)}，Δ/u=${fmt(ratioToUncertainty, 4)}`,
      { twoU, threeU, ratioToUncertainty }
    ),
    makeStep(
      '一致性结论',
      'Δ ≤ 2u → 一致；Δ ≤ 3u → 基本一致；否则偏差显著',
      `Δ=${fmt(deviation)}，2u=${fmt(twoU)}，3u=${fmt(threeU)} → ${verdict}`,
      verdict
    )
  ];

  return {
    nominal,
    signedDeviation,
    deviation,
    twoU,
    threeU,
    ratioToUncertainty,
    relativeErrorPercent,
    absoluteRelativeErrorPercent,
    verdict,
    steps: withIndex(steps)
  };
}

/* ------------------------------------------------------------------ *
 * 8. 格拉布斯检验（残差单轮检验）
 * ------------------------------------------------------------------ */

/**
 * 对拟合残差做单轮格拉布斯检验（α=0.05），定位偏离最大的一个点。
 *
 * @param {number[]} residuals 拟合残差（均值应近似为 0）
 * @param {{alpha?:number}} [options]
 * @returns {object}
 */
function grubbsTest(residuals, options = {}) {
  assertNumericArray(residuals, 'residuals');
  const { alpha = CONSTANTS.DEFAULT_ALPHA } = options;
  assertFiniteNumber(alpha, 'alpha');
  if (Math.abs(alpha - 0.05) > 1e-12) {
    throw new RangeError(`当前仅内置 α=0.05 的格拉布斯临界值表，实际收到 α=${alpha}`);
  }

  const n = residuals.length;
  if (n < CONSTANTS.MIN_SAMPLE_SIZE) {
    throw new RangeError(`格拉布斯检验要求样本量 n ≥ 3，实际收到 n=${n}`);
  }

  const mean = residuals.reduce((sum, value) => sum + value, 0) / n;
  const deviations = residuals.map((value) => Math.abs(value - mean));
  let maxDeviationIndex = 0;
  for (let i = 1; i < n; i += 1) {
    if (deviations[i] > deviations[maxDeviationIndex]) {
      maxDeviationIndex = i;
    }
  }
  const maxDeviation = deviations[maxDeviationIndex];
  const sumSquared = residuals.reduce((sum, value) => sum + (value - mean) ** 2, 0);
  const residualStd = Math.sqrt(sumSquared / (n - 1));
  const criticalValue =
    n <= CONSTANTS.MAX_GRUBBS_SAMPLE_SIZE
      ? CONSTANTS.GRUBBS_CRITICAL_ALPHA_005[n]
      : null;

  const steps = [
    makeStep(
      '残差均值',
      'ē = Σe_i / n',
      `ē = ${fmt(mean)} V（拟合残差均值应近似为 0）`,
      mean
    ),
    makeStep(
      '残差样本标准差',
      's = √(Σ(e_i - ē)² / (n-1))',
      `s = √(${fmt(sumSquared)} / ${n - 1}) = ${fmt(residualStd)} V`,
      residualStd
    ),
    makeStep(
      '偏离最大点',
      '|e_max - ē| = max_i |e_i - ē|',
      `最大偏离出现在第 ${maxDeviationIndex + 1} 个残差，|e_max-ē|=${fmt(maxDeviation)} V`,
      { maxDeviationIndex, maxDeviation }
    )
  ];

  if (residualStd <= CONSTANTS.RESIDUAL_STD_EPSILON) {
    return {
      available: false,
      n,
      alpha,
      residualMean: mean,
      residualStd,
      maxDeviationIndex,
      maxDeviation,
      g: null,
      criticalValue,
      isOutlier: false,
      reason: `残差样本标准差 s=${fmt(residualStd)} 近似为 0（阈值 ${CONSTANTS.RESIDUAL_STD_EPSILON}），G=|e_max-ē|/s 无定义，格拉布斯检验不可用`,
      steps: withIndex([
        ...steps,
        makeStep(
          '格拉布斯统计量',
          'G = |e_max - ē| / s',
          `分母 s=${fmt(residualStd)} ≤ ${CONSTANTS.RESIDUAL_STD_EPSILON}，统计量无定义`,
          null
        )
      ])
    };
  }

  const g = maxDeviation / residualStd;

  if (n > CONSTANTS.MAX_GRUBBS_SAMPLE_SIZE) {
    return {
      available: false,
      n,
      alpha,
      residualMean: mean,
      residualStd,
      maxDeviationIndex,
      maxDeviation,
      g,
      criticalValue: null,
      isOutlier: false,
      reason: `样本量 n=${n} 超出格拉布斯临界值查表范围 3~20，本实现不做近似，请查阅扩展表或改用其他判据`,
      steps: withIndex([
        ...steps,
        makeStep('格拉布斯统计量', 'G = |e_max - ē| / s', `G = ${fmt(maxDeviation)} / ${fmt(residualStd)} = ${fmt(g)}`, g),
        makeStep(
          '临界值',
          'G(α=0.05, n) 查表',
          `n=${n} 超出查表范围 3~20，临界值不给出，不做近似`,
          null
        )
      ])
    };
  }

  const isOutlier = g >= criticalValue;
  return {
    available: true,
    n,
    alpha,
    residualMean: mean,
    residualStd,
    maxDeviationIndex,
    maxDeviation,
    g,
    criticalValue,
    isOutlier,
    reason: isOutlier
      ? `G=${fmt(g)} ≥ G_crit=${criticalValue}，判定第 ${maxDeviationIndex + 1} 个点为异常值`
      : `G=${fmt(g)} < G_crit=${criticalValue}，未检出异常值`,
    steps: withIndex([
      ...steps,
      makeStep('格拉布斯统计量', 'G = |e_max - ē| / s', `G = ${fmt(maxDeviation)} / ${fmt(residualStd)} = ${fmt(g)}`, g),
      makeStep(
        '临界值查表',
        'G_crit = G(α=0.05, n)',
        `G_crit = G(0.05, ${n}) = ${criticalValue}`,
        criticalValue
      ),
      makeStep('判定', 'G ≥ G_crit → 该点为异常值', `${fmt(g)} ${isOutlier ? '≥' : '<'} ${criticalValue} → ${isOutlier ? '异常' : '正常'}`, isOutlier)
    ])
  };
}

/* ------------------------------------------------------------------ *
 * 9. 全流程分析
 * ------------------------------------------------------------------ */

/**
 * 静电场模拟描绘数据全流程分析。
 *
 * @param {object} options
 * @param {number[]} options.radiiMm 半径数组 / mm
 * @param {number[]} options.potentialsV 电位数组 / V
 * @param {number} options.Ua 内电极电位 / V
 * @param {number} options.Ra 内电极半径 / mm
 * @param {number} options.Rb 外电极半径 / mm
 * @param {number} [options.instrumentErrorU=0.005] 电压表 Δ仪 / V
 * @param {number} [options.instrumentErrorUa=0.01] 内电极电位 Δ仪 / V
 * @param {number} [options.nominalRatio=ln5] 标称 ln(Rb/Ra)
 * @param {number} [options.alpha=0.05] 格拉布斯显著性水平
 * @param {number[]} [options.excludeIndices=[]] 需剔除的数据点原始索引
 * @returns {object}
 */
function analyzeProfile(options = {}) {
  const {
    radiiMm,
    potentialsV,
    Ua,
    Ra,
    Rb,
    instrumentErrorU = CONSTANTS.DEFAULT_INSTRUMENT_ERROR_U,
    instrumentErrorUa = CONSTANTS.DEFAULT_INSTRUMENT_ERROR_UA,
    nominalRatio = CONSTANTS.NOMINAL_LN_RATIO,
    alpha = CONSTANTS.DEFAULT_ALPHA,
    excludeIndices = []
  } = options;

  assertNumericArray(radiiMm, 'radiiMm');
  assertNumericArray(potentialsV, 'potentialsV');
  if (radiiMm.length !== potentialsV.length) {
    throw new RangeError(
      `radiiMm 与 potentialsV 长度必须一致，实际为 ${radiiMm.length} 与 ${potentialsV.length}`
    );
  }
  if (radiiMm.length < CONSTANTS.MIN_SAMPLE_SIZE) {
    throw new RangeError(
      `样本量 n=${radiiMm.length} 少于最小样本量 ${CONSTANTS.MIN_SAMPLE_SIZE}，无法完成拟合`
    );
  }
  assertFiniteNumber(Ua, 'Ua');
  assertPositive(Ra, 'Ra');
  assertPositive(Rb, 'Rb');
  if (Rb <= Ra) {
    throw new RangeError(`外电极半径 Rb=${Rb} mm 必须大于内电极半径 Ra=${Ra} mm`);
  }
  if (Ua === 0) {
    throw new RangeError('内电极电位 Ua 不能为 0，否则主结果 lnRatio = -Ua/b 无定义');
  }
  assertPositive(instrumentErrorU, 'instrumentErrorU');
  assertPositive(instrumentErrorUa, 'instrumentErrorUa');
  if (!Array.isArray(excludeIndices)) {
    throw new TypeError('excludeIndices 必须是数组');
  }

  const excludeSet = new Set();
  excludeIndices.forEach((index, position) => {
    if (!Number.isInteger(index)) {
      throw new TypeError(`excludeIndices[${position}] 必须是整数，实际收到 ${String(index)}`);
    }
    if (index < 0 || index >= radiiMm.length) {
      throw new RangeError(
        `excludeIndices[${position}]=${index} 超出数据索引范围 0 ~ ${radiiMm.length - 1}`
      );
    }
    excludeSet.add(index);
  });

  const usedIndices = [];
  const usedRadiiMm = [];
  const usedPotentialsV = [];
  radiiMm.forEach((radius, index) => {
    if (excludeSet.has(index)) {
      return;
    }
    if (radius <= 0) {
      throw new RangeError(`radiiMm[${index}]=${radius} 必须大于 0（半径不能为非正数）`);
    }
    if (radius <= Ra || radius >= Rb) {
      throw new RangeError(
        `第 ${index + 1} 个数据点 r=${radius} mm 不在内外电极之间 (${Ra}, ${Rb}) mm`
      );
    }
    usedIndices.push(index);
    usedRadiiMm.push(radius);
    usedPotentialsV.push(potentialsV[index]);
  });

  if (usedRadiiMm.length < CONSTANTS.MIN_SAMPLE_SIZE) {
    throw new RangeError(
      `剔除后剩余数据点 ${usedRadiiMm.length} 个，少于最小样本量 ${CONSTANTS.MIN_SAMPLE_SIZE}`
    );
  }

  const transformed = toLogRadiusSeries(usedRadiiMm);
  const fit = linearLeastSquares(transformed.x, usedPotentialsV);
  const slopeUnc = slopeUncertainty(fit, { instrumentErrorU });
  const lnRatioValue = lnRatioFromSlope({ slope: fit.slope, Ua });
  const uUa = instrumentErrorUa / Math.sqrt(3);
  const lnRatioUnc = lnRatioUncertainty({
    slope: fit.slope,
    uSlope: slopeUnc.uCombined,
    Ua,
    uUa
  });
  const comparison = compareWithNominal({
    value: lnRatioUnc.value,
    uncertainty: lnRatioUnc.uncertainty,
    nominal: nominalRatio
  });
  const grubbs = grubbsTest(fit.residuals, { alpha });

  return {
    points: {
      total: radiiMm.length,
      used: usedRadiiMm.length,
      usedIndices,
      excludedIndices: Array.from(excludeSet).sort((a, b) => a - b)
    },
    input: {
      Ua,
      Ra,
      Rb,
      instrumentErrorU,
      instrumentErrorUa,
      nominalRatio,
      alpha
    },
    transformed,
    fit,
    slopeUncertainty: slopeUnc,
    lnRatio: {
      value: lnRatioUnc.value,
      uncertainty: lnRatioUnc.uncertainty,
      partialSlope: lnRatioUnc.partialSlope,
      partialUa: lnRatioUnc.partialUa,
      uUa,
      steps: lnRatioUnc.steps
    },
    comparison,
    grubbs,
    steps: withIndex([
      makeStep(
        '数据点',
        'n_used = 总点数 - 剔除点数',
        `总点数 ${radiiMm.length}，剔除 ${excludeSet.size} 个，参与拟合 ${usedRadiiMm.length} 个`,
        { total: radiiMm.length, used: usedRadiiMm.length, excluded: excludeSet.size }
      ),
      ...fit.steps,
      ...slopeUnc.steps,
      ...lnRatioUnc.steps,
      ...comparison.steps,
      ...grubbs.steps
    ])
  };
}

/**
 * 先做格拉布斯检验，若检出异常值则自动剔除并重算。
 *
 * @param {object} options analyzeProfile 的入参
 * @returns {{rejectionApplied:boolean, rejected:object|null, firstPass:object, finalReport:object, reason:string}}
 */
function analyzeProfileWithRejection(options = {}) {
  const firstPass = analyzeProfile(options);
  const { grubbs } = firstPass;

  if (!grubbs.available || !grubbs.isOutlier) {
    return {
      rejectionApplied: false,
      rejected: null,
      firstPass,
      finalReport: firstPass,
      reason: grubbs.available
        ? grubbs.reason
        : `未执行剔除：${grubbs.reason}`
    };
  }

  const originalIndex = firstPass.points.usedIndices[grubbs.maxDeviationIndex];
  const previousExclusions = Array.isArray(options.excludeIndices) ? options.excludeIndices : [];
  const finalReport = analyzeProfile({
    ...options,
    excludeIndices: [...previousExclusions, originalIndex]
  });

  return {
    rejectionApplied: true,
    rejected: {
      originalIndex,
      radiiMm: options.radiiMm[originalIndex],
      potentialsV: options.potentialsV[originalIndex],
      g: grubbs.g,
      criticalValue: grubbs.criticalValue,
      reason: '格拉布斯检验（α=0.05）判定该点为异常值并剔除'
    },
    firstPass,
    finalReport,
    reason: `已剔除原始索引 ${originalIndex}（r=${options.radiiMm[originalIndex]} mm）并重算`
  };
}

/* ------------------------------------------------------------------ *
 * 导出（浏览器全局 + Node CommonJS）
 * ------------------------------------------------------------------ */

const ElectrostaticCore = {
  CONSTANTS,
  theoryPotential,
  toLogRadiusSeries,
  linearLeastSquares,
  slopeUncertainty,
  lnRatioFromSlope,
  lnRatioUncertainty,
  compareWithNominal,
  grubbsTest,
  analyzeProfile,
  analyzeProfileWithRejection
};

if (typeof module === 'object' && module !== null && typeof module.exports === 'object') {
  module.exports = ElectrostaticCore;
}
if (typeof globalThis !== 'undefined') {
  globalThis.ElectrostaticCore = ElectrostaticCore;
}