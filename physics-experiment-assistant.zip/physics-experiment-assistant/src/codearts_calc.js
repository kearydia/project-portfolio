/*!
 * 大学物理实验数据处理助手 —— 核心计算模块
 * 纯 JavaScript，无第三方依赖，支持 Node.js (CommonJS) 与浏览器（全局 PhysicsCalc）。
 *
 * 设计原则：
 *   1. 所有数值均由程序精确计算，AI 只负责解释误差来源；
 *   2. 每个函数返回结构化计算步骤（公式 + 代入数值 + 结果），供网页点击展开显示；
 *   3. 输入非法时抛出 TypeError / RangeError，便于前端提示与单元测试断言。
 */
(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.PhysicsCalc = factory();
  }
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var PI = Math.PI;
  var FOUR_PI_SQUARED = 4 * PI * PI;
  var SQRT3 = Math.sqrt(3);

  /* ------------------------------------------------------------------ *
   * 通用工具：入参校验 / 数值格式化 / 计算步骤构造
   * ------------------------------------------------------------------ */

  function isFiniteNumber(value) {
    return typeof value === 'number' && Number.isFinite(value);
  }

  function assertFiniteNumber(value, name) {
    if (!isFiniteNumber(value)) {
      throw new TypeError(name + ' 必须是有限数字');
    }
    return value;
  }

  function assertFiniteArray(values, name, minLength) {
    if (!Array.isArray(values)) {
      throw new TypeError(name + ' 必须是数组');
    }
    var min = minLength === undefined ? 1 : minLength;
    if (values.length < min) {
      throw new RangeError(name + ' 至少需要 ' + min + ' 个数据点');
    }
    for (var i = 0; i < values.length; i += 1) {
      if (!isFiniteNumber(values[i])) {
        throw new TypeError(name + '[' + i + '] 不是有限数字');
      }
    }
    return values;
  }

  /** 保留 6 位有效数字用于步骤展示；极大/极小值自动改用科学计数法。 */
  function formatValue(value, digits) {
    var sig = digits === undefined ? 6 : digits;
    if (!Number.isFinite(value)) return String(value);
    if (value === 0) return '0';
    var abs = Math.abs(value);
    if (abs >= 1e-4 && abs < 1e6) {
      return String(Number(value.toPrecision(sig)));
    }
    return value.toExponential(Math.max(sig - 1, 1)).replace('e', 'E').replace(/\.?0+E/, 'E');
  }

  function joinTerms(values, max) {
    var limit = max === undefined ? 8 : max;
    if (values.length <= limit) {
      return values.map(function (v) { return formatValue(v); }).join(' + ');
    }
    return values.slice(0, limit).map(function (v) { return formatValue(v); }).join(' + ') +
      ' + … （共 ' + values.length + ' 项）';
  }

  function makeStep(title, formula, substitution, value, unit) {
    return {
      step: 0,
      title: title,
      formula: formula,
      substitution: substitution,
      result: formatValue(value),
      value: value,
      unit: unit || ''
    };
  }

  function renumber(steps) {
    return steps.map(function (item, index) {
      return {
        step: index + 1,
        title: item.title,
        formula: item.formula,
        substitution: item.substitution,
        result: item.result,
        value: item.value,
        unit: item.unit
      };
    });
  }

  /** 把步骤数组渲染成纯文本，供网页 <pre> 或“展开查看步骤”区域直接显示。 */
  function formatSteps(steps) {
    if (!Array.isArray(steps) || steps.length === 0) return '';
    return steps.map(function (item) {
      var unit = item.unit ? ' ' + item.unit : '';
      return [
        item.step + '. ' + item.title,
        '   公式: ' + item.formula,
        '   代入: ' + item.substitution,
        '   结果: ' + item.result + unit
      ].join('\n');
    }).join('\n\n');
  }

  /* ------------------------------------------------------------------ *
   * 1. 基础统计与不确定度
   * ------------------------------------------------------------------ */

  /** 算术平均值 x̄ = Σxᵢ / n */
  function mean(values) {
    assertFiniteArray(values, 'values', 1);
    var n = values.length;
    var sum = 0;
    for (var i = 0; i < n; i += 1) sum += values[i];
    var value = sum / n;
    var steps = renumber([
      makeStep('求和', 'Σxᵢ = x₁ + x₂ + … + xₙ', joinTerms(values), sum),
      makeStep('算术平均值', 'x̄ = Σxᵢ / n', formatValue(sum) + ' / ' + n, value)
    ]);
    return { value: value, mean: value, sum: sum, n: n, steps: steps };
  }

  /** 样本标准差 s = √(Σ(xᵢ − x̄)² / (n − 1))，分母为 n−1（贝塞尔修正）。 */
  function sampleStdDev(values, options) {
    var opts = options || {};
    assertFiniteArray(values, 'values', 2);
    var n = values.length;
    var meanValue = typeof opts.mean === 'number' ? opts.mean : mean(values).value;
    var ss = 0;
    for (var i = 0; i < n; i += 1) {
      var d = values[i] - meanValue;
      ss += d * d;
    }
    var variance = ss / (n - 1);
    var value = Math.sqrt(variance);
    var steps = renumber([
      makeStep('偏差平方和', 'SS = Σ(xᵢ − x̄)²',
        'x̄ = ' + formatValue(meanValue) + '，SS = ' + formatValue(ss), ss),
      makeStep('样本方差', 's² = SS / (n − 1)',
        formatValue(ss) + ' / ' + (n - 1), variance),
      makeStep('样本标准差', 's = √(s²)', '√(' + formatValue(variance) + ')', value)
    ]);
    return { value: value, stdDev: value, variance: variance, ss: ss, mean: meanValue, n: n, steps: steps };
  }

  /** A 类标准不确定度 uA = t · s / √n（t 因子默认 1，小样本按 t 分布取 2.776 等）。 */
  function uncertaintyA(values, options) {
    var opts = options || {};
    assertFiniteArray(values, 'values', 2);
    var tFactor = opts.tFactor === undefined ? 1 : assertFiniteNumber(opts.tFactor, 'tFactor');
    if (!(tFactor > 0)) throw new RangeError('tFactor 必须为正数');
    var n = values.length;
    var meanResult = mean(values);
    var stdResult = sampleStdDev(values, { mean: meanResult.value });
    var uA = tFactor * stdResult.value / Math.sqrt(n);
    var steps = renumber([
      makeStep('数据个数', 'n = 测量次数', 'n = ' + n, n, '次'),
      makeStep('算术平均值', 'x̄ = Σxᵢ / n',
        formatValue(meanResult.sum) + ' / ' + n, meanResult.value),
      makeStep('样本标准差', 's = √(Σ(xᵢ − x̄)² / (n − 1))',
        '√(' + formatValue(stdResult.ss) + ' / ' + (n - 1) + ')', stdResult.value),
      makeStep('A类不确定度', 'u_A = t · s / √n（t 因子默认 1）',
        formatValue(tFactor) + ' × ' + formatValue(stdResult.value) + ' / √' + n, uA)
    ]);
    return {
      value: uA,
      uA: uA,
      tFactor: tFactor,
      stdDev: stdResult.value,
      mean: meanResult.value,
      n: n,
      steps: steps
    };
  }

  /** B 类标准不确定度：仪器最大允差按均匀分布折算 uB = Δ仪 / √3。 */
  function uncertaintyB(deltaInstrument, options) {
    var opts = options || {};
    var delta = assertFiniteNumber(deltaInstrument, 'deltaInstrument');
    if (delta < 0) throw new RangeError('仪器最大允差 Δ仪 不能为负数');
    var divisor = opts.divisor === undefined ? SQRT3 : assertFiniteNumber(opts.divisor, 'divisor');
    if (!(divisor > 0)) throw new RangeError('divisor 必须为正数');
    var value = delta / divisor;
    var steps = renumber([
      makeStep('仪器最大允差', 'Δ仪 = 仪器精度等级 × 量程（或直接给定）',
        'Δ仪 = ' + formatValue(delta), delta),
      makeStep('B类不确定度', 'u_B = Δ仪 / √3（均匀分布）',
        formatValue(delta) + ' / ' + formatValue(divisor), value)
    ]);
    return { value: value, uB: value, delta: delta, divisor: divisor, steps: steps };
  }

  /** 合成标准不确定度 uC = √(uA² + uB²) */
  function combinedUncertainty(uA, uB, options) {
    var a = assertFiniteNumber(uA, 'uA');
    var b = assertFiniteNumber(uB, 'uB');
    if (a < 0 || b < 0) throw new RangeError('不确定度分量不能为负数');
    var value = Math.sqrt(a * a + b * b);
    var steps = renumber([
      makeStep('A类分量平方', 'u_A²', formatValue(a) + '²', a * a),
      makeStep('B类分量平方', 'u_B²', formatValue(b) + '²', b * b),
      makeStep('合成标准不确定度', 'u_C = √(u_A² + u_B²)',
        '√(' + formatValue(a * a) + ' + ' + formatValue(b * b) + ')', value)
    ]);
    var result = { value: value, uC: value, uA: a, uB: b, steps: steps };
    if (options && options.label) result.label = options.label;
    return result;
  }

  /** 相对不确定度：E = u / |x|，同时返回小数与百分数。 */
  function relativeUncertainty(uncertainty, measured) {
    var u = assertFiniteNumber(uncertainty, 'uncertainty');
    var x = assertFiniteNumber(measured, 'measured');
    if (u < 0) throw new RangeError('不确定度不能为负数');
    if (x === 0) throw new RangeError('测量值不能为 0（相对不确定度无定义）');
    var absX = Math.abs(x);
    var fraction = u / absX;
    var percent = fraction * 100;
    var steps = renumber([
      makeStep('相对不确定度（小数）', 'E = u / |x|',
        formatValue(u) + ' / |' + formatValue(x) + '|', fraction),
      makeStep('相对不确定度（百分数）', 'E% = E × 100%',
        formatValue(fraction) + ' × 100%', percent, '%')
    ]);
    return { fraction: fraction, percent: percent, value: fraction, uncertainty: u, measured: x, steps: steps };
  }

  /* ------------------------------------------------------------------ *
   * 2. 一元线性最小二乘拟合
   * ------------------------------------------------------------------ */

  /**
   * y = k·x + b 的最小二乘拟合。
   * 返回斜率/截距及其标准不确定度、相关系数 r、残差、残差标准差与计算步骤。
   */
  function fitLinear(xs, ys) {
    assertFiniteArray(xs, 'xs', 3);
    assertFiniteArray(ys, 'ys', 3);
    var n = xs.length;
    if (ys.length !== n) throw new RangeError('xs 与 ys 长度必须相同');

    var sumX = 0;
    var sumY = 0;
    var i;
    for (i = 0; i < n; i += 1) {
      sumX += xs[i];
      sumY += ys[i];
    }
    var xMean = sumX / n;
    var yMean = sumY / n;

    var sxx = 0;
    var syy = 0;
    var sxy = 0;
    for (i = 0; i < n; i += 1) {
      var dx = xs[i] - xMean;
      var dy = ys[i] - yMean;
      sxx += dx * dx;
      syy += dy * dy;
      sxy += dx * dy;
    }
    if (sxx === 0) throw new RangeError('xs 不能全部相同（无法确定斜率）');

    var slope = sxy / sxx;
    var intercept = yMean - slope * xMean;

    var residuals = [];
    var ssRes = 0;
    for (i = 0; i < n; i += 1) {
      var residual = ys[i] - (slope * xs[i] + intercept);
      residuals.push(residual);
      ssRes += residual * residual;
    }
    var dof = n - 2;
    var residualStd = Math.sqrt(ssRes / dof);
    var slopeStd = residualStd / Math.sqrt(sxx);
    var interceptStd = residualStd * Math.sqrt(1 / n + (xMean * xMean) / sxx);
    var rRaw = syy === 0 ? 0 : sxy / Math.sqrt(sxx * syy);
    var r = Math.max(-1, Math.min(1, rRaw));

    var steps = renumber([
      makeStep('x 的平均值', 'x̄ = Σxᵢ / n',
        formatValue(sumX) + ' / ' + n, xMean),
      makeStep('y 的平均值', 'ȳ = Σyᵢ / n',
        formatValue(sumY) + ' / ' + n, yMean),
      makeStep('x 离差平方和', 'Sxx = Σ(xᵢ − x̄)²',
        'x̄ = ' + formatValue(xMean) + '，Sxx = ' + formatValue(sxx), sxx),
      makeStep('x、y 交叉积和', 'Sxy = Σ(xᵢ − x̄)(yᵢ − ȳ)', 'Sxy = ' + formatValue(sxy), sxy),
      makeStep('y 离差平方和', 'Syy = Σ(yᵢ − ȳ)²',
        'ȳ = ' + formatValue(yMean) + '，Syy = ' + formatValue(syy), syy),
      makeStep('拟合斜率', 'k = Sxy / Sxx',
        formatValue(sxy) + ' / ' + formatValue(sxx), slope),
      makeStep('拟合截距', 'b = ȳ − k·x̄',
        formatValue(yMean) + ' − ' + formatValue(slope) + ' × ' + formatValue(xMean), intercept),
      makeStep('残差平方和', 'SSres = Σ(yᵢ − k·xᵢ − b)²',
        'SSres = ' + formatValue(ssRes), ssRes),
      makeStep('残差标准差', 's = √(SSres / (n − 2))',
        '√(' + formatValue(ssRes) + ' / ' + dof + ')', residualStd),
      makeStep('斜率标准不确定度', 'u(k) = s / √Sxx',
        formatValue(residualStd) + ' / √' + formatValue(sxx), slopeStd),
      makeStep('截距标准不确定度', 'u(b) = s · √(1/n + x̄²/Sxx)',
        formatValue(residualStd) + ' × √(1/' + n + ' + ' + formatValue(xMean * xMean) +
        '/' + formatValue(sxx) + ')', interceptStd),
      makeStep('相关系数', 'r = Sxy / √(Sxx · Syy)',
        formatValue(sxy) + ' / √(' + formatValue(sxx) + ' × ' + formatValue(syy) + ')', r)
    ]);

    return {
      slope: slope,
      intercept: intercept,
      slopeStd: slopeStd,
      interceptStd: interceptStd,
      r: r,
      residuals: residuals,
      ssRes: ssRes,
      residualStd: residualStd,
      dof: dof,
      n: n,
      xMean: xMean,
      yMean: yMean,
      sxx: sxx,
      syy: syy,
      sxy: sxy,
      steps: steps
    };
  }

  /* ------------------------------------------------------------------ *
   * 3. 异常值检测（3σ 残差法 / 格拉布斯法）与剔除后重算
   * ------------------------------------------------------------------ */

  /**
   * 格拉布斯检验临界值表，仅收录显著性 α = 0.05、样本量 n = 3 ~ 20。
   * 本模块统一使用这一判据（单次测量列与拟合残差共用），不做表外近似：
   * n 超出范围时直接报错，避免静默近似导致误判。
   */
  var GRUBBS_TABLE = {
    3: 1.153, 4: 1.463, 5: 1.672, 6: 1.822, 7: 1.938, 8: 2.032, 9: 2.110, 10: 2.176,
    11: 2.234, 12: 2.285, 13: 2.331, 14: 2.371, 15: 2.409, 16: 2.443, 17: 2.475,
    18: 2.504, 19: 2.532, 20: 2.557
  };
  var GRUBBS_ALPHA = 0.05;
  var GRUBBS_MIN_N = 3;
  var GRUBBS_MAX_N = 20;

  /**
   * 格拉布斯检验临界值 G(α = 0.05, n)。
   * n 超出临界值表范围时抛出附带样本量与表范围的 RangeError，绝不近似。
   */
  function grubbsCriticalValue(n, alpha) {
    var a = alpha === undefined ? GRUBBS_ALPHA : alpha;
    if (a !== GRUBBS_ALPHA) {
      throw new RangeError('异常值判据统一采用格拉布斯检验（显著性 α = 0.05），不支持 α = ' + a);
    }
    if (!Number.isInteger(n)) {
      throw new RangeError('格拉布斯检验要求样本量 n 为整数，当前 n = ' + n);
    }
    if (n < GRUBBS_MIN_N) {
      throw new RangeError('格拉布斯检验要求 n ≥ ' + GRUBBS_MIN_N + '，当前 n = ' + n);
    }
    if (n > GRUBBS_MAX_N) {
      throw new RangeError(
        '格拉布斯临界值表仅覆盖 n = ' + GRUBBS_MIN_N + ' ~ ' + GRUBBS_MAX_N +
        '，当前 n = ' + n + '。为避免静默近似，请减少数据点后重新检验；' +
        '如需处理大样本，请先分组或改用其他统计判据。'
      );
    }
    return GRUBBS_TABLE[n];
  }

  function computeStats(list) {
    var n = list.length;
    var sum = 0;
    var i;
    for (i = 0; i < n; i += 1) sum += list[i].value;
    var meanValue = n === 0 ? 0 : sum / n;
    var ss = 0;
    for (i = 0; i < n; i += 1) {
      var d = list[i].value - meanValue;
      ss += d * d;
    }
    var variance = n > 1 ? ss / (n - 1) : 0;
    return { n: n, sum: sum, mean: meanValue, ss: ss, variance: variance, std: Math.sqrt(variance) };
  }

  /**
   * 3σ 残差法：|xᵢ − x̄| > 3s 判为异常值。
   * options.threshold 可改判定倍数，options.useSampleStd=false 改用总体标准差。
   *
   * 注意：该函数仅作为对照/教学用途保留，默认异常值流程（detectOutliers /
   * rejectOutliers / grubbsResiduals）一律使用格拉布斯检验（α = 0.05）。
   */
  function detectOutliers3Sigma(values, options) {
    var opts = options || {};
    var threshold = opts.threshold === undefined ? 3 : assertFiniteNumber(opts.threshold, 'threshold');
    if (!(threshold > 0)) throw new RangeError('threshold 必须为正数');
    assertFiniteArray(values, 'values', 2);
    var n = values.length;
    var meanResult = mean(values);
    var useSample = opts.useSampleStd !== false;
    var std = useSample
      ? sampleStdDev(values, { mean: meanResult.value }).value
      : Math.sqrt(computeStats(values.map(function (v) { return { value: v }; })).ss / n);
    var limit = threshold * std;
    var outliers = [];
    var keptValues = [];
    var keptIndices = [];
    for (var i = 0; i < n; i += 1) {
      var deviation = Math.abs(values[i] - meanResult.value);
      if (std > 0 && deviation > limit) {
        outliers.push({
          index: i,
          value: values[i],
          deviation: deviation,
          ratio: deviation / std
        });
      } else {
        keptValues.push(values[i]);
        keptIndices.push(i);
      }
    }
    var steps = renumber([
      makeStep('算术平均值', 'x̄ = Σxᵢ / n',
        formatValue(meanResult.sum) + ' / ' + n, meanResult.value),
      makeStep('标准差', useSample ? 's = √(Σ(xᵢ − x̄)² / (n − 1))' : 'σ = √(Σ(xᵢ − x̄)² / n)',
        'σ = ' + formatValue(std), std),
      makeStep('判别阈值', '|xᵢ − x̄| > ' + formatValue(threshold) + ' × σ',
        formatValue(threshold) + ' × ' + formatValue(std), limit),
      makeStep('异常值个数', '统计超过阈值的测量值', '异常值个数 = ' + outliers.length,
        outliers.length, '个')
    ]);
    return {
      method: '3sigma',
      threshold: threshold,
      mean: meanResult.value,
      stdDev: std,
      limit: limit,
      outliers: outliers,
      hasOutliers: outliers.length > 0,
      keptValues: keptValues,
      keptIndices: keptIndices,
      removedCount: outliers.length,
      steps: steps
    };
  }

  /**
   * 格拉布斯检验：G = |xᵢ − x̄| / s，与临界值 G(0.05, n) 比较，判定最大偏差点。
   * 单一判据，单次测量列与拟合残差共用（options.kind='residuals' 仅影响步骤文案）。
   * n 超出 3 ~ 20 时抛错，不做近似。
   */
  function grubbsTest(values, options) {
    var opts = options || {};
    assertFiniteArray(values, 'values', 3);
    var alpha = opts.alpha === undefined ? GRUBBS_ALPHA : opts.alpha;
    var kind = opts.kind === 'residuals' ? 'residuals' : 'measurement';
    var n = values.length;
    var critical = grubbsCriticalValue(n, alpha);
    var meanResult = mean(values);
    var stdResult = sampleStdDev(values, { mean: meanResult.value });
    var std = stdResult.value;
    var worstIndex = 0;
    var worstDeviation = -1;
    for (var i = 0; i < n; i += 1) {
      var deviation = Math.abs(values[i] - meanResult.value);
      if (deviation > worstDeviation) {
        worstDeviation = deviation;
        worstIndex = i;
      }
    }
    var g = std > 0 ? worstDeviation / std : 0;
    var isOutlier = g > critical;
    var sourceLabel = kind === 'residuals' ? '拟合残差列' : '单次测量列';
    var steps = renumber([
      makeStep('算术平均值（' + sourceLabel + '）', 'x̄ = Σxᵢ / n',
        formatValue(meanResult.sum) + ' / ' + n, meanResult.value),
      makeStep('样本标准差', 's = √(Σ(xᵢ − x̄)² / (n − 1))',
        '√(' + formatValue(stdResult.ss) + ' / ' + (n - 1) + ')', std),
      makeStep('最大偏差', '|xᵢ − x̄|max',
        '候选值 x = ' + formatValue(values[worstIndex]) + '，偏差 = ' + formatValue(worstDeviation),
        worstDeviation),
      makeStep('格拉布斯统计量', 'G = |xᵢ − x̄|max / s',
        formatValue(worstDeviation) + ' / ' + formatValue(std), g),
      makeStep('临界值（查表）', 'G(α=' + String(alpha) + ', n=' + n + ')',
        '查格拉布斯临界值表（n = ' + n + '，未做近似）= ' + formatValue(critical), critical),
      makeStep('判定', 'G > G(0.05, n) ？',
        formatValue(g) + (isOutlier ? ' > ' : ' ≤ ') + formatValue(critical), isOutlier ? 1 : 0)
    ]);
    steps[steps.length - 1].result = isOutlier ? '是（判为异常值）' : '否（保留）';
    return {
      method: 'grubbs',
      alpha: alpha,
      kind: kind,
      n: n,
      mean: meanResult.value,
      stdDev: std,
      statistic: g,
      critical: critical,
      candidateIndex: worstIndex,
      candidateValue: values[worstIndex],
      isOutlier: isOutlier,
      hasOutliers: isOutlier,
      steps: steps
    };
  }

  /**
   * 统一的异常值判据入口（默认且唯一：格拉布斯检验，α = 0.05）。
   * options.kind: 'measurement'（默认，单次测量列）或 'residuals'（拟合残差）。
   */
  function detectOutliers(values, options) {
    var opts = options || {};
    return grubbsTest(values, { alpha: opts.alpha, kind: opts.kind });
  }

  /**
   * 对拟合残差做格拉布斯检验。
   * 接受 fitLinear 的返回对象（取其 residuals）或直接的残差数组。
   */
  function grubbsResiduals(input, options) {
    var residuals;
    if (Array.isArray(input)) {
      residuals = input;
    } else if (input && Array.isArray(input.residuals)) {
      residuals = input.residuals;
    } else {
      throw new TypeError('grubbsResiduals 需要残差数组或 fitLinear 的返回对象');
    }
    var opts = {};
    if (options) {
      Object.keys(options).forEach(function (key) { opts[key] = options[key]; });
    }
    opts.kind = 'residuals';
    return grubbsTest(residuals, opts);
  }

  /**
   * 迭代剔除异常值并在剩余数据上重算统计量。
   * 统一采用格拉布斯检验（α = 0.05，逐个剔除）；n 超出临界值表时给出明确错误。
   * options.maxIterations: 剔除轮数上限。
   */
  function rejectOutliers(values, options) {
    var opts = options || {};
    assertFiniteArray(values, 'values', 3);
    if (opts.method !== undefined && opts.method !== 'grubbs') {
      throw new RangeError("异常值剔除统一采用格拉布斯检验，method 仅支持 'grubbs'");
    }
    if (opts.threshold !== undefined) {
      throw new RangeError('threshold 属于 3σ 判据，默认流程已统一为格拉布斯检验；请改用 alpha = 0.05');
    }
    var method = 'grubbs';
    var alpha = opts.alpha === undefined ? GRUBBS_ALPHA : opts.alpha;
    if (alpha !== GRUBBS_ALPHA) {
      throw new RangeError('异常值判据统一采用格拉布斯检验（显著性 α = 0.05），不支持 α = ' + alpha);
    }
    // 提前按全样本量校验表范围，确保“超出临界值表”时立即给出明确提示。
    grubbsCriticalValue(values.length, alpha);
    var maxIterations = opts.maxIterations === undefined ? values.length : opts.maxIterations;
    if (!Number.isInteger(maxIterations) || maxIterations < 1) {
      throw new RangeError('maxIterations 必须为正整数');
    }

    var pool = values.map(function (value, index) {
      return { value: value, index: index };
    });
    var removed = [];
    var log = [];
    var iteration = 0;
    var active = true;
    var minSize = GRUBBS_MIN_N;

    while (active && iteration < maxIterations) {
      active = false;
      var stats = computeStats(pool);
      if (pool.length < minSize || stats.std === 0) break;
      iteration += 1;
      var victims = [];
      var i;
      var critical = grubbsCriticalValue(pool.length, alpha);
      var worstIndex = 0;
      var worstG = -1;
      for (i = 0; i < pool.length; i += 1) {
        var g = Math.abs(pool[i].value - stats.mean) / stats.std;
        if (g > worstG) {
          worstG = g;
          worstIndex = i;
        }
      }
      if (worstG > critical) {
        victims.push({
          poolIndex: worstIndex,
          statistic: worstG,
          critical: critical,
          limit: critical * stats.std,
          item: pool[worstIndex]
        });
      }
      if (victims.length === 0) break;
      active = true;
      victims.forEach(function (victim) {
        removed.push({
          index: victim.item.index,
          value: victim.item.value,
          iteration: iteration,
          method: method,
          statistic: victim.statistic,
          critical: victim.critical,
          limit: victim.limit
        });
      });
      var removedPoolIndexes = victims.map(function (victim) { return victim.poolIndex; });
      pool = pool.filter(function (item, index) {
        return removedPoolIndexes.indexOf(index) === -1;
      });
      log.push({ iteration: iteration, removedCount: victims.length, remaining: pool.length });
    }

    var finalStats = computeStats(pool);
    var keptValues = pool.map(function (item) { return item.value; });
    var keptIndices = pool.map(function (item) { return item.index; });
    var uA = pool.length > 1 ? finalStats.std / Math.sqrt(pool.length) : null;
    var branchSteps = log.map(function (entry) {
      return makeStep('第 ' + entry.iteration + ' 轮剔除',
        'G > G(0.05, n) 则剔除最大偏差点',
        '本轮剔除 ' + entry.removedCount + ' 个，剩余 ' + entry.remaining + ' 个',
        entry.removedCount, '个');
    });
    var steps = renumber(branchSteps.concat([
      makeStep('剔除后平均值', 'x̄ = Σxᵢ / n',
        formatValue(finalStats.sum) + ' / ' + finalStats.n, finalStats.mean),
      makeStep('剔除后标准差', 's = √(Σ(xᵢ − x̄)² / (n − 1))',
        'n = ' + finalStats.n + '，s = ' + formatValue(finalStats.std), finalStats.std),
      makeStep('剔除后A类不确定度', 'u_A = s / √n',
        formatValue(finalStats.std) + ' / √' + finalStats.n, uA === null ? 0 : uA)
    ]));

    return {
      method: method,
      iterations: iteration,
      removed: removed,
      removedCount: removed.length,
      keptValues: keptValues,
      keptIndices: keptIndices,
      log: log,
      statistics: {
        n: finalStats.n,
        mean: finalStats.mean,
        stdDev: finalStats.std,
        uA: uA
      },
      steps: steps
    };
  }

  /* ------------------------------------------------------------------ *
   * 4. 实验项目：单摆测 g、伏安法测电阻
   * ------------------------------------------------------------------ */

  /**
   * 单摆：T²–L 拟合，g = 4π²/k。
   * 不确定度同时计入：
   *   1) 拟合斜率 u(k)：u₁(g) = (4π²/k²)·u(k)
   *   2) 摆长 B 类不确定度 u(L) = Δ尺/√3：u₂(g) = g·u(L)/L̄
   * 合成：u(g) = √(u₁² + u₂²)。
   * data.lengthDelta 为尺子最大允差（单位 m）；未提供时按 0 处理。
   */
  function pendulumGravity(data) {
    var input = data || {};
    var lengths = assertFiniteArray(input.lengths, 'lengths', 3);
    var periods = assertFiniteArray(input.periods, 'periods', 3);
    if (lengths.length !== periods.length) {
      throw new RangeError('lengths 与 periods 长度必须相同');
    }
    var lengthDelta = 0;
    if (input.lengthDelta !== undefined) {
      lengthDelta = assertFiniteNumber(input.lengthDelta, 'lengthDelta');
      if (lengthDelta < 0) throw new RangeError('尺子最大允差 lengthDelta 不能为负数');
    }
    var squaredPeriods = periods.map(function (t) { return t * t; });
    var fit = fitLinear(lengths, squaredPeriods);
    if (!(fit.slope > 0)) throw new RangeError('拟合斜率必须为正数，才能换算重力加速度 g');

    var meanLength = mean(lengths).value;
    var g = FOUR_PI_SQUARED / fit.slope;
    var uGSlope = (FOUR_PI_SQUARED / (fit.slope * fit.slope)) * fit.slopeStd;
    var uLength = lengthDelta / SQRT3;
    var uGLength = meanLength === 0 ? 0 : g * uLength / Math.abs(meanLength);
    var uG = Math.sqrt(uGSlope * uGSlope + uGLength * uGLength);
    var relativePercent = g === 0 ? 0 : (uG / Math.abs(g)) * 100;

    var steps = renumber([
      makeStep('周期平方预处理', 'yᵢ = Tᵢ²',
        periods.map(function (t) { return formatValue(t) + '² = ' + formatValue(t * t); }).join('，'),
        squaredPeriods[0], 's²')
    ].concat(fit.steps, [
      makeStep('重力加速度', 'g = 4π² / k',
        '4π² / ' + formatValue(fit.slope), g, 'm/s²'),
      makeStep('斜率引起的 g 不确定度', 'u₁(g) = (4π²/k²) · u(k)',
        '(' + formatValue(FOUR_PI_SQUARED) + '/' + formatValue(fit.slope * fit.slope) + ') × ' +
        formatValue(fit.slopeStd), uGSlope, 'm/s²'),
      makeStep('摆长 B 类不确定度', 'u(L) = Δ尺 / √3',
        lengthDelta === 0
          ? '未提供 Δ尺，按 u(L) = 0 处理'
          : formatValue(lengthDelta) + ' / ' + formatValue(SQRT3), uLength, 'm'),
      makeStep('摆长引起的 g 不确定度', 'u₂(g) = g · u(L) / L̄',
        formatValue(g) + ' × ' + formatValue(uLength) + ' / ' + formatValue(meanLength),
        uGLength, 'm/s²'),
      makeStep('g 的不确定度合成', 'u(g) = √(u₁(g)² + u₂(g)²)',
        '√(' + formatValue(uGSlope * uGSlope) + ' + ' + formatValue(uGLength * uGLength) + ')',
        uG, 'm/s²'),
      makeStep('相对不确定度', 'E(g) = u(g) / g × 100%',
        formatValue(uG) + ' / ' + formatValue(g) + ' × 100%', relativePercent, '%')
    ]));

    return {
      slope: fit.slope,
      intercept: fit.intercept,
      r: fit.r,
      squaredPeriods: squaredPeriods,
      fit: fit,
      meanLength: meanLength,
      lengthDelta: lengthDelta,
      uLength: uLength,
      g: g,
      uG: uG,
      uGSlope: uGSlope,
      uGLength: uGLength,
      relativeUncertaintyPercent: relativePercent,
      steps: steps
    };
  }

  /** 伏安法：U–I 拟合（I 为横轴），R = 斜率，u(R) = u(k)。电流单位须为 A。 */
  function ohmsLawResistance(data) {
    var input = data || {};
    var voltages = assertFiniteArray(input.voltages, 'voltages', 3);
    var currents = assertFiniteArray(input.currents, 'currents', 3);
    if (voltages.length !== currents.length) {
      throw new RangeError('voltages 与 currents 长度必须相同');
    }
    var fit = fitLinear(currents, voltages);
    if (!(fit.slope > 0)) throw new RangeError('拟合斜率必须为正数，才能换算电阻 R');

    var resistance = fit.slope;
    var uR = fit.slopeStd;
    var relativePercent = resistance === 0 ? 0 : (uR / Math.abs(resistance)) * 100;

    var steps = renumber(fit.steps.concat([
      makeStep('电阻', 'R = k（U–I 图斜率）',
        'R = ' + formatValue(fit.slope), resistance, 'Ω'),
      makeStep('电阻不确定度', 'u(R) = u(k)',
        'u(R) = ' + formatValue(fit.slopeStd), uR, 'Ω'),
      makeStep('相对不确定度', 'E(R) = u(R) / R × 100%',
        formatValue(uR) + ' / ' + formatValue(resistance) + ' × 100%', relativePercent, '%')
    ]));

    return {
      resistance: resistance,
      uR: uR,
      relativeUncertaintyPercent: relativePercent,
      slope: fit.slope,
      intercept: fit.intercept,
      r: fit.r,
      fit: fit,
      steps: steps
    };
  }

  /* ------------------------------------------------------------------ *
   * 5. 与公认值比较
   * ------------------------------------------------------------------ */

  /**
   * 与公认值 x0 比较：相对误差 E% = |x − x0| / |x0| × 100%，
   * 并判定 |x − x0| ≤ 2u（k=2 扩展不确定度）是否成立。
   */
  function compareWithReference(data) {
    var input = data || {};
    var measured = assertFiniteNumber(input.measured, 'measured');
    var reference = assertFiniteNumber(input.reference, 'reference');
    var uncertainty = assertFiniteNumber(input.uncertainty, 'uncertainty');
    if (uncertainty < 0) throw new RangeError('uncertainty 不能为负数');
    if (reference === 0) throw new RangeError('reference 不能为 0');
    var k = input.k === undefined ? 2 : assertFiniteNumber(input.k, 'k');
    if (!(k > 0)) throw new RangeError('k 必须为正数');

    var absoluteError = measured - reference;
    var absError = Math.abs(absoluteError);
    var relativeErrorPercent = (absError / Math.abs(reference)) * 100;
    var expandedUncertainty = k * uncertainty;
    var within2u = absError <= 2 * uncertainty;
    var consistent = absError <= expandedUncertainty;

    var steps = renumber([
      makeStep('绝对偏差', 'Δ = x − x0',
        formatValue(measured) + ' − ' + formatValue(reference), absoluteError),
      makeStep('相对误差', 'E% = |x − x0| / |x0| × 100%',
        formatValue(absError) + ' / |' + formatValue(reference) + '| × 100%',
        relativeErrorPercent, '%'),
      makeStep('2u 判据', '|x − x0| ≤ 2u ？',
        formatValue(absError) + (within2u ? ' ≤ ' : ' > ') + formatValue(2 * uncertainty),
        within2u ? 1 : 0),
      makeStep('扩展不确定度判据', '|x − x0| ≤ ' + formatValue(k) + 'u ？',
        formatValue(absError) + (consistent ? ' ≤ ' : ' > ') + formatValue(expandedUncertainty),
        consistent ? 1 : 0)
    ]);
    steps[2].result = within2u ? '成立' : '不成立';
    steps[3].result = consistent ? '成立' : '不成立';

    return {
      measured: measured,
      reference: reference,
      uncertainty: uncertainty,
      k: k,
      absoluteError: absoluteError,
      absError: absError,
      relativeErrorPercent: relativeErrorPercent,
      expandedUncertainty: expandedUncertainty,
      within2u: within2u,
      consistent: consistent,
      steps: steps
    };
  }

  /* ------------------------------------------------------------------ *
   * 6. 表格脏数据校验（不抛未捕获异常）
   * ------------------------------------------------------------------ */

  function makeValidationError(row, column, columnLabel, code, message) {
    return {
      row: row,
      column: column,
      columnLabel: columnLabel,
      code: code,
      message: message
    };
  }

  function describeCellValue(value) {
    if (value === undefined) return 'undefined（空）';
    if (value === null) return 'null（空）';
    if (typeof value === 'string') return '"' + value + '"';
    return String(value);
  }

  function normalizeTableSchema(schema) {
    if (!schema || typeof schema !== 'object') {
      throw new TypeError('schema 必须是对象');
    }
    if (!Array.isArray(schema.columns) || schema.columns.length === 0) {
      throw new TypeError('schema.columns 必须是非空数组');
    }
    var columns = schema.columns.map(function (column, index) {
      if (!column || typeof column !== 'object') {
        throw new TypeError('schema.columns[' + index + '] 必须是对象');
      }
      if (typeof column.key !== 'string' || column.key.length === 0) {
        throw new TypeError('schema.columns[' + index + '].key 必须是非空字符串');
      }
      return {
        key: column.key,
        label: typeof column.label === 'string' && column.label.length > 0
          ? column.label
          : column.key,
        unit: column.unit === undefined || column.unit === null ? null : String(column.unit),
        unitKey: typeof column.unitKey === 'string' && column.unitKey.length > 0
          ? column.unitKey
          : column.key + 'Unit',
        type: column.type === undefined ? 'number' : column.type
      };
    });
    return {
      columns: columns,
      checkUnits: schema.checkUnits !== false,
      minRows: schema.minRows === undefined ? 1 : schema.minRows
    };
  }

  function validateTableUnsafe(rows, schema) {
    var normalized = normalizeTableSchema(schema);
    var columns = normalized.columns;
    var schemaKeys = columns.map(function (column) { return column.key; });
    var unitKeys = columns.map(function (column) { return column.unitKey; });
    var errors = [];
    var validRows = [];
    var validRowNumbers = [];

    if (!Array.isArray(rows)) {
      return {
        ok: false,
        rowCount: 0,
        errorCount: 1,
        errors: [makeValidationError(0, 'table', '表格', 'NOT_ARRAY', '表格数据必须是数组')],
        validRows: [],
        validRowNumbers: []
      };
    }
    if (rows.length === 0) {
      return {
        ok: false,
        rowCount: 0,
        errorCount: 1,
        errors: [makeValidationError(0, 'table', '表格', 'EMPTY_TABLE', '表格为空：至少需要 1 行数据')],
        validRows: [],
        validRowNumbers: []
      };
    }
    if (rows.length < normalized.minRows) {
      errors.push(makeValidationError(
        0, 'table', '表格', 'TOO_FEW_ROWS',
        '表格行数不足：至少需要 ' + normalized.minRows + ' 行，实际 ' + rows.length + ' 行'
      ));
    }

    rows.forEach(function (row, rowIndex) {
      var rowNo = rowIndex + 1;
      var rowErrors = [];

      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        rowErrors.push(makeValidationError(
          rowNo, 'row', '整行', 'ROW_TYPE',
          '第 ' + rowNo + ' 行：数据必须是对象（键为列名），实际为 ' + describeCellValue(row)
        ));
      } else {
        var rowKeys = Object.keys(row).filter(function (key) {
          return unitKeys.indexOf(key) === -1;
        });
        if (rowKeys.length !== columns.length) {
          rowErrors.push(makeValidationError(
            rowNo, 'row', '列数', 'COLUMN_COUNT',
            '第 ' + rowNo + ' 行：列数不符，期望 ' + columns.length + ' 列（' +
            schemaKeys.join('、') + '），实际 ' + rowKeys.length + ' 列（' +
            (rowKeys.length === 0 ? '无数据列' : rowKeys.join('、')) + '）'
          ));
        }

        schemaKeys.forEach(function (key) {
          if (!Object.prototype.hasOwnProperty.call(row, key)) {
            var missing = columns[schemaKeys.indexOf(key)];
            rowErrors.push(makeValidationError(
              rowNo, key, missing.label, 'MISSING_COLUMN',
              '第 ' + rowNo + ' 行：缺少列「' + missing.label + '」'
            ));
          }
        });

        rowKeys.forEach(function (key) {
          if (schemaKeys.indexOf(key) === -1) {
            rowErrors.push(makeValidationError(
              rowNo, key, key, 'EXTRA_COLUMN',
              '第 ' + rowNo + ' 行：存在多余的列「' + key + '」（列数不符）'
            ));
          }
        });

        columns.forEach(function (column) {
          var value = row[column.key];
          if (value === undefined || value === null ||
            (typeof value === 'string' && value.trim() === '')) {
            rowErrors.push(makeValidationError(
              rowNo, column.key, column.label, 'EMPTY_VALUE',
              '第 ' + rowNo + ' 行：列「' + column.label + '」为空值'
            ));
            return;
          }
          if (column.type === 'number' && !isFiniteNumber(value)) {
            rowErrors.push(makeValidationError(
              rowNo, column.key, column.label, 'NOT_NUMBER',
              '第 ' + rowNo + ' 行：列「' + column.label + '」不是有效数字（实际为 ' +
              describeCellValue(value) + '）'
            ));
            return;
          }
          if (column.type !== 'number' && typeof value !== column.type) {
            rowErrors.push(makeValidationError(
              rowNo, column.key, column.label, 'TYPE_MISMATCH',
              '第 ' + rowNo + ' 行：列「' + column.label + '」类型应为 ' + column.type +
              '（实际为 ' + describeCellValue(value) + '）'
            ));
            return;
          }
          if (normalized.checkUnits && column.unit !== null) {
            var unitValue = row[column.unitKey];
            if (unitValue === undefined || unitValue === null ||
              (typeof unitValue === 'string' && unitValue.trim() === '')) {
              rowErrors.push(makeValidationError(
                rowNo, column.unitKey, column.label, 'MISSING_UNIT',
                '第 ' + rowNo + ' 行：列「' + column.label + '」缺少单位（' +
                column.unitKey + '，应填写 "' + column.unit + '"）'
              ));
            } else if (String(unitValue).trim() !== column.unit) {
              rowErrors.push(makeValidationError(
                rowNo, column.unitKey, column.label, 'UNIT_MISMATCH',
                '第 ' + rowNo + ' 行：列「' + column.label + '」单位应为 "' + column.unit +
                '"，实际为 "' + String(unitValue).trim() + '"'
              ));
            }
          }
        });
      }

      errors = errors.concat(rowErrors);
      if (rowErrors.length === 0) {
        validRows.push(row);
        validRowNumbers.push(rowNo);
      }
    });

    return {
      ok: errors.length === 0,
      rowCount: rows.length,
      errorCount: errors.length,
      errors: errors,
      validRows: validRows,
      validRowNumbers: validRowNumbers,
      columnKeys: schemaKeys
    };
  }

  /**
   * 校验实验表格数据：空值、非数字、列数不符、单位列缺失/不匹配。
   * 始终返回结构化结果（绝不抛出未捕获异常），错误信息包含行号与列名。
   *
   * schema 示例：
   *   { columns: [{ key: 'length', label: '摆长 L', unit: 'm' }], minRows: 1 }
   * 每行形如 { length: 0.5, lengthUnit: 'm' }（单位键默认 = key + 'Unit'）。
   */
  function validateTable(rows, schema) {
    try {
      return validateTableUnsafe(rows, schema);
    } catch (err) {
      return {
        ok: false,
        rowCount: Array.isArray(rows) ? rows.length : 0,
        errorCount: 1,
        errors: [makeValidationError(
          0, 'schema', '表结构', 'INVALID_SCHEMA',
          '表结构无效：' + (err && err.message ? err.message : String(err))
        )],
        validRows: [],
        validRowNumbers: []
      };
    }
  }

  /* ------------------------------------------------------------------ *
   * 7. 可独立打开的 HTML 报告
   * ------------------------------------------------------------------ */

  function escapeHtml(value) {
    var text = value === undefined || value === null ? '' : String(value);
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function collectSummaryItems(calc) {
    var items = [];
    function push(label, value, unit) {
      if (typeof value === 'number' && Number.isFinite(value)) {
        items.push({ label: label, value: formatValue(value), unit: unit || '' });
      }
    }
    push('重力加速度 g', calc.g, 'm/s²');
    push('斜率引起的 u₁(g)', calc.uGSlope, 'm/s²');
    push('摆长引起的 u₂(g)', calc.uGLength, 'm/s²');
    push('合成不确定度 u(g)', calc.uG, 'm/s²');
    push('电阻 R', calc.resistance, 'Ω');
    push('电阻不确定度 u(R)', calc.uR, 'Ω');
    push('拟合斜率 k', calc.slope, '');
    push('相关系数 r', calc.r, '');
    push('相对不确定度', calc.relativeUncertaintyPercent, '%');
    if (items.length === 0) push('计算结果', calc.value, '');
    return items;
  }

  function renderSummary(summary) {
    if (summary.length === 0) {
      return '<p class="muted">本次计算结果未包含可展示的数值字段。</p>';
    }
    return '<table class="summary"><tbody>' + summary.map(function (item) {
      return '<tr><th scope="row">' + escapeHtml(item.label) + '</th><td>' +
        escapeHtml(item.value) + (item.unit ? ' <span class="unit">' + escapeHtml(item.unit) +
        '</span>' : '') + '</td></tr>';
    }).join('') + '</tbody></table>';
  }

  function renderComparison(comparison) {
    if (!comparison || typeof comparison !== 'object') {
      return '<p class="muted">未提供与公认值的比较结果。</p>';
    }
    function cell(value) {
      return typeof value === 'number' && Number.isFinite(value)
        ? escapeHtml(formatValue(value))
        : '—';
    }
    function judge(value) {
      if (value === true) return '<span class="pass">成立</span>';
      if (value === false) return '<span class="fail">不成立</span>';
      return '—';
    }
    return '<table class="compare"><tbody>' +
      '<tr><th scope="row">测量值</th><td>' + cell(comparison.measured) + '</td></tr>' +
      '<tr><th scope="row">公认值</th><td>' + cell(comparison.reference) + '</td></tr>' +
      '<tr><th scope="row">绝对偏差</th><td>' + cell(comparison.absError) + '</td></tr>' +
      '<tr><th scope="row">相对误差</th><td>' +
      (typeof comparison.relativeErrorPercent === 'number'
        ? escapeHtml(formatValue(comparison.relativeErrorPercent)) + ' %' : '—') + '</td></tr>' +
      '<tr><th scope="row">2u 判据（|Δ| ≤ 2u）</th><td>' + judge(comparison.within2u) + '</td></tr>' +
      '<tr><th scope="row">扩展不确定度判据（|Δ| ≤ ku）</th><td>' +
      judge(comparison.consistent) + '</td></tr>' +
      '</tbody></table>';
  }

  function renderSteps(steps) {
    return '<table class="steps"><thead><tr>' +
      '<th>#</th><th>步骤</th><th>公式</th><th>代入</th><th>结果</th>' +
      '</tr></thead><tbody>' + steps.map(function (step) {
        var unit = step.unit ? ' ' + step.unit : '';
        return '<tr><td class="no">' + escapeHtml(step.step) + '</td>' +
          '<td>' + escapeHtml(step.title) + '</td>' +
          '<td><code>' + escapeHtml(step.formula) + '</code></td>' +
          '<td>' + escapeHtml(step.substitution) + '</td>' +
          '<td><strong>' + escapeHtml(step.result) + escapeHtml(unit) + '</strong></td></tr>';
      }).join('') + '</tbody></table>';
  }

  /**
   * 生成可独立打开的 HTML 报告字符串（内联样式、无外部依赖）。
   * result: {
   *   title?, simulated?, generatedAt?,
   *   calculation: 计算结果（含 steps；也可直接把计算结果作为 result 传入）,
   *   comparison?: compareWithReference 的返回值
   * }
   * simulated 默认为 true，报告中会显著标注「模拟数据」。
   */
  function buildReportHTML(result) {
    var input = result || {};
    var calc = input.calculation || input.result || input;
    if (!calc || typeof calc !== 'object' || !Array.isArray(calc.steps) || calc.steps.length === 0) {
      throw new TypeError('buildReportHTML 的计算结果必须包含非空 steps（公式步骤）');
    }
    var title = input.title === undefined ? '实验算盘 · 实验数据报告' : String(input.title);
    var simulated = input.simulated !== false;
    var generatedAt = input.generatedAt === undefined
      ? new Date().toISOString()
      : String(input.generatedAt);
    var summary = collectSummaryItems(calc);
    var badgeText = simulated ? '模拟数据' : '真实测量数据';
    var noticeText = simulated
      ? '本报告数据标注为「模拟数据」，仅用于方法演示与教学，不作为真实实验结果。'
      : '本报告数据来源为真实测量记录，请结合原始记录复核。';

    return [
      '<!DOCTYPE html>',
      '<html lang="zh-CN">',
      '<head>',
      '<meta charset="utf-8">',
      '<meta name="viewport" content="width=device-width, initial-scale=1">',
      '<title>' + escapeHtml(title) + '</title>',
      '<style>',
      'body{font-family:-apple-system,"Segoe UI","Noto Sans SC",sans-serif;',
      'margin:0;padding:32px;background:#f5f6f8;color:#1f2328;line-height:1.6}',
      'main{max-width:960px;margin:0 auto;background:#fff;padding:32px;',
      'border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,.08)}',
      'h1{font-size:24px;margin:0 0 8px}h2{font-size:18px;margin:28px 0 12px;',
      'padding-bottom:6px;border-bottom:1px solid #e6e8eb}',
      '.meta{color:#656d76;font-size:13px;margin-bottom:16px}',
      '.badge{display:inline-block;background:#fff4e5;color:#9a5b00;border:1px solid #ffd8a8;',
      'font-size:13px;font-weight:600;padding:2px 10px;border-radius:999px}',
      '.badge.real{background:#e8f5e9;color:#1b5e20;border-color:#a5d6a7}',
      '.notice{background:#fff8e1;border-left:4px solid #f0a500;padding:10px 14px;',
      'font-size:13px;margin:12px 0 0}',
      '.notice.real{background:#eef7ee;border-left-color:#2e7d32}',
      'table{width:100%;border-collapse:collapse;font-size:14px;margin:8px 0}',
      'th,td{border:1px solid #e6e8eb;padding:8px 10px;text-align:left;vertical-align:top}',
      'th{background:#f6f8fa;font-weight:600}',
      '.summary th{width:42%}.summary .unit{color:#656d76}',
      '.steps .no{width:36px;text-align:center;color:#656d76}',
      '.steps code{font-size:13px;background:#f6f8fa;padding:1px 4px;border-radius:4px}',
      '.pass{color:#1b5e20;font-weight:600}.fail{color:#b3261e;font-weight:600}',
      '.muted{color:#656d76}footer{margin-top:28px;color:#656d76;font-size:12px}',
      '</style>',
      '</head>',
      '<body>',
      '<main>',
      '<header>',
      '<h1>' + escapeHtml(title) + '</h1>',
      '<p class="meta">生成时间：' + escapeHtml(generatedAt) + ' · 计算工具：实验算盘</p>',
      '<span class="badge' + (simulated ? '' : ' real') + '">' + escapeHtml(badgeText) + '</span>',
      '<p class="notice' + (simulated ? '' : ' real') + '">' + escapeHtml(noticeText) + '</p>',
      '</header>',
      '<section><h2>计算结果</h2>' + renderSummary(summary) + '</section>',
      '<section><h2>与公认值比较</h2>' + renderComparison(input.comparison) + '</section>',
      '<section><h2>计算步骤与公式</h2>' + renderSteps(calc.steps) + '</section>',
      '<footer>由「实验算盘」自动生成 · 所有数值均由程序计算，公式与代入值一并列出以便复核。</footer>',
      '</main>',
      '</body>',
      '</html>'
    ].join('\n');
  }

  return {
    // 常量
    PI: PI,
    SQRT3: SQRT3,
    GRUBBS_ALPHA: GRUBBS_ALPHA,
    // 统计与不确定度
    mean: mean,
    sampleStdDev: sampleStdDev,
    uncertaintyA: uncertaintyA,
    uncertaintyB: uncertaintyB,
    combinedUncertainty: combinedUncertainty,
    relativeUncertainty: relativeUncertainty,
    // 拟合
    fitLinear: fitLinear,
    // 异常值（默认且唯一：格拉布斯 α = 0.05；3σ 仅保留为对照实现）
    detectOutliers: detectOutliers,
    detectOutliers3Sigma: detectOutliers3Sigma,
    grubbsTest: grubbsTest,
    grubbsResiduals: grubbsResiduals,
    grubbsCriticalValue: grubbsCriticalValue,
    rejectOutliers: rejectOutliers,
    // 实验项目
    pendulumGravity: pendulumGravity,
    ohmsLawResistance: ohmsLawResistance,
    // 与公认值比较
    compareWithReference: compareWithReference,
    // 表格校验与报告
    validateTable: validateTable,
    buildReportHTML: buildReportHTML,
    escapeHtml: escapeHtml,
    // 展示工具
    formatValue: formatValue,
    formatSteps: formatSteps
  };
}));