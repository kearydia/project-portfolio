/* 实验算盘 · 界面层（只负责交互与展示，所有数字来自 engine.js / calc.js / codearts_calc.js） */
(function () {
  'use strict';
  const E = globalThis.LabEngine, C = globalThis.PhysCalc, K = globalThis.PhysicsCalc, V = globalThis.LabVerify;
  const SAMPLES = globalThis.SAMPLE_DATA || {};
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = (x, p = 6) => !Number.isFinite(x) ? '—' : (Math.abs(x) >= 1e5 || (x !== 0 && Math.abs(x) < 1e-3)) ? x.toExponential(p - 1).replace(/e\+?(-?)(\d+)/, (m, s, d) => '×10' + (s ? '⁻' : '') + d.split('').map(c => '⁰¹²³⁴⁵⁶⁷⁸⁹'[c]).join('')) : String(Number(x.toPrecision(p)));
  // 仅转换展示副本；引擎里的公式、代入值和计算结果保持原样。
  function pretty(value, formatNumbers = false) {
    if (typeof value === 'number') return num(value, 6);
    let text = String(value == null ? '' : value);
    const symbols = { pi: 'π', Delta: 'Δ', delta: 'δ', rho: 'ρ', lambda: 'λ', sigma: 'σ', alpha: 'α', gamma: 'γ', theta: 'θ', nu: 'ν', sum: 'Σ', cdot: '·', times: '×', Rightarrow: '⇒', ln: 'ln', sin: 'sin', min: 'min' };
    text = text.replace(/\\(mathrm|text)\{([^{}]*)\}/g, '$2').replace(/\\bar\{([^{}]*)\}/g, '$1̄')
      .replace(/\\([a-zA-Z]+)/g, (all, key) => symbols[key] || all).replace(/\\[,;! ]|\\quad\b/g, ' ')
      .replace(/_\{([^{}]*)\}/g, '_$1').replace(/\^\{([^{}]*)\}/g, '^$1');
    let previous;
    do {
      previous = text;
      text = text.replace(/\\frac\{([^{}]*)\}\{([^{}]*)\}/g, '(($1)/($2))').replace(/\\sqrt\{([^{}]*)\}/g, '√($1)');
    } while (text !== previous);
    const names = { rho: 'ρ', rho0: 'ρ₀', lambda: 'λ', sigma: 'σ', alpha: 'α', gamma: 'γ', theta: 'θ', nu: 'ν', wallCorr: '管壁修正', bottomCorr: '管底修正' };
    text = text.replace(/\bfit\.(slope|intercept|r)\b/g, (all, key) => ({ slope: 'b', intercept: 'a', r: 'r' }[key]))
      .replace(/\b(mean|params)\.([A-Za-z][\w]*)/g, (all, kind, key) => (names[key] || key) + (kind === 'mean' ? '̄' : ''))
      .replace(/\b(wallCorr|bottomCorr)\b/g, key => names[key]).replace(/\^2(?!\d)/g, '²').replace(/\^3(?!\d)/g, '³');
    if (formatNumbers) text = text.replace(/(?<![\p{L}\p{Nd}_.])(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?(?![\p{L}\p{Nd}_.])/gu, x => num(Number(x), 6));
    return text;
  }
  // 结果符号只改显示：代码里的键名（gamma、lambda 等）换成常用符号。
  const SYM = { gamma: 'γ', lambda: 'λ', alpha: 'α', rho: 'ρ', sigma: 'σ', KH: 'K_H', Ex: 'E_x', Rx: 'R_x', I0: 'I₀', c0: 'c₀' };
  const symOf = key => SYM[key] || key;
  const displayStep = s => ({ title: pretty(s.title), formula: pretty(s.formula), substitution: pretty(s.substitution, true), result: pretty(s.result, true), unit: s.unit || '' });
  const reg = E.registry(globalThis.EXP_TEMPLATES || []);
  const S = { tpl: null, rows: [], source: '', simulated: false, cat: '全部', query: '', params: {}, deltas: {}, reference: '', result: null, openItem: null, outlier: null, autoExcluded: [], ai: '', stage: 1, dirty: false, animate: false, hoverIndex: null, openingClosed: false };
  const categoryClass = c => ({ '力学': 'cat-mechanics', '热学': 'cat-heat', '电磁学': 'cat-electricity', '光学': 'cat-optics', '近代物理': 'cat-modern' }[c] || 'cat-mechanics');
  const reducedMotion = () => typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function closeOpening() {
    const opening = $('opening'); if (opening.hidden || S.openingClosed) return;
    S.openingClosed = true;
    if (reducedMotion()) opening.hidden = true;
    else { opening.classList.add('opening-closing'); setTimeout(() => { opening.hidden = true; }, 180); }
  }
  function enter(id, className, active) {
    const el = $(id); el.classList.remove(className);
    if (active && !reducedMotion()) { void el.offsetWidth; el.classList.add(className); }
  }

  /* ---------- 实验选择 ---------- */
  function renderCats() {
    $('cats').innerHTML = ['全部', ...E.CATEGORIES].map(c => '<button role="tab" aria-selected="' + (S.cat === c) + '" class="cat ' + categoryClass(c) + (S.cat === c ? ' on' : '') + '" data-cat="' + c + '">' + c + '</button>').join('');
  }
  function renderList() {
    const list = E.search(reg.templates, S.query, S.cat);
    $('tpl-list').innerHTML = list.length ? E.CATEGORIES.map(category => {
      const group = list.filter(t => t.category === category); if (!group.length) return '';
      return '<section class="tpl-group ' + categoryClass(category) + '"><h3 class="tpl-group-title">' + esc(category) + '<span>' + group.length + '</span></h3>' + group.map(t => {
        const icon = (globalThis.EXP_ICONS || {})[t.id] || '';
        const content = '<span class="tpl-icon" aria-hidden="true">' + icon + '</span><b class="tpl-name">' + esc(t.name) + '</b>';
        return t.verified === true ? '<button class="tpl' + (S.tpl && S.tpl.id === t.id ? ' on' : '') + '" data-id="' + t.id + '" aria-pressed="' + !!(S.tpl && S.tpl.id === t.id) + '" title="' + esc(t.name + '：' + t.summary) + '">' + content + '</button>'
          : '<div class="tpl off" aria-disabled="true" title="' + esc(t.summary + '；该模板尚未通过验证，暂不可用') + '">' + content + '</div>';
      }).join('') + '</section>';
    }).join('') : '<p class="hint">没有匹配的实验。该分类的模板正在完善中。</p>';
  }
  function selectTemplate(id, loadSample = true, activate = true) {
    const t = reg.templates.find(x => x.id === id && x.verified === true); if (!t) return;
    if (activate) { closeOpening(); if (globalThis.history && typeof history.replaceState === 'function') history.replaceState(null, '', '#tpl=' + t.id); }
    S.tpl = t; S.params = {}; S.deltas = {}; S.reference = ''; S.rows = []; S.result = null; S.openItem = null; S.ai = ''; S.hoverIndex = null;
    $('tip').hidden = true;
    renderList(); renderParams();
    $('columns-hint').textContent = 'CSV 需要的列：' + t.inputs.map(i => i.key + '(' + i.unit + ') ' + i.label).join('，') + '；单次测量量只需写在第一行；以 # 开头的行为注释。';
    if (loadSample) loadSampleData(); else update();
    enter('workspace', 'workspace-enter', activate);
  }

  /* ---------- 参数 ---------- */
  function renderParams() {
    const t = S.tpl; if (!t) { $('params').innerHTML = ''; return; }
    const inputNumber = value => { const n = Number(value); return value !== '' && Number.isFinite(n) && (Math.abs(n) >= 1e6 || (n !== 0 && Math.abs(n) < 1e-3)) ? n.toExponential().replace('e+', 'e') : value; };
    const deltaLabel = p => { const label = p.label.replace(/[（(].*$/, '').trim(), symbol = label.match(/([A-Za-zΑ-ω][A-Za-zΑ-ω₀-₉]*)$/u); return 'Δ' + (symbol ? symbol[1] : pretty(symOf(p.key))); };
    const f = (key, label, value, unit, kind) => '<label>' + esc(label) + '<span class="unit">' + esc(unit || '') + '</span><input data-' + kind + '="' + esc(key) + '" value="' + esc(inputNumber(value)) + '" inputmode="decimal"></label>';
    let h = '<div class="pgroup"><b>仪器误差 Δ仪</b>' + t.inputs.map(i => f(i.key, i.label, S.deltas[i.key] ?? i.instrumentError ?? 0, i.unit, 'delta')).join('') + '</div>';
    if ((t.params || []).length) h += '<div class="pgroup"><b>实验参数</b>' + t.params.map(p => p.type === 'switch'
      ? '<label class="switch"><input type="checkbox" data-switch="' + esc(p.key) + '"' + (Number(S.params[p.key] ?? p.default) === 1 ? ' checked' : '') + '> ' + esc(p.label) + '</label><p class="hint">' + esc(p.note || '只有勾选后才改变结果。') + '</p>'
      : f(p.key, p.label, S.params[p.key] ?? p.default, p.unit, 'param') + (p.instrumentError !== undefined ? f('Δ' + p.key, deltaLabel(p), S.params['Δ' + p.key] ?? p.instrumentError, p.unit, 'param') : '')).join('') + '</div>';
    h += '<div class="pgroup"><b>公认值</b>' + f('ref', t.result.label, S.reference !== '' ? S.reference : t.accepted.value, t.accepted.unit, 'ref') + '<p class="hint">' + esc(t.accepted.note || '') + '</p></div>';
    $('params').innerHTML = h;
  }

  /* ---------- 数据导入 ---------- */
  function loadCSV(text, source) {
    const parsed = E.parseCSV(text, S.tpl);
    S.source = source; S.result = null; S.openItem = null;
    if (!parsed.ok) { S.rows = []; showError('数据有问题，未进行计算：', parsed.errors); $('source').textContent = '来源：' + source; renderAll(); return; }
    hideError(); S.simulated = parsed.simulated;
    const a = E.autoExclude(S.tpl, parsed.rows, { params: S.params });
    S.rows = a.rows; S.autoExcluded = a.outlier.indices; S.stage = Math.max(S.stage, 2);
    $('source').innerHTML = '来源：' + esc(source) + (S.simulated ? ' <span class="sim">模拟数据</span>' : '');
    S.animate = true; update();
  }
  function loadSampleData() { const text = E.sampleText(S.tpl, SAMPLES), name = String(S.tpl.sampleCsv).includes('\n') ? S.tpl.id + '_模拟数据（模板内置）' : String(S.tpl.sampleCsv).split('/').pop(); if (text) loadCSV(text, name); else showError('未找到示例数据 ' + name, []); }
  function readFile(file) {
    if (!file) return;
    closeOpening();
    if (/\.xlsx?$/i.test(file.name)) { showError('暂不直接读取 Excel 文件：请在 Excel/WPS 中“另存为 CSV（UTF-8）”后再上传。', []); return; }
    const reader = new FileReader(); reader.onload = () => loadCSV(String(reader.result), file.name); reader.onerror = () => showError('文件读取失败：' + file.name, []); reader.readAsText(file, 'utf-8');
  }

  /* ---------- 计算与渲染 ---------- */
  function update() {
    if (!S.tpl) return;
    if (!S.rows.length) { S.result = null; renderAll(); return; }
    try {
      S.result = E.process(S.tpl, S.rows, { params: S.params, deltas: S.deltas, reference: S.reference, useT: $('use-t').checked, coverage: Number($('coverage').value) });
      hideError();
    } catch (e) { S.result = null; showError('无法计算：' + e.message, []); }
    renderAll();
  }
  function renderAll() { renderResult(); renderChart(); renderTable(); renderBanner(); renderExplain(); renderConventions(); renderStage(); enter('sec-result', 'result-enter', S.animate); enter('chart', 'chart-enter', S.animate); S.animate = false; }
  function showError(title, list) { $('error').hidden = false; $('error').innerHTML = '<b>' + esc(title) + '</b>' + (list.length ? '<ul>' + list.map(m => '<li>' + esc(m) + '</li>').join('') + '</ul>' : ''); }
  function hideError() { $('error').hidden = true; $('error').innerHTML = ''; }
  function renderStage() { [1, 2, 3].forEach(i => $('step-' + i).classList.toggle('on', S.stage === i)); [1, 2, 3].forEach(i => $('step-' + i).classList.toggle('done', S.stage > i)); }
  function renderBanner() {
    const b = $('banner'); const r = S.result;
    if (!r) { b.hidden = true; return; }
    const o = r.outlier, excluded = S.rows.map((x, i) => x.excluded ? i : -1).filter(i => i >= 0);
    if (o.indices.length) {
      const i = o.indices[0], isEx = S.rows[i] && S.rows[i].excluded;
      b.hidden = false;
      const detail = o.criterion + '：G=' + num(o.statistic) + ' > G临界=' + num(o.critical) + '；' + o.note + (S.tpl.method === 'successive_diff' ? '；逐差法要求等间隔成对数据，仅提示、不自动剔除，请核对原始记录。' : '；当前使用 ' + r.included + '/' + r.total + ' 个点。');
      b.innerHTML = '<span title="' + esc(detail) + '">第 ' + (i + 1) + ' 行疑似异常（格拉布斯 G=' + o.statistic.toFixed(2) + '&gt;' + o.critical.toFixed(2) + '），' + (isEx ? '已剔除' : '参与计算') + '</span><button class="btn small" data-act="' + (isEx ? 'restore-outlier' : 'exclude-outlier') + '">' + (isEx ? '恢复' : '剔除') + '</button>';
    } else if (excluded.length) { b.hidden = false; b.innerHTML = '<span>已手动剔除第 ' + excluded.map(i => i + 1).join('、') + ' 行。</span><button class="btn small" data-act="restore-all">全部恢复</button>'; }
    else { b.hidden = true; b.innerHTML = ''; return; }
    b.className = 'alert warn';
  }
  function renderResult() {
    const r = S.result, t = S.tpl;
    $('tpl-name').textContent = t ? t.name + '（' + t.category + '）' : '';
    if (!r) { $('main-value').textContent = '—'; $('main-meta').textContent = t ? '请上传数据或加载示例数据' : '请先选择实验'; $('main-value').disabled = true; $('badge').className = 'badge'; $('badge').textContent = ''; $('key-metrics').innerHTML = ''; $('items').innerHTML = ''; $('steps').hidden = true; return; }
    $('main-value').innerHTML = '<span class="sym">' + esc(symOf(t.result.key)) + ' =</span> ' + esc(r.formatted);
    $('main-value').disabled = false; $('main-value').dataset.item = String(r.items.findIndex(it => it.main));
    $('main-meta').innerHTML = '公认值 ' + esc(num(r.reference)) + ' ' + esc(t.result.unit) + ' · 使用 ' + r.included + '/' + r.total + ' 个数据点' + (r.core ? ' · 已交叉校验' : '') + ' · 点数字可看过程';
    const cls = { '一致': 'good', '基本一致': 'mid', '偏差显著': 'bad' }[r.comparison.verdict];
    $('badge').className = 'badge ' + cls; $('badge').innerHTML = '<b>' + r.comparison.verdict + '</b><span>|x−x₀| ' + (r.comparison.within2u ? '≤' : '>') + ' 2u</span>';
    const metrics = ['result.u', 'compare', 'fit.r'];
    const itemButton = (it, k, cls, label = it.label) => '<button class="' + cls + (S.openItem === k ? ' open' : '') + '" data-item="' + k + '" aria-expanded="' + (S.openItem === k) + '"><span>' + esc(pretty(label)) + '</span><b>' + esc(num(it.value)) + '</b><i>' + esc(it.unit) + '</i></button>';
    $('key-metrics').innerHTML = metrics.map(key => { const k = r.items.findIndex(it => it.key === key); return k < 0 ? '' : itemButton(r.items[k], k, 'metric', { 'result.u': '合成不确定度 u', compare: '相对误差', 'fit.r': '相关系数 r' }[key]); }).join('') + '<div class="metric"><span>相对不确定度</span><b>' + num(r.relU, 3) + '</b><i>%</i></div>';
    const switches = new Set((t.params || []).filter(p => p.type === 'switch').map(p => 'params.' + p.key));
    $('items').innerHTML = r.items.map((it, k) => it.main || metrics.includes(it.key) || switches.has(it.key) ? '' : itemButton(it, k, 'item')).join('');
    renderSteps();
  }
  function renderSteps() {
    const r = S.result, el = $('steps'); if (!r || S.openItem == null || !r.items[S.openItem]) { el.hidden = true; return; }
    const it = r.items[S.openItem]; el.hidden = false;
    const stepsHTML = steps => '<ol>' + steps.map(displayStep).map(s => '<li>' + (s.title ? '<em>' + esc(s.title) + '</em>' : '') + '<code>' + esc(s.formula) + '</code><span class="sub">' + esc(s.substitution) + '</span><b>= ' + esc(s.result) + (s.unit ? ' ' + esc(s.unit) : '') + '</b></li>').join('') + '</ol>';
    // 偏导逐项留在完整推导；预览按原顺序优先呈现测量与修正步骤。
    const keySteps = it.steps.filter(s => !/∂[^=]*\/∂|偏导/.test(String(s.formula) + ' ' + String(s.title)));
    const limit = S.tpl.id === 'pendulum_fit' ? 6 : 8;
    const preview = keySteps.length > limit ? keySteps.slice(0, limit - 1).concat(keySteps.slice(-1)) : keySteps;
    el.innerHTML = '<h3>计算过程：' + esc(pretty(it.label)) + ' = ' + esc(num(it.value, 6)) + ' ' + esc(it.unit) + '</h3>' + (it.steps.length ? stepsHTML(preview) + (preview.length < it.steps.length ? '<details><summary>展开完整推导（' + it.steps.length + ' 步）</summary>' + stepsHTML(it.steps) + '</details>' : '') : '<p class="hint">该量为输入参数，直接取自参数面板。</p>');
  }
  function chartSVG(chart, outliers, interactive = true) {
    const W = 760, H = 420, L = 78, Rm = 24, T = 64, B = 58;
    const pts = chart.points.filter(p => Number.isFinite(p.x) && Number.isFinite(p.y)); if (!pts.length) return '';
    const xs = pts.map(p => p.x), ys = pts.map(p => p.y);
    const tx = C.niceTicks(Math.min(...xs), Math.max(...xs)), ty = C.niceTicks(Math.min(...ys), Math.max(...ys));
    const X = x => L + (x - tx.min) / (tx.max - tx.min) * (W - L - Rm), Y = y => H - B - (y - ty.min) / (ty.max - ty.min) * (H - T - B);
    const lab = (v, t) => Math.abs(t.step) < 1e-3 || Math.abs(t.max) >= 1e5 ? v.toExponential(1) : v.toFixed(t.decimals);
    let s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" class="svg" role="' + (interactive ? 'group' : 'img') + '" aria-label="数据图像"><rect width="' + W + '" height="' + H + '" fill="var(--sheet)"/>';
    s += '<g aria-label="图例" font-size="14" fill="var(--ink-soft)"><circle cx="320" cy="24" r="5" fill="var(--data)"/><text x="331" y="29">参与计算</text><circle cx="421" cy="24" r="5" fill="var(--sheet)" stroke="var(--ink-soft)" stroke-width="2"/><text x="432" y="29">已剔除</text><circle cx="510" cy="24" r="7.5" fill="var(--sheet)" stroke="var(--outlier)" stroke-width="2"/><text x="523" y="29">格拉布斯异常</text><line x1="628" y1="24" x2="651" y2="24" stroke="var(--brand)" stroke-width="2.5"/><text x="658" y="29">拟合线</text></g>';
    s += '<defs><clipPath id="plot-area"><rect x="' + L + '" y="' + T + '" width="' + (W - L - Rm) + '" height="' + (H - T - B) + '"/></clipPath></defs>';
    tx.ticks.forEach(v => { s += '<line x1="' + X(v) + '" y1="' + T + '" x2="' + X(v) + '" y2="' + (H - B) + '" stroke="var(--grid)"/><text class="tick" x="' + X(v) + '" y="' + (H - B + 18) + '" text-anchor="middle" font-size="14" fill="var(--ink-soft)">' + lab(v, tx) + '</text>'; });
    ty.ticks.forEach(v => { s += '<line x1="' + L + '" y1="' + Y(v) + '" x2="' + (W - Rm) + '" y2="' + Y(v) + '" stroke="var(--grid)"/><text class="tick" x="' + (L - 8) + '" y="' + (Y(v) + 4) + '" text-anchor="end" font-size="14" fill="var(--ink-soft)">' + lab(v, ty) + '</text>'; });
    s += '<path d="M' + L + ',' + T + 'V' + (H - B) + 'H' + (W - Rm) + '" stroke="var(--ink-soft)" fill="none"/>';
    if (chart.line && Number.isFinite(chart.line.slope) && Number.isFinite(chart.line.intercept)) {
      const f = x => chart.line.intercept + chart.line.slope * x;
      // 「名称 / 单位」形式的坐标轴：方程里只写名称，单位放在括号里；斜率为 0（平均值线）时只写平均值。
      const axis = label => String(label).replace(/\s*[（(][^()（）]*[)）]\s*$/, '').split(/\s+\/\s+/);
      const ax = axis(chart.xLabel), ay = axis(chart.yLabel);
      const units = [ax, ay].filter(a => a.length === 2).map(a => a[0] + '：' + a[1]).join('，');
      const equation = chart.line.slope === 0 ? '平均值 ' + ay[0] + ' = ' + num(chart.line.intercept, 4)
        : ay[0] + ' = ' + num(chart.line.slope, 4) + ' × ' + ax[0] + (chart.line.intercept < 0 ? ' − ' : ' + ') + num(Math.abs(chart.line.intercept), 4) + (units ? '（' + units + '）' : '');
      s += '<line class="fit-line" pathLength="1" x1="' + X(tx.min) + '" y1="' + Y(f(tx.min)) + '" x2="' + X(tx.max) + '" y2="' + Y(f(tx.max)) + '" stroke="var(--brand)" stroke-width="2.5" clip-path="url(#plot-area)"/>';
      s += '<text class="fit-equation" x="' + (W - Rm) + '" y="50" text-anchor="end" font-size="14" fill="var(--brand)">' + esc(equation) + '</text>';
    }
    pts.forEach((p, order) => { const flag = outliers.includes(p.index), c = flag ? '#e5484d' : p.excluded ? '#9aa6bb' : '#0e8a83', token = flag ? '--outlier' : p.excluded ? '--ink-soft' : '--data';
      // 保留 P0 的 stroke/fill 属性契约，实际呈色统一由主题变量控制。
      const action = interactive ? ' tabindex="0" role="button" aria-label="第 ' + (p.index + 1) + ' 行，' + (p.excluded ? '已剔除，按下恢复' : '参与计算，按下剔除') + '"' : '';
      s += '<circle class="pt" data-index="' + p.index + '" data-x="' + p.x + '" data-y="' + p.y + '" cx="' + X(p.x) + '" cy="' + Y(p.y) + '" r="' + (flag ? 7.5 : 6) + '" fill="' + (flag || p.excluded ? '#fff' : c) + '" stroke="' + c + '" style="stroke:var(' + token + ');fill:var(' + (flag || p.excluded ? '--sheet' : token) + ');--point-delay:' + Math.round(order / Math.max(1, pts.length - 1) * 220) + 'ms" stroke-width="2.4"' + action + '><title>第 ' + (p.index + 1) + ' 行：x=' + num(p.x) + '，y=' + num(p.y) + (p.excluded ? '（已剔除）' : '') + '</title></circle>';
      if (flag) s += '<text x="' + Math.max(L + 4, Math.min(W - Rm - 106, X(p.x) + 12)) + '" y="' + Math.max(T + 14, Y(p.y) - 12) + '" font-size="14" fill="var(--outlier)" stroke="var(--sheet)" stroke-width="3" paint-order="stroke" pointer-events="none">第 ' + (p.index + 1) + ' 行' + (p.excluded ? ' 已剔除' : '') + '</text>';
    });
    s += '<text x="' + (L + (W - L - Rm) / 2) + '" y="' + (H - 14) + '" text-anchor="middle" font-size="14" fill="var(--ink)">' + esc(chart.xLabel) + '</text><text transform="translate(18,' + (T + (H - T - B) / 2) + ') rotate(-90)" text-anchor="middle" font-size="14" fill="var(--ink)">' + esc(chart.yLabel) + '</text></svg>';
    return s;
  }
  function renderChart() { const r = S.result; $('chart').innerHTML = r ? chartSVG(r.chart, r.outlier.indices) : '<p class="hint empty">加载数据后显示图像</p>'; refreshTip(); }
  function refreshTip() {
    const r = S.result, i = S.hoverIndex, p = r && r.chart.points.find(p => p.index === i);
    const tip = $('tip'); if (!p || !S.rows[i]) { tip.hidden = true; return; }
    tip.hidden = false; tip.innerHTML = '第 ' + (i + 1) + ' 行<br>' + esc(r.chart.xLabel) + '：<b>' + num(p.x) + '</b><br>' + esc(r.chart.yLabel) + '：<b>' + num(p.y) + '</b><br>' + (S.rows[i].excluded ? '已剔除 · 点击恢复' : '参与计算 · 点击剔除');
  }
  function renderTable() {
    const t = S.tpl; if (!t) { $('table').innerHTML = ''; return; }
    const cols = t.inputs, out = S.result ? S.result.outlier.indices : [];
    $('table').innerHTML = '<thead><tr><th>保留</th><th>#</th>' + cols.map(c => '<th>' + esc(c.label) + ' (' + esc(c.unit) + ')</th>').join('') + '<th>状态</th></tr></thead><tbody>' +
      S.rows.map((r, i) => '<tr class="' + (r.excluded ? 'ex' : '') + (out.includes(i) ? ' flag' : '') + '"><td><input type="checkbox" data-keep="' + i + '"' + (r.excluded ? '' : ' checked') + '></td><td>' + (i + 1) + '</td>' + cols.map(c => '<td><input class="cell" data-row="' + i + '" data-col="' + c.key + '" value="' + esc(r.values[c.key]) + '"></td>').join('') + '<td>' + (out.includes(i) ? '<span class="pill red">疑似异常</span>' : '') + (r.excluded ? '<span class="pill gray">已剔除</span>' : '<span class="pill green">参与计算</span>') + '</td></tr>').join('') + '</tbody>';
  }
  function renderConventions() {
    const c = S.result ? S.result.conventions : { typeA: 'u_A=s/√n（t 因子默认关闭，可在参数区开启）', typeB: 'u_B=Δ仪/√3（均匀分布）', compare: 'k=2：|x−x₀|≤2u_C 判为一致', outlier: '格拉布斯检验（α=0.05）' };
    $('conventions').innerHTML = ['A 类：' + c.typeA, 'B 类：' + c.typeB, '合成：u_C=√(u_A²+u_B²)；间接量按各输入互不相关，用偏导数传递', '拟合：u(b)=√(u_A²+u_B²)，u_A(b)=s_e/√S_xx，u_B(b)=u_B(y′)/√S_xx（y 列 Δ仪/√3 换算到 y′，取各点方均根）；x 列仪器误差不计入', '比较：' + c.compare + '；≤3u_C 为基本一致', '异常值：唯一判据 ' + c.outlier + '，默认剔除，可恢复', '修约：不确定度保留 1~2 位有效数字，测量值末位与之对齐'].map(x => '<li>' + esc(x) + '</li>').join('');
  }
  function ruleExplain(r) {
    const t = r.tpl, lines = ['以下内容根据已算好的结果按固定规则生成，不会改动任何数字。'];
    lines.push('与公认值比较：结论为“' + r.comparison.verdict + '”。' + (r.comparison.verdict === '一致' ? '测量值与公认值之差在 2 倍合成不确定度以内，说明本次测量没有明显系统误差。' : '差值超出 2 倍合成不确定度，说明可能存在未计入的系统误差，请优先检查下列误差来源。'));
    const fr = r.items.find(i => i.key === 'fit.r'); if (fr) lines.push(Math.abs(fr.value) >= 0.999 ? '数据线性关系很好，拟合结果可信。' : '线性相关系数偏低，数据离散较大，建议检查读数或增加测量点。');
    if (r.outlier.indices.length) lines.push('格拉布斯检验检出 1 个疑似异常点，常见原因是读数/记录错误或操作失误；剔除后应在报告中说明原因，不能只为接近公认值而删点。');
    if (r.relU > 2) lines.push('相对不确定度偏大，主要应减小离散度（增加测量次数）或换用更精密的仪器。');
    if ((t.errorSources || []).length) lines.push('本实验主要误差来源：' + t.errorSources.join('；') + '。'); else lines.push('误差来源提示：请检查各直接测量量的仪器误差、读数方法与实验条件（温度、对准、零点）。从“计算过程”中各偏导项的大小可以看出哪个量对结果不确定度贡献最大，应优先改进它的测量。');
    if ((t.suggestions || []).length) lines.push('改进建议：' + t.suggestions.join('；') + '。');
    return lines;
  }
  function renderExplain() { const r = S.result; $('explain').innerHTML = r ? '<ul>' + ruleExplain(r).map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '<p class="hint">计算完成后自动生成。</p>'; }
  function renderVerify() {
    if (!V) return;
    const res = V.run(E, reg.templates, SAMPLES);
    $('verify').innerHTML = res.map(c => '<details' + (c.id === 'A' ? ' open' : '') + '><summary>' + (c.ok ? '通过' : '未通过') + ' · 数据 ' + c.id + '：' + esc(c.title) + '</summary>' + (c.error ? '<p class="alert error">' + esc(c.error) + '</p>' : '<table class="vt"><thead><tr><th>量</th><th>程序结果</th><th>独立计算</th><th>相对差</th><th></th></tr></thead><tbody>' + c.rows.map(x => '<tr><td>' + esc(x.label) + '</td><td>' + esc(num(x.got, 10)) + '</td><td>' + esc(num(x.expected, 10)) + '</td><td>' + x.rel.toExponential(1) + '</td><td>' + (x.rel < 1e-3 ? '&lt;0.1%' : '超差') + '</td></tr>').join('') + '</tbody></table>') + '</details>').join('') + '<p class="hint">独立计算值来自纯 Python 脚本（不调用本项目代码），数据为手算验证用小数据集，非教材例题。</p>';
  }

  /* ---------- 报告导出（基于码道核心 buildReportHTML，补充数据表/图像/解释） ---------- */
  function reportHTML() {
    const r = S.result, t = S.tpl; if (!r) throw new Error('请先完成计算');
    const steps = [], seen = new Set();
    r.items.forEach(it => it.steps.forEach(original => {
      const s = displayStep({ ...original, title: original.title || it.label });
      // 同一个量在码道核心和通用引擎里各算一次时，代入式和结果相同，只保留第一次。
      // 只合并代入了具体数值的步骤（含两位以上数字或小数），避免把“仪器误差 Δ/√3”“0”这类通用写法误合并。
      const sub = String(s.substitution).replace(/\s+/g, ''), key = /\d{2,}|\d\.\d/.test(sub) ? JSON.stringify([sub, String(s.result).replace(/\s+/g, '')]) : JSON.stringify([s.formula, s.substitution, s.result]);
      if (!seen.has(key)) { seen.add(key); steps.push({ ...s, step: steps.length + 1 }); }
    }));
    let html = K.buildReportHTML({ title: '实验算盘 · ' + t.name + ' · 数据处理报告', simulated: S.simulated, generatedAt: new Date().toLocaleString('zh-CN'), calculation: { steps, value: r.value }, comparison: r.comparison });
    const unit = t.result.unit || '';
    const formattedValue = unit && r.formatted.endsWith(' ' + unit) ? r.formatted.slice(0, -unit.length).trim() : r.formatted;
    const summary = '<section><h2>计算结果</h2><table class="result-summary"><thead><tr><th>量</th><th>值 ± 不确定度</th><th>单位</th></tr></thead><tbody><tr><td>' + esc(symOf(t.result.key)) + '</td><td>' + esc(formattedValue) + '</td><td>' + esc(unit) + '</td></tr></tbody></table></section>';
    const measured = value => esc(num(value, 6)) + (unit ? ' ' + esc(unit) : '');
    const judge = value => value === true ? '成立' : value === false ? '不成立' : '—';
    const comparison = '<section><h2>与公认值比较</h2><table class="compare"><tbody>' +
      '<tr><th scope="row">测量值</th><td>' + measured(r.value) + '</td></tr>' +
      '<tr><th scope="row">公认值</th><td>' + measured(r.reference) + '</td></tr>' +
      '<tr><th scope="row">绝对偏差</th><td>' + measured(r.comparison.absError) + '</td></tr>' +
      '<tr><th scope="row">相对误差</th><td>' + esc(num(r.comparison.relativeErrorPercent, 6)) + ' %</td></tr>' +
      '<tr><th scope="row">2u 判据（|Δ| ≤ 2u）</th><td>' + judge(r.comparison.within2u) + '</td></tr>' +
      '<tr><th scope="row">扩展不确定度判据（|Δ| ≤ ku）</th><td>' + judge(r.comparison.consistent) + '</td></tr>' +
      '<tr><th scope="row">结论</th><td>' + esc(r.comparison.verdict) + '</td></tr></tbody></table></section>';
    html = html.replace(/<section><h2>计算结果<\/h2>[\s\S]*?<\/section>/, summary)
      .replace(/<section><h2>与公认值比较<\/h2>[\s\S]*?<\/section>/, comparison);
    const cols = t.inputs;
    const extra = '<section><h2>最终结果</h2><p style="font-size:22px"><b>' + esc(t.result.label) + ' = ' + esc(r.formatted) + '</b>（相对不确定度 ' + num(r.relU, 3) + '%，与公认值 ' + esc(num(r.reference)) + ' ' + esc(t.result.unit) + ' 比较：' + esc(r.comparison.verdict) + '，相对误差 ' + num(r.comparison.relativeErrorPercent, 3) + '%）</p><p>计算约定：' + Object.values(r.conventions).map(esc).join('；') + '</p></section>' +
      '<section><h2>原始数据</h2><table><thead><tr><th>#</th>' + cols.map(c => '<th>' + esc(c.label) + ' (' + esc(c.unit) + ')</th>').join('') + '<th>状态</th></tr></thead><tbody>' + S.rows.map((x, i) => '<tr><td>' + (i + 1) + '</td>' + cols.map(c => '<td>' + esc(x.values[c.key]) + '</td>').join('') + '<td>' + (x.excluded ? '已剔除' + (r.outlier.indices.includes(i) ? '（格拉布斯检验判为异常）' : '') : '参与计算') + '</td></tr>').join('') + '</tbody></table><p>数据来源：' + esc(S.source) + (S.simulated ? '（模拟数据）' : '') + '</p></section>' +
      '<section><h2>数据图像</h2>' + chartSVG(r.chart, r.outlier.indices, false) + '</section>' +
      '<section><h2>误差分析建议（仅供参考）</h2><ul>' + ruleExplain(r).map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' + (S.ai ? '<h3>大模型生成的说明</h3><p>' + esc(S.ai).replace(/\n/g, '<br>') + '</p>' : '') + '</section>';
    html = html.replace('<section><h2>计算结果</h2>', extra + '<section><h2>计算结果</h2>').replace('<h1>', '<p class="report-brand">实验算盘 · 大学物理实验数据处理助手 —— <span>算得准，讲得清</span></p><h1>');
    const widths = [4, 18, 28, 36, 14];
    html = html.replace('<table class="steps">', '<table class="steps"><colgroup>' + widths.map(w => '<col style="width:' + w + '%" width="' + w + '%">').join('') + '</colgroup>');
    html = html.replace(/<table\b[\s\S]*?<\/table>/g, table => '<div class="report-table">' + table + '</div>');
    const reportStyle = ':root{--paper:#fff;--sheet:#fff;--grid:#dfe6dc;--grid-major:#c6d4c8;--ink:#1e2a36;--ink-soft:#5a6670;--line:#d9d3c4;--brand:#1f3a5f;--brass:#b8862b;--data:#0e8a83;--outlier:#c8372d;--ok:#2f7d4f;--warn-bg:#fff4dc;--warn-ink:#7a4b00;' +
      '--font-body:"PingFang SC","Microsoft YaHei","Noto Sans SC","Noto Sans CJK SC",system-ui,sans-serif;--font-heading:"Noto Serif SC","Noto Serif CJK SC","Source Han Serif SC","Songti SC","STSong","SimSun",serif;--font-note:"KaiTi","STKaiti","Kaiti SC","Noto Serif SC","Noto Serif CJK SC",serif;--font-mono:"Cascadia Mono","Consolas","SF Mono","Menlo","Noto Sans Mono","Microsoft YaHei","PingFang SC","Noto Sans CJK SC",ui-monospace,monospace}' +
      '*{box-sizing:border-box}body{margin:0;padding:32px;background:var(--paper);color:var(--ink);font:14px/1.7 var(--font-body)}main{min-width:0;max-width:960px;margin:0 auto}section{min-width:0}h1,h2,h3{font-family:var(--font-heading);color:var(--brand)}h1{font-size:26px;margin:12px 0}h2{font-size:19px;margin:26px 0 10px;border-bottom:1px solid var(--line);padding-bottom:6px}h3{font-size:16px}.report-brand{color:var(--brand);font-weight:700;margin:0}.report-brand span{font-family:var(--font-note)}' +
      '.meta,.muted,footer,.steps .no{color:var(--ink-soft);font-size:13px}.badge{display:inline-block;border:1px solid var(--warn-ink);border-radius:4px;color:var(--warn-ink);padding:2px 8px}.badge.real,.pass{color:var(--ok)}.notice{background:var(--warn-bg);color:var(--warn-ink);border-left:2px solid var(--brass);padding:8px 12px}.notice.real{background:var(--sheet);color:var(--ok);border-color:var(--ok)}.fail{color:var(--outlier)}' +
      '.report-table{max-width:100%;overflow-x:auto}table{border-collapse:collapse;table-layout:fixed;width:100%;font-size:14px;margin:8px 0}th,td{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top;overflow-wrap:anywhere;word-break:break-word}th{color:var(--brand);font-weight:600}td,code,svg text{font-family:var(--font-mono);font-variant-numeric:tabular-nums}svg{display:block;max-width:100%;height:auto}.steps .no{width:4%;padding:8px 2px}.steps code{font-size:13px;white-space:normal;overflow-wrap:anywhere}footer{margin-top:28px}' +
      widths.map((w, i) => '.steps th:nth-child(' + (i + 1) + '),.steps td:nth-child(' + (i + 1) + '){width:' + w + '%}').join('') +
      '@media(max-width:600px){body{padding:12px}th,td{padding:6px 4px}}@media print{body{padding:0;background:var(--paper)}main{max-width:none}.report-table{overflow:visible}thead{display:table-header-group}tr,svg,.notice{break-inside:avoid;page-break-inside:avoid}h1,h2,h3{break-after:avoid;page-break-after:avoid}th,td,.badge,.notice{background:transparent;box-shadow:none}}';
    html = html.replace(/<style[^>]*>[\s\S]*?<\/style>/, '<style>' + reportStyle + '</style>');
    // Word 的 HTML 读取器不一定支持 CSS 变量；导出时展开同一套主题值。
    const theme = Object.fromEntries([...reportStyle.matchAll(/(--[\w-]+):([^;}]+)/g)].map(m => [m[1], m[2]]));
    return html.replace(/var\((--[\w-]+)\)/g, (all, name) => theme[name] || all);
  }
  function download(name, text, type) { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + text], { type })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
  function exportReport(kind) {
    try { const h = reportHTML(), base = '实验算盘_' + S.tpl.name.replace(/[\\/:*?"<>|（）()·\s]/g, '').replace(/²/g, '2').replace(/³/g, '3').replace(/–/g, '-') + (S.simulated ? '_模拟数据' : '') + '_报告';
      if (kind === 'doc') download(base + '.doc', h.replace('<html lang="zh-CN">', '<html lang="zh-CN" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">'), 'application/msword'); else download(base + '.html', h, 'text/html;charset=utf-8');
      S.stage = 3; renderStage();
    } catch (e) { showError('导出失败：' + e.message, []); }
  }

  /* ---------- 可选：OpenAI 兼容接口（只发送已算好的结果，Key 仅存内存） ---------- */
  async function askAI() {
    const r = S.result, base = $('api-base').value.trim().replace(/\/+$/, ''), model = $('api-model').value.trim(), key = $('api-key').value.trim();
    if (!r) { $('api-status').textContent = '请先完成计算'; return; }
    if (!base || !model || !key) { $('api-status').textContent = '请填写 Base URL、模型名和 API Key；未填写时使用上方的分析建议。'; return; }
    const payload = { 实验: r.tpl.name, 结果: r.formatted, 相对不确定度百分比: num(r.relU, 3), 公认值: r.reference, 相对误差百分比: num(r.comparison.relativeErrorPercent, 3), 判定: r.comparison.verdict, 剔除点数: r.total - r.included, 异常判据: r.outlier.criterion };
    $('api-status').textContent = '请求中…';
    try {
      const res = await fetch(base + '/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key }, body: JSON.stringify({ model, temperature: 0.3, messages: [
        { role: 'system', content: '你是大学物理实验助教。下面的数值全部由程序精确计算。你只能解释误差来源并给出改进建议，不得给出任何新的数值，不得修改或重新计算已有数值。用中文，分条，200 字以内。' },
        { role: 'user', content: JSON.stringify(payload) }] }) });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json(); S.ai = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';
      $('ai-text').innerHTML = '<p class="tag">仅供参考（模型：' + esc(model) + '）</p><p>' + esc(S.ai).replace(/\n/g, '<br>') + '</p>'; $('api-status').textContent = '完成';
    } catch (e) { $('api-status').textContent = '调用失败（' + e.message + '），已保留上方的分析建议。'; }
  }

  /* ---------- 事件 ---------- */
  document.addEventListener('click', e => {
    if (e.target.closest('button')) closeOpening();
    const el = e.target.closest('[data-cat],[data-id],[data-item],[data-act],circle.pt'); if (!el) return;
    if (el.dataset.cat) { S.cat = el.dataset.cat; renderCats(); renderList(); }
    else if (el.dataset.id) selectTemplate(el.dataset.id);
    else if (el.dataset.item !== undefined) { const k = Number(el.dataset.item); S.openItem = S.openItem === k ? null : k; renderResult(); }
    else if (el.dataset.act) { const i = S.result && S.result.outlier.indices[0];
      if (el.dataset.act === 'restore-outlier') S.rows[i].excluded = false; if (el.dataset.act === 'exclude-outlier') S.rows[i].excluded = true; if (el.dataset.act === 'restore-all') S.rows.forEach(r => { r.excluded = false; }); update(); }
    else if (el.matches('circle.pt')) { const i = Number(el.dataset.index); S.hoverIndex = i; S.rows[i].excluded = !S.rows[i].excluded; update(); }
  });
  document.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('circle.pt')) {
      e.preventDefault(); const i = Number(e.target.dataset.index); S.hoverIndex = i; S.rows[i].excluded = !S.rows[i].excluded; update();
      const point = $('chart').querySelector && $('chart').querySelector('circle[data-index="' + i + '"]'); if (point) point.focus();
    }
  });
  $('opening-sample').addEventListener('click', () => { selectTemplate('pendulum_fit'); if ($('sec-result').scrollIntoView) setTimeout(() => $('sec-result').scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' }), reducedMotion() ? 0 : 180); });
  $('opening-choose').addEventListener('click', () => { closeOpening(); if ($('experiment-list').scrollIntoView) setTimeout(() => $('experiment-list').scrollIntoView({ behavior: reducedMotion() ? 'auto' : 'smooth', block: 'start' }), reducedMotion() ? 0 : 180); });
  $('search').addEventListener('input', e => { S.query = e.target.value; renderList(); });
  $('params').addEventListener('input', e => { const t = e.target; if (t.dataset.delta) S.deltas[t.dataset.delta] = t.value; if (t.dataset.param) S.params[t.dataset.param] = t.value; if (t.dataset.ref) S.reference = t.value; update(); });
  $('params').addEventListener('change', e => { const t = e.target; if (t.dataset.switch) { S.params[t.dataset.switch] = t.checked ? 1 : 0; update(); } });
  $('use-t').addEventListener('change', update); $('coverage').addEventListener('change', update);
  $('table').addEventListener('change', e => { const t = e.target;
    if (t.dataset.keep !== undefined) { S.rows[Number(t.dataset.keep)].excluded = !t.checked; update(); }
    if (t.dataset.row !== undefined) { const v = t.value.trim(); if (v === '' && !['column_x', 'column_y'].includes((S.tpl.inputs.find(i => i.key === t.dataset.col) || {}).kind)) { S.rows[Number(t.dataset.row)].values[t.dataset.col] = ''; update(); return; } if (!/^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$/.test(v)) { showError('第 ' + (Number(t.dataset.row) + 1) + ' 行「' + t.dataset.col + '」的值“' + v + '”不是有效数字，已恢复原值。', []); t.value = S.rows[Number(t.dataset.row)].values[t.dataset.col]; return; } S.rows[Number(t.dataset.row)].values[t.dataset.col] = Number(v); update(); } });
  $('add-row').addEventListener('click', () => { if (!S.tpl || !S.rows.length) return; const last = S.rows[S.rows.length - 1]; S.rows.push({ values: { ...last.values }, excluded: false }); update(); });
  $('restore').addEventListener('click', () => { S.rows.forEach(r => { r.excluded = false; }); update(); });
  $('load-sample').addEventListener('click', () => { closeOpening(); if (S.tpl) loadSampleData(); });
  $('load-dirty').addEventListener('click', () => { const t = reg.templates.find(x => x.id === 'pendulum_fit'); if (t && S.tpl !== t) selectTemplate('pendulum_fit', false); loadCSV(SAMPLES['脏数据示例_模拟数据.csv'] || '', '脏数据示例_模拟数据.csv'); });
  $('file').addEventListener('change', e => readFile(e.target.files[0]));
  const drop = $('drop');
  drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); $('file').click(); } });
  ['dragenter', 'dragover'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(n => drop.addEventListener(n, e => { e.preventDefault(); drop.classList.remove('over'); }));
  drop.addEventListener('drop', e => readFile(e.dataTransfer.files[0]));
  $('export-html').addEventListener('click', () => exportReport('html')); $('export-doc').addEventListener('click', () => exportReport('doc'));
  $('ask-ai').addEventListener('click', askAI);
  const chartEl = $('chart'), tip = $('tip');
  chartEl.addEventListener('mousemove', e => { const c = e.target.closest('circle.pt'); if (!c) { S.hoverIndex = null; tip.hidden = true; return; } S.hoverIndex = Number(c.dataset.index); refreshTip();
    const box = chartEl.getBoundingClientRect(); tip.style.left = Math.max(0, Math.min(e.clientX - box.left + 14, box.width - tip.offsetWidth)) + 'px'; tip.style.top = (e.clientY - box.top + 10) + 'px'; });
  chartEl.addEventListener('mouseleave', () => { S.hoverIndex = null; tip.hidden = true; });
  const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(x => { if (x.isIntersecting && S.result) { S.stage = 3; renderStage(); } }), { threshold: 0.6 }) : null; if (io) io.observe($('sec-export'));

  /* ---------- 启动 ---------- */
  if (reg.rejected.length) showError('以下模板接口不完整，已忽略：', reg.rejected.map(x => (x.id || '?') + '：' + x.errors.join('，')));
  renderCats(); renderList(); renderVerify();
  const initialHash = location.hash, want = (initialHash.match(/(?:^#|&)tpl=([\w-]+)/) || [])[1];
  $('opening').hidden = /(?:^#|&)tpl=/.test(initialHash); S.openingClosed = $('opening').hidden;
  const first = reg.templates.find(t => t.id === want && t.verified === true) || reg.templates.find(t => t.verified === true); if (first) selectTemplate(first.id, true, false); else renderAll();
  if (/(?:^#|&)open=1(?:&|$)/.test(initialHash) && S.result) { S.openItem = S.result.items.findIndex(i => i.main); renderResult(); }
})();
