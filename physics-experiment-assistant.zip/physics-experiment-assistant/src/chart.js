(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PhysChart = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const escape = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const number = x => Number(x.toPrecision(5)).toString();
  function svg(plot, rows, outliers = []) {
    const points = plot.points.filter(p => Number.isFinite(p.x) && Number.isFinite(p.y));
    if (!points.length) return '';
    const width = 800, height = 390, left = 85, right = 30, top = 30, bottom = 65;
    let xmin = Math.min(...points.map(p => p.x)), xmax = Math.max(...points.map(p => p.x));
    let ymin = Math.min(...points.map(p => p.y)), ymax = Math.max(...points.map(p => p.y));
    const line = plot.line;
    if (line) { const ends = [line.intercept + line.slope * xmin, line.intercept + line.slope * xmax]; ymin = Math.min(ymin, ...ends); ymax = Math.max(ymax, ...ends); }
    const dx = (xmax - xmin || Math.abs(xmin) || 1) * 0.08, dy = (ymax - ymin || Math.abs(ymin) || 1) * 0.14;
    xmin -= dx; xmax += dx; ymin -= dy; ymax += dy;
    const X = x => left + (x - xmin) / (xmax - xmin) * (width - left - right), Y = y => height - bottom - (y - ymin) / (ymax - ymin) * (height - top - bottom);
    let markup = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 390" role="img" aria-label="实验散点与拟合线" style="width:100%;height:auto;background:#fff;font-family:Arial,sans-serif"><rect width="800" height="390" fill="white"/>';
    for (let i = 0; i <= 5; i++) {
      const x = xmin + (xmax - xmin) * i / 5, y = ymin + (ymax - ymin) * i / 5;
      markup += '<path d="M' + X(x) + ',' + top + 'V' + (height - bottom) + ' M' + left + ',' + Y(y) + 'H' + (width - right) + '" stroke="#e7edf5" fill="none"/>';
      markup += '<text x="' + X(x) + '" y="345" text-anchor="middle" font-size="12" fill="#52627a">' + number(x) + '</text><text x="75" y="' + (Y(y) + 4) + '" text-anchor="end" font-size="12" fill="#52627a">' + number(y) + '</text>';
    }
    markup += '<path d="M85,30V325H770" stroke="#9caec5" fill="none"/>';
    if (line) markup += '<line x1="' + X(xmin) + '" y1="' + Y(line.intercept + line.slope * xmin) + '" x2="' + X(xmax) + '" y2="' + Y(line.intercept + line.slope * xmax) + '" stroke="#6256db" stroke-width="2.5"/>';
    points.forEach(p => {
      const excluded = rows[p.index].excluded, flagged = outliers.includes(p.index), color = excluded ? '#9aa7b9' : flagged ? '#e45252' : '#17a99c';
      const title = '第 ' + (p.index + 1) + ' 点：' + plot.xLabel + '=' + number(p.x) + '，' + plot.yLabel + '=' + number(p.y) + (excluded ? '（已剔除，点击恢复）' : flagged ? '（疑似异常，点击剔除）' : '（点击剔除）');
      markup += '<circle data-index="' + p.index + '" cx="' + X(p.x) + '" cy="' + Y(p.y) + '" r="6" fill="' + (excluded ? 'white' : color) + '" stroke="' + color + '" stroke-width="2.2" tabindex="0" role="button" aria-label="' + escape(title) + '" style="cursor:pointer"><title>' + escape(title) + '</title></circle>';
    });
    markup += '<text x="425" y="380" text-anchor="middle" font-size="14" fill="#33445e">' + escape(plot.xLabel) + '</text><text transform="translate(20,180) rotate(-90)" text-anchor="middle" font-size="14" fill="#33445e">' + escape(plot.yLabel) + '</text></svg>';
    return markup;
  }
  return { svg, escape };
});
