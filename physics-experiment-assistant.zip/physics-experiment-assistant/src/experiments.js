(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./calc.js'));
  else root.PhysExperiments = factory(root.PhysCalc);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C) {
  'use strict';
  const defaults = {
    pendulum: { mode: 'fit', reference: 9.80, length: 0.8, deltaL: 0.001, deltaT: 0.002, timeMode: 'period', cycles: 20, bMode: 'rectangular', useT: false, coverage: 0.95, origin: false },
    resistance: { reference: 100, correction: 'none', ra: 0.5, rv: 100000, currentUnit: 'mA', origin: false },
    young: { reference: 2e11, length: 1.0, diameter: '0.00050,0.000501,0.000499,0.000500,0.000500', arm: 0.05, distance: 1.5, deltaL: 0.001, deltaD: 0.001, deltaB: 0.0001, deltaDiameter: 0.000001, forceUnit: 'kg', readingUnit: 'cm', gravity: 9.80, bMode: 'rectangular', useT: false, coverage: 0.95, origin: false }
  };
  const names = { pendulum: '单摆测重力加速度', resistance: '伏安法测电阻', young: '杨氏模量（拉伸法＋光杠杆）' };
  const S = (formula, substitution, result) => ({ formula, substitution, result });
  function positive(x, label) { if (!Number.isFinite(x) || x <= 0) throw new Error(label + '必须大于零'); return x; }
  function nonnegative(x, label) { if (!Number.isFinite(x) || x < 0) throw new Error(label + '不得为负数'); return x; }
  function columns(type, p) {
    if (type === 'pendulum') return [p.mode === 'single' ? '测量序号' : '摆长 L (m)', p.timeMode === 'total' ? '总时间 t (s)' : '周期 T (s)'];
    if (type === 'resistance') return ['电流 I (' + p.currentUnit + ')', '电压 U (V)'];
    return [p.forceUnit === 'kg' ? '质量 m (kg)' : '拉力 F (N)', '标尺读数 n (' + p.readingUnit + ')'];
  }
  function parseCSV(text, type, params = {}) {
    const p = { ...defaults[type], ...params };
    const lines = String(text).replace(/^\uFEFF/, '').split(/\r?\n/).filter(line => line.trim() && !line.trimStart().startsWith('#'));
    if (lines.length < 2) throw new Error('CSV 至少包含表头和一行数据');
    const delimiter = lines[0].includes('\t') ? '\t' : ',';
    function split(line) {
      const out = []; let cell = '', quote = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') { if (quote && line[i + 1] === '"') { cell += '"'; i++; } else quote = !quote; }
        else if (ch === delimiter && !quote) { out.push(cell.trim()); cell = ''; } else cell += ch;
      }
      if (quote) throw new Error('CSV 引号未闭合；不支持跨行单元格');
      out.push(cell.trim()); return out;
    }
    const headers = split(lines[0]); const norm = s => s.toLowerCase().replace(/[\s_（）()]/g, '');
    const hs = headers.map(norm); const find = patterns => hs.findIndex(h => patterns.some(re => re.test(h)));
    let xi, yi;
    if (type === 'pendulum') {
      xi = p.mode === 'single' ? find([/^序号/, /^测量序号/, /^index$/, /^编号/]) : find([/^l(?:m)?$/, /^摆长/, /^长度/]);
      yi = find([/^t(?:s)?$/, /^周期/, /^时间/, /^总时间/, /^t\d+/, /^tn/]);
    } else if (type === 'resistance') { xi = find([/^i(?:ma|a)?$/, /^电流/]); yi = find([/^u(?:v)?$/, /^电压/]); }
    else { xi = find([/^m(?:kg)?$/, /^f(?:n)?$/, /^质量/, /^砝码/, /^拉力/, /^力/]); yi = find([/^n(?:cm|mm|m)?$/, /^读数/, /^标尺/, /^δn/, /^Δn/i]); }
    if (yi < 0 || (xi < 0 && !(type === 'pendulum' && p.mode === 'single'))) throw new Error('无法识别表头，请使用：' + columns(type, p).join('、'));
    const ni = find([/^备注$/, /^note$/]);
    const rows = lines.slice(1).map((line, i) => {
      const cells = split(line), x = xi < 0 ? i + 1 : Number(cells[xi]), y = Number(cells[yi]);
      if ((xi >= 0 && !cells[xi]) || !cells[yi] || !Number.isFinite(x) || !Number.isFinite(y)) throw new Error('第 ' + (i + 1) + ' 条数据存在空值或无效数字');
      return { x, y, note: ni >= 0 ? cells[ni] || '' : '', excluded: false };
    });
    const hints = {};
    if (type === 'resistance') { if (/ma/.test(hs[xi])) hints.currentUnit = 'mA'; else if (/ia$|电流a$/.test(hs[xi])) hints.currentUnit = 'A'; }
    if (type === 'young') { if (/^m|质量|砝码/.test(hs[xi])) hints.forceUnit = 'kg'; else if (/^f|拉力|^力/.test(hs[xi])) hints.forceUnit = 'N'; if (/mm/.test(hs[yi])) hints.readingUnit = 'mm'; else if (/cm/.test(hs[yi])) hints.readingUnit = 'cm'; else if (/nm$|读数m$/.test(hs[yi])) hints.readingUnit = 'm'; }
    if (type === 'pendulum') { if (/总时间|^t\d+|^tn/.test(hs[yi])) hints.timeMode = 'total'; else if (/周期|^ts?$/.test(hs[yi])) hints.timeMode = 'period'; }
    return { rows, headers, hints, simulated: /模拟数据/.test(text) };
  }
  function process(type, rows, params = {}) {
    if (!defaults[type]) throw new Error('未知实验');
    const p = { ...defaults[type], ...params }; positive(p.reference, '公认值');
    const used = rows.map((row, index) => ({ ...row, index })).filter(r => !r.excluded);
    const min = type === 'pendulum' && p.mode === 'single' ? 3 : p.origin ? 2 : 3;
    if (used.length < min) throw new Error('当前方法至少保留 ' + min + ' 个数据点');
    used.forEach(r => { if (!Number.isFinite(r.x) || !Number.isFinite(r.y)) throw new Error('数据表中有空值或非数值'); });
    let fit = null, value, uncertainty, unit, symbol, detection, derived, plot, steps = [], metrics = [];
    const add = (label, result, unit = '') => { metrics.push({ label, value: result.value, unit, steps: result.steps }); steps.push(...result.steps); return result.value; };
    if (type === 'pendulum') {
      unit = 'm/s²'; symbol = 'g'; positive(p.cycles, '计时周期数');
      if (!Number.isInteger(p.cycles)) throw new Error('计时周期数须为正整数');
      const divisor = p.timeMode === 'total' ? p.cycles : 1;
      const ts = used.map(r => positive(r.y / divisor, '周期'));
      if (divisor !== 1) steps.push(S('T=t_N/N', 'N=' + divisor, ts.join(', ')));
      if (p.mode === 'single') {
        positive(p.length, '摆长');
        const t = add('平均周期', C.mean(ts), 's'), a = add('周期 A 类不确定度', C.typeA(ts, p), 's');
        const b = add('周期 B 类不确定度', C.typeB(p.deltaT / divisor, p.bMode), 's');
        const ut = add('周期合成不确定度', C.combine(a, b), 's'), ul = add('摆长 B 类不确定度', C.typeB(p.deltaL, p.bMode), 'm');
        derived = C.powerProduct(4 * Math.PI ** 2, { L: { value: p.length, uncertainty: ul, power: 1 }, T: { value: t, uncertainty: ut, power: -2 } });
        detection = C.grubbs(ts);
        plot = { xLabel: '测量序号', yLabel: '周期 T (s)', points: rows.map((r, index) => ({ x: r.x, y: r.y / divisor, index })), line: { slope: 0, intercept: t } };
        steps.unshift(S('g=4π²L/T²；(u_g/g)²=(u_L/L)²+(2u_T/T)²', '单摆长法；时间仪器误差与输入时间采用同一口径', '独立输入量传递'));
      } else {
        const xs = used.map(r => positive(r.x, '摆长')), ys = ts.map(t => t * t);
        fit = C.linearFit(xs, ys, p); positive(fit.slope, 'T²–L 斜率');
        derived = C.powerProduct(4 * Math.PI ** 2, { slope: { value: fit.slope, uncertainty: fit.slopeUncertainty, power: -1 } });
        detection = C.residualOutliers(fit);
        plot = { xLabel: '摆长 L (m)', yLabel: '周期平方 T² (s²)', points: rows.map((r, index) => ({ x: r.x, y: (r.y / divisor) ** 2, index })), line: fit };
        steps.push(S('T²=(4π²/g)L+a；g=4π²/b；u_g=|g/b|u_b', '由 T²–L 拟合斜率传递；该模式只计斜率标准不确定度', '不包含摆长与计时的系统误差'));
      }
    } else if (type === 'resistance') {
      unit = 'Ω'; symbol = 'R'; const factor = p.currentUnit === 'mA' ? 0.001 : 1;
      fit = C.linearFit(used.map(r => r.x * factor), used.map(r => r.y), p); positive(fit.slope, '测得电阻');
      const rm = fit.slope, um = fit.slopeUncertainty; nonnegative(p.ra, '电流表内阻'); positive(p.rv, '电压表内阻');
      if (p.correction === 'internal') derived = C.propagate(q => q.Rm - p.ra, { Rm: { value: rm, uncertainty: um } }, { Rm: 1 });
      else if (p.correction === 'external') {
        if (rm >= p.rv) throw new Error('外接修正要求测得电阻小于电压表内阻');
        derived = C.propagate(q => q.Rm * p.rv / (p.rv - q.Rm), { Rm: { value: rm, uncertainty: um } }, { Rm: p.rv ** 2 / (p.rv - rm) ** 2 });
      } else derived = { value: rm, uncertainty: um, steps: [] };
      positive(derived.value, '修正后电阻'); detection = C.residualOutliers(fit);
      plot = { xLabel: '电流 I (A)', yLabel: '电压 U (V)', points: rows.map((r, index) => ({ x: r.x * factor, y: r.y, index })), line: fit };
      steps.push(S('I(A)=I(mA)×10⁻³；U=a+R测 I', '电流输入单位=' + p.currentUnit, '斜率单位 V/A=Ω'));
      steps.push(S(p.correction === 'internal' ? 'R=R测−R_A' : p.correction === 'external' ? '1/R=1/R测−1/R_V' : 'R=R测', 'R测=' + rm + ', R_A=' + p.ra + ', R_V=' + p.rv, derived.value));
      steps.push(S('修正参数视为给定常量', '仅由拟合斜率传递；未计 R_A、R_V 自身不确定度', derived.uncertainty));
    } else {
      unit = 'Pa'; symbol = 'E'; positive(p.length, '丝长'); positive(p.arm, '光杠杆臂长'); positive(p.distance, '镜尺距离'); positive(p.gravity, '重力加速度');
      const ds = String(p.diameter).trim().split(/[,，;；\s]+/).map(Number); ds.forEach(d => positive(d, '金属丝直径'));
      const d = add('平均直径', C.mean(ds), 'm'), da = ds.length > 1 ? add('直径 A 类不确定度', C.typeA(ds, p), 'm') : 0;
      const db = add('直径 B 类不确定度', C.typeB(p.deltaDiameter, p.bMode), 'm');
      const ud = add('直径合成不确定度', C.combine(da, db), 'm');
      const ul = add('丝长 B 类不确定度', C.typeB(p.deltaL, p.bMode), 'm'), ub = add('臂长 B 类不确定度', C.typeB(p.deltaB, p.bMode), 'm'), uD = add('镜尺距离 B 类不确定度', C.typeB(p.deltaD, p.bMode), 'm');
      const ff = p.forceUnit === 'kg' ? p.gravity : 1, nf = { cm: 0.01, mm: 0.001, m: 1 }[p.readingUnit];
      if (!nf) throw new Error('标尺读数单位无效');
      fit = C.linearFit(used.map(r => r.x * ff), used.map(r => r.y * nf), p); positive(fit.slope, '标尺读数–力斜率');
      derived = C.powerProduct(8 / Math.PI, { L: { value: p.length, uncertainty: ul, power: 1 }, D: { value: p.distance, uncertainty: uD, power: 1 }, d: { value: d, uncertainty: ud, power: -2 }, b: { value: p.arm, uncertainty: ub, power: -1 }, k: { value: fit.slope, uncertainty: fit.slopeUncertainty, power: -1 } });
      detection = C.residualOutliers(fit);
      plot = { xLabel: '拉力 F (N)', yLabel: '标尺读数 n (m)', points: rows.map((r, index) => ({ x: r.x * ff, y: r.y * nf, index })), line: fit };
      steps.unshift(S('E=FL/(AΔL)；A=πd²/4；ΔL=bΔn/(2D)', '小角度近似，反射光偏角为光杠杆转角的两倍', 'E=8LD/(πd²b k)，k=Δn/ΔF'), S('n=a+kF（截距吸收初始读数；斜率等价于Δn–ΔF）', 'F=' + (p.forceUnit === 'kg' ? 'm×' + p.gravity : '输入 N') + '；读数×' + nf + ' → m', 'k 单位 m/N；全部长度用 m，E 单位 Pa'));
    }
    value = derived.value; uncertainty = derived.uncertainty;
    if (fit) { steps.push(...fit.steps); metrics.push({ label: '拟合斜率', value: fit.slope, unit: type === 'pendulum' ? 's²/m' : type === 'resistance' ? 'Ω' : 'm/N', steps: fit.steps }, { label: '斜率标准不确定度', value: fit.slopeUncertainty, unit: '', steps: fit.steps }, { label: '截距', value: fit.intercept, unit: '', steps: fit.steps }, { label: '截距标准不确定度', value: fit.interceptUncertainty, unit: '', steps: fit.steps }, { label: '相关系数 r', value: fit.r, unit: '', steps: fit.steps }); }
    steps.push(...derived.steps, ...detection.steps);
    const formatted = C.formatResult(value, uncertainty, unit), comparison = C.compare(value, p.reference, uncertainty), rel = C.relative(value, uncertainty);
    steps.push(...formatted.steps, ...rel.steps, ...comparison.steps);
    const warnings = ['不确定度传递假设输入量互不相关；线性拟合采用未加权最小二乘。'];
    if (p.useT && (type === 'young' || p.mode === 'single')) warnings.push('已按选项对 A 类分量乘 t 因子；此时合成量不是严格的标准不确定度，2u/3u 判据仅按所选 u 执行，不代表严格覆盖概率。');
    if (p.origin) warnings.push('已强制过原点；只有理论和零点校准支持时才使用。');
    if (uncertainty === 0) warnings.push('计算得到零不确定度，通常来自理想直线或未提供误差；不代表真实测量无误差。');
    return { type, title: names[type], params: p, value, uncertainty, unit, symbol, formatted: formatted.value, relativeUncertainty: rel.value, comparison, fit, metrics, steps, plot, outlierIndices: detection.indices.map(i => used[i].index), count: used.length, excludedCount: rows.length - used.length, warnings };
  }
  return { defaults, names, columns, parseCSV, process };
});
