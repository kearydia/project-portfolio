/*
 * 手算验证对照：小数据集 + 独立计算的期望值。
 * 期望值由独立 Python 脚本（过程证据/03_运行验证/handref_independent.py；v1.1 起拟合不确定度含 B 类分量，见 tools/python/handref_v11.py，纯 Python 实现，不调用本项目代码）计算得到。
 * 这些数据是“手算验证数据”，不是教材例题，也不是实验数据。
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.LabVerify = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const CASES = [
    { id: 'A', tpl: 'pendulum_single', csv: '手算验证数据_pendulum_single.csv', title: '单摆单摆长法（L=0.800 m，ΔT=0.01 s，ΔL=0.001 m，不乘 t）', params: { L: 0.8 }, deltas: { T: 0.01 },
      expected: [['T̄ (s)', 'item:mean.T', 1.8], ['s (s)', 'item:s.T', 0.0158113883], ['u_A (s)', 'item:uA.T', 0.007071067812], ['u_B (s)', 'item:uB.T', 0.005773502692], ['u_C(T) (s)', 'item:uC.T', 0.009128709292], ['g (m/s²)', 'value', 9.747757433], ['u(g) (m/s²)', 'genericUncertainty', 0.09912155708]] },
    { id: 'B', tpl: 'pendulum_fit', csv: '手算验证数据_pendulum_fit.csv', title: '单摆 T²–L 拟合（4 点）', params: {}, deltas: {},
      expected: [['斜率 (s²/m)', 'item:fit.slope', 4.05955], ['截距 (s²)', 'item:fit.intercept', -0.01781], ['u_A(斜率)', 'item:fit.uAslope', 0.03127966592], ['u_B(斜率)', 'item:fit.uBslope', 0.008677749324], ['u(斜率)', 'item:fit.uslope', 0.03246106642], ['r', 'item:fit.r', 0.9999406351], ['g (m/s²)', 'value', 9.724826053], ['u(g) 仅斜率项', 'genericUncertainty', 0.07776187619]] },
    { id: 'C', tpl: 'ohm_fit', csv: '手算验证数据_ohm_fit.csv', title: '伏安法 U–I 拟合（5 点）', params: {}, deltas: {},
      expected: [['R (Ω)', 'value', 100.2], ['u_A(R) (Ω)', 'item:fit.uAslope', 0.6], ['u_B(R) (Ω)', 'item:fit.uBslope', 0.09128709292], ['u(R) (Ω)', 'uncertainty', 0.6069047152], ['r', 'item:fit.r', 0.9999462197]] },
    { id: 'D', tpl: 'young_fit', csv: '手算验证数据_young_fit.csv', title: '杨氏模量 n–m 拟合（5 点，L=1.000 m, D=1.500 m, b=0.0500 m, d=0.500 mm）', params: { L: 1, D: 1.5, b: 0.05, d: 0.5, g: 9.8 }, deltas: {},
      expected: [['k (m/kg)', 'item:fit.slope', 0.01506], ['u_A(k) (m/kg)', 'item:fit.uAslope', 5.033222957e-5], ['u_B(k) (m/kg)', 'item:fit.uBslope', 1.825741858e-4], ['u(k) (m/kg)', 'item:fit.uslope', 1.893849695e-4], ['r', 'item:fit.r', 0.9999832458], ['E (Pa)', 'value', 1.988485663e11]] }
  ];
  function pick(result, path) { return path.startsWith('item:') ? (result.items.find(i => i.key === path.slice(5)) || {}).value : result[path]; }
  function run(engine, templates, samples) {
    return CASES.map(c => {
      const tpl = templates.find(t => t.id === c.tpl);
      if (!tpl) return { ...c, error: '缺少模板 ' + c.tpl, rows: [] };
      try {
        const parsed = engine.parseCSV(samples[c.csv], tpl);
        if (!parsed.ok) throw new Error(parsed.errors.join('；'));
        const r = engine.process(tpl, parsed.rows, { params: c.params, deltas: c.deltas, useT: false });
        const rows = c.expected.map(([label, path, exp]) => { const got = pick(r, path), rel = Math.abs(got - exp) / Math.max(Math.abs(exp), 1e-300); return { label, got, expected: exp, rel, ok: rel < 1e-3 }; });
        return { ...c, rows, ok: rows.every(x => x.ok) };
      } catch (e) { return { ...c, error: e.message, rows: [], ok: false }; }
    });
  }
  return { CASES, run };
});
