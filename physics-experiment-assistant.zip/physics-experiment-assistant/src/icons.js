/* 实验器具速写：按 32 格绘制的线条图，图形均为本项目手绘。 */
(function () {
  'use strict';
  const svg = lines => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + lines + '</svg>';
  const drawings = {
    electrostaticField: '<circle cx="16" cy="16" r="12"/><circle cx="16" cy="16" r="4"/><path d="M16 11V6m-1.8 1.8L16 6l1.8 1.8M21 16h5m-1.8-1.8L26 16l-1.8 1.8M16 21v5m-1.8-1.8L16 26l1.8-1.8M11 16H6m1.8-1.8L6 16l1.8 1.8"/>',
    focusing: '<path d="M3 8v16m0-16c0-5 4-5 4 0v16c0 5 4 5 4 0V8c0-5 4-5 4 0v16c0 5 4 5 4 0V8c0-5 4-5 4 0v16M27 5h3v22h-3z"/><path d="M1 16h3c2-8 4-8 6 0s4 8 6 0 4-8 6 0l5 0"/><circle cx="28.5" cy="16" r="1"/>',
    pendulum: '<path d="M6 5h20M10 2v3m6 0 7 17M16 5v16M8 23a14 14 0 0 0 17 3"/><circle cx="24" cy="25" r="3"/>',
    spring: '<path d="M6 4h20M16 4v4l-4 2 8 3-8 3 8 3-4 2v3M11 24h10v5H11zM7 4v24m-2-4 2 4 2-4"/>',
    opticalLever: '<path d="M4 7h4v18H4zM4 11h4m-4 4h4m-4 4h4M12 25h16M17 25l3-8 4 8M16 16l11-3M7 10l13 5-13 6M25 13V5h4"/>',
    lens: '<path d="M3 16h26M16 4c-7 6-7 18 0 24 7-6 7-18 0-24ZM4 8h7l13 16h4M4 24h7L24 8h4"/>',
    prism: '<path d="m16 4 13 23H3ZM2 14h8l7 7 13-3M9 14l4 2m6 5 8 4"/>',
    grating: '<path d="M14 4v24m4-24v24M2 16h12m4 0h12M18 14l11-9M18 18l11 9M7 13l4 3-4 3"/>',
    michelson: '<path d="M3 14h5v4H3zM8 16h18M16 16V5M13 5h6M27 11v10M12 20l8-8M16 16v10M11 27h10"/><circle cx="16" cy="27" r="3"/>',
    rings: '<circle cx="16" cy="15" r="10"/><circle cx="16" cy="15" r="6.5"/><circle cx="16" cy="15" r="3"/><path d="M3 28h26M8 28v-3m16 3v-3"/>',
    circuit: '<path d="M12 7H4v18h24V7h-8M12 4h8v6h-8ZM4 17h8m8 0h8"/><circle cx="16" cy="17" r="4"/><path d="m14 19 3-4"/>',
    bridge: '<path d="m16 3 12 13-12 13L4 16ZM16 3v8m0 10v8M2 16h2m24 0h2M8 8l4 4m8 8 4 4M8 24l4-4m8-8 4-4"/><circle cx="16" cy="16" r="5"/><path d="m14 18 3-4"/>',
    potentiometer: '<path d="M4 5h24v4H4v4h24v4H4v4h24v4H4M6 29h20M16 29v-8m-3 3 3-3 3 3"/>',
    hall: '<path d="m8 9 14-4 4 17-14 5ZM3 15l8-2m12 5 6-2M13 5V2m6 24v4M14 12l5 8M12 17l9-3"/>',
    photoelectric: '<circle cx="18" cy="15" r="10"/><path d="M12 9v12m0-12c7 0 7 12 0 12M22 10v10M12 21v7H5M22 20v8h6M2 4l6 6M1 10l6 3M3 5V2m0 3H0"/>',
    sound: '<path d="M4 7h24v18H4M8 11c3 0 3 10 6 10s3-10 6-10 3 10 6 10M4 10v12M1 12v8M9 28h14m-14-2v4m14-4v4"/>',
    string: '<path d="M3 17h26M4 9v16m24-16v16M4 17c4-12 8-12 12 0s8 12 12 0M8 28h16M8 26v4m16-4v4"/>',
    thermometer: '<path d="M19 13h9v15H10V13h3M19 9V5a3 3 0 0 0-6 0v15a5 5 0 1 0 6 0ZM16 9v14m3-15h3m-3 4h3M5 16v10"/><circle cx="16" cy="24" r="1.5"/>',
    fallingBall: '<path d="M10 3v24c0 3 14 3 14 0V3M8 3h18M10 8h14m-3 5h3m-3 5h3m-3 5h3M16 16v7m-2-2 2 2 2-2"/><circle cx="16" cy="12" r="2.5"/>',
    trifilar: '<ellipse cx="16" cy="6" rx="10" ry="3"/><ellipse cx="16" cy="25" rx="10" ry="4"/><path d="M6 6v19M16 9v20M26 6v19m-7-6 3-3-4-1M22 16c-1-4-6-5-10-2"/>',
    film: '<path d="M3 24h26M5 24v5h22v-5M16 3v7m-4-7h8M16 10l-7 8m7-8 7 8M9 18v6m14-6v6"/><ellipse cx="16" cy="18" rx="7" ry="2.5"/>',
    gas: '<path d="M12 3h8m-6 0v7c-6 2-7 6-7 11v7h18v-7c0-5-1-9-7-11V3M19 6h9v14M25 20v5h6v-5M25 22h6M10 16h5m-5 5h5"/>',
    mechanics: '<path d="M5 27h22M8 26V8h16v18M12 8V4h8v4M12 15h8v8h-8zM16 11v4"/>',
    optics: '<path d="M2 16h28M16 5v22M3 7l25 18M3 25 28 7M13 7l3-2 3 2m-6 18 3 2 3-2"/>',
    modern: '<circle cx="16" cy="16" r="3"/><ellipse cx="16" cy="16" rx="13" ry="5"/><ellipse cx="16" cy="16" rx="5" ry="13" transform="rotate(35 16 16)"/><path d="m5 25 3-3m16-12 3-3"/>'
  };
  const mapping = {
    electrostatic_field: 'electrostaticField',
    em_ratio_focusing: 'focusing',
    pendulum_fit: 'pendulum', pendulum_single: 'pendulum',
    young_diff: 'spring', young_fit: 'opticalLever', youngs_modulus: 'opticalLever',
    thin_lens_uv: 'lens', thin_lens_conjugate: 'lens', prism_min_deviation: 'prism',
    grating: 'grating', michelson: 'michelson', newton_rings: 'rings',
    ohm_fit: 'circuit', wheatstone_bridge: 'bridge', potentiometer: 'potentiometer',
    hall_effect: 'hall', photoelectric_planck: 'photoelectric', sound_speed: 'sound',
    string_vibration: 'string', specific_heat_water: 'thermometer', linear_expansion: 'thermometer',
    viscosity_falling_ball: 'fallingBall', trifilar_inertia: 'trifilar', surface_tension: 'film', gamma_air: 'gas'
  };
  const categoryFallback = { '力学': 'mechanics', '热学': 'thermometer', '电磁学': 'circuit', '光学': 'optics', '近代物理': 'modern' };
  const icons = {};
  Object.keys(mapping).forEach(id => { icons[id] = svg(drawings[mapping[id]]); });
  (globalThis.EXP_TEMPLATES || []).forEach(t => {
    if (!icons[t.id]) icons[t.id] = svg(drawings[categoryFallback[t.category] || 'mechanics']);
  });
  globalThis.EXP_ICONS = Object.freeze(icons);
})();
