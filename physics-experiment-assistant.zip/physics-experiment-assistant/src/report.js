(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./chart.js'));
  else root.PhysReport = factory(root.PhysChart);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (chart) {
  'use strict';
  const esc = chart.escape;
  function build({ result, rows, columns, explanation, simulated, source, parameterLabels = {} }) {
    const provenance = simulated ? '模拟数据：用于功能演示，不代表真实实验结果。' : '用户提供数据：真实性由数据提供者确认。';
    const table = '<table><thead><tr><th>序号</th><th>' + esc(columns[0]) + '</th><th>' + esc(columns[1]) + '</th><th>状态</th><th>备注</th></tr></thead><tbody>' + rows.map((r, i) => '<tr><td>' + (i + 1) + '</td><td>' + esc(r.x) + '</td><td>' + esc(r.y) + '</td><td>' + (r.excluded ? '已剔除' : result.outlierIndices.includes(i) ? '保留／疑似异常' : '保留') + '</td><td>' + esc(r.note || '') + '</td></tr>').join('') + '</tbody></table>';
    const steps = result.steps.map(s => '<li><p class="formula">' + esc(s.formula) + '</p><p>代入：' + esc(s.substitution) + '</p><p>结果：' + esc(s.result) + '</p></li>').join('');
    const params = Object.entries(result.params).map(([key, value]) => '<tr><td>' + esc(parameterLabels[key] || key) + '</td><td>' + esc(value) + '</td></tr>').join('');
    return '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>实验算盘 · ' + esc(result.title) + '实验报告</title><style>body{font-family:"Microsoft YaHei",sans-serif;max-width:1000px;margin:40px auto;padding:0 24px;color:#25334c;line-height:1.7}h1,h2{color:#4740a3}table{border-collapse:collapse;width:100%;margin:18px 0}th,td{border:1px solid #cdd5e3;padding:7px;text-align:left}th{background:#edf1fb}p,li{overflow-wrap:anywhere}li{margin-bottom:24px}.result{font-size:24px;font-weight:bold}.notice{background:#fff1d8;padding:12px}.formula{font-family:Consolas,monospace}pre{white-space:pre-wrap}svg{max-width:100%}@media print{body{margin:0}tr,li{break-inside:avoid}}</style></head><body><h1>大学物理实验数据处理助手 · 实验报告</h1><p>华为开发者大赛·西安欧亚学院站 · 团队 奖金我来了</p><h2>' + esc(result.title) + '</h2><p class="notice">' + provenance + '</p><p>数据来源：' + esc(source || '手动输入') + '；生成时间：' + esc(new Date().toLocaleString('zh-CN')) + '</p><h2>测量结果与对比</h2><p class="result">' + esc(result.symbol + ' = ' + result.formatted) + '</p><p>未修约值：' + esc(result.value) + '；不确定度：' + esc(result.uncertainty) + ' ' + esc(result.unit) + '；相对不确定度：' + esc(result.relativeUncertainty) + '%</p><p>公认值：' + esc(result.params.reference) + ' ' + esc(result.unit) + '；相对误差：' + esc(result.comparison.relativeError) + '%；结论：' + esc(result.comparison.verdict) + '（差值≤2u 一致，≤3u 基本一致）。</p><p>保留 ' + result.count + ' 点，剔除 ' + result.excludedCount + ' 点。' + esc(result.warnings.join(' ')) + '</p><h2>图表</h2>' + chart.svg(result.plot, rows, result.outlierIndices) + '<p>实心青色：保留；红色：疑似异常；灰色空心：已剔除。拟合用标准化残差绝对值大于2.5标记；重复测量用单轮 Grubbs α=0.05。</p><h2>原始数据（包含剔除记录）</h2>' + table + '<h2>参数（长度采用米；枚举值见 README）</h2><table><tr><th>参数</th><th>设定</th></tr>' + params + '</table><h2>公式与完整计算步骤</h2><ol>' + steps + '</ol><h2>误差解释与改进建议</h2><pre>' + esc(explanation) + '</pre><hr><p>AI 只解释，不承担数值计算。示例数据均为模拟数据。</p></body></html>';
  }
  function download(html, format, filename) {
    const blob = new Blob(['\ufeff', html], { type: format === 'doc' ? 'application/msword' : 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob), link = document.createElement('a');
    link.href = url; link.download = filename + '.' + format; document.body.appendChild(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  return { build, download };
});
