(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.PhysCalc = factory();
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const step = (formula, substitution, result) => ({ formula, substitution, result });
  const finite = (x, name = '数值') => { if (!Number.isFinite(x)) throw new Error(name + '必须是有限数'); return x; };
  const nonnegative = (x, name) => { finite(x, name); if (x < 0) throw new Error(name + '不得为负数'); return x; };
  const series = (xs, min = 1) => {
    if (!Array.isArray(xs) || xs.length < min) throw new Error('至少需要 ' + min + ' 个有效数据');
    xs.forEach(x => finite(x)); return xs;
  };
  function mean(xs) {
    series(xs); const value = xs.reduce((a, b) => a + b, 0) / xs.length;
    return { value, steps: [step('\\bar{x}=\\sum x_i/n', '(' + xs.join(' + ') + ')/' + xs.length, value)] };
  }
  function standardDeviation(xs) {
    series(xs, 2); const m = mean(xs); const ss = xs.reduce((a, b) => a + (b - m.value) ** 2, 0);
    const value = Math.sqrt(ss / (xs.length - 1));
    return { value, steps: [...m.steps, step('s=\\sqrt{\\sum(x_i-\\bar{x})^2/(n-1)}', '√(' + ss + '/' + (xs.length - 1) + ')', value)] };
  }
  // Student-t CDF: regularized incomplete beta, Lanczos log-gamma, continued fraction.
  // Quantiles define two-sided central coverage P(|t| <= t_P)=P, not one-sided P.
  function logGamma(z) {
    const c = [676.5203681218851, -1259.1392167224028, 771.3234287776531, -176.6150291621406, 12.507343278686905, -0.13857109526572012, 9.984369578019572e-6, 1.5056327351493116e-7];
    if (z < 0.5) return Math.log(Math.PI) - Math.log(Math.sin(Math.PI * z)) - logGamma(1 - z);
    z -= 1; let x = 0.9999999999998099;
    c.forEach((a, i) => { x += a / (z + i + 1); });
    const t = z + 7.5; return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
  }
  function betaFraction(a, b, x) {
    const tiny = 1e-300; let c = 1, d = 1 - (a + b) * x / (a + 1);
    if (Math.abs(d) < tiny) d = tiny;
    d = 1 / d; let h = d;
    for (let m = 1; m <= 300; m++) {
      let aa = m * (b - m) * x / ((a + 2 * m - 1) * (a + 2 * m));
      d = 1 + aa * d; if (Math.abs(d) < tiny) d = tiny;
      c = 1 + aa / c; if (Math.abs(c) < tiny) c = tiny;
      d = 1 / d; h *= d * c;
      aa = -(a + m) * (a + b + m) * x / ((a + 2 * m) * (a + 2 * m + 1));
      d = 1 + aa * d; if (Math.abs(d) < tiny) d = tiny;
      c = 1 + aa / c; if (Math.abs(c) < tiny) c = tiny;
      d = 1 / d; const delta = d * c; h *= delta;
      if (Math.abs(delta - 1) < 3e-14) break;
    }
    return h;
  }
  function betaI(x, a, b) {
    if (x <= 0) return 0; if (x >= 1) return 1;
    const bt = Math.exp(logGamma(a + b) - logGamma(a) - logGamma(b) + a * Math.log(x) + b * Math.log1p(-x));
    return x < (a + 1) / (a + b + 2) ? bt * betaFraction(a, b, x) / a : 1 - bt * betaFraction(b, a, 1 - x) / b;
  }
  function tQuantile(p, df) {
    let lo = 0, hi = 1;
    const cdf = t => 1 - 0.5 * betaI(df / (df + t * t), df / 2, 0.5);
    while (cdf(hi) < p) hi *= 2;
    for (let i = 0; i < 90; i++) { const mid = (lo + hi) / 2; if (cdf(mid) < p) lo = mid; else hi = mid; }
    return (lo + hi) / 2;
  }
  const T_TABLE = { '0.95': {}, '0.683': {} };
  [0.95, 0.683].forEach(p => { for (let n = 2; n <= 200; n++) T_TABLE[String(p)][n] = tQuantile((1 + p) / 2, n - 1); });
  const GRUBBS_TABLE = {};
  function criticalG(n) {
    const t = tQuantile(1 - 0.05 / (2 * n), n - 2);
    return (n - 1) / Math.sqrt(n) * Math.sqrt(t * t / (n - 2 + t * t));
  }
  for (let n = 3; n <= 200; n++) GRUBBS_TABLE[n] = criticalG(n);
  function tFactor(n, coverage = 0.95) {
    if (!Number.isInteger(n) || n < 2) throw new Error('t 因子需要 n≥2');
    if (![0.95, 0.683].includes(coverage)) throw new Error('覆盖概率须为 0.95 或 0.683');
    const value = T_TABLE[String(coverage)][n] || tQuantile((1 + coverage) / 2, n - 1);
    return { value, steps: [step('P(|t_{n-1}|≤t_P)=P', 'n=' + n + ', P=' + coverage, value)] };
  }
  function typeA(xs, options = {}) {
    const s = standardDeviation(xs); const t = options.useT ? tFactor(xs.length, options.coverage || 0.95) : { value: 1, steps: [] };
    const value = t.value * s.value / Math.sqrt(xs.length);
    return { value, s: s.value, factor: t.value, steps: [...s.steps, ...t.steps, step('u_A=t·s/\\sqrt{n}', t.value + '×' + s.value + '/√' + xs.length, value)] };
  }
  function typeB(delta, mode = 'rectangular') {
    nonnegative(delta, '仪器误差'); if (!['rectangular', 'direct'].includes(mode)) throw new Error('未知 B 类模型');
    const divisor = mode === 'direct' ? 1 : Math.sqrt(3), value = delta / divisor;
    return { value, steps: [step(mode === 'direct' ? 'u_B=Δ仪' : 'u_B=Δ仪/\\sqrt{3}', delta + '/' + divisor, value)] };
  }
  function combine(...values) {
    if (values.length === 1 && Array.isArray(values[0])) values = values[0];
    series(values); values.forEach(x => nonnegative(x, '不确定度'));
    const value = Math.hypot(...values);
    return { value, steps: [step('u_C=\\sqrt{\\sum u_i^2}', '√(' + values.map(x => x + '²').join(' + ') + ')', value)] };
  }
  function relative(value, uncertainty) {
    finite(value); nonnegative(uncertainty, '不确定度'); if (value === 0) throw new Error('零值不能计算相对不确定度');
    const result = uncertainty / Math.abs(value) * 100;
    return { value: result, steps: [step('u_r=u_C/|x|×100%', uncertainty + '/|' + value + '|×100%', result)] };
  }
  function propagate(fn, quantities, partials) {
    const names = Object.keys(quantities), inputs = {};
    if (!names.length) throw new Error('至少给定一个输入量');
    names.forEach(k => { inputs[k] = finite(quantities[k].value, k); nonnegative(quantities[k].uncertainty, k + '不确定度'); });
    const value = finite(fn(inputs), '间接量结果'), derivatives = {}, terms = [], steps = [];
    names.forEach(k => {
      const h = Math.cbrt(Number.EPSILON) * (Math.max(Math.abs(inputs[k]), quantities[k].uncertainty) || 1);
      const d = partials && partials[k] !== undefined ? (typeof partials[k] === 'function' ? partials[k](inputs) : partials[k]) : (fn({ ...inputs, [k]: inputs[k] + h }) - fn({ ...inputs, [k]: inputs[k] - h })) / (2 * h);
      derivatives[k] = finite(d, '偏导数'); terms.push(d * quantities[k].uncertainty);
      steps.push(step('∂f/∂' + k, (partials && partials[k] !== undefined ? '解析偏导' : '中心差分') + '，' + k + '=' + inputs[k], d));
    });
    const uncertainty = Math.hypot(...terms);
    steps.push(step('u_f=\\sqrt{\\sum(∂f/∂x_i·u_i)^2}（输入量互不相关）', '√(' + terms.map(t => '(' + t + ')²').join('+') + ')', uncertainty));
    return { value, uncertainty, derivatives, steps };
  }
  function powerProduct(coefficient, quantities) {
    finite(coefficient); let value = coefficient, sum = 0; const terms = [];
    Object.entries(quantities).forEach(([name, q]) => {
      finite(q.value, name); finite(q.power, '指数'); nonnegative(q.uncertainty, name + '不确定度');
      if (q.value === 0) throw new Error('乘幂相对传递的输入量不能为零');
      value *= q.value ** q.power; sum += (q.power * q.uncertainty / q.value) ** 2;
      terms.push('(' + q.power + '×' + q.uncertainty + '/' + q.value + ')²');
    });
    finite(value, '乘幂结果'); const uncertainty = Math.abs(value) * Math.sqrt(sum);
    return { value, uncertainty, steps: [step('f=C\\prod x_i^{p_i}', coefficient + ' × ' + Object.entries(quantities).map(([k, q]) => k + '(' + q.value + ')^' + q.power).join(' × '), value), step('u_f/|f|=\\sqrt{\\sum(p_i u_i/x_i)^2}（互不相关）', '|' + value + '|×√(' + terms.join('+') + ')', uncertainty)] };
  }
  function linearFit(xs, ys, options = {}) {
    const origin = !!options.origin; series(xs, origin ? 2 : 3); series(ys, xs.length);
    if (xs.length !== ys.length) throw new Error('x/y 长度不一致');
    const n = xs.length, mx = mean(xs).value, my = mean(ys).value;
    const sxx = xs.reduce((s, x) => s + (x - mx) ** 2, 0), syy = ys.reduce((s, y) => s + (y - my) ** 2, 0);
    const sxy = xs.reduce((s, x, i) => s + (x - mx) * (ys[i] - my), 0);
    if (sxx === 0) throw new Error('横坐标不能全部相同，无法拟合斜率');
    const denom = origin ? xs.reduce((s, x) => s + x * x, 0) : sxx;
    const slope = (origin ? xs.reduce((s, x, i) => s + x * ys[i], 0) : sxy) / denom;
    const intercept = origin ? 0 : my - slope * mx;
    const residuals = xs.map((x, i) => ys[i] - intercept - slope * x);
    const sse = residuals.reduce((s, r) => s + r * r, 0), df = n - (origin ? 1 : 2), residualStd = Math.sqrt(sse / df);
    const slopeUncertainty = residualStd / Math.sqrt(denom), interceptUncertainty = origin ? 0 : residualStd * Math.sqrt(1 / n + mx * mx / sxx);
    const r = syy === 0 ? 0 : Math.max(-1, Math.min(1, sxy / Math.sqrt(sxx * syy)));
    const leverage = xs.map(x => origin ? x * x / denom : 1 / n + (x - mx) ** 2 / sxx);
    const standardizedResiduals = residuals.map((e, i) => residualStd < 1e-14 * Math.max(1, Math.abs(my)) ? 0 : e / (residualStd * Math.sqrt(Math.max(1e-15, 1 - leverage[i]))));
    const steps = [
      step(origin ? 'b=Σx_i y_i/Σx_i²（过原点）' : 'b=S_{xy}/S_{xx}', (origin ? xs.reduce((s, x, i) => s + x * ys[i], 0) : sxy) + '/' + denom, slope),
      step(origin ? 'a=0（约束）' : 'a=ȳ−b x̄', origin ? '强制截距为零' : my + '−' + slope + '×' + mx, intercept),
      step('s_e=√(Σe_i²/ν)', '√(' + sse + '/' + df + ')', residualStd),
      step('u_b=s_e/√S_{xx}（过原点时分母为 √Σx_i²）', residualStd + '/√' + denom, slopeUncertainty),
      step('u_a=s_e√(1/n+x̄²/S_{xx})；约束截距时为0', origin ? '约束 a=0' : residualStd + '×√(1/' + n + '+' + mx + '²/' + sxx + ')', interceptUncertainty),
      step('r=S_{xy}/√(S_{xx}S_{yy})', sxy + '/√(' + sxx + '×' + syy + ')', r),
      step('e_i=y_i−a−bx_i', residuals.join(', '), '残差列表'),
      step('z_i=e_i/[s_e√(1−h_ii)]；|z_i|>2.5 标记异常', standardizedResiduals.join(', '), '仅提示，不自动剔除')
    ];
    return { slope, intercept, slopeUncertainty, interceptUncertainty, r, residuals, standardizedResiduals, residualStd, df, sse, steps };
  }
  function residualOutliers(fit) {
    const indices = fit.standardizedResiduals.flatMap((z, i) => Math.abs(z) > 2.5 ? [i] : []);
    return { indices, steps: [step('|e_i/[s_e√(1−h_ii)]|>2.5', fit.standardizedResiduals.join(', '), indices.length + ' 个疑似异常点')] };
  }
  function grubbs(xs) {
    series(xs, 3); const m = mean(xs).value, s = standardDeviation(xs).value;
    const deviations = xs.map(x => Math.abs(x - m)); const index = deviations.indexOf(Math.max(...deviations));
    const statistic = s === 0 ? 0 : deviations[index] / s, critical = GRUBBS_TABLE[xs.length] || criticalG(xs.length);
    const indices = statistic > critical ? [index] : [];
    return { indices, statistic, critical, steps: [step('G=max|x_i−x̄|/s', Math.max(...deviations) + '/' + s, statistic), step('G_crit=(n−1)/√n · √[t²/(n−2+t²)]；t=t_{1−α/(2n),n−2}', 'α=0.05, n=' + xs.length, critical), step('G>G_crit 时标记一个最极端点（单轮）', statistic + ' > ' + critical, indices.length ? '疑似异常' : '未检出')] };
  }
  function formatResult(value, uncertainty, unit = '') {
    finite(value); nonnegative(uncertainty, '不确定度');
    if (uncertainty === 0) return { value: String(value) + ' ± 0' + (unit ? ' ' + unit : ''), uncertaintyText: '0', valueText: String(value), steps: [step('u=0', '理想数据或输入未提供不确定度', '未据此推断测量完全精确')] };
    const exponent = Math.floor(Math.log10(uncertainty)), first = Math.floor(uncertainty / 10 ** exponent + 1e-12);
    const digits = first <= 2 ? 2 : 1;
    let place = exponent - digits + 1, quantum = 10 ** place;
    const roundedU = Math.round(uncertainty / quantum + 1e-10) * quantum;
    // A carry (e.g. 0.099 -> 0.1) must not invent an extra significant digit.
    place = Math.max(place, Math.floor(Math.log10(roundedU)) - digits + 1); quantum = 10 ** place;
    const roundedV = Math.sign(value) * Math.round(Math.abs(value) / quantum + 1e-10) * quantum;
    const decimals = Math.max(0, -place);
    const uncertaintyText = roundedU.toFixed(Math.min(100, decimals)), valueText = roundedV.toFixed(Math.min(100, decimals));
    return { value: valueText + ' ± ' + uncertaintyText + (unit ? ' ' + unit : ''), valueText, uncertaintyText, quantum, steps: [step('u 首位1或2留2位有效数字，否则留1位；x末位与u对齐（四舍五入）', 'x=' + value + ', u=' + uncertainty + ', 修约间隔=' + quantum, valueText + ' ± ' + uncertaintyText + ' ' + unit)] };
  }
  function compare(value, reference, uncertainty) {
    finite(value); finite(reference); nonnegative(uncertainty, '不确定度'); if (reference === 0) throw new Error('公认值不能为零');
    const difference = Math.abs(value - reference), relativeError = difference / Math.abs(reference) * 100;
    const verdict = difference <= 2 * uncertainty ? '一致' : difference <= 3 * uncertainty ? '基本一致' : '偏差显著';
    return { relativeError, difference, verdict, steps: [step('E=|x−x₀|/|x₀|×100%', '|' + value + '−' + reference + '|/|' + reference + '|×100%', relativeError + '%'), step('|x−x₀|≤2u：一致；≤3u：基本一致；其余：偏差显著', '差值=' + difference + ', 2u=' + 2 * uncertainty + ', 3u=' + 3 * uncertainty, verdict)] };
  }
  // 科学计数法输出：|x|≥1e5 或 0<|x|<1e-3 时，按 (a ± b)×10ⁿ 单位 格式化，修约规则与 formatResult 相同
  const SUP = { '-': '⁻', '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹' };
  const sup = n => String(n).split('').map(c => SUP[c] || c).join('');
  function formatAuto(value, uncertainty, unit = '') {
    if (unit === '1') unit = '';
    finite(value); nonnegative(uncertainty, '不确定度');
    const a = Math.abs(value);
    if (!(a >= 1e5 || (a > 0 && a < 1e-3))) return formatResult(value, uncertainty, unit);
    const e = Math.floor(Math.log10(a)), scale = 10 ** e;
    const inner = formatResult(value / scale, uncertainty / scale, '');
    const text = '(' + inner.valueText + ' ± ' + inner.uncertaintyText + ')×10' + sup(e) + (unit ? ' ' + unit : '');
    return { ...inner, value: text, exponent: e, steps: [...inner.steps, step('科学计数法：x=(a±u_a)×10^n', 'n=' + e, text)] };
  }
  // 逐差法：按 x 升序的 2k 个等间隔数据，δ_i=y_{i+k}−y_i（i=1..k）
  function successiveDiff(xs, ys, options = {}) {
    series(xs, 4); series(ys, xs.length);
    let n = xs.length; const dropped = n % 2 === 1; if (dropped) n -= 1;
    const k = n / 2, deltas = [], dxs = [];
    for (let i = 0; i < k; i++) { deltas.push(ys[i + k] - ys[i]); dxs.push(xs[i + k] - xs[i]); }
    const dx = mean(dxs).value, md = mean(deltas).value;
    const a = typeA(deltas, options), slope = md / dx;
    const uB = options.instrumentErrorY ? typeB(options.instrumentErrorY).value : 0;
    const u = Math.hypot(a.value, uB), slopeUncertainty = u / dx;
    const steps = [
      step('按 x 升序分前后两组（共 2k 个点）', (dropped ? '点数为奇数，舍去最后一点；' : '') + 'k=' + k, 'k=' + k),
      step('δ_i=y_{i+k}−y_i', deltas.join(', '), '逐差值'),
      step('\\bar{δ}=Σδ_i/k', '(' + deltas.join(' + ') + ')/' + k, md),
      ...a.steps,
      step('u_B(δ)=Δ仪/√3（与模板库约定一致）', String(options.instrumentErrorY || 0), uB),
      step('u(δ)=√(u_A²+u_B²)', '√(' + a.value + '² + ' + uB + '²)', u),
      step('Δx_k=平均(x_{i+k}−x_i)', dxs.join(', '), dx),
      step('斜率 b=\\bar{δ}/Δx_k，u_b=u(δ)/Δx_k', md + '/' + dx, slope)
    ];
    return { slope, slopeUncertainty, meanDelta: md, deltaUncertainty: u, uA: a.value, uB, k, dx, deltas, dropped, steps };
  }
  // 坐标轴“好看”刻度：步长取 1/2/5×10ⁿ
  function niceTicks(min, max, count = 6) {
    if (!(Number.isFinite(min) && Number.isFinite(max))) return { min: 0, max: 1, step: 0.2, ticks: [0, 0.2, 0.4, 0.6, 0.8, 1], decimals: 1 };
    if (min === max) { const d = Math.abs(min) * 0.1 || 1; min -= d; max += d; }
    const raw = (max - min) / Math.max(1, count - 1), p = 10 ** Math.floor(Math.log10(raw)), f = raw / p;
    const stepSize = (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * p;
    const lo = Math.floor(min / stepSize + 1e-9) * stepSize, hi = Math.ceil(max / stepSize - 1e-9) * stepSize;
    const decimals = Math.max(0, -Math.floor(Math.log10(stepSize) + 1e-9));
    const ticks = []; for (let v = lo; v <= hi + stepSize * 1e-6; v += stepSize) ticks.push(Number(v.toFixed(Math.min(20, decimals + 2))));
    return { min: lo, max: hi, step: stepSize, ticks, decimals };
  }
  // 单一异常判据：格拉布斯检验（α=0.05，单轮，最极端一点）
  function grubbsOnResiduals(residuals) { return grubbs(residuals); }
  return { mean, standardDeviation, typeA, typeB, combine, relative, propagate, powerProduct, linearFit, residualOutliers, grubbs, grubbsOnResiduals, formatResult, formatAuto, successiveDiff, niceTicks, compare, tFactor, T_TABLE, GRUBBS_TABLE };
});
