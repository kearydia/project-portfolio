(function () {
  'use strict';
  const E = window.PhysExperiments, C = window.PhysCalc, Chart = window.PhysChart, AI = window.PhysAI, Report = window.PhysReport;
  const $ = id => document.getElementById(id), esc = Chart.escape;
  const state = { type: 'pendulum', params: { ...E.defaults.pendulum }, rows: [], result: null, simulated: true, sourceSimulated: true, source: '', explanation: '', modelExplanation: '', revision: 0 };
  const labels = { mode: '计算方法', reference: '公认值', length: '摆长 / 金属丝长 L (m)', deltaL: '长度仪器误差 ΔL (m)', deltaT: '输入时间仪器误差 Δt (s)', timeMode: '时间输入方式', cycles: '总时间对应的周期数 N', bMode: 'B 类模型', useT: 'A 类是否乘 t 因子', coverage: 't 因子双侧覆盖概率', origin: '是否强制过原点', correction: '伏安法接法修正', ra: '电流表内阻 R_A (Ω)', rv: '电压表内阻 R_V (Ω)', currentUnit: '电流输入单位', diameter: '直径重复测量 d (m)，逗号分隔', arm: '光杠杆臂长 b (m)', distance: '镜尺距离 D (m)', deltaD: '镜尺距离仪器误差 ΔD (m)', deltaB: '臂长仪器误差 Δb (m)', deltaDiameter: '直径仪器误差 Δd (m)', forceUnit: '载荷输入单位', readingUnit: '标尺读数单位', gravity: '质量换算用 g (m/s²)' };
  const options = { mode: [['fit', 'T²–L 多摆长拟合'], ['single', '单摆长重复测量']], timeMode: [['period', '单周期 T (s)'], ['total', 'N 次总时间 t_N (s)']], bMode: [['rectangular', '均匀分布：Δ仪 / √3'], ['direct', '直接使用：Δ仪']], useT: [['false', '不乘（标准不确定度）'], ['true', '乘 t 因子（教学选项）']], coverage: [['0.95', '95%（双侧）'], ['0.683', '68.3%（双侧）']], origin: [['false', '自由截距（推荐）'], ['true', '强制过原点']], correction: [['none', '不修正'], ['internal', '内接：R测 − R_A'], ['external', '外接：1/R = 1/R测 − 1/R_V']], currentUnit: [['mA', 'mA（毫安）'], ['A', 'A（安培）']], forceUnit: [['kg', '质量 m (kg)'], ['N', '拉力 F (N)']], readingUnit: [['cm', 'cm（厘米）'], ['mm', 'mm（毫米）'], ['m', 'm（米）']] };
  const fmt = n => Number.isFinite(n) ? Number(n.toPrecision(7)).toString() : '—';
  function stepsHTML(steps) { return '<ol class="steps">' + steps.map(s => '<li><code>' + esc(s.formula) + '</code><p>代入：' + esc(s.substitution) + '</p><p>结果：' + esc(s.result) + '</p></li>').join('') + '</ol>'; }
  function activeFields() {
    if (state.type === 'pendulum') return ['mode', 'reference', 'timeMode', ...(state.params.timeMode === 'total' ? ['cycles'] : []), ...(state.params.mode === 'single' ? ['length', 'deltaL', 'deltaT', 'bMode', 'useT', ...(state.params.useT ? ['coverage'] : [])] : ['origin'])];
    if (state.type === 'resistance') return ['reference', 'currentUnit', 'correction', ...(state.params.correction === 'internal' ? ['ra'] : state.params.correction === 'external' ? ['rv'] : []), 'origin'];
    return ['reference', 'length', 'diameter', 'arm', 'distance', 'forceUnit', ...(state.params.forceUnit === 'kg' ? ['gravity'] : []), 'readingUnit', 'deltaL', 'deltaDiameter', 'deltaB', 'deltaD', 'bMode', 'useT', ...(state.params.useT ? ['coverage'] : []), 'origin'];
  }
  function renderParameters() {
    $('parameters').innerHTML = activeFields().map(key => {
      let control;
      if (options[key]) control = '<select data-param="' + key + '" id="param-' + key + '">' + options[key].map(([value, label]) => '<option value="' + value + '"' + (String(state.params[key]) === value ? ' selected' : '') + '>' + esc(label) + '</option>').join('') + '</select>';
      else if (key === 'diameter') control = '<textarea data-param="diameter" id="param-diameter" rows="3">' + esc(state.params[key]) + '</textarea>';
      else control = '<input data-param="' + key + '" id="param-' + key + '" type="number" step="any" value="' + esc(state.params[key]) + '">';
      return '<label class="param-label" for="param-' + key + '">' + esc(labels[key]) + control + '</label>';
    }).join('');
    $('method-note').textContent = state.type === 'pendulum' ? state.params.mode === 'single' ? 'g=4π²L/T²。重复周期用 Grubbs 检验；仪器误差与输入时间保持同一口径。切换计算方法时会载入对应模拟数据。' : 'T²–L 拟合。此模式只由斜率标准不确定度传递 u_g，不包含仪器共同系统误差。' : state.type === 'resistance' ? '横轴为电流，纵轴为电压。拟合时自动统一为 A、V。修正参数的自身不确定度暂不计入。' : 'E=8LD/(πd²bk)，k=Δn/ΔF。各长度参数用 m，读数和载荷按所选单位换算；截距吸收标尺初始读数。';
  }
  function renderSamples() {
    $('sample-select').innerHTML = window.PhysSamples.filter(s => s.type === state.type).map(s => '<option value="' + s.id + '">' + esc(s.name.replaceAll('_', ' · ')) + '</option>').join('');
  }
  function renderHeaders() { const cols = E.columns(state.type, state.params); $('data-table').querySelector('thead').innerHTML = '<tr><th>保留</th><th>#</th><th>' + esc(cols[0]) + '</th><th>' + esc(cols[1]) + '</th><th>备注 / 剔除依据</th><th>状态</th></tr>'; }
  function renderData() {
    renderHeaders(); $('data-table').querySelector('tbody').innerHTML = state.rows.map((r, i) => '<tr data-row="' + i + '"><td><input type="checkbox" data-keep="' + i + '" aria-label="保留第 ' + (i + 1) + ' 行"' + (r.excluded ? '' : ' checked') + '></td><td>' + (i + 1) + '</td><td><input type="number" step="any" data-field="x" data-row="' + i + '" aria-label="第 ' + (i + 1) + ' 行横坐标" value="' + (Number.isFinite(r.x) ? r.x : '') + '"></td><td><input type="number" step="any" data-field="y" data-row="' + i + '" aria-label="第 ' + (i + 1) + ' 行纵坐标" value="' + (Number.isFinite(r.y) ? r.y : '') + '"></td><td><input data-field="note" data-row="' + i + '" aria-label="第 ' + (i + 1) + ' 行备注" value="' + esc(r.note || '') + '"></td><td class="row-state"></td></tr>').join('');
  }
  function markRows() {
    $('data-table').querySelectorAll('tbody tr').forEach(tr => {
      const index = Number(tr.dataset.row), excluded = state.rows[index].excluded, outlier = state.result && state.result.outlierIndices.includes(index);
      tr.className = excluded ? 'excluded' : outlier ? 'outlier' : '';
      tr.querySelector('input[type=checkbox]').checked = !excluded;
      tr.querySelector('.row-state').textContent = excluded ? '已剔除' : outlier ? '疑似异常' : '保留';
    });
  }
  function recalculate() {
    state.revision++; state.modelExplanation = ''; $('model-explanation').textContent = ''; $('api-status').textContent = '';
    $('source-label').textContent = (state.simulated ? '模拟数据 · ' : '用户数据 · ') + state.source;
    $('simulated').checked = state.simulated;
    try {
      const r = E.process(state.type, state.rows, state.params); state.result = r;
      $('error').hidden = true;
      const badge = r.comparison.verdict === '一致' ? 'good' : r.comparison.verdict === '基本一致' ? 'medium' : 'bad';
      const metrics = [...r.metrics, { label: '相对不确定度', value: r.relativeUncertainty, unit: '%', steps: C.relative(r.value, r.uncertainty).steps }, { label: '相对误差', value: r.comparison.relativeError, unit: '%', steps: r.comparison.steps }];
      $('results').innerHTML = '<details class="result-main"><summary><span class="result-label">' + esc(r.title) + ' · ' + (state.simulated ? '模拟数据' : '用户数据') + '</span><span class="result-number">' + esc(r.symbol + ' = ' + r.formatted) + '</span><span class="click-hint">展开：公式、代入数值与完整结果 ↓</span></summary>' + stepsHTML(r.steps) + '</details><div class="compare-row"><span class="badge ' + badge + '">' + r.comparison.verdict + '</span><span>公认值 ' + esc(fmt(r.params.reference) + ' ' + r.unit) + '</span><span>相对误差 ' + fmt(r.comparison.relativeError) + '%</span><span>保留 ' + r.count + ' / ' + state.rows.length + ' 点</span></div><div class="metrics">' + metrics.map(m => '<details class="metric"><summary>' + esc(m.label) + '<strong>' + esc(fmt(m.value) + ' ' + m.unit) + '</strong></summary>' + stepsHTML(m.steps) + '</details>').join('') + '</div><div class="method-warning">' + esc(r.warnings.join(' ')) + '</div>';
      $('chart').innerHTML = Chart.svg(r.plot, state.rows, r.outlierIndices);
      state.explanation = AI.explain(r); $('explanation').textContent = state.explanation;
      $('data-status').textContent = '疑似异常 ' + r.outlierIndices.length + ' 点；已剔除 ' + r.excludedCount + ' 点。' + (r.fit ? '检测标准：|标准化残差| > 2.5。' : '检测标准：Grubbs 单轮双侧检验，α=0.05。') + ' 不会自动剔除。';
      ['export-html', 'export-doc'].forEach(id => { $(id).disabled = false; });
      $('exclude-outliers').disabled = !r.outlierIndices.length;
    } catch (error) {
      state.result = null; state.explanation = '';
      $('error').textContent = error.message; $('error').hidden = false;
      $('results').innerHTML = ''; $('chart').innerHTML = '<p class="hint">请修正参数或补充有效数据后查看图表。</p>';
      $('explanation').textContent = '请先获得有效计算结果。'; $('data-status').textContent = '当前数据无法计算；导出已暂停。';
      ['export-html', 'export-doc', 'exclude-outliers'].forEach(id => { $(id).disabled = true; });
    }
    markRows();
  }
  function loadSample(id) {
    const sample = window.PhysSamples.find(s => s.id === id); if (!sample) return;
    state.type = sample.type; state.params = { ...E.defaults[sample.type], ...sample.params };
    const parsed = E.parseCSV(sample.csv, state.type, state.params);
    state.params = { ...state.params, ...parsed.hints }; state.rows = parsed.rows; state.simulated = true; state.sourceSimulated = true; state.source = sample.name + '.csv';
    renderParameters(); renderSamples(); $('sample-select').value = sample.id; renderData(); recalculate(); $('import-status').textContent = '已加载固定种子模拟数据，包含 1 个预设异常点。'; $('import-status').className = 'status';
  }
  document.querySelectorAll('.tab').forEach(button => button.addEventListener('click', () => {
    const next = button.dataset.type; if (next === state.type) return;
    document.querySelectorAll('.tab').forEach(b => { b.classList.toggle('active', b === button); b.setAttribute('aria-pressed', String(b === button)); });
    loadSample(window.PhysSamples.find(s => s.type === next).id);
  }));
  $('load-sample').addEventListener('click', () => loadSample($('sample-select').value));
  $('parameters').addEventListener('input', event => {
    const key = event.target.dataset.param; if (!key) return;
    if (key === 'mode') { loadSample(event.target.value === 'single' ? 'pendulum_single' : 'pendulum_fit'); return; }
    const old = state.params[key]; state.params[key] = typeof old === 'boolean' ? event.target.value === 'true' : typeof old === 'number' ? (event.target.value.trim() ? Number(event.target.value) : NaN) : event.target.value;
    if (options[key]) { renderParameters(); renderHeaders(); }
    recalculate();
  });
  $('data-table').addEventListener('input', event => {
    const field = event.target.dataset.field; if (!field) return;
    const row = state.rows[Number(event.target.dataset.row)]; row[field] = field === 'note' ? event.target.value : event.target.value.trim() ? Number(event.target.value) : NaN; recalculate();
  });
  $('data-table').addEventListener('change', event => { if (event.target.dataset.keep !== undefined) { state.rows[Number(event.target.dataset.keep)].excluded = !event.target.checked; recalculate(); } });
  function togglePoint(event) { const circle = event.target.closest('[data-index]'); if (!circle) return; const row = state.rows[Number(circle.dataset.index)]; row.excluded = !row.excluded; recalculate(); }
  $('chart').addEventListener('click', togglePoint);
  $('chart').addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); togglePoint(event); } });
  $('exclude-outliers').addEventListener('click', () => { if (!state.result) return; state.result.outlierIndices.forEach(i => { state.rows[i].excluded = true; }); recalculate(); });
  $('restore-all').addEventListener('click', () => { state.rows.forEach(r => { r.excluded = false; }); recalculate(); });
  $('add-row').addEventListener('click', () => { state.rows.push({ x: NaN, y: NaN, note: state.simulated ? '模拟数据' : '', excluded: false }); renderData(); recalculate(); });
  $('simulated').addEventListener('change', () => {
    state.simulated = state.sourceSimulated || $('simulated').checked;
    if (state.sourceSimulated && !$('simulated').checked) $('import-status').textContent = '此数据源明确标注为模拟数据，不能取消来源标记。';
    recalculate();
  });
  async function importFile(file) {
    if (!file) return;
    try {
      if (/\.xlsx?$/i.test(file.name)) throw new Error('请另存为 CSV；本离线版本不引入 Excel 解析库。');
      if (file.size > 2 * 1024 * 1024) throw new Error('文件超过 2 MB，请缩小数据规模后导入。');
      const snapshot = state.revision, text = await file.text();
      if (state.revision !== snapshot) throw new Error('读取期间实验或数据已改变，请重新选择文件。');
      const parsed = E.parseCSV(text, state.type, state.params);
      if (parsed.rows.length > 1000) throw new Error('当前演示版本最多支持 1000 行数据。');
      state.rows = parsed.rows; state.params = { ...state.params, ...parsed.hints }; state.simulated = parsed.simulated; state.sourceSimulated = parsed.simulated; state.source = file.name;
      renderParameters(); renderData(); recalculate();
      $('import-status').textContent = '成功导入 ' + parsed.rows.length + ' 行。请核对实验方法、表头单位及时间周期数。'; $('import-status').className = 'status';
    } catch (error) { $('import-status').textContent = error.message; $('import-status').className = 'status bad'; }
    $('file-input').value = '';
  }
  $('file-input').addEventListener('change', event => importFile(event.target.files[0]));
  ['dragenter', 'dragover'].forEach(name => $('drop-zone').addEventListener(name, event => { event.preventDefault(); $('drop-zone').classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach(name => $('drop-zone').addEventListener(name, event => { event.preventDefault(); $('drop-zone').classList.remove('dragover'); }));
  $('drop-zone').addEventListener('drop', event => importFile(event.dataTransfer.files[0]));
  document.addEventListener('dragover', event => event.preventDefault());
  document.addEventListener('drop', event => event.preventDefault());
  $('ask-ai').addEventListener('click', async () => {
    if (!state.result) { $('api-status').textContent = '请先获得有效计算结果。'; return; }
    const revision = state.revision; $('ask-ai').disabled = true; $('api-status').textContent = '正在请求解释，规则文本仍保留…';
    try {
      const explanation = await AI.requestExplanation(state.result, { base: $('api-base').value, model: $('api-model').value, key: $('api-key').value });
      if (state.revision !== revision) { $('api-status').textContent = '数据已改变，已忽略旧结果的模型解释。'; return; }
      state.modelExplanation = explanation; $('model-explanation').textContent = explanation; $('api-status').textContent = '解释已返回；计算结果未改变。';
    } catch (error) { $('api-status').textContent = '请求失败：' + error.message + '。保留规则解释。请检查网络、密钥和接口 CORS 设置。'; }
    finally { $('ask-ai').disabled = false; }
  });
  function exportReport(format) {
    if (!state.result) return;
    const html = Report.build({ result: state.result, rows: state.rows, columns: E.columns(state.type, state.params), explanation: state.explanation + (state.modelExplanation ? '\n\n' + state.modelExplanation : ''), simulated: state.simulated, source: state.source, parameterLabels: labels });
    Report.download(html, format, state.result.title.replace(/[（）＋]/g, '') + (state.simulated ? '_模拟数据' : '') + '_实验报告');
  }
  $('export-html').addEventListener('click', () => exportReport('html'));
  $('export-doc').addEventListener('click', () => exportReport('doc'));
  loadSample('pendulum_fit');
})();
