/*
 * 实验算盘 · 通用实验引擎（模板驱动）
 * 依赖：src/calc.js（PhysCalc，统计/拟合/传递/修约）与 src/codearts_calc.js（PhysicsCalc，码道 CodeArts 生成的计算核心：
 *       格拉布斯检验 detectOutliers / grubbsResiduals、表格校验 validateTable、与公认值比较 compareWithReference、单摆/伏安法核心）。
 * 模板接口见 TEMPLATE_SPEC.md。引擎本身不含任何具体实验的公式。
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./calc.js'), require('./codearts_calc.js'));
  else root.LabEngine = factory(root.PhysCalc, root.PhysicsCalc);
})(typeof globalThis !== 'undefined' ? globalThis : this, function (C, K) {
  'use strict';
  const CATEGORIES = ['力学', '热学', '电磁学', '光学', '近代物理'];
  const METHODS = ['direct', 'linear_fit', 'successive_diff', 'formula'];
  const KINDS = ['repeated', 'single', 'column_x', 'column_y'];
  const SQRT3 = Math.sqrt(3);
  const S = (formula, substitution, result, title) => ({ title: title || '', formula, substitution: String(substitution), result });

  /* ---------- 模板校验与注册表 ---------- */
  function validateTemplate(t) {
    const e = [];
    if (!t || typeof t !== 'object') return ['模板必须是对象'];
    ['id', 'name', 'category', 'summary', 'method'].forEach(k => { if (typeof t[k] !== 'string' || !t[k]) e.push('缺少字段 ' + k); });
    if (t.category && !CATEGORIES.includes(t.category)) e.push('category 必须是 ' + CATEGORIES.join('/') + ' 之一');
    if (t.method && !METHODS.includes(t.method)) e.push('method 必须是 ' + METHODS.join('/') + ' 之一');
    if (!Array.isArray(t.inputs)) e.push('inputs 必须是数组');
    else t.inputs.forEach((i, n) => { if (!i.key || !i.label) e.push('inputs[' + n + '] 缺少 key/label'); if (i.kind && !KINDS.includes(i.kind)) e.push('inputs[' + n + '].kind 非法'); });
    if (t.params && !Array.isArray(t.params)) e.push('params 必须是数组');
    if (!t.result || typeof t.result.compute !== 'function') e.push('result.compute 必须是函数');
    if (t.method === 'linear_fit' || t.method === 'successive_diff') {
      if (t.transform && typeof t.transform !== 'object') e.push('transform 必须是对象（可省略，省略时直接用 column_x/column_y 两列）');
      if (!dataInputs(t).some(i => i.kind === 'column_x') || !dataInputs(t).some(i => i.kind === 'column_y')) e.push(t.method + ' 需要 column_x 与 column_y 输入');
    }
    if (t.method === 'direct' && !dataInputs(t).some(i => i.kind === 'repeated')) e.push('direct 需要至少一个 repeated 输入');
    if (!t.accepted || !Number.isFinite(t.accepted.value)) e.push('accepted.value 必须是数字');
    return e;
  }
  function registry(list) {
    const seen = new Set(), templates = [], rejected = [];
    (list || []).forEach(t => {
      const errors = validateTemplate(t);
      if (!errors.length && seen.has(t.id)) errors.push('id 重复：' + t.id);
      if (errors.length) rejected.push({ id: t && t.id, errors }); else { seen.add(t.id); templates.push(t); }
    });
    return { templates, rejected };
  }
  function search(templates, query, category) {
    const q = String(query || '').trim().toLowerCase();
    return templates.filter(t => (!category || category === '全部' || t.category === category) &&
      (!q || [t.name, t.summary, t.category, t.id, ...(t.keywords || [])].join(' ').toLowerCase().includes(q)));
  }
  const dataInputs = t => (t.inputs || []).filter(i => i.kind !== 'single');

  /* ---------- CSV 解析 + 脏数据校验（校验调用码道核心 validateTable） ---------- */
  const norm = s => String(s || '').trim().toLowerCase().replace(/[（(\[【].*$/, '').replace(/[\s_]/g, '');
  const NUM = /^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$/;
  const rowKeys = tpl => tpl.method === 'linear_fit' || tpl.method === 'successive_diff' ? dataInputs(tpl).filter(i => i.kind === 'column_x' || i.kind === 'column_y') : [];
  function parseCSV(text, tpl) {
    const src = String(text == null ? '' : text).replace(/^\uFEFF/, '');
    const comments = [], body = [];
    src.split(/\r?\n/).forEach(line => { const s = line.trim(); if (!s) return; if (s.startsWith('#')) comments.push(s); else body.push(line); });
    const fail = msgs => ({ ok: false, errors: msgs, rows: [], simulated: false, comments });
    if (!body.length) return fail(['文件中没有数据：只有空行或 # 注释行。请确认第一行是表头，下面是数据。']);
    const first = body[0], delim = first.includes('\t') ? '\t' : first.includes(',') ? ',' : first.includes('，') ? '，' : first.includes(';') ? ';' : ',';
    const split = l => l.split(delim).map(c => c.trim().replace(/^"(.*)"$/, '$1'));
    const header = split(first), cols = (tpl.inputs || []), index = {}, missing = [];
    cols.forEach(i => {
      const names = [i.key, i.label, ...(i.aliases || [])].map(norm);
      let at = header.findIndex(h => h.trim() === i.key);
      if (at < 0) at = header.findIndex(h => names.includes(norm(h)));
      if (at < 0) missing.push('「' + i.label + '」（列名可写 ' + i.key + (i.unit ? '(' + i.unit + ')' : '') + '）'); else index[i.key] = at;
    });
    if (missing.length) return fail(['表头无法识别：缺少列 ' + missing.join('、') + '。当前表头为：' + header.join(' | ') + '。请检查是否选错了实验类型。']);
    const objects = [], errors = [];
    body.slice(1).forEach((line, n) => {
      const cells = split(line), o = {};
      if (cells.length < header.length && rowKeys(tpl).length) errors.push('数据第 ' + (n + 1) + ' 行：列数不足（应有 ' + header.length + ' 列，实际 ' + cells.length + ' 列）');
      cols.forEach(i => { const raw = cells[index[i.key]]; o[i.key] = raw === undefined || raw === '' ? '' : NUM.test(raw) ? Number(raw) : raw; });
      objects.push(o);
    });
    const rk = rowKeys(tpl), minRows = tpl.method === 'successive_diff' ? 4 : 3;
    if (rk.length) {
      const v = K.validateTable(objects.map(o => Object.fromEntries(rk.map(i => [i.key, o[i.key]]))), { columns: rk.map(i => ({ key: i.key, label: i.label + (i.unit ? '(' + i.unit + ')' : '') })), checkUnits: false, minRows });
      if (!v.ok) v.errors.forEach(e => errors.push(e.message.replace(/^第 (\d+) 行/, '数据第 $1 行')));
    }
    cols.filter(i => !rk.includes(i)).forEach(i => {
      const vals = []; objects.forEach((o, n) => { const x = o[i.key]; if (x === '') return; if (typeof x !== 'number') errors.push('数据第 ' + (n + 1) + ' 行：列「' + i.label + '」不是有效数字（实际为 "' + x + '"）'); else vals.push(x); });
      const need = i.kind === 'repeated' && tpl.method === 'direct' ? 3 : 1;
      if (vals.length < need) errors.push('列「' + i.label + '」至少需要 ' + need + ' 个数值（当前 ' + vals.length + ' 个）' + (i.kind === 'single' ? '，单次测量量写在第一行即可' : ''));
    });
    if (errors.length) return fail(errors);
    const rows = objects.map(o => ({ values: o, excluded: false }));
    const simulated = comments.some(c => c.includes('模拟数据')) || src.includes('模拟数据');
    return { ok: true, errors: [], rows, simulated, comments };
  }
  function sampleText(tpl, samples) {
    const s = String(tpl.sampleCsv || '');
    if (s.includes('\n')) return s;
    return (samples || {})[s.split('/').pop()] || '';
  }

  /* ---------- 参数与不确定度 ---------- */
  function paramValues(tpl, overrides = {}) {
    const p = {}, u = {};
    // 开关先读取，供 enabledBy 参数判断是否启用；开关本身没有测量不确定度。
    (tpl.params || []).filter(d => d.type === 'switch').forEach(d => {
      const raw = overrides[d.key];
      const v = Number(raw !== undefined && raw !== '' ? raw : d.default);
      if (v !== 0 && v !== 1) throw new Error('开关「' + d.label + '」必须是 0 或 1');
      p[d.key] = v; u[d.key] = 0;
    });
    (tpl.params || []).forEach(d => {
      if (d.type === 'switch') return;
      if (d.enabledBy && !p[d.enabledBy]) { p[d.key] = d.default; u[d.key] = 0; return; }
      const v = overrides[d.key] !== undefined && overrides[d.key] !== '' ? Number(overrides[d.key]) : d.default;
      if (!Number.isFinite(v)) throw new Error('参数「' + d.label + '」必须是数字');
      p[d.key] = v;
      const du = overrides['Δ' + d.key] !== undefined && overrides['Δ' + d.key] !== '' ? Number(overrides['Δ' + d.key]) : d.instrumentError;
      if (du !== undefined && !(du >= 0)) throw new Error('参数「' + d.label + '」的仪器误差必须是非负数');
      u[d.key] = d.uncertainty !== undefined ? d.uncertainty : du !== undefined ? du / SQRT3 : 0;
    });
    return { p, u };
  }
  const xyOf = (tpl, row, p) => {
    const t = tpl.transform || {}, xi = dataInputs(tpl).find(i => i.kind === 'column_x'), yi = dataInputs(tpl).find(i => i.kind === 'column_y');
    const fx = typeof t.x === 'function' ? t.x : r => r[typeof t.x === 'string' ? t.x : xi.key];
    const fy = typeof t.y === 'function' ? t.y : r => r[typeof t.y === 'string' ? t.y : yi.key];
    return { x: fx(row, p), y: fy(row, p) };
  };
  const getPath = (o, path) => path.split('.').reduce((a, k) => a == null ? a : a[k], o);
  const setPath = (o, path, v) => { const ks = path.split('.'); let a = o; ks.slice(0, -1).forEach(k => { a = a[k]; }); a[ks[ks.length - 1]] = v; };
  const clone = ctx => ({ mean: { ...ctx.mean }, fit: ctx.fit ? { ...ctx.fit } : null, diff: ctx.diff ? { ...ctx.diff } : null, params: { ...ctx.params }, n: ctx.n });

  /* ---------- 异常值：单一判据 = 格拉布斯检验 α=0.05（码道核心 detectOutliers） ---------- */
  function detectOutliers(tpl, rows, p) {
    const criterion = '格拉布斯检验（α=0.05，单轮，检验最偏离的一个点）';
    try {
      let values, kind;
      if (tpl.method === 'direct' || tpl.method === 'formula') {
        kind = 'measurement';
        for (const i of dataInputs(tpl).filter(x => x.kind === 'repeated')) {
          const idx = rows.map((r, k) => typeof r.values[i.key] === 'number' ? k : -1).filter(k => k >= 0);
          if (idx.length < 3) continue;
          const g = K.detectOutliers(idx.map(k => rows[k].values[i.key]), { kind });
          if (g.isOutlier) return { criterion, indices: [idx[g.candidateIndex]], statistic: g.statistic, critical: g.critical, n: g.n, steps: g.steps, note: '对「' + i.label + '」的重复测量值做检验' };
          values = values || { g, label: i.label };
        }
        return { criterion, indices: [], statistic: values && values.g.statistic, critical: values && values.g.critical, steps: values ? values.g.steps : [], note: '对各重复测量列做检验' };
      }
      else { if (!tpl.transform) { const xi = dataInputs(tpl).find(i => i.kind === 'column_x'), yi = dataInputs(tpl).find(i => i.kind === 'column_y'); tpl = { ...tpl, transform: { x: xi.key, y: yi.key } }; } const pts = rows.map(r => xyOf(tpl, r.values, p)); const fit = C.linearFit(pts.map(q => q.x), pts.map(q => q.y)); values = fit.residuals; kind = 'residuals'; }
      const g = K.detectOutliers(values, { kind });
      return { criterion, indices: g.isOutlier ? [g.candidateIndex] : [], statistic: g.statistic, critical: g.critical, n: g.n, steps: g.steps, note: kind === 'residuals' ? '对全部数据点的拟合残差做检验' : '对重复测量值做检验' };
    } catch (err) { return { criterion, indices: [], steps: [], note: '未执行异常检验：' + err.message }; }
  }

  /* ---------- 主流程 ---------- */
  function process(tpl, rows, options = {}) {
    const { p, u: pu } = paramValues(tpl, options.params || {});
    const deltas = options.deltas || {}, tOpt = { useT: !!options.useT, coverage: options.coverage || 0.683 };
    const included = rows.filter(r => !r.excluded), items = [], ctx = { mean: {}, fit: null, diff: null, params: { ...p }, n: included.length }, u = {};
    Object.keys(p).forEach(k => { u['params.' + k] = pu[k]; });
    const delta = i => deltas[i.key] !== undefined && deltas[i.key] !== '' ? Number(deltas[i.key]) : (i.instrumentError || 0);
    const add = (key, label, value, unit, steps) => items.push({ key, label, value, unit: unit || '', steps: steps || [] });
    let chart, fitUB = 0;
    const tf = tpl.transform || {};
    // 直接测量量：repeated → 平均值与 A/B 合成；single → 取第一行数值，u=Δ仪/√3（所有方法通用）
    (tpl.inputs || []).filter(i => i.kind === 'repeated' || i.kind === 'single').forEach(i => {
      const xs = included.map(r => r.values[i.key]).filter(x => typeof x === 'number');
      const all = rows.map(r => r.values[i.key]).filter(x => typeof x === 'number');
      if (i.kind === 'single') {
        const v = (xs.length ? xs : all)[0]; if (!Number.isFinite(v)) throw new Error('缺少单次测量量「' + i.label + '」的数值');
        const b = C.typeB(delta(i)); ctx.mean[i.key] = v; u['mean.' + i.key] = b.value;
        add('mean.' + i.key, i.label + '（单次测量）', v, i.unit, [S('单次测量值', '取自数据表', v)]);
        add('uB.' + i.key, 'u_B(' + i.key + ')', b.value, i.unit, b.steps);
        return;
      }
      if (xs.length < (tpl.method === 'direct' || tpl.method === 'formula' ? 3 : 2)) throw new Error('「' + i.label + '」有效测量值太少（当前 ' + xs.length + ' 个）');
      const m = C.mean(xs), a = C.typeA(xs, tOpt), b = C.typeB(delta(i)), c = C.combine(a.value, b.value);
      ctx.mean[i.key] = m.value; u['mean.' + i.key] = c.value;
      add('mean.' + i.key, i.label + ' 平均值', m.value, i.unit, m.steps);
      add('s.' + i.key, i.label + ' 样本标准差 s', a.s, i.unit, a.steps.slice(0, -1));
      add('uA.' + i.key, 'A 类不确定度 u_A(' + i.key + ')', a.value, i.unit, a.steps);
      add('uB.' + i.key, 'B 类不确定度 u_B(' + i.key + ')', b.value, i.unit, b.steps);
      add('uC.' + i.key, '合成不确定度 u_C(' + i.key + ')', c.value, i.unit, [...a.steps.slice(-1), ...b.steps, ...c.steps]);
    });
    if (tpl.method === 'direct' || tpl.method === 'formula') {
      const first = dataInputs(tpl).find(i => i.kind === 'repeated');
      chart = { kind: 'series', xLabel: '测量序号', yLabel: first.label + (first.unit ? ' (' + first.unit + ')' : ''), points: rows.map((r, k) => ({ index: k, x: k + 1, y: r.values[first.key], excluded: r.excluded })).filter(q => typeof q.y === 'number'), line: { slope: 0, intercept: ctx.mean[first.key] } };
    } else {
      const xi = dataInputs(tpl).find(i => i.kind === 'column_x'), yi = dataInputs(tpl).find(i => i.kind === 'column_y');
      const t2 = tpl.transform ? tpl : { ...tpl, transform: { x: xi.key, y: yi.key } };
      const pts = rows.map((r, k) => ({ index: k, ...xyOf(t2, r.values, p), excluded: r.excluded }));
      const use = pts.filter(q => !q.excluded);
      pts.forEach(q => { if (!Number.isFinite(q.x) || !Number.isFinite(q.y)) throw new Error('第 ' + (q.index + 1) + ' 行变换后不是有限数（检查零值或负值）'); });
      const xLabel = tf.xLabel || xi.label + (xi.unit ? ' (' + xi.unit + ')' : ''), yLabel = tf.yLabel || yi.label + (yi.unit ? ' (' + yi.unit + ')' : '');
      if (tpl.method === 'linear_fit') {
        if (use.length < 3) throw new Error('最小二乘拟合至少需要 3 个保留数据点（当前 ' + use.length + ' 个）');
        const f = C.linearFit(use.map(q => q.x), use.map(q => q.y));
        // 斜率/截距的 B 类分量：由 y 列仪器误差 u_B(y)=Δy/√3 经 y'=h(y) 换算（数值求导，取各点方均根），
        // u_B(b)=u_B(y')/√S_xx，u_B(a)=u_B(y')·√(1/n+x̄²/S_xx)；x 列仪器误差不计入（见 TEMPLATE_SPEC.md）
        const uBy = C.typeB(delta(yi)).value;
        const dy = use.map(q => { const v = rows[q.index].values, y0 = v[yi.key], h = Math.max(Math.abs(y0) * 1e-6, 1e-12); return Math.abs((xyOf(t2, { ...v, [yi.key]: y0 + h }, p).y - xyOf(t2, { ...v, [yi.key]: y0 - h }, p).y) / (2 * h)) * uBy; });
        const uByT = Math.sqrt(dy.reduce((s, x) => s + x * x, 0) / dy.length);
        const xs = use.map(q => q.x), mx = xs.reduce((s, x) => s + x, 0) / xs.length, sxx = xs.reduce((s, x) => s + (x - mx) ** 2, 0);
        const uBb = uByT / Math.sqrt(sxx), uBa = uByT * Math.sqrt(1 / xs.length + mx * mx / sxx);
        fitUB = uBb;
        const uCb = Math.hypot(f.slopeUncertainty, uBb), uCa = Math.hypot(f.interceptUncertainty, uBa);
        ctx.fit = { slope: f.slope, intercept: f.intercept, r: f.r, xMean: mx, yMean: use.reduce((s, q) => s + q.y, 0) / use.length }; u['fit.slope'] = uCb; u['fit.intercept'] = uCa;
        const sB = [S("u_B(y)=Δy/√3，换算到 y' 取各点方均根", 'Δy=' + delta(yi) + '，u_B(y)=' + uBy, uByT),
          S('u_B(b)=u_B(y\')/√S_xx', uByT + '/√' + sxx, uBb), S('u_B(a)=u_B(y\')·√(1/n+x̄²/S_xx)', uByT + '×√(1/' + xs.length + '+' + mx + '²/' + sxx + ')', uBa)];
        add('fit.slope', '斜率 b', f.slope, tf.slopeUnit, f.steps.slice(0, 1).concat(f.steps.slice(3, 4)));
        add('fit.intercept', '截距 a', f.intercept, tf.interceptUnit, f.steps.slice(1, 2).concat(f.steps.slice(4, 5)));
        add('fit.uAslope', '斜率 A 类不确定度 u_A(b)', f.slopeUncertainty, tf.slopeUnit, f.steps.slice(2, 4));
        add('fit.uBslope', '斜率 B 类不确定度 u_B(b)', uBb, tf.slopeUnit, sB.slice(0, 2));
        add('fit.uslope', '斜率合成不确定度 u(b)', uCb, tf.slopeUnit, [...f.steps.slice(2, 4), ...sB.slice(0, 2), S('u(b)=√(u_A²+u_B²)', '√(' + f.slopeUncertainty + '²+' + uBb + '²)', uCb)]);
        add('fit.uintercept', '截距合成不确定度 u(a)', uCa, tf.interceptUnit, [...f.steps.slice(2, 3), ...f.steps.slice(4, 5), sB[0], sB[2], S('u(a)=√(u_A²+u_B²)', '√(' + f.interceptUncertainty + '²+' + uBa + '²)', uCa)]);
        add('fit.r', '相关系数 r', f.r, '', f.steps.slice(5, 6));
        chart = { kind: 'fit', xLabel, yLabel, points: pts, line: { slope: f.slope, intercept: f.intercept } };
      } else {
        // 逐差法：按数据表顺序（等间隔递增）前后两组对应相减
        if (use.length < 4) throw new Error('逐差法至少需要 4 个保留数据点（当前 ' + use.length + ' 个）');
        const d = C.successiveDiff(use.map(q => q.x), use.map(q => q.y), { ...tOpt, instrumentErrorY: tf.yInstrumentError ? tf.yInstrumentError(delta(yi), p) : delta(yi) });
        ctx.diff = { slope: d.slope, meanDelta: d.meanDelta, k: d.k, dx: d.dx }; ctx.fit = { slope: d.slope, intercept: NaN };
        u['diff.slope'] = d.slopeUncertainty; u['fit.slope'] = d.slopeUncertainty;
        // 模板约定：ctx.diff[列名] = 该列逐差平均值，u = √(u_A² + (Δ仪/√3)²)
        [xi, yi].forEach(i => {
          const vals = use.map(q => rows[q.index].values[i.key]), r = C.successiveDiff(use.map(q => q.x), vals, { ...tOpt, instrumentErrorY: delta(i) });
          ctx.diff[i.key] = r.meanDelta; u['diff.' + i.key] = r.deltaUncertainty;
          add('diff.' + i.key, '逐差平均 δ̄(' + i.key + ')', r.meanDelta, i.unit, r.steps.slice(0, -2));
        });
        add('diff.slope', '逐差法斜率 b', d.slope, tf.slopeUnit, d.steps);
        const mx = use.reduce((s, q) => s + q.x, 0) / use.length, my = use.reduce((s, q) => s + q.y, 0) / use.length;
        chart = { kind: 'fit', xLabel, yLabel, points: pts, line: { slope: d.slope, intercept: my - d.slope * mx } };
      }
    }
    (tpl.params || []).forEach(d => {
      if (d.type === 'switch') add('params.' + d.key, d.label, p[d.key], '', [S('开关：0=关闭，1=开启；u=0，不参与传递', d.note || d.label, p[d.key])]);
      else if (d.enabledBy && !p[d.enabledBy]) add('params.' + d.key, d.label + '（未启用）', p[d.key], d.unit, [S('对应修正关闭，不参与计算和不确定度传递', d.enabledBy + '=0', '未启用')]);
      else add('params.' + d.key, d.label, p[d.key], d.unit, [S('u(' + d.key + ')=Δ/√3', d.uncertainty !== undefined ? '模板给定标准不确定度' : '仪器误差 Δ/√3', pu[d.key])]);
    });
    // 结果与不确定度传递（输入量互不相关，数值偏导）
    const R = tpl.result, value = R.compute(clone(ctx));
    if (!Number.isFinite(value)) throw new Error('结果不是有限数，请检查数据与参数（是否有零或负值）');
    const names = (R.uncertaintyInputs || []).filter(k => {
      const d = (tpl.params || []).find(d => k === 'params.' + d.key);
      return u[k] !== undefined && (!d || (d.type !== 'switch' && (!d.enabledBy || p[d.enabledBy])));
    });
    const quantities = {}; names.forEach(k => { quantities[k] = { value: getPath(ctx, k), uncertainty: u[k] }; });
    const prop = names.length ? C.propagate(vals => { const c = clone(ctx); Object.entries(vals).forEach(([k, v]) => setPath(c, k, v)); return R.compute(c); }, quantities) : { value, uncertainty: 0, steps: [] };
    let finalValue = value, finalU = prop.uncertainty, core = null;
    const resultSteps = [S(R.formulaTex, Object.keys(quantities).map(k => k + '=' + quantities[k].value).join('，') || '见上', value, '计算 ' + R.label), ...(typeof R.steps === 'function' ? R.steps(clone(ctx), { uncertainties: { ...u }, typeA: Object.fromEntries(items.filter(i => i.key.startsWith("uA.")).map(i => [i.key.slice(3), i.value])), rows: included.map(r => ({ ...r.values })) }) : []), ...prop.steps];
    if (typeof R.core === 'function') {
      core = R.core({ rows: included.map(r => r.values), params: p, pu, deltas: Object.fromEntries(dataInputs(tpl).map(i => [i.key, delta(i)])), K, C });
      if (core && Number.isFinite(core.value)) {
        finalValue = core.value; finalU = core.uncertainty;
        // 码道核心函数的斜率不确定度只含 A 类；v1.1 起再合成 y 列仪器误差带来的斜率 B 类分量
        if (fitUB > 0 && (R.uncertaintyInputs || []).includes('fit.slope')) {
          const h = Math.abs(ctx.fit.slope) * 1e-6 || 1e-12, c1 = clone(ctx); c1.fit.slope += h;
          const term = Math.abs((R.compute(c1) - value) / h) * fitUB, u0 = finalU;
          finalU = Math.hypot(u0, term);
          resultSteps.push(S('u=√(u_核心²+(∂f/∂b·u_B(b))²)', '√(' + u0 + '²+' + term + '²)', finalU, '合成斜率 B 类分量'));
        }
        resultSteps.push(S('交叉校验（码道核心函数）', '通用引擎=' + value + '；码道核心=' + core.value, Math.abs(core.value - value) <= 1e-9 * Math.abs(value) ? '一致' : '不一致，请检查', '交叉校验'));
        resultSteps.push(...(core.steps || []));
      }
    }
    const fmt = C.formatAuto(finalValue, finalU, R.unit);
    const reference = options.reference !== undefined && options.reference !== null && String(options.reference).trim() !== '' && Number.isFinite(Number(options.reference)) ? Number(options.reference) : tpl.accepted.value;
    const cmp = K.compareWithReference({ measured: finalValue, reference, uncertainty: finalU, k: 2 });
    const verdict = cmp.within2u ? '一致' : cmp.absError <= 3 * finalU ? '基本一致' : '偏差显著';
    const relU = finalValue !== 0 ? finalU / Math.abs(finalValue) * 100 : NaN;
    items.push({ key: 'result', label: R.label, value: finalValue, unit: R.unit, steps: resultSteps, main: true });
    items.push({ key: 'result.u', label: R.label + ' 的合成不确定度', value: finalU, unit: R.unit, steps: prop.steps.concat(core && core.steps ? [] : []) });
    items.push({ key: 'compare', label: '相对误差（与公认值）', value: cmp.relativeErrorPercent, unit: '%', steps: cmp.steps });
    const outlier = detectOutliers(tpl, rows, p);
    return { tpl, params: p, value: finalValue, uncertainty: finalU, genericValue: value, genericUncertainty: prop.uncertainty, core, formatted: fmt.value, relU, reference,
      comparison: { ...cmp, verdict }, items, chart, outlier, included: included.length, total: rows.length,
      conventions: { typeB: 'u_B=Δ仪/√3（均匀分布）', typeA: tOpt.useT ? 'u_A=t·s/√n（t 因子开启，P=' + tOpt.coverage + '）' : 'u_A=s/√n（t 因子关闭）', compare: 'k=2：|x−x₀|≤2u_C 判为一致，≤3u_C 基本一致', outlier: outlier.criterion } };
  }
  function autoExclude(tpl, rows, options = {}) {
    const { p } = paramValues(tpl, options.params || {});
    const o = detectOutliers(tpl, rows.map(r => ({ ...r, excluded: false })), p);
    // 逐差法要求等间隔成对数据，剔除会破坏配对：疑似异常点只提示、不自动剔除
    if (tpl.method === 'successive_diff') return { rows: rows.map(r => ({ ...r })), outlier: { ...o, flagOnly: true } };
    return { rows: rows.map((r, i) => ({ ...r, excluded: o.indices.includes(i), auto: o.indices.includes(i) })), outlier: o };
  }
  return { CATEGORIES, validateTemplate, registry, search, parseCSV, sampleText, process, detectOutliers, autoExclude, paramValues };
});
