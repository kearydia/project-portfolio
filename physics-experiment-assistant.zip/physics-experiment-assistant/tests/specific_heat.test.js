'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), cp = require('node:child_process');
const E = require('../src/engine.js'), tpl = require('../templates/specific_heat_water.js');
const PY = require('./templates_work_ref/python_reference_v13.json').specific_heat_water;
const baseline = require('./templates_work_ref/before_specific_heat.json');
const root = path.join(__dirname, '..'), read = p => fs.readFileSync(path.join(root, p), 'utf8');
const relative = (a, b) => Math.abs(a - b) / Math.abs(b);
const sample = () => {
  const parsed = E.parseCSV(tpl.sampleCsv, tpl);
  assert.ok(parsed.ok, parsed.errors.join(';'));
  return E.autoExclude(tpl, parsed.rows);
};
const calc = (params = {}, deltas = {}) => E.process(tpl, sample().rows, { params, deltas });
const derivatives = r => r.items.find(i => i.key === 'result.u').steps.filter(s => s.formula.startsWith('∂f/∂'));
const item = (r, key) => r.items.find(i => i.key === key).value;

test('比热容：接口、分类、方法及粘滞系数之后注册', () => {
  assert.deepEqual(E.validateTemplate(tpl), []);
  assert.equal(tpl.id, 'specific_heat_water'); assert.equal(tpl.category, '热学');
  assert.equal(tpl.method, 'linear_fit'); assert.equal(tpl.verified, true);
  assert.equal(tpl.result.unit, 'kJ/(kg·K)'); assert.equal(tpl.accepted.value, 4.18);
  assert.match(read('index.html'), /viscosity_falling_ball\.js"><\/script>\s*<script src="templates\/specific_heat_water\.js"><\/script>/);
});

test('比热容：固定种子、CSV 副本、全部真值及首行 single 一致', () => {
  const csv = read('sample_data/templates_work/specific_heat_water_模拟数据.csv').replace(/\r\n/g, '\n');
  assert.equal(csv, tpl.sampleCsv); assert.equal(require('../tools/gen_specific_heat_data.js').generateSample(), csv);
  assert.match(csv.split('\n')[0], /模拟数据（非真实测量）.*20261114.*全部真值.*噪声.*第 9 行/);
  assert.equal(require('../sample_data/templates_work/truth.json')[tpl.id], 4.18);
  const rows = E.parseCSV(csv, tpl).rows;
  assert.equal(rows.length, 16);
  rows.forEach((r, i) => {
    assert.equal(r.values.t, i * 60);
    const expected = 20 + 9 / (910 * 1.5e-4) * (1 - Math.exp(-1.5e-4 * i * 60));
    assert.ok(Math.abs(r.values.T - expected - (i === 8 ? 0.8 : 0)) <= 0.055000001);
    for (const [key, value] of Object.entries({ U: 6, I: 1.5, m0: 0.2, m1: 0.06 }))
      assert.equal(r.values[key], i === 0 ? value : '');
  });
});

for (const on of [0, 1]) test('比热容手算：修正' + (on ? '开' : '关') + '，结果与 Python 解析不确定度一致', () => {
  // Python 独立计算：t=[0,100,200]，T=[20,21,22]；k=0.01，T̄=21，Sxx=20000。
  // 关：(9/0.01−900×0.06−20)/0.2/1000=4.13，u=0.186441650143774。
  // 开：k有效=0.01015，c0=4.06349753694581，u=0.181260577955961 kJ/(kg·K)。
  const rows = [0, 1, 2].map(i => ({ values: { t: i * 100, T: 20 + i,
    U: i === 0 ? 6 : '', I: i === 0 ? 1.5 : '', m0: i === 0 ? 0.2 : '', m1: i === 0 ? 0.06 : '' }, excluded: false }));
  const r = E.process(tpl, rows, { params: { heatLoss: on } });
  const ref = PY[on ? 'hand_on' : 'hand_off'];
  assert.ok(Math.abs(r.value - (on ? 4.06349753694581 : 4.13)) < 1e-13);
  assert.ok(relative(r.value, ref.value) < 1e-12); assert.ok(relative(r.uncertainty, ref.u) < 1e-8);
  assert.equal(item(r, 'fit.uAslope'), 0);
  assert.ok(relative(item(r, 'fit.uBslope'), 0.1 / Math.sqrt(3) / Math.sqrt(20000)) < 1e-8);
});

for (const on of [0, 1]) test('比热容模拟数据：修正' + (on ? '开' : '关') + '，JS/Python 结果<0.1%、不确定度<1%', () => {
  const r = calc({ heatLoss: on }), ref = PY[on ? 'sample_on' : 'sample_off'];
  assert.ok(relative(r.value, ref.value) < 1e-3); assert.ok(relative(r.uncertainty, ref.u) < 1e-2);
  assert.equal(r.comparison.verdict, ref.verdict); assert.equal(r.comparison.verdict, on ? '一致' : '偏差显著');
  assert.equal(r.included, PY.included);
  assert.ok(relative(item(r, 'fit.uAslope'), ref.fit.uA) < 1e-8);
  assert.ok(relative(item(r, 'fit.uBslope'), ref.fit.uB) < 1e-8);
  assert.equal(derivatives(r).length, on ? 9 : 7);
  for (const s of derivatives(r)) {
    const key = s.formula.split('.').pop();
    assert.ok(relative(s.result, ref.partials[key]) < 1e-7, key + ': T̄ 必须固定，不随斜率扰动');
  }
});

test('比热容：关闭与基本公式严格相等，K/θ 及其误差不参与计算或传递', () => {
  const r = calc();
  const base = (item(r, 'mean.U') * item(r, 'mean.I') / item(r, 'fit.slope') - 900 * item(r, 'mean.m1') - 20) / item(r, 'mean.m0') / 1000;
  assert.equal(r.value, base);
  for (const params of [{ K: 0.1, theta: 100, Δtheta: 100 }, { K: '无效', theta: '无效', Δtheta: -1 }]) {
    const changed = calc(params);
    assert.equal(changed.value, r.value); assert.equal(changed.uncertainty, r.uncertainty);
  }
  assert.ok(derivatives(r).every(s => !/params\.(K|theta|heatLoss)$/.test(s.formula)));
});

test('比热容：开启散热修正后值减小，K/θ 误差启用，时间列误差不计入', () => {
  const off = calc(), on = calc({ heatLoss: 1 }), noThetaU = calc({ heatLoss: 1, Δtheta: 0 });
  assert.ok(on.value < off.value); assert.equal(on.value, noThetaU.value); assert.ok(on.uncertainty > noThetaU.uncertainty);
  const noK = { ...tpl, params: tpl.params.map(p => p.key === 'K' ? { ...p, uncertainty: 0 } : p) };
  const zeroK = E.process(noK, sample().rows, { params: { heatLoss: 1 } });
  assert.equal(zeroK.value, on.value); assert.ok(zeroK.uncertainty < on.uncertainty);
  assert.equal(calc({}, { t: 10000 }).uncertainty, off.uncertainty);
  assert.equal(calc({ heatLoss: 1 }, { t: 10000 }).uncertainty, on.uncertainty);
});

test('比热容：格拉布斯检出第 9 行，可恢复，single 第一行被排除仍可读取', () => {
  const a = sample();
  assert.deepEqual(a.outlier.indices, [8]); assert.deepEqual(a.outlier.indices, PY.excluded_indices);
  assert.ok(relative(a.outlier.statistic, PY.statistic) < 1e-10); assert.equal(a.outlier.critical, PY.critical);
  assert.equal(a.rows.filter(r => r.excluded).length, 1);
  assert.equal(E.process(tpl, a.rows.map(r => ({ ...r, excluded: false }))).included, 16);
  const withoutFirst = a.rows.map((r, i) => ({ ...r, excluded: r.excluded || i === 0 }));
  assert.equal(item(E.process(tpl, withoutFirst), 'mean.U'), 6);
});

test('比热容：ctx.fit 均值只含保留点，满足 T̄=a+b·t̄，步骤完整且均值不传递', () => {
  let captured;
  const inspect = { ...tpl, result: { ...tpl.result, compute: c => { captured ||= c; return tpl.result.compute(c); } } };
  const rows = sample().rows, kept = rows.filter(r => !r.excluded);
  const r = E.process(inspect, rows, { params: { heatLoss: 1 } });
  assert.equal(captured.fit.xMean, kept.reduce((s, r) => s + r.values.t, 0) / kept.length);
  assert.equal(captured.fit.yMean, kept.reduce((s, r) => s + r.values.T, 0) / kept.length);
  assert.ok(Math.abs(captured.fit.yMean - captured.fit.intercept - captured.fit.slope * captured.fit.xMean) < 1e-12);
  assert.ok(derivatives(r).every(s => !/Mean|heatLoss/.test(s.formula)));
  const steps = r.items.find(i => i.key === 'result').steps;
  for (const title of ['电加热功率', '散热修正状态与假设', '保留拟合点的平均温度', '散热对应的升温速率', '修正后的升温速率', '总热容及其组成', '水的比热容与单位换算'])
    assert.ok(steps.some(s => s.title === title && s.formula && s.substitution && s.result));
});

test('比热容：非法质量、升温斜率、冷却常数报中文错误', () => {
  const rows = sample().rows;
  assert.throws(() => E.process(tpl, rows.map(r => ({ ...r, values: { ...r.values, m0: 0 } }))), /质量/);
  assert.throws(() => E.process(tpl, rows.map(r => ({ ...r, values: { ...r.values, T: -r.values.t } }))), /升温斜率/);
  assert.throws(() => calc({ heatLoss: 1, K: -0.01 }), /冷却常数/);
  assert.throws(() => calc({ heatLoss: 1, theta: 1000 }), /修正后的升温速率/);
});

test('追加拟合均值后：全部 23 个既有模板 value/u 与变更前严格相等', () => {
  const S = require('../sample_data/samples.js');
  assert.equal(Object.keys(baseline.templates).length, 23);
  for (const [id, ref] of Object.entries(baseline.templates)) {
    const t = require('../templates/' + id + '.js'), p = E.parseCSV(E.sampleText(t, S), t);
    assert.ok(p.ok);
    const r = E.process(t, E.autoExclude(t, p.rows).rows);
    assert.equal(r.value, ref.value, id + ' value'); assert.equal(r.uncertainty, ref.u, id + ' u');
  }
});

test('run_all：排除后续荷质比模板后，只增加比热容一行，其余输出逐字节不变', () => {
  const actual = cp.execFileSync(process.execPath, ['tools/run_all.js'], { cwd: root }).toString('utf8');
  const added = actual.split('\n').filter(line => line.startsWith(tpl.name + ' |'));
  assert.equal(added.length, 1);
  const prior = actual.replace(/^静电场模拟描绘（同轴圆柱电极，U–ln r 图线法） \|[^\n]*\n/m, '').replace(/^电子荷质比（纵向磁场聚焦法） \|[^\n]*\n/m, '').replace(/^示波器的使用（测频率、周期与峰峰值） \|[^\n]*\n/m, '');
  assert.deepEqual(Buffer.from(prior.replace(added[0] + '\n', '')), Buffer.from(baseline.runAll));
});

// 纯 Node 的 DOM/event doubles，不启动浏览器或其他应用。
test('比热容 UI：默认关闭、假设可见、开关实时重算并可恢复', () => {
  class Element {
    constructor() { this.handlers = {}; this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.dataset = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
    emit(name, target) { for (const fn of this.handlers[name] || []) fn({ target, preventDefault() {} }); }
  }
  const html = read('index.html').replace(/<!--[\s\S]*?-->/g, ''), elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  const document = new Element(); document.getElementById = id => elements[id];
  const context = { console, document, location: { hash: '#tpl=specific_heat_water&open=1' } };
  context.window = context; context.globalThis = context; vm.createContext(context);
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) vm.runInContext(read(m[1]), context, { filename: m[1] });
  const e = elements, check = checked => e.params.emit('change', { dataset: { switch: 'heatLoss' }, checked });
  assert.match(e.params.innerHTML, /type="checkbox" data-switch="heatLoss">/);
  for (const text of ['假设牛顿冷却', 'T̄ 不计不确定度', 'c₁、Cₛ、K、θ 均为假设值', '断电后另测冷却曲线']) assert.ok(e.params.innerHTML.includes(text));
  assert.match(e.badge.innerHTML, /偏差显著/);
  const original = e['main-value'].innerHTML;
  check(true); assert.notEqual(e['main-value'].innerHTML, original); assert.match(e.badge.innerHTML, /<b>一致<\/b>/);
  assert.match(e.steps.innerHTML, /修正后的升温速率/);
  check(false); assert.equal(e['main-value'].innerHTML, original);
});
