'use strict';
// 通用引擎 + 模板库测试：手算验证对照、模拟数据与公认值、17 个模板库模板与独立 Python 参考、脏数据中文报错
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const C = require('../src/calc.js');
const E = require('../src/engine.js');
const V = require('../src/verify.js');
const SAMPLES = require('../sample_data/samples.js');
const ids = fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/templates\/[\w-]+\.js/g).map(s => s.slice(10, -3));
const T = ids.map(id => require('../templates/' + id + '.js'));
const byId = id => T.find(t => t.id === id);
const PY = require('./templates_work_ref/python_reference.json');
const rel = (a, b) => Math.abs(a - b) / Math.abs(b);

test('index.html 注册的模板与 templates/ 目录一致，且全部通过接口校验', () => {
  const files = fs.readdirSync(path.join(root, 'templates')).filter(f => f.endsWith('.js')).map(f => f.slice(0, -3)).sort();
  assert.deepEqual([...ids].sort(), files);
  const reg = E.registry(T); assert.equal(reg.rejected.length, 0, JSON.stringify(reg.rejected)); assert.equal(reg.templates.length, T.length);
  T.forEach(t => { assert.equal(t.verified, true, t.id); assert.ok(E.CATEGORIES.includes(t.category)); assert.ok(E.sampleText(t, SAMPLES).includes('模拟数据'), t.id + ' 示例须标注模拟数据'); });
});
test('模板接口校验能发现缺字段', () => {
  assert.ok(E.validateTemplate({ id: 'x' }).length > 3);
  assert.ok(E.validateTemplate({ ...byId('ohm_fit'), category: '化学' }).some(e => e.includes('category')));
});
test('搜索与分类筛选', () => {
  assert.ok(E.search(T, '单摆', '全部').every(t => t.name.includes('单摆')));
  assert.equal(E.search(T, '单摆', '全部').length, 2);
  assert.ok(E.search(T, '', '光学').length >= 5);
  assert.ok(E.search(T, '', '近代物理').some(t => t.id === 'photoelectric_planck'));
  assert.equal(E.search(T, '不存在的实验', '全部').length, 0);
});
for (const c of V.run(E, T, SAMPLES)) {
  test('手算验证数据 ' + c.id + '：程序结果与独立 Python 计算一致（相对差<1e-6）', () => {
    assert.ok(!c.error, c.error); c.rows.forEach(r => assert.ok(r.rel < 1e-6, r.label + ' ' + r.got + ' vs ' + r.expected));
  });
}
for (const [id, row, tol] of [['pendulum_fit', 9, 1], ['pendulum_single', 5, 1], ['ohm_fit', 8, 2], ['young_fit', 8, 2], ['young_diff', null, 2]]) {
  test(id + ' 模拟数据：格拉布斯检出人为异常点，剔除后与公认值一致', () => {
    const t = byId(id), p = E.parseCSV(E.sampleText(t, SAMPLES), t); assert.ok(p.ok); assert.ok(p.simulated);
    const a = E.autoExclude(t, p.rows); assert.deepEqual(a.outlier.indices, row === null ? [] : [row]);
    const r = E.process(t, a.rows);
    assert.ok(r.comparison.relativeErrorPercent < tol, String(r.comparison.relativeErrorPercent)); assert.equal(r.comparison.verdict, '一致');
    if (r.core) assert.ok(rel(r.core.value, r.genericValue) < 1e-12, '码道核心与通用引擎结果一致');
  });
}
for (const id of Object.keys(PY)) {
  test('模板库 ' + id + '：与独立 Python 参考一致（结果<0.1%，不确定度<1%）', () => {
    const t = byId(id); assert.ok(t, '模板未注册'); const p = E.parseCSV(E.sampleText(t, SAMPLES), t); assert.ok(p.ok, p.errors.join(';'));
    const r = E.process(t, p.rows);
    assert.ok(rel(r.value, PY[id].value) < 1e-3); assert.ok(rel(r.uncertainty, PY[id].u) < 1e-2);
    assert.ok(rel(r.value, PY[id].true) <= 1e-2, '与模拟真值相对误差≤1%');
  });
}
test('脏数据：空值、非数字、缺列、行数不足、空文件都给出中文提示', () => {
  const t = byId('pendulum_fit');
  const dirty = E.parseCSV(SAMPLES['脏数据示例_模拟数据.csv'], t); assert.equal(dirty.ok, false);
  assert.ok(dirty.errors.some(m => /数据第 2 行.*为空/.test(m)), dirty.errors.join('|')); assert.ok(dirty.errors.some(m => /数据第 3 行.*不是有效数字/.test(m)));
  assert.match(E.parseCSV('L(m),X\n1,2\n', t).errors[0], /缺少列.*「周期 T」/);
  assert.match(E.parseCSV('L(m),T(s)\n0.5,1.4\n0.6,1.5\n', t).errors.join(''), /至少需要 3 行/);
  assert.match(E.parseCSV('# 只有注释\n\n', t).errors[0], /没有数据/);
  assert.match(E.parseCSV('序号,T(s)\n1,1.8\n2,abc\n3,1.81\n4,1.79\n', byId('pendulum_single')).errors.join(''), /不是有效数字/);
  assert.equal(E.parseCSV('\uFEFFL\tT\n0.4\t1.27\n0.6\t1.55\n0.8\t1.80\n', t).ok, true, '支持 BOM 与制表符');
});
test('计算异常给出中文错误而非 NaN', () => {
  const t = byId('pendulum_fit'), rows = [0.4, 0.6, 0.8].map(L => ({ values: { L, T: 0 }, excluded: false }));
  assert.throws(() => E.process(t, rows), /有限数|斜率/);
  const t2 = byId('pendulum_single'), r2 = [1.8, 1.8].map(T => ({ values: { T }, excluded: false }));
  assert.throws(() => E.process(t2, r2), /太少|至少/);
});
test('剔除/恢复后重新计算；t 因子开关改变 u_A', () => {
  const t = byId('pendulum_single'), p = E.parseCSV(E.sampleText(t, SAMPLES), t);
  const all = E.process(t, p.rows), ex = E.process(t, E.autoExclude(t, p.rows).rows);
  assert.notEqual(all.value, ex.value); assert.equal(ex.included, all.included - 1);
  const withT = E.process(t, E.autoExclude(t, p.rows).rows, { useT: true, coverage: 0.95 });
  assert.ok(withT.items.find(i => i.key === 'uA.T').value > ex.items.find(i => i.key === 'uA.T').value);
});
test('逐差法：疑似异常点只提示不自动剔除', () => {
  const t = byId('michelson'), p = E.parseCSV(E.sampleText(t, SAMPLES), t), a = E.autoExclude(t, p.rows);
  assert.ok(a.rows.every(r => !r.excluded)); assert.equal(a.outlier.flagOnly, true);
});
test('科学计数法修约与好看刻度', () => {
  assert.equal(C.formatAuto(1.99978836924e11, 5.919e8, 'Pa').value, '(2.000 ± 0.006)×10¹¹ Pa');
  assert.equal(C.formatAuto(6.65518e-34, 7.09e-37, 'J·s').value, '(6.655 ± 0.007)×10⁻³⁴ J·s');
  assert.equal(C.formatAuto(9.80311, 0.00537, 'm/s²').value, '9.803 ± 0.005 m/s²');
  assert.deepEqual(C.niceTicks(0.2987, 1.0844).ticks, [0.2, 0.4, 0.6, 0.8, 1, 1.2]);
  assert.equal(C.niceTicks(1.0221, 4.5845).step, 1);
});
test('逐差法核心：已知线性数据', () => {
  const d = C.successiveDiff([1, 2, 3, 4, 5, 6], [2, 4, 6, 8, 10, 12]);
  assert.equal(d.k, 3); assert.equal(d.meanDelta, 6); assert.equal(d.slope, 2); assert.equal(d.uA, 0);
});
test('报告与界面源码不含密钥/本地存储，页面无外部资源', () => {
  const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  assert.doesNotMatch(html, /(src|href)=["']https?:/);
  for (const f of ['src/ui.js', 'src/engine.js']) assert.doesNotMatch(fs.readFileSync(path.join(root, f), 'utf8'), /localStorage|sessionStorage|document\.cookie|sk-[A-Za-z0-9]{10}/);
});
test('公认值输入框为空时使用模板公认值', () => {
  const t = byId('ohm_fit'), p = E.parseCSV(E.sampleText(t, SAMPLES), t);
  assert.equal(E.process(t, p.rows, { reference: '' }).reference, 100); assert.equal(E.process(t, p.rows, { reference: '101' }).reference, 101);
});
test('浏览器方式加载：所有模板脚本在同一全局作用域内依次执行不冲突', () => {
  const vm = require('node:vm'), ctx = { console }; ctx.globalThis = ctx; vm.createContext(ctx);
  ids.forEach(id => vm.runInContext(fs.readFileSync(path.join(root, 'templates', id + '.js'), 'utf8'), ctx, { filename: id + '.js' }));
  assert.equal(ctx.EXP_TEMPLATES.length, ids.length);
});

test('v1.1 手算：拟合斜率 B 类分量 u_B(k)=Δy/√3/√Sxx（x=1..5，Δy=0.03，数据严格线性故 u_A=0）', () => {
  const tpl = { id: 'tmp_ub', name: '临时', category: '力学', method: 'linear_fit', inputs: [{ key: 'x', label: 'x', unit: '', instrumentError: 0, kind: 'column_x' }, { key: 'y', label: 'y', unit: '', instrumentError: 0.03, kind: 'column_y' }], params: [],
    result: { key: 'k', label: 'k', unit: '', compute: c => c.fit.slope, uncertaintyInputs: ['fit.slope'] }, accepted: { value: 2, unit: '' } };
  const rows = [1, 2, 3, 4, 5].map(x => ({ values: { x, y: 2 * x + 1 }, excluded: false }));
  const r = E.process(tpl, rows), it = k => r.items.find(i => i.key === k).value;
  assert.ok(Math.abs(it('fit.uAslope')) < 1e-12);
  assert.ok(rel(it('fit.uBslope'), 0.005477225575) < 1e-9, String(it('fit.uBslope')));
  assert.ok(rel(it('fit.uslope'), 0.005477225575) < 1e-9);
  assert.ok(rel(r.genericUncertainty, 0.005477225575) < 1e-9);
});
test('v1.1：g 与 λ 的参数不确定度参与传递（杨氏模量、弦振动、牛顿环）', () => {
  for (const [id, key] of [['young_fit', 'g'], ['youngs_modulus', 'g'], ['string_vibration', 'g'], ['newton_rings', 'lambda']]) {
    const t = byId(id); assert.ok(t.result.uncertaintyInputs.includes('params.' + key), id);
    assert.ok(t.params.find(p => p.key === key).uncertainty > 0, id);
  }
});
