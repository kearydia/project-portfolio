'use strict';

/**
 * calc.js 单元测试（node --test）
 * 数据集均为手算可验证的小样本，断言使用具体数值而非“非空”类弱断言。
 */

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const C = require('../src/codearts_calc.js');

const TOL = 1e-12;

/** 相对误差断言：|actual − expected| ≤ tol × max(1, |expected|) */
function closeTo(actual, expected, tol, message) {
  const t = tol === undefined ? TOL : tol;
  assert.equal(typeof actual, 'number', `${message}: 结果必须是数字`);
  assert.ok(Number.isFinite(actual), `${message}: 结果必须是有限数字，实际为 ${actual}`);
  const allowed = t * Math.max(1, Math.abs(expected));
  assert.ok(
    Math.abs(actual - expected) <= allowed,
    `${message}: 期望 ${expected}，实际 ${actual}（允许误差 ${allowed}）`
  );
}

/** 校验“计算步骤”结构完整、编号连续、结果可展示 */
function assertSteps(steps, minLength, message) {
  const label = message || 'steps';
  assert.ok(Array.isArray(steps), `${label}: 必须是数组`);
  assert.ok(steps.length >= (minLength || 1), `${label}: 至少 ${minLength || 1} 步，实际 ${steps.length} 步`);
  steps.forEach((step, index) => {
    assert.equal(step.step, index + 1, `${label}: 第 ${index + 1} 步编号应为 ${index + 1}`);
    assert.equal(typeof step.title, 'string', `${label}: 第 ${index + 1} 步缺少 title`);
    assert.ok(step.title.length > 0, `${label}: 第 ${index + 1} 步 title 不能为空`);
    assert.equal(typeof step.formula, 'string', `${label}: 第 ${index + 1} 步缺少 formula`);
    assert.ok(step.formula.length > 0, `${label}: 第 ${index + 1} 步 formula 不能为空`);
    assert.equal(typeof step.substitution, 'string', `${label}: 第 ${index + 1} 步缺少 substitution`);
    assert.ok(step.substitution.length > 0, `${label}: 第 ${index + 1} 步必须代入具体数值`);
    assert.equal(typeof step.result, 'string', `${label}: 第 ${index + 1} 步结果必须是字符串`);
    assert.ok(step.result.length > 0, `${label}: 第 ${index + 1} 步结果不能为空`);
    assert.ok(Number.isFinite(step.value), `${label}: 第 ${index + 1} 步 value 必须是有限数字`);
  });
}

/* ================================================================== *
 * 1. 基础统计与不确定度
 * ================================================================== */

describe('基础统计', () => {
  it('mean：对 [1,2,3,4,5] 求平均值 = 3，并返回求和步骤', () => {
    const result = C.mean([1, 2, 3, 4, 5]);
    closeTo(result.value, 3, TOL, 'mean.value');
    assert.equal(result.sum, 15);
    assert.equal(result.n, 5);
    assertSteps(result.steps, 2, 'mean.steps');
    assert.equal(result.steps[0].substitution, '1 + 2 + 3 + 4 + 5');
    assert.equal(result.steps[1].value, 3);
  });

  it('mean：单点数据返回该点本身', () => {
    const result = C.mean([2.5]);
    closeTo(result.value, 2.5, TOL, 'mean 单点');
    assert.equal(result.n, 1);
  });

  it('mean：超过 8 项时步骤文本做省略但保留项数说明', () => {
    const result = C.mean(new Array(10).fill(2));
    closeTo(result.value, 2, TOL, 'mean 十项');
    assert.ok(result.steps[0].substitution.includes('共 10 项'), '应说明总项数');
    assert.ok(result.steps[0].substitution.includes('…'), '应省略中间项');
  });

  it('mean：非法输入抛出明确异常', () => {
    assert.throws(() => C.mean([]), RangeError);
    assert.throws(() => C.mean('123'), TypeError);
    assert.throws(() => C.mean([1, NaN, 3]), TypeError);
    assert.throws(() => C.mean([1, Infinity]), TypeError);
    assert.throws(() => C.mean([1, '2']), TypeError);
  });

  it('sampleStdDev：[1,2,3,4,5] 的样本标准差 = √2.5', () => {
    const result = C.sampleStdDev([1, 2, 3, 4, 5]);
    closeTo(result.value, Math.sqrt(2.5), 1e-15, 's');
    closeTo(result.variance, 2.5, 1e-15, 's²');
    closeTo(result.ss, 10, 1e-15, 'SS');
    assert.equal(result.n, 5);
    assertSteps(result.steps, 3, 'sampleStdDev.steps');
    assert.ok(result.steps[2].formula.includes('s = √(s²)'));
  });

  it('sampleStdDev：[2,4,4,4,5,5,7,9] 的 s = √(32/7)', () => {
    const result = C.sampleStdDev([2, 4, 4, 4, 5, 5, 7, 9]);
    closeTo(result.mean, 5, TOL, 'mean');
    closeTo(result.ss, 32, 1e-12, 'SS');
    closeTo(result.value, Math.sqrt(32 / 7), 1e-15, 's');
  });

  it('sampleStdDev：显式传入均值时结果不变', () => {
    const withMean = C.sampleStdDev([1, 2, 3, 4, 5], { mean: 3 });
    closeTo(withMean.value, Math.sqrt(2.5), 1e-15, '显式 mean');
  });

  it('sampleStdDev：少于 2 个数据抛出 RangeError', () => {
    assert.throws(() => C.sampleStdDev([1]), RangeError);
  });
});

describe('不确定度合成', () => {
  it('uncertaintyA：[1,2,3,4,5]，t=1 时 uA = s/√5', () => {
    const result = C.uncertaintyA([1, 2, 3, 4, 5]);
    closeTo(result.uA, 0.7071067811865476, 1e-15, 'uA');
    closeTo(result.stdDev, Math.sqrt(2.5), 1e-15, 's');
    assert.equal(result.tFactor, 1);
    assert.equal(result.n, 5);
    assertSteps(result.steps, 4, 'uncertaintyA.steps');
    assert.ok(result.steps[3].formula.includes('u_A = t · s / √n'));
  });

  it('uncertaintyA：t=2.776 时放大 2.776 倍', () => {
    const result = C.uncertaintyA([1, 2, 3, 4, 5], { tFactor: 2.776 });
    closeTo(result.uA, 2.776 * Math.sqrt(2.5 / 5), 1e-15, 'uA(t=2.776)');
    assert.ok(result.steps[3].substitution.includes('2.776'), '步骤中必须出现 t 因子数值');
    assert.ok(result.steps[3].substitution.includes('√5'), '步骤中必须出现 √n');
  });

  it('uncertaintyA：tFactor 非正或非数字时抛错', () => {
    assert.throws(() => C.uncertaintyA([1, 2, 3], { tFactor: 0 }), RangeError);
    assert.throws(() => C.uncertaintyA([1, 2, 3], { tFactor: -1 }), RangeError);
    assert.throws(() => C.uncertaintyA([1, 2, 3], { tFactor: '2' }), TypeError);
    assert.throws(() => C.uncertaintyA([1]), RangeError);
  });

  it('uncertaintyB：Δ仪=0.1 时 uB = 0.1/√3', () => {
    const result = C.uncertaintyB(0.1);
    closeTo(result.uB, 0.05773502691896258, 1e-15, 'uB');
    closeTo(result.divisor, Math.sqrt(3), 1e-15, 'divisor');
    assertSteps(result.steps, 2, 'uncertaintyB.steps');
    assert.ok(result.steps[1].formula.includes('√3'), '公式必须说明均匀分布除以 √3');
    assert.equal(result.steps[1].substitution, '0.1 / 1.73205');
  });

  it('uncertaintyB：支持自定义除数与零允差', () => {
    closeTo(C.uncertaintyB(0.1, { divisor: 2 }).uB, 0.05, 1e-15, 'divisor=2');
    closeTo(C.uncertaintyB(0).uB, 0, 1e-15, '零允差');
  });

  it('uncertaintyB：负允差、非法除数抛错', () => {
    assert.throws(() => C.uncertaintyB(-0.1), RangeError);
    assert.throws(() => C.uncertaintyB(0.1, { divisor: 0 }), RangeError);
    assert.throws(() => C.uncertaintyB(0.1, { divisor: 'x' }), TypeError);
    assert.throws(() => C.uncertaintyB(NaN), TypeError);
  });

  it('combinedUncertainty：uC = √(uA² + uB²)', () => {
    const uA = 0.7071067811865476;
    const uB = 0.05773502691896258;
    const result = C.combinedUncertainty(uA, uB);
    closeTo(result.uC, 0.70946, 1e-5, 'uC 手算近似值');
    closeTo(result.uC, Math.sqrt(uA * uA + uB * uB), 1e-15, 'uC 与分量关系');
    assertSteps(result.steps, 3, 'combinedUncertainty.steps');
    assert.equal(result.steps[2].substitution, `√(${C.formatValue(uA * uA)} + ${C.formatValue(uB * uB)})`);
  });

  it('combinedUncertainty：任一分为 0 时等于另一分量；支持 label', () => {
    closeTo(C.combinedUncertainty(0.3, 0).uC, 0.3, 1e-15, 'uB=0');
    closeTo(C.combinedUncertainty(0, 0.4).uC, 0.4, 1e-15, 'uA=0');
    assert.equal(C.combinedUncertainty(0.1, 0.2, { label: 'g' }).label, 'g');
  });

  it('combinedUncertainty：负分量或非数字抛错', () => {
    assert.throws(() => C.combinedUncertainty(-0.1, 0.2), RangeError);
    assert.throws(() => C.combinedUncertainty(0.1, NaN), TypeError);
  });

  it('relativeUncertainty：u=0.70946、x=3 时约 23.65%', () => {
    const u = 0.7094598884624212;
    const result = C.relativeUncertainty(u, 3);
    closeTo(result.fraction, u / 3, 1e-15, 'fraction');
    closeTo(result.percent, (u / 3) * 100, 1e-12, 'percent');
    closeTo(result.percent, 23.6487, 1e-4, 'percent 手算近似值');
    assertSteps(result.steps, 2, 'relativeUncertainty.steps');
    assert.equal(result.steps[1].unit, '%');
  });

  it('relativeUncertainty：测量值取绝对值，0 与负不确定度抛错', () => {
    closeTo(C.relativeUncertainty(0.2, -4).percent, 5, 1e-12, '负测量值取模');
    assert.throws(() => C.relativeUncertainty(0.2, 0), RangeError);
    assert.throws(() => C.relativeUncertainty(-0.2, 1), RangeError);
  });
});

/* ================================================================== *
 * 2. 一元线性最小二乘拟合
 * ================================================================== */

describe('一元线性最小二乘拟合', () => {
  it('手算样例 [1,2,3,4] / [1,3,2,5]：k=1.1、b=0、r≈0.8315', () => {
    const fit = C.fitLinear([1, 2, 3, 4], [1, 3, 2, 5]);
    closeTo(fit.slope, 1.1, 1e-14, '斜率');
    closeTo(fit.intercept, 0, 1e-14, '截距');
    closeTo(fit.sxx, 5, 1e-15, 'Sxx');
    closeTo(fit.sxy, 5.5, 1e-15, 'Sxy');
    closeTo(fit.syy, 8.75, 1e-15, 'Syy');
    closeTo(fit.ssRes, 2.7, 1e-14, '残差平方和');
    closeTo(fit.residualStd, 1.161895003862225, 1e-14, '残差标准差');
    closeTo(fit.slopeStd, 0.5196152422706632, 1e-14, '斜率不确定度');
    closeTo(fit.interceptStd, 1.4230249470757708, 1e-14, '截距不确定度');
    closeTo(fit.r, 0.8315218406202999, 1e-14, '相关系数');
    assert.equal(fit.dof, 2);
    assert.equal(fit.n, 4);
    const expectedResiduals = [-0.1, 0.8, -1.3, 0.6];
    fit.residuals.forEach((value, index) => {
      closeTo(value, expectedResiduals[index], 1e-14, `残差[${index}]`);
    });
    const sumResidual = fit.residuals.reduce((a, b) => a + b, 0);
    closeTo(sumResidual, 0, 1e-12, '残差和应为 0');
    assertSteps(fit.steps, 12, 'fitLinear.steps');
    assert.ok(fit.steps[5].formula.includes('k = Sxy / Sxx'));
    assert.ok(fit.steps[11].formula.includes('r = Sxy / √(Sxx · Syy)'));
  });

  it('完美正相关：斜率 2、截距 0、r=1、残差全 0', () => {
    const fit = C.fitLinear([1, 2, 3, 4], [2, 4, 6, 8]);
    closeTo(fit.slope, 2, 1e-15, '斜率');
    closeTo(fit.intercept, 0, 1e-15, '截距');
    closeTo(fit.r, 1, 1e-15, 'r');
    closeTo(fit.slopeStd, 0, 1e-15, 'u(k)');
    closeTo(fit.interceptStd, 0, 1e-15, 'u(b)');
    fit.residuals.forEach((value, index) => closeTo(value, 0, 1e-15, `残差[${index}]`));
  });

  it('完美负相关：斜率 −2、r=−1', () => {
    const fit = C.fitLinear([1, 2, 3, 4], [8, 6, 4, 2]);
    closeTo(fit.slope, -2, 1e-15, '斜率');
    closeTo(fit.r, -1, 1e-15, 'r');
    closeTo(fit.intercept, 10, 1e-15, '截距');
  });

  it('y 为常数：斜率 0、截距为常数、r 定义为 0', () => {
    const fit = C.fitLinear([1, 2, 3], [5, 5, 5]);
    closeTo(fit.slope, 0, 1e-15, '斜率');
    closeTo(fit.intercept, 5, 1e-15, '截距');
    closeTo(fit.r, 0, 1e-15, 'r');
    closeTo(fit.slopeStd, 0, 1e-15, 'u(k)');
  });

  it('拟合结果可复现（相同输入两次结果完全一致）', () => {
    const a = C.fitLinear([1, 2, 3, 4], [1, 3, 2, 5]);
    const b = C.fitLinear([1, 2, 3, 4], [1, 3, 2, 5]);
    assert.deepEqual(a.residuals, b.residuals);
    assert.equal(a.slope, b.slope);
    assert.equal(a.slopeStd, b.slopeStd);
  });

  it('非法输入：长度不等 / 点数不足 / x 全相同 / 非数字', () => {
    assert.throws(() => C.fitLinear([1, 2, 3], [1, 2]), RangeError);
    assert.throws(() => C.fitLinear([1, 2], [1, 2]), RangeError);
    assert.throws(() => C.fitLinear([2, 2, 2], [1, 2, 3]), RangeError);
    assert.throws(() => C.fitLinear([1, 2, 3], [1, '2', 3]), TypeError);
    assert.throws(() => C.fitLinear(null, [1, 2, 3]), TypeError);
  });
});

/* ================================================================== *
 * 3. 异常值检测与剔除重算
 * ================================================================== */

describe('异常值检测', () => {
  it('grubbsCriticalValue：α=0.05 时按表取值（n=3~20）', () => {
    closeTo(C.grubbsCriticalValue(3), 1.153, 0, 'n=3, α=0.05');
    closeTo(C.grubbsCriticalValue(5), 1.672, 0, 'n=5, α=0.05');
    closeTo(C.grubbsCriticalValue(10), 2.176, 0, 'n=10, α=0.05');
    closeTo(C.grubbsCriticalValue(20), 2.557, 0, 'n=20, α=0.05');
    assert.equal(C.GRUBBS_ALPHA, 0.05, '统一显著性水平应为 0.05');
  });

  it('grubbsCriticalValue：n 超出临界值表时明确报错，不做静默近似', () => {
    assert.throws(
      () => C.grubbsCriticalValue(21),
      (err) => err instanceof RangeError &&
        err.message.includes('3 ~ 20') &&
        err.message.includes('21') &&
        err.message.includes('避免静默近似'),
      'n=21 必须提示表范围与当前样本量'
    );
    assert.throws(() => C.grubbsCriticalValue(25), /格拉布斯临界值表仅覆盖/);
    assert.throws(() => C.grubbsCriticalValue(2), RangeError);
    assert.throws(() => C.grubbsCriticalValue(2.5), RangeError);
    assert.throws(() => C.grubbsCriticalValue('5'), RangeError);
  });

  it('grubbsCriticalValue：显著性水平只支持 0.05', () => {
    assert.throws(() => C.grubbsCriticalValue(5, 0.01), /α = 0\.05/);
    assert.throws(() => C.grubbsCriticalValue(5, 0.1), /α = 0\.05/);
  });

  it('grubbsTest：6 点数据中的 100 被判为异常（G=2.0399 > 1.822）', () => {
    const result = C.grubbsTest([1, 2, 3, 4, 5, 100]);
    closeTo(result.statistic, 2.0399410223, 1e-9, 'G');
    closeTo(result.critical, 1.822, 0, '临界值');
    assert.equal(result.isOutlier, true);
    assert.equal(result.candidateIndex, 5);
    assert.equal(result.candidateValue, 100);
    closeTo(result.stdDev, Math.sqrt(1570.1666666666667), 1e-12, 's');
    assertSteps(result.steps, 6, 'grubbsTest.steps');
    assert.ok(result.steps[4].substitution.includes('1.822'), '步骤必须代入临界值');
    assert.equal(result.steps[5].result, '是（判为异常值）', '判定步骤应给出可读结论');
  });

  it('grubbsTest：1~5 数据无异常（G=1.2649 ≤ 1.672）', () => {
    const result = C.grubbsTest([1, 2, 3, 4, 5]);
    closeTo(result.statistic, 1.2649110640673518, 1e-12, 'G');
    assert.equal(result.isOutlier, false);
    assert.equal(result.candidateIndex, 0);
  });

  it('grubbsTest：全部数据相同不会误判', () => {
    const result = C.grubbsTest([2, 2, 2, 2]);
    closeTo(result.statistic, 0, 0, 'G');
    assert.equal(result.isOutlier, false);
  });

  it('detectOutliers3Sigma：19 个 1 + 1 个 20，末位被 3σ 判为异常', () => {
    const values = new Array(19).fill(1).concat([20]);
    const result = C.detectOutliers3Sigma(values);
    assert.equal(result.hasOutliers, true);
    assert.equal(result.removedCount, 1);
    assert.equal(result.outliers[0].index, 19);
    closeTo(result.outliers[0].value, 20, 0, '异常值');
    closeTo(result.mean, 1.95, 1e-14, 'x̄');
    closeTo(result.stdDev, 4.248529157249593, 1e-12, 's');
    closeTo(result.limit, 12.74558747174878, 1e-12, '3s 阈值');
    closeTo(result.outliers[0].ratio, 4.248529157249593, 1e-12, '偏差倍数');
    assert.equal(result.keptValues.length, 19);
    assert.deepEqual(result.keptIndices, Array.from({ length: 19 }, (_, i) => i));
    assertSteps(result.steps, 4, 'detectOutliers3Sigma.steps');
  });

  it('detectOutliers3Sigma：threshold=1 时 [1,2,3,4,5] 两端越界', () => {
    const result = C.detectOutliers3Sigma([1, 2, 3, 4, 5], { threshold: 1 });
    assert.deepEqual(result.outliers.map((item) => item.index), [0, 4]);
    closeTo(result.limit, Math.sqrt(2.5), 1e-15, '阈值');
    assert.deepEqual(result.keptValues, [2, 3, 4]);
  });

  it('detectOutliers3Sigma：useSampleStd=false 改用总体标准差', () => {
    const result = C.detectOutliers3Sigma([1, 2, 3, 4, 5], { threshold: 1, useSampleStd: false });
    closeTo(result.stdDev, Math.sqrt(2), 1e-15, '总体标准差');
    closeTo(result.limit, Math.sqrt(2), 1e-15, '阈值');
    assert.equal(result.hasOutliers, true);
  });

  it('detectOutliers3Sigma：常数数据不产生异常', () => {
    const result = C.detectOutliers3Sigma([3, 3, 3, 3]);
    assert.equal(result.hasOutliers, false);
    assert.equal(result.removedCount, 0);
    assert.equal(result.keptValues.length, 4);
  });

  it('detectOutliers3Sigma：非法输入抛错', () => {
    assert.throws(() => C.detectOutliers3Sigma([1]), RangeError);
    assert.throws(() => C.detectOutliers3Sigma([1, 2], { threshold: 0 }), RangeError);
    assert.throws(() => C.detectOutliers3Sigma([1, 2], { threshold: 'x' }), TypeError);
  });

  it('rejectOutliers（格拉布斯）：剔除 100 后在 1~5 上重算统计量', () => {
    const result = C.rejectOutliers([1, 2, 3, 4, 5, 100]);
    assert.equal(result.method, 'grubbs');
    assert.equal(result.removedCount, 1);
    assert.equal(result.removed[0].index, 5);
    closeTo(result.removed[0].value, 100, 0, '被剔除的值');
    closeTo(result.removed[0].critical, 1.822, 0, '该轮临界值');
    assert.deepEqual(result.keptValues, [1, 2, 3, 4, 5]);
    assert.deepEqual(result.keptIndices, [0, 1, 2, 3, 4]);
    closeTo(result.statistics.mean, 3, 1e-15, '重算均值');
    closeTo(result.statistics.stdDev, Math.sqrt(2.5), 1e-15, '重算标准差');
    closeTo(result.statistics.uA, 0.7071067811865476, 1e-15, '重算 uA');
    assert.equal(result.statistics.n, 5);
    assertSteps(result.steps, 4, 'rejectOutliers.steps');
    assert.ok(result.steps[result.steps.length - 1].title.includes('剔除后A类不确定度'));
  });

  it('rejectOutliers（格拉布斯）：无异常时不做任何剔除', () => {
    const result = C.rejectOutliers([1, 2, 3, 4, 5]);
    assert.equal(result.removedCount, 0);
    assert.equal(result.iterations, 1, '应执行一轮确认判定');
    assert.equal(result.keptValues.length, 5);
  });

  it('rejectOutliers（格拉布斯）：maxIterations 限制剔除轮数', () => {
    const limited = C.rejectOutliers([1, 2, 3, 4, 5, 100, 1000], { maxIterations: 1 });
    assert.equal(limited.removedCount, 1);
    assert.equal(limited.iterations, 1);
    assert.deepEqual(limited.keptValues, [1, 2, 3, 4, 5, 100]);

    const full = C.rejectOutliers([1, 2, 3, 4, 5, 100, 1000]);
    assert.equal(full.removedCount, 2, '不限制时应剔除两个异常值');
    assert.deepEqual(full.keptValues, [1, 2, 3, 4, 5]);
    closeTo(full.statistics.mean, 3, 1e-15, '最终均值');
  });

  it('rejectOutliers：统一走格拉布斯，拒绝 3σ 与非 0.05 显著性', () => {
    assert.throws(
      () => C.rejectOutliers([1, 2, 3, 4, 5], { method: '3sigma' }),
      /统一采用格拉布斯检验/
    );
    assert.throws(() => C.rejectOutliers([1, 2, 3, 4, 5], { alpha: 0.01 }), /α = 0\.05/);
    const result = C.rejectOutliers([1, 2, 3, 4, 5, 100]);
    assert.equal(result.method, 'grubbs');
    assert.equal(result.removedCount, 1);
  });

  it('rejectOutliers：n 超出临界值表时立即给出明确提示', () => {
    const values = Array.from({ length: 21 }, (_, i) => i + 1);
    assert.throws(
      () => C.rejectOutliers(values),
      (err) => err instanceof RangeError &&
        err.message.includes('n = 3 ~ 20') &&
        err.message.includes('n = 21'),
      'n=21 应提示表范围，而不是静默近似'
    );
  });

  it('rejectOutliers：非法方法或参数抛错', () => {
    assert.throws(() => C.rejectOutliers([1, 2, 3], { method: 'zscore' }), RangeError);
    assert.throws(() => C.rejectOutliers([1, 2, 3], { method: '3sigma' }), RangeError);
    assert.throws(() => C.rejectOutliers([1, 2, 3], { threshold: 3 }), /3σ 判据/);
    assert.throws(() => C.rejectOutliers([1, 2, 3], { maxIterations: 0 }), RangeError);
    assert.throws(() => C.rejectOutliers([1, 2]), RangeError);
  });
});

/* ================================================================== *
 * 4. 实验项目
 * ================================================================== */

describe('单摆测重力加速度', () => {
  it('理想数据 T=2√L：斜率 4、g=π²、r=1', () => {
    const lengths = [0.5, 0.6, 0.7, 0.8];
    const periods = lengths.map((L) => 2 * Math.sqrt(L));
    const result = C.pendulumGravity({ lengths, periods });
    closeTo(result.slope, 4, 1e-14, 'T²–L 斜率');
    closeTo(result.g, Math.PI * Math.PI, 1e-6, 'g');
    assert.ok(result.uG < 1e-6, `理想数据的 u(g) 应接近 0，实际 ${result.uG}`);
    closeTo(result.r, 1, 1e-12, 'r');
    result.squaredPeriods.forEach((value, index) => {
      closeTo(value, periods[index] ** 2, 1e-15, `T²[${index}]`);
    });
    assertSteps(result.steps, 19, 'pendulumGravity.steps');
    const formulas = result.steps.map((step) => step.formula);
    assert.ok(formulas.some((f) => f.includes('g = 4π² / k')), '应包含 g 定义式');
    assert.ok(formulas.some((f) => f.includes('u₁(g) = (4π²/k²) · u(k)')), '应包含斜率不确定度传递');
    assert.ok(formulas.some((f) => f.includes('u(L) = Δ尺 / √3')), '应包含摆长 B 类不确定度公式');
    assert.ok(formulas.some((f) => f.includes('u₂(g) = g · u(L) / L̄')), '应包含摆长到 g 的传递公式');
    assert.ok(formulas.some((f) => f.includes('u(g) = √(u₁(g)² + u₂(g)²)')), '应包含合成公式');
    assert.equal(result.uGLength, 0, '未提供 Δ尺时摆长分量应为 0');
    closeTo(result.uG, result.uGSlope, 1e-15, '未提供 Δ尺时 u(g) 等于斜率分量');
  });

  it('含测量误差数据：g=9.5202、u(g)=0.0703，且满足不确定度传递关系', () => {
    const result = C.pendulumGravity({
      lengths: [0.4, 0.5, 0.6, 0.7],
      periods: [1.27, 1.42, 1.56, 1.69]
    });
    closeTo(result.slope, 4.146800000000001, 1e-12, '斜率');
    closeTo(result.g, 9.520212598716462, 1e-12, 'g');
    closeTo(result.uGSlope, 0.07030464832133997, 1e-12, 'u₁(g)');
    closeTo(result.uGLength, 0, 1e-15, '未提供 Δ尺时 u₂(g) = 0');
    closeTo(result.uG, 0.07030464832133997, 1e-12, 'u(g)');
    closeTo(result.relativeUncertaintyPercent, 0.7384777135210049, 1e-12, 'E(g)%');
    // 传递关系：u(g)/g = u(k)/k
    closeTo(result.uG / result.g, result.fit.slopeStd / result.slope, 1e-12, 'u(g)/g = u(k)/k');
    // g = 4π²/k 由拟合斜率直接决定
    closeTo(result.g, (4 * Math.PI * Math.PI) / result.slope, 1e-12, 'g 定义式');
    assert.equal(result.fit.n, 4);
  });

  it('单摆：数据长度不一致或斜率为负时抛错', () => {
    assert.throws(() => C.pendulumGravity({ lengths: [0.4, 0.5, 0.6, 0.7], periods: [1.2, 1.3, 1.4] }), RangeError);
    assert.throws(() => C.pendulumGravity({ lengths: [0.4, 0.5, 0.6], periods: [2, 1.5, 1] }), RangeError);
    assert.throws(() => C.pendulumGravity({ lengths: [0.4, 0.5], periods: [1.2, 1.3] }), RangeError);
    assert.throws(() => C.pendulumGravity(), TypeError);
  });
});

describe('伏安法测电阻', () => {
  it('理想数据 U=5I：R=5 Ω、u(R)≈0、r=1', () => {
    const result = C.ohmsLawResistance({
      currents: [0.01, 0.02, 0.03, 0.04],
      voltages: [0.05, 0.1, 0.15, 0.2]
    });
    closeTo(result.resistance, 5, 1e-14, 'R');
    assert.ok(result.uR < 1e-12, `理想数据 u(R) 应接近 0，实际 ${result.uR}`);
    closeTo(result.r, 1, 1e-14, 'r');
    assertSteps(result.steps, 15, 'ohmsLawResistance.steps');
    assert.ok(result.steps[result.steps.length - 3].formula.includes('R = k（U–I 图斜率）'));
  });

  it('含测量误差数据：R=5.06 Ω、u(R)=0.0906 Ω', () => {
    const result = C.ohmsLawResistance({
      currents: [0.01, 0.02, 0.03, 0.04],
      voltages: [0.048, 0.102, 0.149, 0.201]
    });
    closeTo(result.resistance, 5.0600000000000005, 1e-12, 'R');
    closeTo(result.uR, 0.09055385138137409, 1e-12, 'u(R)');
    closeTo(result.uR, result.fit.slopeStd, 1e-15, 'u(R) 等于斜率不确定度');
    closeTo(result.relativeUncertaintyPercent, 1.7896018059560097, 1e-12, 'E(R)%');
    closeTo(result.r, 0.9996798863124033, 1e-12, 'r');
  });

  it('伏安法：长度不一致或斜率为负时抛错', () => {
    assert.throws(() => C.ohmsLawResistance({ currents: [0.1, 0.2, 0.3], voltages: [1, 2, 3, 4] }), RangeError);
    assert.throws(() => C.ohmsLawResistance({
      currents: [0.01, 0.02, 0.03],
      voltages: [0.3, 0.2, 0.1]
    }), RangeError);
    assert.throws(() => C.ohmsLawResistance({ currents: [0.1, 0.2], voltages: [1, 2] }), RangeError);
  });
});

/* ================================================================== *
 * 5. 与公认值比较
 * ================================================================== */

describe('与公认值比较', () => {
  it('|x−x0| ≤ 2u 成立：9.8696 与 9.80665、u=0.05', () => {
    const result = C.compareWithReference({
      measured: 9.8696,
      reference: 9.80665,
      uncertainty: 0.05
    });
    closeTo(result.absoluteError, 0.06295, 1e-12, 'Δ');
    closeTo(result.absError, 0.06295, 1e-12, '|Δ|');
    closeTo(result.relativeErrorPercent, 0.6419113560696043, 1e-12, '相对误差%');
    closeTo(result.expandedUncertainty, 0.1, 1e-15, '2u');
    assert.equal(result.within2u, true);
    assert.equal(result.consistent, true);
    assertSteps(result.steps, 4, 'compareWithReference.steps');
    assert.ok(result.steps[2].formula.includes('|x − x0| ≤ 2u'));
    assert.equal(result.steps[2].result, '成立', '2u 判据结论可读');
  });

  it('|x−x0| > 2u：10.0 与 9.80665、u=0.05 判定不成立', () => {
    const result = C.compareWithReference({
      measured: 10,
      reference: 9.80665,
      uncertainty: 0.05
    });
    closeTo(result.absoluteError, 0.19335, 1e-12, 'Δ');
    closeTo(result.relativeErrorPercent, 1.9716212977928248, 1e-12, '相对误差%');
    assert.equal(result.within2u, false);
    assert.equal(result.consistent, false);
    assert.equal(result.steps[2].result, '不成立');
  });

  it('k=3 时扩展判据可成立而 2u 判据不成立', () => {
    const result = C.compareWithReference({
      measured: 9.95,
      reference: 9.80665,
      uncertainty: 0.05,
      k: 3
    });
    closeTo(result.expandedUncertainty, 0.15000000000000002, 1e-15, '3u');
    assert.equal(result.within2u, false, '|Δ|=0.14335 > 2u=0.1');
    assert.equal(result.consistent, true, '|Δ|=0.14335 ≤ 3u=0.15');
  });

  it('比较：reference 为 0、负不确定度、非正 k 抛错', () => {
    assert.throws(() => C.compareWithReference({ measured: 1, reference: 0, uncertainty: 0.1 }), RangeError);
    assert.throws(() => C.compareWithReference({ measured: 1, reference: 2, uncertainty: -0.1 }), RangeError);
    assert.throws(() => C.compareWithReference({ measured: 1, reference: 2, uncertainty: 0.1, k: 0 }), RangeError);
    assert.throws(() => C.compareWithReference({ measured: '1', reference: 2, uncertainty: 0.1 }), TypeError);
  });
});

/* ================================================================== *
 * 6. 步骤展示与运行环境兼容性
 * ================================================================== */

describe('计算步骤展示', () => {
  it('formatSteps 输出公式、代入数值与结果', () => {
    const text = C.formatSteps(C.uncertaintyB(0.1).steps);
    assert.ok(text.includes('公式:'), '应包含公式行');
    assert.ok(text.includes('代入:'), '应包含代入行');
    assert.ok(text.includes('结果:'), '应包含结果行');
    assert.ok(text.includes('0.057735'), '应包含计算结果');
    assert.ok(text.includes('Δ仪 / √3'), '应保留符号公式');
    assert.equal(text.split('\n\n').length, 2, '两步之间用空行分隔');
  });

  it('formatSteps 对空输入返回空字符串', () => {
    assert.equal(C.formatSteps([]), '');
    assert.equal(C.formatSteps(null), '');
  });

  it('formatValue：常规数值、科学计数法与零', () => {
    assert.equal(C.formatValue(1.23456789), '1.23457');
    assert.equal(C.formatValue(0), '0');
    assert.equal(C.formatValue(1e-8), '1E-8');
    assert.equal(C.formatValue(-2.5e-9), '-2.5E-9');
    assert.equal(C.formatValue(12e6), '1.2E+7');
    assert.equal(C.formatValue(1234567), '1.23457E+6');
  });

  it('所有对外计算函数都返回可展开的完整步骤', () => {
    const outputs = [
      C.mean([1, 2, 3]),
      C.sampleStdDev([1, 2, 3]),
      C.uncertaintyA([1, 2, 3]),
      C.uncertaintyB(0.1),
      C.combinedUncertainty(0.1, 0.2),
      C.relativeUncertainty(0.1, 2),
      C.fitLinear([1, 2, 3], [2, 4, 6]),
      C.detectOutliers3Sigma([1, 2, 3, 4]),
      C.detectOutliers([1, 2, 3, 4]),
      C.grubbsTest([1, 2, 3, 4]),
      C.grubbsResiduals(C.fitLinear([1, 2, 3], [2, 4, 6])),
      C.rejectOutliers([1, 2, 3, 4]),
      C.pendulumGravity({ lengths: [0.4, 0.5, 0.6], periods: [1.27, 1.42, 1.56] }),
      C.ohmsLawResistance({ currents: [0.01, 0.02, 0.03], voltages: [0.05, 0.1, 0.15] }),
      C.compareWithReference({ measured: 9.8, reference: 9.80665, uncertainty: 0.02 })
    ];
    outputs.forEach((output, index) => {
      assertSteps(output.steps, 2, `输出[${index}].steps`);
      assert.ok(C.formatSteps(output.steps).length > 0, `输出[${index}] 步骤文本不能为空`);
    });
  });
});

describe('运行环境兼容性', () => {
  it('在无 module 的沙箱中执行时挂载到全局 PhysicsCalc（浏览器用法）', () => {
    const source = fs.readFileSync(path.join(__dirname, '../src/codearts_calc.js'), 'utf8');
    const sandbox = {};
    sandbox.globalThis = sandbox;
    vm.createContext(sandbox);
    vm.runInContext(source, sandbox);
    assert.equal(typeof sandbox.PhysicsCalc, 'object');
    assert.equal(typeof sandbox.PhysicsCalc.mean, 'function');
    closeTo(sandbox.PhysicsCalc.mean([2, 4, 6]).value, 4, 1e-15, '浏览器全局 API');
    closeTo(sandbox.PhysicsCalc.fitLinear([1, 2, 3], [2, 4, 6]).slope, 2, 1e-15, '浏览器全局拟合');
    assert.equal(typeof sandbox.PhysicsCalc.validateTable, 'function', '浏览器应可调用表格校验');
    assert.equal(typeof sandbox.PhysicsCalc.buildReportHTML, 'function', '浏览器应可生成 HTML 报告');
    assert.equal(
      sandbox.PhysicsCalc.validateTable([{ x: 1 }], {
        columns: [{ key: 'x', label: 'X' }]
      }).ok,
      true,
      '浏览器全局表格校验可正常运行'
    );
  });
});

/* ================================================================== *
 * 7. 统一异常值判据（格拉布斯 α = 0.05，含拟合残差）
 * ================================================================== */

describe('统一异常值判据（格拉布斯 α = 0.05）', () => {
  it('detectOutliers 默认走格拉布斯检验，并标记数据来源为单次测量列', () => {
    const result = C.detectOutliers([1, 2, 3, 4, 5, 100]);
    assert.equal(result.method, 'grubbs');
    assert.equal(result.alpha, 0.05);
    assert.equal(result.kind, 'measurement');
    assert.equal(result.n, 6);
    assert.equal(result.isOutlier, true);
    assert.equal(result.hasOutliers, true);
    closeTo(result.critical, 1.822, 0, '查表临界值');
    assert.ok(result.steps[0].title.includes('单次测量列'), '步骤应标注数据来源');
  });

  it('grubbsResiduals：直接对 fitLinear 的残差列做检验', () => {
    const fit = C.fitLinear([1, 2, 3, 4], [1, 3, 2, 5]);
    const result = C.grubbsResiduals(fit);
    assert.equal(result.kind, 'residuals');
    assert.equal(result.n, 4);
    closeTo(result.critical, 1.463, 0, 'n=4 临界值');
    closeTo(result.mean, 0, 1e-15, '残差均值为 0');
    closeTo(result.stdDev, Math.sqrt(0.9), 1e-15, '残差标准差');
    closeTo(result.statistic, 1.3 / Math.sqrt(0.9), 1e-14, 'G 统计量');
    assert.equal(result.candidateIndex, 2, '最大偏差应定位到残差 −1.3');
    assert.equal(result.candidateValue, fit.residuals[2]);
    assert.equal(result.isOutlier, false, 'G=1.3703 ≤ 1.463，不应判为异常');
    assert.ok(result.steps[0].title.includes('拟合残差列'), '步骤应标注残差来源');
  });

  it('grubbsResiduals：也接受直接传入的残差数组，且能识别异常残差', () => {
    const result = C.grubbsResiduals([-0.1, 0.8, -1.3, 10, 0.6], { alpha: 0.05 });
    assert.equal(result.kind, 'residuals');
    assert.equal(result.isOutlier, true, '离群残差 10 应被判为异常');
    assert.equal(result.candidateIndex, 3);
    closeTo(result.candidateValue, 10, 0, '候选残差');
  });

  it('grubbsResiduals：输入既非数组也非拟合结果时抛 TypeError', () => {
    assert.throws(() => C.grubbsResiduals(null), TypeError);
    assert.throws(() => C.grubbsResiduals({ slope: 1 }), TypeError);
    assert.throws(() => C.grubbsResiduals('abc'), TypeError);
  });

  it('n 超出临界值表时，默认判据给出明确提示而不是近似值', () => {
    const values = Array.from({ length: 21 }, (_, i) => i + 1);
    assert.throws(
      () => C.detectOutliers(values),
      (err) => err instanceof RangeError &&
        err.message.includes('仅覆盖 n = 3 ~ 20') &&
        err.message.includes('当前 n = 21'),
      'detectOutliers 应透传明确提示'
    );
    assert.throws(
      () => C.grubbsResiduals(new Array(21).fill(0)),
      /格拉布斯临界值表仅覆盖 n = 3 ~ 20/
    );
  });

  it('3σ 函数保留但不进入默认流程', () => {
    assert.equal(typeof C.detectOutliers3Sigma, 'function', '3σ 函数应继续导出');
    const threeSigma = C.detectOutliers3Sigma(new Array(19).fill(1).concat([20]));
    assert.equal(threeSigma.method, '3sigma');
    assert.equal(threeSigma.hasOutliers, true);

    const defaultResult = C.detectOutliers([1, 2, 3, 4, 5, 100]);
    assert.equal(defaultResult.method, 'grubbs', '默认流程必须是格拉布斯');
    assert.notEqual(defaultResult.method, threeSigma.method);
  });
});

/* ================================================================== *
 * 8. 单摆 g 的摆长 B 类不确定度合成
 * ================================================================== */

describe('单摆不确定度：合成摆长 B 类分量', () => {
  const lengths = [0.4, 0.5, 0.6, 0.7];
  const periods = [1.27, 1.42, 1.56, 1.69];

  it('Δ尺=1 mm 时按 u(L)=Δ尺/√3 与 u₂(g)=g·u(L)/L̄ 合成', () => {
    const result = C.pendulumGravity({ lengths, periods, lengthDelta: 0.001 });
    closeTo(result.g, 9.520212598716462, 1e-12, 'g');
    closeTo(result.meanLength, 0.55, 1e-15, 'L̄');
    closeTo(result.lengthDelta, 0.001, 0, 'Δ尺');
    closeTo(result.uLength, 0.001 / Math.sqrt(3), 1e-15, 'u(L)');
    closeTo(result.uGSlope, 0.07030464832133997, 1e-12, 'u₁(g)');
    closeTo(result.uGLength, result.g * result.uLength / result.meanLength, 1e-15, 'u₂(g) 传递关系');
    closeTo(result.uGLength, 0.0099937, 1e-5, 'u₂(g) 手算近似值');
    closeTo(result.uG, Math.hypot(result.uGSlope, result.uGLength), 1e-15, '平方和开方合成');
    assert.ok(result.uG > result.uGSlope, '合成后应大于仅斜率分量');
    closeTo(result.uG, 0.0710103, 1e-5, 'u(g) 手算近似值');
    closeTo(result.relativeUncertaintyPercent, (result.uG / result.g) * 100, 1e-12, 'E(g)%');
  });

  it('steps 中写出摆长 B 类、传递与合成公式', () => {
    const result = C.pendulumGravity({ lengths, periods, lengthDelta: 0.001 });
    assertSteps(result.steps, 19, 'pendulumGravity(B类).steps');
    const formulas = result.steps.map((step) => step.formula);
    assert.ok(formulas.includes('u₁(g) = (4π²/k²) · u(k)'));
    assert.ok(formulas.includes('u(L) = Δ尺 / √3'));
    assert.ok(formulas.includes('u₂(g) = g · u(L) / L̄'));
    assert.ok(formulas.includes('u(g) = √(u₁(g)² + u₂(g)²)'));

    const lengthStep = result.steps.find((step) => step.title === '摆长 B 类不确定度');
    assert.ok(lengthStep, '必须存在摆长 B 类不确定度步骤');
    assert.equal(lengthStep.unit, 'm');
    assert.ok(lengthStep.substitution.includes('0.001'), '代入值必须包含 Δ尺');
    assert.ok(lengthStep.substitution.includes('1.73205'), '代入值必须包含 √3');

    const combineStep = result.steps.find((step) => step.title === 'g 的不确定度合成');
    assert.ok(combineStep, '必须存在合成步骤');
    assert.equal(combineStep.unit, 'm/s²');
    closeTo(combineStep.value, result.uG, 1e-15, '合成步骤数值');
  });

  it('Δ尺=0 时摆长分量归零，退化回斜率不确定度', () => {
    const result = C.pendulumGravity({ lengths, periods, lengthDelta: 0 });
    closeTo(result.uLength, 0, 1e-15, 'u(L)');
    closeTo(result.uGLength, 0, 1e-15, 'u₂(g)');
    closeTo(result.uG, result.uGSlope, 1e-15, 'u(g) = u₁(g)');
  });

  it('Δ尺 非法时抛错', () => {
    assert.throws(() => C.pendulumGravity({ lengths, periods, lengthDelta: -0.001 }), RangeError);
    assert.throws(() => C.pendulumGravity({ lengths, periods, lengthDelta: '0.001' }), TypeError);
    assert.throws(() => C.pendulumGravity({ lengths, periods, lengthDelta: NaN }), TypeError);
  });
});

/* ================================================================== *
 * 9. 表格脏数据校验
 * ================================================================== */

describe('表格脏数据校验 validateTable', () => {
  const schema = {
    columns: [
      { key: 'length', label: '摆长 L', unit: 'm' },
      { key: 'period', label: '周期 T', unit: 's' }
    ]
  };
  const goodRow = { length: 0.5, lengthUnit: 'm', period: 1.42, periodUnit: 's' };

  it('合法表格通过校验并返回有效行号', () => {
    const rows = [
      goodRow,
      { length: 0.6, lengthUnit: 'm', period: 1.56, periodUnit: 's' }
    ];
    const result = C.validateTable(rows, schema);
    assert.equal(result.ok, true);
    assert.equal(result.errorCount, 0);
    assert.deepEqual(result.errors, []);
    assert.equal(result.rowCount, 2);
    assert.equal(result.validRows.length, 2);
    assert.deepEqual(result.validRowNumbers, [1, 2]);
    assert.deepEqual(result.columnKeys, ['length', 'period']);
  });

  it('空值：报出行号与列名，且不抛异常', () => {
    const rows = [{ length: null, lengthUnit: 'm', period: '  ', periodUnit: 's' }];
    const result = C.validateTable(rows, schema);
    assert.equal(result.ok, false);
    assert.equal(result.errorCount, 2);
    assert.equal(result.errors[0].code, 'EMPTY_VALUE');
    assert.equal(result.errors[0].row, 1);
    assert.equal(result.errors[0].column, 'length');
    assert.ok(result.errors[0].message.includes('第 1 行'), '必须包含行号');
    assert.ok(result.errors[0].message.includes('摆长 L'), '必须包含列名');
    assert.ok(result.errors[0].message.includes('为空值'));
    assert.equal(result.errors[1].column, 'period');
    assert.ok(result.errors[1].message.includes('周期 T'));
    assert.deepEqual(result.validRows, []);
  });

  it('非数字：字符串、数字字符串与 NaN 都报 NOT_NUMBER', () => {
    const rows = [
      { length: 'abc', lengthUnit: 'm', period: 1.4, periodUnit: 's' },
      { length: '0.5', lengthUnit: 'm', period: 1.4, periodUnit: 's' },
      { length: NaN, lengthUnit: 'm', period: 1.4, periodUnit: 's' }
    ];
    const result = C.validateTable(rows, schema);
    assert.equal(result.ok, false);
    assert.equal(result.errorCount, 3);
    result.errors.forEach((error, index) => {
      assert.equal(error.code, 'NOT_NUMBER');
      assert.equal(error.row, index + 1);
      assert.equal(error.column, 'length');
      assert.ok(error.message.includes(`第 ${index + 1} 行`));
      assert.ok(error.message.includes('摆长 L'));
    });
    assert.ok(result.errors[0].message.includes('"abc"'), '错误信息应包含实际值');
    assert.ok(result.errors[2].message.includes('NaN'), 'NaN 也应被识别');
  });

  it('列数不符：多列与缺列分别给出中文提示', () => {
    const extra = C.validateTable([{ ...goodRow, note: 'x' }], schema);
    assert.equal(extra.ok, false);
    const codes = extra.errors.map((error) => error.code);
    assert.ok(codes.includes('COLUMN_COUNT'), '应报告列数不符');
    assert.ok(codes.includes('EXTRA_COLUMN'), '应指出多余列');
    const extraMessage = extra.errors.map((error) => error.message).join('\n');
    assert.ok(extraMessage.includes('第 1 行'));
    assert.ok(extraMessage.includes('期望 2 列'));
    assert.ok(extraMessage.includes('note'));

    const missing = C.validateTable([{ length: 0.5, lengthUnit: 'm' }], schema);
    assert.equal(missing.ok, false);
    const missingCodes = missing.errors.map((error) => error.code);
    assert.ok(missingCodes.includes('COLUMN_COUNT'));
    assert.ok(missingCodes.includes('MISSING_COLUMN'));
    assert.ok(missing.errors.some((error) =>
      error.code === 'MISSING_COLUMN' && error.message.includes('第 1 行') &&
      error.message.includes('周期 T')));
  });

  it('单位列缺失与单位不匹配分别给出提示', () => {
    const missingUnit = C.validateTable([
      { length: 0.5, period: 1.4, periodUnit: 's' }
    ], schema);
    assert.equal(missingUnit.ok, false);
    assert.ok(missingUnit.errors.some((error) => error.code === 'MISSING_UNIT'));
    const missingMessage = missingUnit.errors.find((error) => error.code === 'MISSING_UNIT').message;
    assert.ok(missingMessage.includes('第 1 行'));
    assert.ok(missingMessage.includes('摆长 L'));
    assert.ok(missingMessage.includes('应填写 "m"'));

    const wrongUnit = C.validateTable([
      { length: 0.5, lengthUnit: 'cm', period: 1.4, periodUnit: 's' }
    ], schema);
    assert.equal(wrongUnit.ok, false);
    const mismatch = wrongUnit.errors.find((error) => error.code === 'UNIT_MISMATCH');
    assert.ok(mismatch, '应报告单位不匹配');
    assert.ok(mismatch.message.includes('单位应为 "m"'));
    assert.ok(mismatch.message.includes('"cm"'));
  });

  it('整行类型错误：null / 数组 / 字符串均返回行级错误', () => {
    const result = C.validateTable([null, ['a'], 'bad', goodRow], schema);
    assert.equal(result.ok, false);
    assert.equal(result.errorCount, 3);
    result.errors.forEach((error, index) => {
      assert.equal(error.code, 'ROW_TYPE');
      assert.equal(error.row, index + 1);
      assert.ok(error.message.includes('数据必须是对象'));
    });
    assert.deepEqual(result.validRowNumbers, [4]);
    assert.equal(result.validRows.length, 1);
  });

  it('多行数据只标记出错行，合法行仍保留', () => {
    const result = C.validateTable([
      goodRow,
      { length: '', lengthUnit: 'm', period: 1.4, periodUnit: 's' }
    ], schema);
    assert.equal(result.ok, false);
    assert.equal(result.rowCount, 2);
    assert.deepEqual(result.validRowNumbers, [1]);
    assert.deepEqual(result.validRows, [goodRow]);
    assert.ok(result.errors.every((error) => error.row === 2), '错误应全部集中在第 2 行');
  });

  it('空表、非数组与行数不足都返回结构化错误而非抛异常', () => {
    const empty = C.validateTable([], schema);
    assert.equal(empty.ok, false);
    assert.equal(empty.errors[0].code, 'EMPTY_TABLE');

    const notArray = C.validateTable(null, schema);
    assert.equal(notArray.ok, false);
    assert.equal(notArray.errors[0].code, 'NOT_ARRAY');

    const minRows = C.validateTable([goodRow], { columns: schema.columns, minRows: 3 });
    assert.equal(minRows.ok, false);
    assert.ok(minRows.errors.some((error) => error.code === 'TOO_FEW_ROWS'));
    assert.equal(minRows.validRows.length, 1, '行本身合法时应保留');
  });

  it('schema 非法时收敛为 INVALID_SCHEMA，不泄漏异常', () => {
    const cases = [
      C.validateTable([goodRow], null),
      C.validateTable([goodRow], { columns: [] }),
      C.validateTable([goodRow], { columns: [{ key: '' }] }),
      C.validateTable([goodRow], { columns: ['length'] })
    ];
    cases.forEach((result) => {
      assert.equal(result.ok, false);
      assert.equal(result.errors[0].code, 'INVALID_SCHEMA');
      assert.ok(result.errors[0].message.startsWith('表结构无效：'));
    });
  });

  it('checkUnits=false 时跳过单位校验', () => {
    const result = C.validateTable(
      [{ length: 0.5, period: 1.4 }],
      { columns: schema.columns, checkUnits: false }
    );
    assert.equal(result.ok, true);
    assert.equal(result.validRows.length, 1);
  });

  it('非数字列类型不匹配时报告 TYPE_MISMATCH', () => {
    const textSchema = {
      columns: [{ key: 'label', label: '备注', type: 'string' }]
    };
    const bad = C.validateTable([{ label: 123 }], textSchema);
    assert.equal(bad.ok, false);
    assert.equal(bad.errors.length, 1);
    assert.equal(bad.errors[0].code, 'TYPE_MISMATCH');
    assert.equal(bad.errors[0].row, 1);
    assert.equal(bad.errors[0].column, 'label');
    assert.ok(bad.errors[0].message.includes('第 1 行'));
    assert.ok(bad.errors[0].message.includes('备注'));
    assert.ok(bad.errors[0].message.includes('类型应为 string'));

    const good = C.validateTable([{ label: '正常文本' }], textSchema);
    assert.equal(good.ok, true);
  });
});

/* ================================================================== *
 * 10. 可独立打开的 HTML 报告
 * ================================================================== */

describe('HTML 报告 buildReportHTML', () => {
  const pendulum = C.pendulumGravity({
    lengths: [0.4, 0.5, 0.6, 0.7],
    periods: [1.27, 1.42, 1.56, 1.69],
    lengthDelta: 0.001
  });
  const comparison = C.compareWithReference({
    measured: pendulum.g,
    reference: 9.80665,
    uncertainty: pendulum.uG
  });
  const options = {
    title: '实验算盘 · 单摆测 g',
    calculation: pendulum,
    comparison: comparison,
    generatedAt: '2026-01-01T00:00:00.000Z'
  };

  it('输出完整 HTML 文档：结果、步骤公式、公认值对比、模拟数据标注', () => {
    const html = C.buildReportHTML(options);
    assert.ok(html.startsWith('<!DOCTYPE html>'), '必须是完整文档');
    assert.ok(html.includes('<html lang="zh-CN">'));
    assert.ok(html.includes('<meta charset="utf-8">'));
    assert.ok(html.includes('实验算盘 · 单摆测 g'));
    assert.ok(html.includes('生成时间：2026-01-01T00:00:00.000Z'));

    // 模拟数据标注
    assert.ok(html.includes('模拟数据'));
    assert.ok(html.includes('本报告数据标注为「模拟数据」'));

    // 计算结果与步骤公式
    assert.ok(html.includes('重力加速度 g'));
    assert.ok(html.includes('合成不确定度 u(g)'));
    assert.ok(html.includes('g = 4π² / k'));
    assert.ok(html.includes('u₁(g) = (4π²/k²) · u(k)'));
    assert.ok(html.includes('u(L) = Δ尺 / √3'));
    assert.ok(html.includes('u(g) = √(u₁(g)² + u₂(g)²)'));
    assert.ok(html.includes('相对不确定度'));

    // 公认值对比
    assert.ok(html.includes('与公认值比较'));
    assert.ok(html.includes('9.80665'));
    assert.ok(html.includes('2u 判据（|Δ| ≤ 2u）'));
    assert.ok(html.includes('扩展不确定度判据'));
    assert.ok(html.includes('不成立'));
    assert.ok(html.includes('</html>'));
  });

  it('步骤表包含每一步的公式、代入值与结果', () => {
    const html = C.buildReportHTML({ ...options, simulated: false });
    pendulum.steps.forEach((step) => {
      assert.ok(html.includes(C.escapeHtml(step.title)), `缺少步骤标题：${step.title}`);
      assert.ok(html.includes(C.escapeHtml(step.formula)), `缺少公式：${step.formula}`);
      assert.ok(html.includes(C.escapeHtml(step.substitution)), `缺少代入值：${step.substitution}`);
      assert.ok(html.includes(C.escapeHtml(step.result)), `缺少结果：${step.result}`);
    });
    assert.ok(html.includes('<td class="no">1</td>'), '步骤表应有序号列');
  });

  it('simulated=false 时标注为真实测量数据', () => {
    const html = C.buildReportHTML({ ...options, simulated: false });
    assert.ok(html.includes('真实测量数据'));
    assert.ok(html.includes('本报告数据来源为真实测量记录'));
    assert.ok(!html.includes('本报告数据标注为「模拟数据」'));
    assert.ok(html.includes('badge real'));
  });

  it('可以直接传入计算结果对象，缺省标题且提示未提供对比', () => {
    const html = C.buildReportHTML(pendulum);
    assert.ok(html.includes('实验算盘 · 实验数据报告'));
    assert.ok(html.includes('模拟数据'));
    assert.ok(html.includes('未提供与公认值的比较结果。'));
    assert.ok(html.includes('重力加速度 g'));
    assert.ok(html.includes('摆长引起的 u₂(g)'));
  });

  it('所有动态文本都做 HTML 转义，避免注入', () => {
    const html = C.buildReportHTML({
      ...options,
      title: '<script>alert(1)</script>',
      generatedAt: '<b>2026</b>'
    });
    assert.ok(html.includes('&lt;script&gt;alert(1)&lt;/script&gt;'));
    assert.ok(!html.includes('<script>alert(1)</script>'), '不得出现未转义的脚本标签');
    assert.ok(html.includes('&lt;b&gt;2026&lt;/b&gt;'));
    assert.equal(
      C.escapeHtml(`<a href="x">'&'</a>`),
      '&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;'
    );
  });

  it('无可展示数值时给出明确占位提示', () => {
    const html = C.buildReportHTML({
      calculation: {
        steps: [{
          step: 1,
          title: '手工步骤',
          formula: 'x = 1',
          substitution: 'x = 1',
          result: '1',
          value: 1,
          unit: ''
        }]
      }
    });
    assert.ok(html.includes('未包含可展示的数值字段'));
    assert.ok(html.includes('手工步骤'));
  });

  it('对比字段缺失时以占位符显示，不抛出异常', () => {
    const html = C.buildReportHTML({
      calculation: pendulum,
      comparison: {},
      generatedAt: '2026-01-01'
    });
    assert.ok(html.includes('测量值'));
    assert.ok(html.includes('公认值'));
    assert.ok(html.includes('—'), '缺失数值与判定应显示占位符');
    assert.ok(html.includes('2u 判据（|Δ| ≤ 2u）'));
  });

  it('缺少计算结果或 steps 时抛 TypeError', () => {
    assert.throws(() => C.buildReportHTML(), TypeError);
    assert.throws(() => C.buildReportHTML(null), TypeError);
    assert.throws(() => C.buildReportHTML({ calculation: {} }), TypeError);
    assert.throws(() => C.buildReportHTML({ calculation: { steps: [] } }), TypeError);
  });
});