// Directory entry keeps `node --test tests/` working on Node versions that
// resolve the explicit test directory as a CommonJS entry rather than discover it.
require('./calc.test.js');
require('./experiments.test.js');
require('./report-ai.test.js');
require('./ui.test.js');
require('./codearts_calc.test.js');
require('./engine.test.js');

// Include every test file when Node resolves this directory through index.js.
for (const file of require("node:fs").readdirSync(__dirname).filter(file => file.endsWith(".test.js"))) require("./" + file);
