'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm'), cp = require('node:child_process');
const E = require('../src/engine.js'), tpl = require('../templates/em_ratio_focusing.js');
const PY = require('./templates_work_ref/python_reference_em_ratio.json');
const baseline = require('./templates_work_ref/before_em_ratio.json');
const root = path.join(__dirname, '..'), read = p => fs.readFileSync(path.join(root, p), 'utf8');
const relative = (a, b) => Math.abs(a - b) / Math.abs(b);
const mu0 = 4 * Math.PI * 1e-7;
const sample = () => {
  const parsed = E.parseCSV(tpl.sampleCsv, tpl);
  assert.ok(parsed.ok, parsed.errors.join(';'));
  return E.autoExclude(tpl, parsed.rows);
};
const calc = (params = {}, deltas = {}) => E.process(tpl, sample().rows, { params, deltas });
const item = (r, key) => r.items.find(i => i.key === key).value;
const derivatives = r => r.items.find(i => i.key === 'result.u').steps.filter(s => s.formula.startsWith('∂f/∂'));
const handRows = () => [800, 900, 1000].map(U => ({ values: { U, I: Math.sqrt(0.003 * U) }, excluded: false }));

test('荷质比：接口、分类、方法、参考值及注册顺序', () => {
  assert.deepEqual(E.validateTemplate(tpl), []);
  assert.equal(tpl.id, 'em_ratio_focusing'); assert.equal(tpl.category, '近代物理');
  assert.equal(tpl.method, 'linear_fit'); assert.equal(tpl.verified, true);
  assert.equal(tpl.result.unit, 'C/kg'); assert.equal(tpl.accepted.value, 1.75882e11);
  assert.match(tpl.accepted.note, /CODATA 2018/);
  assert.match(read('index.html'), /specific_heat_water\.js"><\/script>\s*<script src="templates\/em_ratio_focusing\.js"><\/script>/);
  for (const key of ['N', 'L', 'D', 'l']) assert.match(tpl.params.find(p => p.key === key).label, /假设值/);
});

test('荷质比：固定种子、CSV 副本、全部真值、电流按聚焦公式反算', () => {
  const csv = read('sample_data/templates_work/em_ratio_focusing_模拟数据.csv').replace(/\r\n/g, '\n');
  assert.equal(csv, tpl.sampleCsv); assert.equal(require('../tools/gen_em_ratio_data.js').generateSample(), csv);
  assert.match(csv.split('\n')[0], /模拟数据（非真实测量）.*20261115.*全部真值.*噪声.*第 5 行/);
  assert.equal(require('../sample_data/templates_work/truth.json')[tpl.id], 1.75882e11);
  const rows = E.parseCSV(csv, tpl).rows;
  assert.equal(rows.length, 9);
  const k = 8 * Math.PI ** 2 * (0.234 ** 2 + 0.09 ** 2) / (mu0 ** 2 * 526 ** 2 * 0.145 ** 2 * 1.75882001076e11);
  rows.forEach((r, i) => {
    assert.equal(r.values.U, 700 + 50 * i);
    assert.ok(Math.abs(r.values.I - Math.sqrt(k * r.values.U) - (i === 4 ? 0.06 : 0)) <= 0.0045);
  });
  assert.ok(rows[0].values.I > 1.4 && rows[8].values.I < 1.9, '励磁电流应在常见仪器的 1–2 A 范围');
});

test('荷质比手算：k=0.003 A²/V，结果与公式及 Python 一致', () => {
  // e/m=8π²(L²+D²)/(μ₀²N²l²k)，L²+D²=0.062856，k=0.003；Python 独立计算 1.80089336069101e11。
  const r = E.process(tpl, handRows());
  const expected = 8 * Math.PI ** 2 * 0.062856 / (mu0 ** 2 * 526 ** 2 * 0.145 ** 2 * 0.003);
  assert.ok(relative(r.value, expected) < 1e-9);
  assert.ok(relative(r.value, PY.hand.value) < 1e-9); assert.ok(relative(r.uncertainty, PY.hand.u) < 1e-6);
  assert.ok(Math.abs(item(r, 'fit.uAslope')) < 1e-12);
  const n2 = E.process(tpl, handRows(), { params: { n: 2 } });
  assert.ok(relative(n2.value, 4 * r.value) < 1e-12); assert.ok(relative(n2.value, PY.hand_n2.value) < 1e-9);
});

test('荷质比模拟数据：JS/Python 结果<1e-9、不确定度<1e-6，与 CODATA 一致', () => {
  const r = calc(), ref = PY.sample;
  assert.ok(relative(r.value, ref.value) < 1e-9); assert.ok(relative(r.uncertainty, ref.u) < 1e-6);
  assert.equal(r.comparison.verdict, ref.verdict); assert.equal(r.comparison.verdict, '一致');
  assert.ok(Math.abs(r.value - 1.75882e11) <= 2 * r.uncertainty);
  assert.equal(r.included, PY.included); assert.equal(r.included, 8);
  assert.ok(relative(item(r, 'fit.slope'), ref.fit.slope) < 1e-9);
  assert.ok(relative(item(r, 'fit.uAslope'), ref.fit.uA) < 1e-8);
  assert.ok(relative(item(r, 'fit.uBslope'), ref.fit.uB) < 1e-8);
  const ds = derivatives(r);
  assert.equal(ds.length, 4);
  for (const s of ds) {
    const key = s.formula.split('.').pop();
    assert.ok(relative(s.result, ref.partials[key]) < 1e-5, key);
  }
});

test('荷质比：N、n 不传递误差；U 列误差不计入；L、D、l 误差计入', () => {
  const r = calc();
  assert.ok(derivatives(r).every(s => !/params\.(N|n)$/.test(s.formula)));
  assert.equal(calc({}, { U: 100 }).uncertainty, r.uncertainty);
  assert.ok(calc({}, { I: 0.02 }).uncertainty > r.uncertainty);
  const noGeom = { ...tpl, params: tpl.params.map(p => ['L', 'D', 'l'].includes(p.key) ? { ...p, uncertainty: 0 } : p) };
  const g = E.process(noGeom, sample().rows);
  assert.equal(g.value, r.value); assert.ok(g.uncertainty < r.uncertainty);
});

test('荷质比：格拉布斯检出第 5 行，可恢复', () => {
  const a = sample();
  assert.deepEqual(a.outlier.indices, [4]); assert.deepEqual(a.outlier.indices, PY.excluded_indices);
  assert.ok(relative(a.outlier.statistic, PY.statistic) < 1e-9); assert.equal(a.outlier.critical, PY.critical);
  assert.equal(E.process(tpl, a.rows.map(r => ({ ...r, excluded: false }))).included, 9);
});

test('荷质比：步骤完整，μ₀ 以 4π×10⁻⁷ 显示', () => {
  const steps = calc().items.find(i => i.key === 'result').steps;
  for (const title of ['常数与仪器参数约定', '有限长螺线管的几何长度', '磁场与励磁电流的关系', '第 n 次聚焦条件', '拟合斜率代入荷质比'])
    assert.ok(steps.some(s => s.title === title && s.formula && s.substitution && s.result), title);
  assert.ok(steps.every(s => !String(s.substitution).includes('0.0000012566')));
});

test('荷质比：非法 n、几何参数、斜率报中文错误', () => {
  assert.throws(() => calc({ n: 1.5 }), /聚焦次数/);
  assert.throws(() => calc({ n: 0 }), /聚焦次数/);
  assert.throws(() => calc({ L: 0 }), /匝数 N、长度 L/);
  const rows = sample().rows.map(r => ({ ...r, values: { ...r.values, I: 3 - r.values.I } }));
  assert.throws(() => E.process(tpl, rows), /斜率 k 必须为正/);
});

test('加入荷质比后：全部 24 个既有模板 value/u 与变更前严格相等', () => {
  const S = require('../sample_data/samples.js');
  assert.equal(Object.keys(baseline.templates).length, 24);
  for (const [id, ref] of Object.entries(baseline.templates)) {
    const t = require('../templates/' + id + '.js'), p = E.parseCSV(E.sampleText(t, S), t);
    assert.ok(p.ok);
    const r = E.process(t, E.autoExclude(t, p.rows).rows);
    assert.equal(r.value, ref.value, id + ' value'); assert.equal(r.uncertainty, ref.u, id + ' u');
  }
});

test('run_all：只在表格末行（脚注之前）增加荷质比一行，其余输出逐字节不变', () => {
  const actual = cp.execFileSync(process.execPath, ['tools/run_all.js'], { cwd: root }).toString('utf8');
  const added = actual.split('\n').filter(line => line.startsWith(tpl.name + ' |'));
  assert.equal(added.length, 1);
  assert.match(added[0], /\| 近代物理 \| e\/m = .*C\/kg \| .* \| 一致 \| 5（已剔除） \| 8\/9$/);
  const lines = baseline.runAll.split('\n'); // 末尾是脚注行和空串
  lines.splice(lines.length - 2, 0, added[0]);
  // 后续实验只允许追加在旧表格末尾，旧行仍逐字节检查。
  const osc = actual.split('\n').filter(line => line.startsWith('示波器的使用（测频率、周期与峰峰值） |'));
  assert.equal(osc.length, 1);
  lines.splice(lines.length - 2, 0, osc[0]);
  assert.deepEqual(Buffer.from(actual.replace(/^静电场模拟描绘（同轴圆柱电极，U–ln r 图线法） \|[^\n]*\n/m, '')), Buffer.from(lines.join('\n')));
});

// 纯 Node 的 DOM/event doubles，不启动浏览器或其他应用。
test('荷质比 UI：打开模板显示假设参数、一致判定和步骤', () => {
  class Element {
    constructor() { this.handlers = {}; this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.dataset = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
    emit(name, target) { for (const fn of this.handlers[name] || []) fn({ target, preventDefault() {} }); }
  }
  const html = read('index.html').replace(/<!--[\s\S]*?-->/g, ''), elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  const document = new Element(); document.getElementById = id => elements[id];
  const context = { console, document, location: { hash: '#tpl=em_ratio_focusing&open=1' } };
  context.window = context; context.globalThis = context; vm.createContext(context);
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) vm.runInContext(read(m[1]), context, { filename: m[1] });
  const e = elements;
  for (const text of ['螺线管匝数 N（假设值）', '电子束交叉点到荧光屏距离 l', '聚焦次数 n']) assert.ok(e.params.innerHTML.includes(text), text);
  assert.match(e.badge.innerHTML, /<b>一致<\/b>/);
  assert.match(e.steps.innerHTML, /拟合斜率代入荷质比/);
});
