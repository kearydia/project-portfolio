'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('index.html').replace(/<!--[\s\S]*?-->/g, '');
const text = markup => markup.replace(/<[^>]*>/g, ' ').replace(/&(?:amp|lt|gt|quot|#39);/g, ' ');

// Load the current page in Node with DOM/event doubles. No browser or network is used.
function app(id = 'pendulum_fit') {
  class Element {
    constructor() { this.handlers = {}; this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.hidden = false; this.dataset = {}; this.style = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
    emit(name, target = this) { for (const fn of this.handlers[name] || []) fn({ target, preventDefault() {} }); }
    appendChild() {}
    click() {}
    remove() {}
  }
  const elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  elements.coverage.value = '0.683';
  const document = new Element(), blobs = [];
  document.getElementById = key => { assert.ok(elements[key], 'Missing DOM id: ' + key); return elements[key]; };
  document.createElement = () => new Element(); document.body = new Element();
  const context = { console, document, location: { hash: '#tpl=' + id + '&open=1' }, Blob,
    URL: { createObjectURL(blob) { blobs.push(blob); return 'blob:local-test'; }, revokeObjectURL() {} },
    setTimeout(fn) { fn(); return 0; } };
  context.window = context; context.globalThis = context; vm.createContext(context);
  let result, snapshot;
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) {
    if (m[1] === 'src/ui.js') {
      const process = context.LabEngine.process;
      context.LabEngine = { ...context.LabEngine, process(...args) {
        result = process(...args); snapshot = JSON.stringify(result); return result;
      } };
    }
    vm.runInContext(read(m[1]), context, { filename: m[1] });
  }
  const click = dataset => document.emit('click', { closest: () => ({ dataset, matches: () => false }) });
  return { elements, document, context, click, result: () => result,
    unchanged: () => assert.equal(JSON.stringify(result), snapshot, 'Rendering must not mutate engine results'),
    async report(kind = 'html') {
      elements['export-' + kind].emit('click');
      assert.ok(blobs.length, elements.error.innerHTML || 'Export must create a report Blob');
      return blobs.at(-1).text();
    } };
}
function point(markup, index) {
  const circle = markup.match(new RegExp('<circle\\b[^>]*data-index="' + index + '"[^>]*>'));
  assert.ok(circle, 'Chart must include row ' + (index + 1));
  return Object.fromEntries([...circle[0].matchAll(/([\w-]+)="([^"]*)"/g)].map(m => [m[1], m[2]]));
}
function cleanSteps(markup, label) {
  const content = text(markup);
  assert.doesNotMatch(content, /\\(?:sqrt|sum|frac|cdot)|\b(?:fit|mean|params)\.[A-Za-z_]+|_\{[^}]+\}/, label);
  for (const m of content.matchAll(/\d+\.\d+(?:e[+-]?\d+)?/gi)) {
    const digits = m[0].split(/e/i)[0].replace('.', '').replace(/^0+/, '');
    assert.ok(digits.length <= 6, label + ': unformatted decimal ' + m[0]);
  }
}
function section(markup, heading) {
  const match = markup.match(new RegExp('<section[^>]*>\\s*<h2>' + heading + '</h2>([\\s\\S]*?)</section>'));
  assert.ok(match, 'Report section missing: ' + heading); return match[1];
}

test('P0 page: required DOM ids remain, compact banner follows the main value inside the result card', () => {
  const required = 'main-value main-meta badge items steps banner error chart tip table params export-html export-doc explain verify tpl-list search cats drop file load-sample load-dirty use-t coverage restore add-row sec-upload sec-result sec-export step-1 step-2 step-3 conventions source columns-hint ask-ai api-base api-model api-key api-status ai-text'.split(' ');
  for (const id of required) assert.equal([...html.matchAll(new RegExp('id="' + id + '"', 'g'))].length, 1, id);
  const result = html.slice(html.indexOf('id="sec-result"'), html.indexOf('</section>', html.indexOf('id="sec-result"')));
  assert.ok(result.indexOf('id="main-value"') >= 0);
  assert.ok(result.indexOf('id="banner"') > result.indexOf('id="main-value"'));
  assert.match(html, /实验算盘/); assert.match(html, /大学物理实验数据处理助手/); assert.match(html, /算得准，讲得清/);
  assert.match(html, /<footer[^>]*>[\s\S]*团队：奖金我来了[\s\S]*<\/footer>/);
});

test('P0 banner: compact anomaly detail and restore retain the engine result contract', () => {
  const ui = app(), e = ui.elements, r = ui.result(), index = r.outlier.indices[0];
  assert.equal(e['main-value'].innerHTML.includes(r.formatted), true);
  assert.match(text(e.banner.innerHTML), /疑似异常/); assert.match(e.banner.innerHTML, /title="[^"]+"/);
  assert.doesNotMatch(e.banner.innerHTML, /<br\s*\/?\s*>/i);
  assert.match(e.banner.innerHTML, /data-act="restore-outlier"/);
  assert.match(text(e.banner.innerHTML), /已剔除/); ui.unchanged();
  const before = r.value; ui.click({ act: 'restore-outlier' });
  assert.notEqual(ui.result().value, before);
  assert.match(e.banner.innerHTML, /data-act="exclude-outlier"/);
  const restored = point(e.chart.innerHTML, index);
  assert.equal(restored.stroke, '#e5484d'); assert.match(restored.fill, /^(?:#fff(?:fff)?|none)$/i);
  ui.unchanged();
});

test('P0 chart: excluded Grubbs point stays red, manual exclusions stay gray, legend and fit equation exist', () => {
  const ui = app(), e = ui.elements, r = ui.result(), flagged = r.outlier.indices[0];
  let circle = point(e.chart.innerHTML, flagged);
  assert.equal(circle.stroke, '#e5484d'); assert.equal(circle.r, '7.5'); assert.match(circle.fill, /^(?:#fff(?:fff)?|none)$/i);
  assert.match(text(e.chart.innerHTML), new RegExp('第\\s*' + (flagged + 1) + '\\s*行'));
  for (const label of ['参与计算', '已剔除', '格拉布斯异常', '拟合线']) assert.ok(text(e.chart.innerHTML).includes(label), label);
  assert.match(text(e.chart.innerHTML), /T²\s*=/);
  const manual = flagged === 0 ? 1 : 0;
  e.table.emit('change', { dataset: { keep: String(manual) }, checked: false });
  circle = point(e.chart.innerHTML, manual);
  assert.equal(circle.stroke, '#9aa6bb'); assert.match(circle.fill, /^(?:#fff(?:fff)?|none)$/i);
  ui.unchanged();
});

test('P0 steps: terminal quantity shows at most six steps plus a closed full derivation; short quantities stay direct', () => {
  const ui = app(), e = ui.elements, r = ui.result(), total = r.items.find(i => i.main).steps.length;
  assert.ok(total > 6);
  const details = e.steps.innerHTML.match(/<details\b([^>]*)>([\s\S]*?)<\/details>/);
  assert.ok(details); assert.doesNotMatch(details[1], /\bopen\b/);
  assert.match(text(details[2]), new RegExp('展开完整推导[（(]' + total + '\\s*步[）)]'));
  const summary = e.steps.innerHTML.replace(details[0], '');
  const count = (summary.match(/<li\b/g) || []).length;
  assert.ok(count >= 3 && count <= 6); assert.equal((details[2].match(/<li\b/g) || []).length, total);
  cleanSteps(e.steps.innerHTML, 'main result');
  const index = r.items.findIndex(i => i.key === 'fit.r');
  ui.click({ item: String(index) });
  assert.doesNotMatch(e.steps.innerHTML, /<details\b/); assert.equal((e.steps.innerHTML.match(/<li\b/g) || []).length, r.items[index].steps.length);
  ui.unchanged();
});

test('P0 steps: every verified template formats internal names, LaTeX and substitution decimals without changing results', () => {
  const ui = app();
  for (const tpl of ui.context.EXP_TEMPLATES.filter(t => t.verified === true)) {
    ui.click({ id: tpl.id });
    const r = ui.result(); assert.equal(r.tpl.id, tpl.id);
    for (let index = 0; index < r.items.length; index++) {
      ui.click({ item: String(index) });
      if (r.items[index].steps.length) cleanSteps(ui.elements.steps.innerHTML, tpl.id + '/' + r.items[index].key);
    }
    ui.unchanged();
  }
});

test('P0 formula: nested fractions remain inside sine arguments on screen and in both reports', async () => {
  const ui = app('prism_min_deviation');
  const formula = 'sin((A+δ_min)/(2))';
  assert.ok(text(ui.elements.steps.innerHTML).includes(formula));
  for (const kind of ['html', 'doc']) assert.ok(text(section(await ui.report(kind), '计算步骤与公式')).includes(formula));
  ui.unchanged();
});

test('P0 exports: HTML and Word contain uncertainty, units, de-duplicated formatted steps and bounded columns', async () => {
  const ui = app(), r = ui.result();
  for (const kind of ['html', 'doc']) {
    const report = await ui.report(kind), summary = section(report, '计算结果'), comparison = section(report, '与公认值比较'), steps = section(report, '计算步骤与公式');
    assert.match(text(summary), /量\s+值\s*±\s*不确定度\s+单位/);
    assert.match(text(summary), /±/); assert.ok(text(summary).includes(r.tpl.result.unit));
    assert.match(text(comparison), new RegExp('公认值\\s+' + r.reference + '\\s+' + r.tpl.result.unit.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
    cleanSteps(steps, kind + ' report');
    const rows = [...steps.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/g)].map(m => [...m[1].matchAll(/<td[^>]*>([\s\S]*?)<\/td>/g)].map(x => text(x[1]).trim())).filter(row => row.length === 5);
    const signatures = rows.map(row => JSON.stringify(row.slice(2)));
    assert.ok(rows.length); assert.equal(new Set(signatures).size, signatures.length);
    assert.match(report, /table-layout\s*:\s*fixed/); assert.match(report, /overflow-x\s*:\s*auto/); assert.match(report, /(?:word-break|overflow-wrap)\s*:/);
    for (const width of [4, 18, 28, 36, 14]) assert.match(steps + report.match(/<style[^>]*>([\s\S]*?)<\/style>/)[1], new RegExp('width(?:\\s*:\\s*|=")' + width + '%'));
    if (kind === 'doc') assert.match(report, /xmlns:w="urn:schemas-microsoft-com:office:word"/);
    ui.unchanged();
  }
});
