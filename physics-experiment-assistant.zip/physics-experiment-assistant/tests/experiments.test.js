'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const E = require('../src/experiments.js');
const samples = require('../samples/samples.js');
const near = (a, b, tol = 1e-10) => assert.ok(Math.abs(a - b) <= tol * Math.max(1, Math.abs(b)), `${a} != ${b}`);
function clean(sample) { const csv = fs.readFileSync(path.join(__dirname, '../samples', sample.name + '.csv'), 'utf8'); const parsed = E.parseCSV(csv, sample.type, sample.params); const params = { ...sample.params, ...parsed.hints }; const before = E.process(sample.type, parsed.rows, params); before.outlierIndices.forEach(i => { parsed.rows[i].excluded = true; }); return { ...parsed, params, before, result: E.process(sample.type, parsed.rows, params) }; }
for (const s of samples) {
  test(s.name + '：CSV与内嵌数据一致、检出预设异常点、剔除后满足公认值容差', () => {
    const csv = fs.readFileSync(path.join(__dirname, '../samples', s.name + '.csv'), 'utf8'); assert.equal(csv, s.csv); assert.ok(csv.startsWith('# 模拟数据：')); const c = clean(s);
    assert.equal(c.simulated, true); assert.deepEqual(c.before.outlierIndices, [s.id === 'pendulum_fit' ? 9 : s.id === 'pendulum_single' ? 5 : 8]);
    assert.ok(c.result.comparison.relativeError < (s.type === 'pendulum' ? 1 : 2)); assert.ok(c.result.uncertainty > 0); assert.ok(c.result.steps.length > 10); assert.ok(c.rows.every(r => r.note === '模拟数据'));
  });
}
test('CSV：BOM、中文表头、注释、制表符与带引号字段', () => { const r = E.parseCSV('\ufeff# 模拟数据\n电流(mA)\t电压(V)\t备注\n1\t0.1\t"模拟数据,检查"\n2\t0.2\t正常', 'resistance'); assert.equal(r.rows[0].x, 1); assert.equal(r.rows[0].y, 0.1); assert.equal(r.rows[0].note, '模拟数据,检查'); assert.equal(r.simulated, true); assert.equal(r.hints.currentUnit, 'mA'); });
test('CSV：伏安法 U、I 逆序仍按表头映射；转义双引号', () => { const r = E.parseCSV('U(V),I(mA),note\n0.1,1,"a""b"', 'resistance'); assert.equal(r.rows[0].x, 1); assert.equal(r.rows[0].note, 'a"b'); });
test('CSV 拒绝缺失表头、空单元格、非数值和未闭合引号', () => { assert.throws(() => E.parseCSV('a,b\n1,2', 'resistance')); assert.throws(() => E.parseCSV('I(mA),U(V)\n1,', 'resistance')); assert.throws(() => E.parseCSV('I(mA),U(V)\nabc,2', 'resistance')); assert.throws(() => E.parseCSV('I(mA),U(V)\n1,"2', 'resistance')); });
test('单摆长法：与独立手算均值、s、u_A、u_B、u_C、g、u_g逐项对照', () => {
  const c = clean(samples[1]), ts = c.rows.filter(r => !r.excluded).map(r => r.y), n = ts.length;
  const mean = ts.reduce((a, b) => a + b, 0) / n, s = Math.sqrt(ts.reduce((a, t) => a + (t - mean) ** 2, 0) / (n - 1));
  const ua = s / Math.sqrt(n), ub = 0.002 / Math.sqrt(3), uc = Math.hypot(ua, ub), ul = 0.001 / Math.sqrt(3), g = 4 * Math.PI ** 2 * 0.8 / mean ** 2, ug = g * Math.hypot(ul / 0.8, 2 * uc / mean);
  near(c.result.metrics[0].value, mean); near(c.result.metrics[1].value, ua); near(c.result.metrics[2].value, ub); near(c.result.metrics[3].value, uc); near(c.result.value, g); near(c.result.uncertainty, ug);
});
test('单摆 N次总时间与单周期等价，仪器总时间误差也除N', () => { const c = clean(samples[1]); const rows = c.rows.map(r => ({ ...r, y: r.y * 20 })); const r = E.process('pendulum', rows, { ...c.params, timeMode: 'total', cycles: 20, deltaT: 0.04 }); near(r.value, c.result.value); near(r.uncertainty, c.result.uncertainty); });
test('伏安法 mA→A 单位换算', () => { const rows = [1, 2, 3, 4].map(x => ({ x, y: x / 10 })); near(E.process('resistance', rows).value, 100); near(E.process('resistance', rows.map(r => ({ ...r, x: r.x / 1000 })), { currentUnit: 'A' }).value, 100); });
test('伏安法内接修正：R=R测−R_A', () => { const c = clean(samples[2]); const r = E.process('resistance', c.rows, { correction: 'internal', ra: 0.5 }); near(r.value, c.result.value - 0.5); near(r.uncertainty, c.result.uncertainty); });
test('伏安法外接修正及其解析偏导', () => { const c = clean(samples[2]), rv = 10000; const r = E.process('resistance', c.rows, { correction: 'external', rv }); near(r.value, c.result.value * rv / (rv - c.result.value)); near(r.uncertainty, c.result.uncertainty * rv ** 2 / (rv - c.result.value) ** 2); });
test('伏安法非法修正边界给出错误', () => { const c = clean(samples[2]); assert.throws(() => E.process('resistance', c.rows, { correction: 'external', rv: 50 })); assert.throws(() => E.process('resistance', c.rows, { correction: 'internal', ra: 200 })); });
test('杨氏模量 kg/cm 与 N/m 等价', () => { const c = clean(samples[3]); const rows = c.rows.map(r => ({ ...r, x: r.x * 9.8, y: r.y / 100 })); const r = E.process('young', rows, { forceUnit: 'N', readingUnit: 'm' }); near(r.value, c.result.value); near(r.uncertainty, c.result.uncertainty); });
test('杨氏模量直径翻倍时 E 缩小为四分之一', () => { const c = clean(samples[3]); const r = E.process('young', c.rows, { diameter: '0.001' }); near(r.value, c.result.value / 4); });
test('非法输入：零直径、零周期、过少有效数据不返回伪结果', () => { assert.throws(() => E.process('young', clean(samples[3]).rows, { diameter: '0' })); assert.throws(() => E.process('pendulum', [{ x: 1, y: 0 }, { x: 2, y: 1 }, { x: 3, y: 2 }])); assert.throws(() => E.process('resistance', [{ x: 1, y: 1 }])); });
test('剔除后仅在保留点重新拟合，恢复可得到原结果', () => { const s = samples[0], parsed = E.parseCSV(s.csv, s.type, s.params), original = E.process(s.type, parsed.rows, s.params); original.outlierIndices.forEach(i => { parsed.rows[i].excluded = true; }); assert.equal(E.process(s.type, parsed.rows, s.params).count, 17); parsed.rows.forEach(r => { r.excluded = false; }); near(E.process(s.type, parsed.rows, s.params).value, original.value); });
