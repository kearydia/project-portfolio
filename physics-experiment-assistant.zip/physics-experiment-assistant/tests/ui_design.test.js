'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const html = read('index.html').replace(/<!--[\s\S]*?-->/g, '');
const css = read('css/app.css');
const text = markup => String(markup).replace(/<[^>]*>/g, ' ').replace(/&(?:amp|lt|gt|quot|#39);/g, ' ');

// Exercise the actual offline scripts and their DOM events, without an app or network.
function app(hash = '#tpl=pendulum_fit&open=1', reducedMotion = true) {
  const downloads = [], blobs = [], replacements = [], scrolls = [];
  class Element {
    constructor(id = '') {
      this.id = id; this.handlers = {}; this.dataset = {}; this.style = { setProperty() {}, removeProperty() {} };
      this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.disabled = false;
      this.hidden = false; this.offsetWidth = 180; this.offsetHeight = 100; this.scrollHeight = 100;
      const classes = new Set();
      this.classList = { add: (...names) => names.forEach(n => classes.add(n)), remove: (...names) => names.forEach(n => classes.delete(n)),
        contains: name => classes.has(name), toggle(name, state) { const on = state === undefined ? !classes.has(name) : !!state; if (on) classes.add(name); else classes.delete(name); return on; } };
    }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
    removeEventListener(name, fn) { this.handlers[name] = (this.handlers[name] || []).filter(f => f !== fn); }
    emit(name, target = this, extra = {}) { for (const fn of this.handlers[name] || []) fn({ target, preventDefault() {}, clientX: 180, clientY: 160, ...extra }); }
    setAttribute(name, value) { this[name] = value; }
    removeAttribute(name) { delete this[name]; }
    getAttribute(name) { return this[name]; }
    appendChild() {}
    remove() {}
    click() { this.clickCount = (this.clickCount || 0) + 1; if (this.download) downloads.push(this.download); this.emit('click'); }
    getBoundingClientRect() { return { left: 0, top: 0, width: 760, height: 420, right: 760, bottom: 420 }; }
    scrollIntoView(options) { scrolls.push({ id: this.id, options }); }
    animate() { return { finished: Promise.resolve(), cancel() {} }; }
    querySelector() { return null; }
    querySelectorAll() { return []; }
  }
  const elements = {};
  for (const m of html.matchAll(/\bid="([^"]+)"/g)) elements[m[1]] = new Element(m[1]);
  elements.coverage.value = '0.683';
  const document = new Element(); document.body = new Element(); document.documentElement = new Element();
  document.getElementById = id => { assert.ok(elements[id], 'Unknown DOM id: ' + id); return elements[id]; };
  document.createElement = () => new Element(); document.querySelectorAll = () => [];
  const location = { hash, pathname: '/index.html', search: '' };
  const context = { console, document, location, Blob,
    history: { replaceState(state, title, url) { replacements.push(String(url)); location.hash = String(url).includes('#') ? '#' + String(url).split('#')[1] : ''; } },
    URL: { createObjectURL(blob) { blobs.push(blob); return 'blob:local-design-test'; }, revokeObjectURL() {} },
    setTimeout(fn) { fn(); return 0; }, clearTimeout() {}, requestAnimationFrame(fn) { fn(0); return 0; }, cancelAnimationFrame() {},
    matchMedia: () => ({ matches: reducedMotion, addEventListener() {}, removeEventListener() {} }),
    getComputedStyle: () => ({ transitionDuration: '0s', animationDuration: '0s' }) };
  context.window = context; context.globalThis = context; vm.createContext(context);
  let result, snapshot;
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) {
    if (m[1] === 'src/ui.js') {
      const process = context.LabEngine.process;
      context.LabEngine = { ...context.LabEngine, process(...args) { result = process(...args); snapshot = JSON.stringify(result); return result; } };
    }
    vm.runInContext(read(m[1]), context, { filename: m[1] });
  }
  const click = (dataset, circle = false) => {
    const node = { dataset, matches: selector => circle && selector === 'circle.pt' }; node.closest = () => node;
    document.emit('click', node); return node;
  };
  return { elements, context, document, replacements, downloads, scrolls, click, result: () => result,
    unchanged: () => assert.equal(JSON.stringify(result), snapshot, 'Rendering must leave the engine result unchanged'),
    async report(kind = 'html') { elements['export-' + kind].emit('click'); assert.ok(blobs.length, elements.error.innerHTML || 'Report not created'); return blobs.at(-1).text(); } };
}

test('UI design: opening is available without a template hash, and deep links show the selected experiment', () => {
  const home = app(''); assert.equal(home.elements.opening.hidden, false);
  assert.match(html, /id="opening"/); assert.match(html, /用示例数据试一下/);
  const linked = app('#tpl=specific_heat_water');
  assert.equal(linked.elements.opening.hidden, true); assert.equal(linked.result().tpl.id, 'specific_heat_water');
  linked.unchanged();
});

test('UI design: opening buttons collapse the introduction and reach the sample or experiment list', () => {
  const sample = app(''); sample.elements['opening-sample'].emit('click');
  assert.equal(sample.elements.opening.hidden, true); assert.equal(sample.result().tpl.id, 'pendulum_fit');
  assert.ok(sample.replacements.some(url => /#tpl=pendulum_fit(?:$|&)/.test(url)));
  const choose = app(''); choose.elements['opening-choose'].emit('click');
  assert.equal(choose.elements.opening.hidden, true);
  assert.ok(choose.scrolls.some(s => s.id === 'experiment-list' || s.id === 'tpl-list'));
});

test('UI design: load and template changes animate once while typed inputs and reduced motion stay still', () => {
  const ui = app('', false), e = ui.elements;
  e['load-sample'].emit('click');
  assert.equal(e['sec-result'].classList.contains('result-enter'), true);
  assert.equal(e.chart.classList.contains('chart-enter'), true);
  for (const value of ['9', '9.8', '9.80']) {
    e.params.emit('input', { dataset: { ref: 'ref' }, value });
    assert.equal(e['sec-result'].classList.contains('result-enter'), false, 'Typing must not replay the result entrance');
    assert.equal(e.chart.classList.contains('chart-enter'), false, 'Typing must not redraw the chart with an entrance');
  }
  e['load-sample'].emit('click');
  assert.equal(e['sec-result'].classList.contains('result-enter'), true);
  assert.equal(e.chart.classList.contains('chart-enter'), true);
  ui.click({ id: 'viscosity_falling_ball' });
  assert.equal(e.workspace.classList.contains('workspace-enter'), true);
  assert.equal(e['sec-result'].classList.contains('result-enter'), true);
  assert.equal(e.chart.classList.contains('chart-enter'), true); ui.unchanged();
  const reduced = app('', true); reduced.elements['opening-choose'].emit('click');
  assert.equal(reduced.elements.opening.hidden, true);
  assert.equal(reduced.elements.opening.classList.contains('opening-closing'), false);
  reduced.click({ id: 'specific_heat_water' });
  assert.equal(reduced.elements.workspace.classList.contains('workspace-enter'), false);
  assert.equal(reduced.elements['sec-result'].classList.contains('result-enter'), false);
  assert.equal(reduced.elements.chart.classList.contains('chart-enter'), false); reduced.unchanged();
});

test('UI design: the upload drop area opens the file chooser with Enter or Space', () => {
  const ui = app(), e = ui.elements; let prevented = 0;
  for (const key of ['Enter', ' ']) {
    const before = e.file.clickCount || 0;
    e.drop.emit('keydown', e.drop, { key, preventDefault() { prevented++; } });
    assert.equal(e.file.clickCount, before + 1, key);
  }
  const before = e.file.clickCount;
  e.drop.emit('keydown', e.drop, { key: 'Tab' });
  assert.equal(e.file.clickCount, before); assert.equal(prevented, 2); ui.unchanged();
});

test('UI design: selecting an experiment updates the hash through replaceState and keeps filtering usable', () => {
  const ui = app(''); ui.click({ id: 'viscosity_falling_ball' });
  assert.equal(ui.elements.opening.hidden, true); assert.equal(ui.result().tpl.id, 'viscosity_falling_ball');
  assert.match(ui.replacements.at(-1), /#tpl=viscosity_falling_ball$/);
  ui.elements.search.emit('input', { value: '比热容' });
  assert.match(ui.elements['tpl-list'].innerHTML, /specific_heat_water/);
  assert.doesNotMatch(ui.elements['tpl-list'].innerHTML, /data-id="pendulum_fit"/);
  ui.unchanged();
});

test('UI design: experiment list groups categories and supplies SVG icons and summary tooltips', () => {
  const ui = app(), markup = ui.elements['tpl-list'].innerHTML;
  for (const category of ui.context.LabEngine.CATEGORIES) assert.ok(text(markup).includes(category), category);
  for (const tpl of ui.context.EXP_TEMPLATES.filter(t => t.verified === true)) {
    const button = markup.match(new RegExp('<button\\b[^>]*data-id="' + tpl.id + '"[^>]*>[\\s\\S]*?</button>'));
    assert.ok(button, tpl.id); assert.match(button[0], /title="[^"]+"/); assert.match(button[0], /<svg\b/);
  }
});

test('UI design: every registered experiment has a compact original line SVG', () => {
  const ui = app(), icons = ui.context.EXP_ICONS;
  assert.ok(icons); const drawings = new Set();
  for (const tpl of ui.context.EXP_TEMPLATES) {
    const svg = icons[tpl.id]; assert.equal(typeof svg, 'string', tpl.id); drawings.add(svg);
    assert.match(svg, /viewBox="0 0 32 32"/); assert.match(svg, /fill="none"/);
    assert.match(svg, /stroke="currentColor"/); assert.match(svg, /stroke-width="1\.6"/);
    assert.match(svg, /stroke-linecap="round"/);
    assert.doesNotMatch(svg, /<(?:image|use|text|foreignObject|script)\b|(?:href|src)=/i);
    for (const fill of svg.matchAll(/\bfill="([^"]+)"/g)) assert.equal(fill[1], 'none', tpl.id);
    const tags = [...svg.matchAll(/<([a-zA-Z]+)\b/g)].map(m => m[1]);
    assert.ok(tags.every(tag => ['svg', 'g', 'path', 'line', 'polyline', 'polygon', 'circle', 'ellipse', 'rect'].includes(tag)), tpl.id);
    assert.ok(tags.filter(tag => !['svg', 'g'].includes(tag)).length <= 12, tpl.id + ': too many primitives');
  }
  assert.ok(drawings.size >= 20, 'The required physical apparatus should have distinct drawings');
  assert.ok(html.indexOf('src/icons.js') < html.indexOf('src/ui.js'));
});

test('UI design: switches stay in the parameter panel and are excluded from displayed result items', () => {
  const ui = app();
  for (const tpl of ui.context.EXP_TEMPLATES.filter(t => (t.params || []).some(p => p.type === 'switch'))) {
    ui.click({ id: tpl.id });
    for (const param of tpl.params.filter(p => p.type === 'switch')) {
      const index = ui.result().items.findIndex(it => it.key === 'params.' + param.key);
      assert.ok(index >= 0, 'The engine switch item must still exist');
      assert.doesNotMatch(ui.elements.items.innerHTML, new RegExp('data-item="' + index + '"'));
      assert.match(ui.elements.params.innerHTML, new RegExp('data-switch="' + param.key + '"'));
      ui.elements.params.emit('change', { dataset: { switch: param.key }, checked: true });
      assert.doesNotMatch(ui.elements.items.innerHTML, new RegExp('data-item="' + index + '"')); ui.unchanged();
    }
  }
});

test('UI design: parameter error labels display symbols and large accepted values round-trip exactly', () => {
  const heat = app('#tpl=specific_heat_water');
  const theta = heat.elements.params.innerHTML.match(/<label[^>]*>(?:(?!<\/label>)[\s\S])*data-param="Δtheta"(?:(?!<\/label>)[\s\S])*<\/label>/);
  assert.ok(theta); assert.match(text(theta[0]), /Δθ/); assert.doesNotMatch(text(theta[0]), /Δtheta/);
  const young = app('#tpl=youngs_modulus');
  const input = young.elements.params.innerHTML.match(/<input\b[^>]*data-ref="ref"[^>]*>/);
  assert.ok(input); const value = input[0].match(/\bvalue="([^"]+)"/)[1];
  assert.equal(Number(value), 200000000000); assert.ok(value.length <= 10, 'Large values should fit visibly in the input');
  const before = young.result().value;
  young.elements.params.emit('input', { dataset: { ref: 'ref' }, value });
  assert.equal(young.result().reference, 200000000000); assert.equal(young.result().value, before); young.unchanged();
});

test('UI design: corrected heat preview keeps the physical steps and folds partial derivatives', () => {
  const ui = app('#tpl=specific_heat_water&open=1');
  ui.elements.params.emit('change', { dataset: { switch: 'heatLoss' }, checked: true });
  const markup = ui.elements.steps.innerHTML, preview = markup.split('<details')[0];
  assert.ok((preview.match(/<li\b/g) || []).length <= 8); assert.doesNotMatch(text(preview), /∂|\\partial/);
  let last = -1;
  for (const title of ['保留拟合点的平均温度', '散热对应的升温速率', '修正后的升温速率']) {
    const index = text(preview).indexOf(title); assert.ok(index > last, title + ' must remain visible and ordered'); last = index;
  }
  assert.match(text(preview), /T̄/); assert.match(text(preview), /δk/); assert.match(markup, /展开完整推导/); ui.unchanged();
});

test('UI design: falling-ball preview shows both enabled correction factors', () => {
  const ui = app('#tpl=viscosity_falling_ball&open=1');
  for (const key of ['wallCorr', 'bottomCorr']) ui.elements.params.emit('change', { dataset: { switch: key }, checked: true });
  const preview = ui.elements.steps.innerHTML.split('<details')[0];
  assert.match(text(preview), /管壁修正因子/); assert.match(text(preview), /管底修正因子/);
  assert.doesNotMatch(text(preview), /∂|\\partial/); assert.ok((preview.match(/<li\b/g) || []).length <= 8); ui.unchanged();
});

test('UI design: clicking a chart point immediately refreshes the existing hover tip', () => {
  const ui = app(), attrs = ui.elements.chart.innerHTML.match(/<circle\b[^>]*data-index="0"[^>]*>/)[0];
  const dataset = Object.fromEntries([...attrs.matchAll(/data-([\w-]+)="([^"]+)"/g)].map(m => [m[1], m[2]]));
  const node = { dataset, matches: selector => selector === 'circle.pt' }; node.closest = () => node;
  ui.elements.chart.emit('mousemove', node); assert.equal(ui.elements.tip.hidden, false);
  const original = text(ui.elements.tip.innerHTML); ui.document.emit('click', node);
  assert.equal(ui.elements.tip.hidden, false); assert.notEqual(text(ui.elements.tip.innerHTML), original);
  assert.match(text(ui.elements.tip.innerHTML), /点击恢复|点击剔除/); ui.unchanged();
});

test('UI design: HTML and Word filenames are plain and reports share the ink palette and print rules', async () => {
  const ui = app();
  for (const kind of ['html', 'doc']) {
    const report = await ui.report(kind), filename = ui.downloads.at(-1);
    assert.ok(filename.startsWith('实验算盘_')); assert.match(filename, new RegExp('_模拟数据_报告\\.' + kind + '$'));
    assert.doesNotMatch(filename, /\s|[()（）²³–]/); assert.match(filename, /T2-L/);
    assert.doesNotMatch(report, /#6d4cff|#2f7cff|linear-gradient/i);
    assert.match(report, /#1f3a5f/i); assert.match(report, /Noto Serif SC/); assert.match(report, /Consolas/);
    assert.match(report, /@media\s+print/); assert.match(report, /(?:break-inside|page-break-inside)\s*:\s*avoid/);
    assert.doesNotMatch(report, /\bvar\s*\(/, 'Exported styles must work in Word without CSS custom properties');
    const charts = report.match(/<svg\b[\s\S]*?<\/svg>/g) || [];
    assert.ok(charts.length, 'Export must retain the data chart');
    for (const chart of charts) {
      assert.doesNotMatch(chart, /\brole="button"|\btabindex\s*=|点击(?:剔除|恢复)|\bEnter\b|\bSpace\b|按(?:回车|空格)/i,
        'Exported charts must omit keyboard and click controls');
    }
    assert.ok(report.includes(ui.result().formatted)); ui.unchanged();
  }
});

test('UI design: prescribed palette, font roles, focus and reduced-motion rules remain local', () => {
  const variables = { paper: '#f5f1e6', sheet: '#fbf9f3', grid: '#dfe6dc', 'grid-major': '#c6d4c8', ink: '#1e2a36',
    'ink-soft': '#5a6670', line: '#d9d3c4', brand: '#1f3a5f', brass: '#b8862b', data: '#0e8a83', outlier: '#c8372d', ok: '#2f7d4f' };
  for (const [key, value] of Object.entries(variables)) assert.match(css, new RegExp('--' + key + '\\s*:\\s*' + value, 'i'));
  assert.doesNotMatch(css, /#6d4cff|#2f7cff/i); assert.doesNotMatch(html + css, /\p{Extended_Pictographic}/u);
  assert.doesNotMatch(text(html), /智能/); assert.doesNotMatch(html + css, /fonts\.google|@import|https?:\/\/[^"'\s)]+\.(?:woff2?|ttf|css|js)/i);
  for (const family of ['Noto Serif SC', 'KaiTi', 'Microsoft YaHei', 'Cascadia Mono', 'Consolas']) assert.ok(css.includes(family), family);
  assert.match(css, /font-variant-numeric\s*:\s*tabular-nums/); assert.match(css, /:focus-visible/);
  assert.match(css, /prefers-reduced-motion/); assert.match(css, /scroll-margin-top\s*:/);
  assert.doesNotMatch(css, /animation[^;}]*\binfinite\b/);
});

test('UI design: responsive and print CSS provides narrow-screen flow and wide projection space', () => {
  const narrow = [...css.matchAll(/@media[^{]*max-width\s*:\s*(\d+)px/g)].some(m => Number(m[1]) >= 390 && Number(m[1]) <= 900);
  assert.ok(narrow, 'A narrow-screen breakpoint must cover the 390px layout');
  assert.match(css, /(?:max-width\s*:\s*1560px|--[\w-]+\s*:\s*1560px)/);
  assert.match(css, /minmax\(\s*0\s*,\s*1fr\s*\)/);
  assert.match(css, /@media\s+print/); assert.match(css, /(?:break-inside|page-break-inside)\s*:\s*avoid/);
});
