'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process'), vm = require('node:vm');
const E = require('../src/engine.js'), tpl = require('../templates/oscilloscope.js');
const { measure, cases } = require('../tools/run_oscilloscope.js');
const { generateSample } = require('../tools/gen_oscilloscope_data.js');
const PY = require('./templates_work_ref/python_reference_oscilloscope.json');
const root = path.join(__dirname, '..'), read = file => fs.readFileSync(path.join(root, file), 'utf8');
const close = (a, b, tolerance = 1e-8) => assert.ok(Math.abs(a - b) <= tolerance * Math.max(Math.abs(b), 1e-20), a + ' vs ' + b);
const rows = () => E.parseCSV(tpl.sampleCsv, tpl).rows;
const hand = () => [4, 5, 6].map((n, i) => ({ values: { n_div: n, v_div: 3 + i }, excluded: false }));
const calc = (params = {}, options = {}) => E.process(tpl, rows(), { ...options, params });

test('示波器：接口、分类、浏览器注册与参考值约定', () => {
  assert.deepEqual(E.validateTemplate(tpl), []);
  assert.equal(tpl.method, 'direct'); assert.equal(tpl.category, '电磁学'); assert.equal(tpl.verified, true);
  assert.match(read('index.html'), /em_ratio_focusing\.js"><\/script>\s*<script src="templates\/oscilloscope\.js"><\/script>/);
  assert.equal(tpl.accepted.value, 1000); assert.match(tpl.accepted.note, /信号发生器|发生器/);
  assert.match(tpl.accepted.note, /不是普适物理常数/);
  assert.equal(calc({}, { reference: 1200 }).reference, 1200);
});

test('示波器：固定种子生成与 CSV、内嵌副本逐字节一致', () => {
  const csv = read('sample_data/oscilloscope_模拟数据.csv');
  assert.equal(generateSample(), csv); assert.equal(generateSample(), generateSample()); assert.equal(csv, tpl.sampleCsv);
  assert.match(csv.split('\n')[0], /模拟数据（非真实测量）.*固定种子 20261116.*全部真值.*噪声/);
  const p = E.parseCSV(csv, tpl); assert.ok(p.ok); assert.ok(p.simulated); assert.equal(p.rows.length, 10);
  p.rows.forEach(r => { assert.ok(Math.abs(r.values.n_div - 5) <= 0.0305); assert.ok(Math.abs(r.values.v_div - 4) <= 0.0405); });
  assert.deepEqual(E.autoExclude(tpl, p.rows).outlier.indices, []);
  assert.equal(calc().comparison.verdict, '一致');
});

test('示波器手算：4/5/6 格，T=1 ms、f=1000 Hz、Vpp=2 V 与独立不确定度', () => {
  const m = measure(hand());
  close(m.T, 0.001); close(m.f, 1000); close(m.Vpp, 2);
  // 两列样本标准差均为 1 div，u_A=1/√3 div。
  close(m.uAT, 0.0002 / Math.sqrt(3)); close(m.uAf, 200 / Math.sqrt(3)); close(m.uAVpp, 0.5 / Math.sqrt(3));
  const un = Math.sqrt(1 / 3 + 0.02 ** 2 / 3);
  close(m.uT, Math.hypot(0.0002 * un, 5 * 0.000001));
  close(m.uf, Math.hypot(0.0002 * un, 5 * 0.000001) / 1e-6);
  close(m.uVpp, Math.hypot(0.5 * un, 4 * 10 * 0.0005));
  assert.notEqual(m.f, (1250 + 1000 + 1 / 0.0012) / 3, '采用平均周期的倒数');
});

test('示波器：4 组、每组 9 个量与 Python 独立参考一致', () => {
  for (const [name, result] of Object.entries(cases())) {
    for (const [key, expected] of Object.entries(PY[name])) close(result[key], expected);
  }
});

test('示波器：时基、灵敏度及探头倍率的单位换算', () => {
  const a = measure(hand()), b = measure(hand(), { params: { timebase: 0.0001, sensitivity: 0.1, probe: 1 } });
  close(b.T, a.T / 2); close(b.f, a.f * 2); close(b.Vpp, a.Vpp / 5);
  const compensated = measure(hand(), { params: { sensitivity: 0.5, probe: 1 } });
  close(compensated.Vpp, a.Vpp);
});

test('示波器：修正关闭忽略无效因子，开启按定义改变三个量及不确定度', () => {
  const a = measure(hand()), b = measure(hand(), { params: { calibration: 1 } });
  close(b.T, a.T * 1.002); close(b.f, a.f / 1.002); close(b.Vpp, a.Vpp * 0.99);
  const off = calc({ calibration: 0, kt: '无效', kv: -10 });
  assert.equal(off.value, calc().value); assert.equal(off.uncertainty, calc().uncertainty);
  for (const key of ['kt', 'kv']) assert.ok(off.items.find(i => i.key === 'params.' + key).label.includes('未启用'));
  const ds = r => r.items.find(i => i.key === 'result.u').steps.filter(s => s.formula.startsWith('∂f/∂')).map(s => s.formula);
  assert.ok(!ds(off).some(s => /kt|kv/.test(s)));
  assert.ok(ds(calc({ calibration: 1 })).includes('∂f/∂params.kt'));
  assert.ok(!ds(calc({ calibration: 1 })).some(s => /kv|calibration/.test(s)));
});

test('示波器：开关归一化、非法参数和逐行非正读数给出中文错误', () => {
  for (const on of [1, '1', true]) assert.equal(calc({ calibration: on }).value, calc({ calibration: 1 }).value);
  for (const off of [0, '0', false]) assert.equal(calc({ calibration: off }).value, calc().value);
  assert.throws(() => calc({ calibration: 2 }), /开关/);
  for (const key of ['timebase', 'sensitivity', 'probe', 'VppNominal']) {
    assert.throws(() => calc({ [key]: 0 }), /必须为正/);
    assert.throws(() => calc({ [key]: Infinity }), /有限数|必须是数字/);
  }
  for (const key of ['kt', 'kv']) assert.throws(() => calc({ calibration: 1, [key]: 0 }), /必须为正/);
  for (const key of ['n_div', 'v_div']) {
    const r = hand(); r[0].values[key] = -1;
    assert.throws(() => E.process(tpl, r), /每行.*必须为正/);
  }
});

test('示波器：改读格误差、t 因子时频率和峰峰值不确定度同步变化', () => {
  const base = measure(hand()), changed = measure(hand(), { deltas: { n_div: 0.2, v_div: 0.2 } });
  assert.ok(changed.uf > base.uf); assert.ok(changed.uVpp > base.uVpp);
  assert.equal(changed.f, base.f); assert.equal(changed.Vpp, base.Vpp);
  const t = measure(hand(), { useT: true, coverage: 0.95 });
  assert.ok(t.uAT > base.uAT * 4); assert.ok(t.uAVpp > base.uAVpp * 4); assert.ok(t.uf > base.uf);
});

test('示波器：步骤显示均值、A 类、合成不确定度和峰峰值标称比较', () => {
  const s = calc().items.find(i => i.key === 'result').steps;
  for (const title of ['平均周期', '由平均周期求频率', '平均峰峰值', '周期的 A 类不确定度', '频率的 A 类不确定度', '峰峰值的 A 类不确定度', '周期的合成不确定度', '峰峰值的合成不确定度', '峰峰值与信号发生器标称值比较'])
    assert.ok(s.some(step => step.title === title && step.formula && step.substitution && step.result), title);
  const compare = p => calc(p).items.find(i => i.key === 'result').steps.find(s => s.title === '峰峰值与信号发生器标称值比较').result;
  assert.match(compare({}), /；一致$/); assert.match(compare({ VppNominal: 10 }), /偏差显著/);
});

test('示波器：剔除与恢复只使用保留行，缺值和不足行报错', () => {
  const r = hand(); r.push({ values: { n_div: 100, v_div: 100 }, excluded: true });
  close(measure(r).f, 1000); close(measure(r).Vpp, 2);
  r[3].excluded = false; assert.notEqual(measure(r).f, 1000);
  assert.throws(() => E.process(tpl, hand().slice(0, 2)), /太少/);
  assert.equal(E.parseCSV('n_div,v_div\n5,4\n5,x\n5,4\n', tpl).ok, false);
  const missing = hand(); delete missing[0].values.v_div;
  assert.throws(() => E.process(tpl, missing), /太少/);
});

test('示波器：run_all 只追加一行，旧 25 行与运行前及 v13 逐字节一致', () => {
  const actual = cp.execFileSync(process.execPath, ['tools/run_all.js'], { cwd: root });
  const text = actual.toString('utf8'), added = text.split('\n').filter(line => line.startsWith(tpl.name + ' |'));
  assert.equal(added.length, 1); assert.match(added[0], /\| 一致 \| 无 \| 10\/10$/);
  const original = Buffer.from(text.replace(added[0] + '\n', '').replace(/^静电场模拟描绘（同轴圆柱电极，U–ln r 图线法） \|[^\n]*\n/m, ''));
  assert.deepEqual(original, fs.readFileSync(path.join(root, 'tools/run_all_before_oscilloscope.txt')));
  const oldRows = read('tools/run_all_v13.txt').split(/\r?\n/).filter(line => line.includes(' | ')).slice(1);
  assert.equal(oldRows.length, 25);
  const actualRows = text.split('\n').filter(line => line.includes(' | ')).slice(1, 26);
  oldRows.forEach((line, i) => assert.deepEqual(Buffer.from(actualRows[i]), Buffer.from(line)));
});

test('示波器：所有旧模板计算值与不确定度与原引擎严格相同', () => {
  const baseline = require('./templates_work_ref/before_oscilloscope.json');
  const S = require('../sample_data/samples.js');
  const ids = read('index.html').match(/templates\/[\w-]+\.js/g).map(s => s.slice(10, -3)).filter(id => id !== tpl.id);
  assert.ok(ids.length >= 25);
  for (const id of Object.keys(baseline)) assert.ok(ids.includes(id), '原有模板缺失：' + id);
  for (const id of Object.keys(baseline)) {
    const t = require('../templates/' + id + '.js'), parsed = E.parseCSV(E.sampleText(t, S), t);
    const data = E.autoExclude(t, parsed.rows).rows;
    for (const options of [{}, { useT: true, coverage: 0.95 }]) {
      const a = baseline[id][options.useT ? "withT" : "default"], b = E.process(t, data, options);
      assert.equal(b.value, a.value, id); assert.equal(b.uncertainty, a.uncertainty, id);
    }
  }
});

test('示波器页面：离线加载、参数开关、步骤和标称比较可见', () => {
  class Element {
    constructor() { this.handlers = {}; this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.dataset = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
  }
  const html = read('index.html').replace(/<!--[\s\S]*?-->/g, ''), elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  const document = new Element(); document.getElementById = id => elements[id];
  const context = { console, document, location: { hash: '#tpl=oscilloscope&open=1' } };
  context.window = context; context.globalThis = context; vm.createContext(context);
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) vm.runInContext(read(m[1]), context, { filename: m[1] });
  assert.match(elements.params.innerHTML, /仪器校准修正/); assert.match(elements.params.innerHTML, /探头衰减倍率/);
  assert.match(elements.badge.innerHTML, /<b>一致<\/b>/); assert.match(elements.steps.innerHTML, /平均峰峰值/);
  assert.match(elements.steps.innerHTML, /周期的 A 类不确定度/);
  for (const file of ['templates/oscilloscope.js', 'tools/gen_oscilloscope_data.js']) assert.doesNotMatch(read(file), /\u667a\u80fd|\b\u0041\u0049\b|\p{Extended_Pictographic}/u);
});
