'use strict';
// Pure Node DOM/event doubles: no browser engine or browser automation is used.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
class Element {
  constructor() { this.handlers = {}; this.dataset = {}; this.value = ''; this.checked = false; this.disabled = false; this.hidden = false; this.textContent = ''; this._html = ''; this.children = {}; this.rows = []; this.classList = { add() {}, remove() {}, toggle() {} }; }
  set innerHTML(html) {
    this._html = html;
    this.rows = [...html.matchAll(/<tr data-row="(\d+)">([\s\S]*?)<\/tr>/g)].map(m => { const tr = new Element(); tr.dataset.row = m[1]; tr.children['input[type=checkbox]'] = new Element(); tr.children['.row-state'] = new Element(); return tr; });
  }
  get innerHTML() { return this._html; }
  querySelector(selector) { if (!this.children[selector]) this.children[selector] = new Element(); return this.children[selector]; }
  querySelectorAll(selector) { if (selector === 'tbody tr') return this.querySelector('tbody').rows; return []; }
  addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
  setAttribute(name, value) { this[name] = value; }
  async emit(name, target = this, extra = {}) { for (const fn of this.handlers[name] || []) await fn({ target, preventDefault() {}, ...extra }); }
}
function app() {
  const html = fs.readFileSync(path.join(root, 'legacy/index_v1.html'), 'utf8'), elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  const tabs = ['pendulum', 'resistance', 'young'].map(type => { const e = new Element(); e.dataset.type = type; return e; });
  const document = { getElementById: id => { assert.ok(elements[id], 'HTML 中缺少 ' + id); return elements[id]; }, querySelectorAll: selector => selector === '.tab' ? tabs : [], addEventListener() {} };
  const downloads = [], context = { document, console, URL, AbortController, setTimeout, clearTimeout, fetch: async () => { throw new Error('模拟网络失败'); } };
  context.window = context; context.globalThis = context;
  vm.createContext(context);
  const scripts = [...html.matchAll(/<script src="([^"]+)"/g)].map(m => m[1]);
  for (const file of scripts) {
    if (file.endsWith('/app.js')) context.PhysReport.download = (...args) => downloads.push(args);
    vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file });
  }
  return { elements, tabs, downloads, context };
}
test('离线资源结构：普通脚本、文件均存在、无CDN或module、密钥无持久化', () => {
  const html = fs.readFileSync(path.join(root, 'legacy/index_v1.html'), 'utf8');
  for (const m of html.matchAll(/(?:src|href)="([^"]+)"/g)) { assert.doesNotMatch(m[1], /^https?:/); assert.ok(fs.existsSync(path.join(root, m[1]))); }
  assert.doesNotMatch(html, /type="module"/);
  for (const file of ['src/app.js', 'src/ai.js']) assert.doesNotMatch(fs.readFileSync(path.join(root, file), 'utf8'), /localStorage|sessionStorage|document\.cookie/);
});
test('UMD 浏览器分支初始化并展示默认模拟数据', () => { const { elements: e, context } = app(); assert.ok(context.PhysCalc && context.PhysExperiments); assert.match(e.results.innerHTML, /模拟数据/); assert.match(e['data-status'].textContent, /疑似异常 1 点/); assert.equal(e['export-html'].disabled, false); assert.equal(e['data-table'].querySelector('tbody').rows.length, 18); });
test('已标注的模拟数据不能取消来源标记', async () => { const { elements: e, downloads } = app(); e.simulated.checked = false; await e.simulated.emit('change'); assert.equal(e.simulated.checked, true); await e['export-html'].emit('click'); assert.match(downloads[0][0], /模拟数据：用于功能演示/); });
test('界面事件：剔除异常、HTML导出、恢复全部、切换三个实验', async () => {
  const { elements: e, tabs, downloads } = app();
  await e['exclude-outliers'].emit('click'); assert.match(e.results.innerHTML, /9\.803 ± 0\.005/); assert.match(e['data-status'].textContent, /已剔除 1 点/);
  await e['export-html'].emit('click'); assert.equal(downloads[0][1], 'html'); assert.match(downloads[0][0], /已剔除/); assert.match(downloads[0][0], /模拟数据：用于功能演示/);
  await e['restore-all'].emit('click'); assert.match(e['data-status'].textContent, /已剔除 0 点/);
  await tabs[1].emit('click'); assert.match(e.results.innerHTML, /伏安法/); await e['exclude-outliers'].emit('click'); assert.match(e.results.innerHTML, /99\.93 ± 0\.04/);
  await tabs[2].emit('click'); assert.match(e.results.innerHTML, /杨氏模量/); await e['exclude-outliers'].emit('click'); assert.match(e.results.innerHTML, /200000000000 ± 600000000/);
});
test('界面事件：参数实时重算、表格非法输入阻止导出、修复后恢复', async () => {
  const { elements: e } = app();
  await e.parameters.emit('input', { dataset: { param: 'reference' }, value: '20' }); assert.match(e.results.innerHTML, /公认值 20/);
  await e['data-table'].emit('input', { dataset: { row: '0', field: 'y' }, value: '' }); assert.equal(e.error.hidden, false); assert.equal(e['export-doc'].disabled, true);
  await e['data-table'].emit('input', { dataset: { row: '0', field: 'y' }, value: '1.187' }); assert.equal(e.error.hidden, true); assert.equal(e['export-doc'].disabled, false);
});
test('界面事件：单摆长切换、图表点击与复选框剔除/恢复、Word导出', async () => {
  const { elements: e, downloads } = app(); await e.parameters.emit('input', { dataset: { param: 'mode' }, value: 'single' }); assert.match(e['data-status'].textContent, /Grubbs/);
  await e['exclude-outliers'].emit('click'); assert.match(e.results.innerHTML, /9\.801 ± 0\.015/);
  await e.chart.emit('click', { closest: () => ({ dataset: { index: '5' } }) }); assert.match(e['data-status'].textContent, /已剔除 0 点/);
  await e['data-table'].emit('change', { dataset: { keep: '5' }, checked: false }); assert.match(e['data-status'].textContent, /已剔除 1 点/);
  await e['export-doc'].emit('click'); assert.equal(downloads[0][1], 'doc'); assert.match(downloads[0][0], /9\.801 ± 0\.015/);
});
test('界面事件：上传CSV、xlsx提示和失败时保留原数据', async () => {
  const { elements: e } = app();
  await e['file-input'].emit('change', { files: [{ name: 'test.csv', size: 100, text: async () => 'L(m),T(s)\n0.5,1.42\n0.6,1.55\n0.7,1.68\n0.8,1.80' }] });
  assert.match(e['import-status'].textContent, /成功导入 4 行/); assert.equal(e.simulated.checked, false); assert.equal(e['data-table'].querySelector('tbody').rows.length, 4);
  await e['file-input'].emit('change', { files: [{ name: 'test.xlsx', size: 100 }] }); assert.match(e['import-status'].textContent, /请另存为 CSV/); assert.equal(e['data-table'].querySelector('tbody').rows.length, 4);
});
test('界面事件：AI调用失败保留规则文本，导出不包含密钥', async () => {
  const { elements: e, downloads } = app(); const original = e.explanation.textContent;
  e['api-base'].value = 'https://example.test/v1'; e['api-model'].value = 'test'; e['api-key'].value = 'private-secret-do-not-export';
  await e['ask-ai'].emit('click'); assert.match(e['api-status'].textContent, /请求失败/); assert.equal(e.explanation.textContent, original); assert.equal(e['ask-ai'].disabled, false);
  await e['export-html'].emit('click'); assert.doesNotMatch(downloads[0][0], /private-secret-do-not-export/);
});
