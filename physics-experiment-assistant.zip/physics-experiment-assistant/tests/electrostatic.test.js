'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), cp = require('node:child_process'), vm = require('node:vm');
const E = require('../src/engine.js'), tpl = require('../templates/electrostatic_field.js');
const PY = require('./templates_work_ref/python_reference_electrostatic.json');
const BEFORE = require('./templates_work_ref/before_electrostatic.json');
const baseline = require('./templates_work_ref/legacy_before_electrostatic.json');
const { generateSample } = require('../tools/gen_electrostatic_data.js');
const root = path.join(__dirname, '..'), read = file => fs.readFileSync(path.join(root, file), 'utf8');
const close = (a, b, tolerance = 1e-3) => assert.ok(Math.abs(a - b) <= tolerance * Math.max(Math.abs(b), 1e-20), a + ' vs ' + b);
const rows = () => E.parseCSV(tpl.sampleCsv, tpl).rows;
const kept = () => E.autoExclude(tpl, rows()).rows;
const calc = (options = {}, all = false) => E.process(tpl, all ? rows() : kept(), options);
const item = (r, key) => r.items.find(i => i.key === key).value;

test('静电场：接口、分类、无量纲参考值、浏览器注册与 verified', () => {
  assert.deepEqual(E.validateTemplate(tpl), []); assert.equal(tpl.id, 'electrostatic_field');
  assert.equal(tpl.method, 'linear_fit'); assert.equal(tpl.category, '电磁学'); assert.equal(tpl.verified, true);
  assert.equal(tpl.result.key, 'lnRatio'); assert.equal(tpl.accepted.value, Math.log(5));
  assert.match(tpl.accepted.note, /按假设仪器参数 Ra=10.0 mm、Rb=50.0 mm 计算，不是普适常数/);
  assert.deepEqual(tpl.result.uncertaintyInputs, ['fit.slope', 'params.Ua']);
  assert.match(read('index.html'), /codearts_calc\.js"><\/script>\s*<script src="src\/electrostatic_codearts\.js"><\/script>/);
  assert.match(read('index.html'), /oscilloscope\.js"><\/script>\s*<script src="templates\/electrostatic_field\.js"><\/script>/);
  assert.equal(typeof tpl.result.core, 'function');
});

test('静电场：固定种子 CSV 与内嵌副本逐字节一致，噪声和异常量满足约定', () => {
  const csv = read('sample_data/electrostatic_field_模拟数据.csv');
  assert.equal(generateSample(), csv); assert.equal(tpl.sampleCsv, csv);
  assert.match(csv.split('\n')[0], /模拟数据（非真实测量）.*20261117.*Ua=5.00 V.*Ra=10 mm.*Rb=50 mm/);
  const p = E.parseCSV(csv, tpl); assert.ok(p.ok); assert.ok(p.simulated); assert.equal(p.rows.length, 9);
  assert.deepEqual(p.rows.map(r => r.values.r), [12,16,20,24,28,32,36,40,44]);
  p.rows.forEach(({ values: r }, i) => assert.ok(Math.abs(r.U - 5 * Math.log(50 / r.r) / Math.log(5) - (i === 5 ? 0.10 : 0)) <= 0.0100005));
});

test('静电场：mm 转 m 后取自然对数，U 保持 V', () => {
  close(tpl.transform.x({r: 20}), Math.log(0.020), 1e-12);
  assert.equal(tpl.transform.y({U: 2.5}), 2.5);
  assert.equal(tpl.inputs[0].instrumentError, 0); assert.equal(tpl.inputs[1].instrumentError, 0.005);
});

test('静电场：单轮格拉布斯检出第六行，剔除与恢复完整重算', () => {
  const a = E.autoExclude(tpl, rows()); assert.deepEqual(a.outlier.indices, [5]);
  close(a.outlier.statistic, PY.statistic, 1e-10); assert.equal(a.outlier.critical, PY.critical_project);
  const before = calc({}, true), after = E.process(tpl, a.rows);
  assert.equal(before.included, 9); assert.equal(after.included, 8); assert.notEqual(before.value, after.value);
  assert.equal(after.comparison.verdict, '一致'); assert.ok(Math.abs(after.value-tpl.accepted.value)<=2*after.uncertainty);
  assert.ok(Math.abs(item(after,'fit.slope')-PY.theoreticalSlope)<0.01);
  a.rows.forEach(r=>{r.excluded=false;}); assert.equal(E.process(tpl,a.rows).value,before.value);
});

test('静电场：剔除前后斜率、截距、相关系数与各不确定度逐项对照 Python（相对差<0.1%）', () => {
  assert.deepEqual(BEFORE, PY.before);
  for(const [all, ref] of [[true,PY.before],[false,PY.after]]) {
    const r=calc({},all);
    for(const key of ['slope','intercept','r','uAslope','uBslope','uslope','uintercept']) close(item(r,'fit.'+key),ref[key]);
    close(r.value,ref.lnRatio); close(r.uncertainty,ref.uncertainty); close(r.genericUncertainty,ref.uncertainty);
    close(r.comparison.relativeErrorPercent,ref.relativeErrorPercent);
    const residuals=r.chart.points.filter(p=>!p.excluded).map(p=>p.y-r.chart.line.intercept-r.chart.line.slope*p.x);
    residuals.forEach((v,i)=>close(v,ref.residuals[i],1e-8));
  }
});

test('静电场：码道核心为权威结果，与通用引擎值及合成不确定度一致', () => {
  for(const all of [false,true]) {
    const r=calc({},all); assert.ok(r.core); assert.equal(r.value,r.core.value);
    close(r.value,r.genericValue,1e-10); close(r.uncertainty,r.genericUncertainty,1e-5);
    assert.ok(r.items.find(i=>i.key==='result').steps.some(s=>s.title==='交叉校验' && s.result==='一致'));
  }
});

test('静电场：Ua 参数覆盖为 6 V 后重算，拟合不变且主结果比例正确', () => {
  const a=calc(),b=calc({params:{Ua:6}});
  assert.equal(item(a,'fit.slope'),item(b,'fit.slope')); close(b.value,a.value*1.2,1e-12);
  close(b.value,PY.Ua6.lnRatio); close(b.uncertainty,PY.Ua6.uncertainty);
});

test('静电场：增大 Ua 仪器误差只增大不确定度，覆盖值能传入码道适配', () => {
  const a=calc(),b=calc({params:{'ΔUa':0.1}});
  assert.equal(a.value,b.value); assert.ok(b.uncertainty>a.uncertainty);
  close(b.uncertainty,b.genericUncertainty,1e-5);
});

test('静电场：斜率与 Ua 偏导方向正确，B 类分量没有重复合成', () => {
  const r=calc(),b=item(r,'fit.slope'),h=1e-5;
  const db=(tpl.result.compute({params:{Ua:5},fit:{slope:b+h}})-tpl.result.compute({params:{Ua:5},fit:{slope:b-h}}))/(2*h);
  const du=(tpl.result.compute({params:{Ua:5+h},fit:{slope:b}})-tpl.result.compute({params:{Ua:5-h},fit:{slope:b}}))/(2*h);
  assert.ok(db>0); assert.ok(du>0); close(db,5/b**2,1e-8); close(du,-1/b,1e-8);
  const analytic=Math.hypot(5/b**2*item(r,'fit.uslope'),(-1/b)*0.01/Math.sqrt(3)); close(r.uncertainty,analytic,1e-5);
});

test('静电场：增大 U 误差增加斜率 B 类和主结果不确定度', () => {
  const a=calc(),b=calc({deltas:{U:0.05}});
  assert.equal(a.value,b.value); close(item(b,'fit.uBslope'),item(a,'fit.uBslope')*10,1e-10);
  assert.ok(b.uncertainty>a.uncertainty); close(b.uncertainty,b.genericUncertainty,1e-5);
});

test('静电场：Ra/Rb 及设定半径误差不进入主结果传递', () => {
  const a=calc(),b=calc({params:{Ra:11,Rb:51},deltas:{r:10}});
  assert.equal(a.value,b.value); assert.equal(a.uncertainty,b.uncertainty);
  const steps=a.items.find(i=>i.key==='result.u').steps;
  assert.ok(!steps.some(s=>/∂f\/∂params\.(Ra|Rb)/.test(s.formula)));
});

test('静电场：U 非数字在 CSV 和直接数据路径均报中文错误', () => {
  const p=E.parseCSV('r,U\n12,1\n16,不是数字\n20,2\n',tpl);
  assert.equal(p.ok,false); assert.match(p.errors.join('；'),/不是有效数字/);
  const data=rows(); data[1].values.U='坏值'; assert.throws(()=>E.process(tpl,data),/有限数|数字/);
});

test('静电场：r≤0 的对数无定义时中文报错', () => {
  for(const radius of [0,-1]) {const data=rows();data[0].values.r=radius;assert.throws(()=>E.process(tpl,data),/有限数|零值|负值|正/);}
});

test('静电场：行数不足拒绝计算，不返回伪结果', () => {
  assert.equal(E.parseCSV('r,U\n12,4\n16,3\n',tpl).ok,false);
  assert.throws(()=>E.process(tpl,rows().slice(0,2)),/至少需要 3/);
});

test('静电场：浏览器 UMD 核心存在，所有模板依次加载不冲突', () => {
  const ctx={console};ctx.globalThis=ctx;vm.createContext(ctx);
  vm.runInContext(read('src/electrostatic_codearts.js'),ctx);
  assert.ok(ctx.ElectrostaticCore);
  const scripts=read('index.html').match(/templates\/[\w-]+\.js/g);
  scripts.forEach(file=>vm.runInContext(read(file),ctx,{filename:file}));
  assert.equal(ctx.EXP_TEMPLATES.filter(t=>t.id===tpl.id).length,1);
});

test('静电场接入后：原有26个实验的52组结果与不确定度严格不变', () => {
  const ids=read('index.html').match(/templates\/[\w-]+\.js/g).map(s=>s.slice(10,-3));
  assert.equal(Object.keys(baseline).length,26); assert.equal(ids.length,27);
  const samples=require('../sample_data/samples.js');
  for(const [id,cases] of Object.entries(baseline)) {
    assert.ok(ids.includes(id)); const t=require('../templates/'+id+'.js'), p=E.parseCSV(E.sampleText(t,samples),t);
    for(const [key,options] of [['default',{}],['withT',{useT:true,coverage:0.95}]]) {
      const r=E.process(t,E.autoExclude(t,p.rows).rows,options);
      assert.equal(r.value,cases[key].value,id); assert.equal(r.uncertainty,cases[key].uncertainty,id);
    }
  }
});

test('静电场 run_all：仅新增一行，原有26行及表头脚注逐字节相同', () => {
  const actual=cp.execFileSync(process.execPath,['tools/run_all.js'],{cwd:root}).toString('utf8');
  const added=actual.split('\n').filter(line=>line.startsWith(tpl.name+' |'));
  assert.equal(added.length,1); assert.match(added[0],/\| 一致 \| 6（已剔除） \| 8\/9$/);
  assert.deepEqual(Buffer.from(actual.replace(added[0]+'\n','')),fs.readFileSync(path.join(root,'tools/run_all_before_electrostatic.txt')));
});
