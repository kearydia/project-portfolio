'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
const E = require('../src/engine.js'), tpl = require('../templates/viscosity_falling_ball.js');
const PY = require('./templates_work_ref/python_reference_v13.json');
const root = path.join(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const relative = (a, b) => Math.abs(a - b) / Math.abs(b);
const sample = () => {
  const parsed = E.parseCSV(tpl.sampleCsv, tpl);
  assert.ok(parsed.ok, parsed.errors.join(';'));
  return E.autoExclude(tpl, parsed.rows);
};
const calc = (params = {}) => E.process(tpl, sample().rows, { params });
const derivativeSteps = r => r.items.find(i => i.key === 'result.u').steps.filter(s => s.formula.startsWith('∂f/∂'));

test('落球法：模板接口、分类与 index.html 注册', () => {
  assert.deepEqual(E.validateTemplate(tpl), []);
  assert.equal(tpl.category, '力学'); assert.equal(tpl.method, 'direct'); assert.equal(tpl.verified, true);
  assert.match(read('index.html'), /<script src="templates\/viscosity_falling_ball\.js"><\/script>/);
  assert.match(tpl.accepted.note, /模拟数据所用的名义参考值（蓖麻油粘度随温度变化很大）/);
});

test('落球法：固定种子 CSV、模板内嵌副本、生成器和 truth 一致', () => {
  // Windows Git 检出可能采用 CRLF；比较内容时统一换行，不改变数据。
  const csv = read('sample_data/templates_work/viscosity_falling_ball_模拟数据.csv').replace(/\r\n/g, '\n');
  assert.equal(csv, tpl.sampleCsv);
  assert.equal(require('../tools/gen_viscosity_data.js').generateSample(), csv);
  assert.match(csv.split('\n')[0], /模拟数据（非真实测量）.*20261113.*生成真值.*噪声/);
  assert.equal(require('../sample_data/templates_work/truth.json')[tpl.id], 0.986);
});

for (const on of [0, 1]) test('落球法手算：修正' + (on ? '全开' : '全关') + '，与 Python 解析偏导一致', () => {
  // t=[10,10,10] s，d=[2,2,2] mm，L=0.1 m；rho=7800，rho0=960，g=9.8。
  // 全关 η=1.4896，u=0.00964590137321175；全开除以 1.12×1.0132，
  // η=1.31267272009475，u=0.00867783905706775 Pa·s（Python 独立计算）。
  const rows = [0, 1, 2].map(i => ({ values: { t: 10, d: 2, L: i === 0 ? 0.1 : '' }, excluded: false }));
  const r = E.process(tpl, rows, { params: { wallCorr: on, bottomCorr: on } });
  assert.ok(Math.abs(r.value - (on ? 1.4896 / 1.12 / 1.0132 : 1.4896)) < 1e-14);
  const ref = PY[on ? 'hand_on' : 'hand_off'];
  assert.ok(relative(r.value, ref.value) < 1e-12);
  assert.ok(relative(r.uncertainty, ref.u) < 1e-8);
});

for (const on of [0, 1]) test('落球法模拟数据：修正' + (on ? '全开' : '全关') + '，JS 与 Python 结果<0.1%、不确定度<1%', () => {
  const r = calc({ wallCorr: on, bottomCorr: on }), ref = PY[on ? 'sample_on' : 'sample_off'];
  assert.ok(relative(r.value, ref.value) < 1e-3);
  assert.ok(relative(r.uncertainty, ref.u) < 1e-2);
  assert.equal(r.comparison.verdict, ref.verdict);
  assert.equal(r.comparison.verdict, on ? '一致' : '偏差显著');
  assert.equal(r.included, PY.included);
  // 对每个偏导独立核对；JS d 用 mm，Python 用 m，故解析导数除以 1000。
  for (const s of derivativeSteps(r)) {
    const key = s.formula.split('.').pop();
    const expected = ref.partials_SI[key] / (key === 'd' ? 1000 : 1);
    assert.ok(relative(s.result, expected) < 1e-7, key);
  }
});

test('落球法：关闭修正与基本公式严格相等，D/H 的值和误差不影响结果', () => {
  const r = calc(), value = key => r.items.find(i => i.key === key).value;
  const base = (7800 - 960) * 9.8 * (value('mean.d') / 1000) ** 2 * value('mean.t') / (18 * value('mean.L'));
  assert.equal(r.value, base);
  for (const params of [{ D: 0.1, H: 0.9, ΔD: 100, ΔH: 100 }, { D: '无效', H: 0, ΔD: -1, ΔH: '无效' }]) {
    const changed = calc(params);
    assert.equal(changed.value, r.value); assert.equal(changed.uncertainty, r.uncertainty);
  }
  assert.ok(derivativeSteps(r).every(s => !/params\.(D|H|wallCorr|bottomCorr)$/.test(s.formula)));
});

test('落球法：两个开关可独立启用，仅相应长度参与传递，全开结果更小', () => {
  const off = calc(), d = off.items.find(i => i.key === 'mean.d').value / 1000;
  const wall = calc({ wallCorr: 1 }), bottom = calc({ bottomCorr: 1 }), both = calc({ wallCorr: 1, bottomCorr: 1 });
  assert.ok(Math.abs(wall.value - off.value / (1 + 2.4 * d / 0.04)) < 1e-14);
  assert.ok(Math.abs(bottom.value - off.value / (1 + 3.3 * d / 0.5)) < 1e-14);
  assert.ok(both.value < wall.value && both.value < bottom.value && wall.value < off.value && bottom.value < off.value);
  assert.ok(derivativeSteps(wall).some(s => s.formula.endsWith('params.D')));
  assert.ok(derivativeSteps(wall).every(s => !s.formula.endsWith('params.H')));
  assert.ok(derivativeSteps(bottom).some(s => s.formula.endsWith('params.H')));
  assert.ok(derivativeSteps(bottom).every(s => !s.formula.endsWith('params.D')));
});

test('落球法：开关转换为 0/1，强制 u=0，即使误列在传递列表也不求偏导', () => {
  const modified = { ...tpl, params: tpl.params.map(p => p.type === 'switch' ? { ...p, uncertainty: 100, instrumentError: 100 } : p),
    result: { ...tpl.result, uncertaintyInputs: [...tpl.result.uncertaintyInputs, 'params.wallCorr', 'params.bottomCorr'] } };
  for (const raw of [1, '1', true]) {
    const p = E.paramValues(modified, { wallCorr: raw, bottomCorr: false });
    assert.equal(p.p.wallCorr, 1); assert.equal(p.p.bottomCorr, 0);
    assert.equal(p.u.wallCorr, 0); assert.equal(p.u.bottomCorr, 0);
  }
  assert.equal(E.paramValues(tpl, { wallCorr: '0' }).p.wallCorr, 0);
  assert.throws(() => E.paramValues(tpl, { wallCorr: 2 }), /0 或 1/);
  const r = E.process(modified, sample().rows, { params: { wallCorr: 1, bottomCorr: 1 } });
  assert.equal(r.uncertainty, calc({ wallCorr: 1, bottomCorr: 1 }).uncertainty);
  assert.equal(derivativeSteps(r).length, 8);
});

test('落球法：开启后 D/H 的仪器误差参与不确定度，关闭后不参与', () => {
  for (const [flag, key] of [['wallCorr', 'D'], ['bottomCorr', 'H']]) {
    const r = calc({ [flag]: 1 }), zero = calc({ [flag]: 1, ['Δ' + key]: 0 });
    assert.equal(r.value, zero.value); assert.ok(r.uncertainty > zero.uncertainty);
    assert.equal(calc({ ['Δ' + key]: 0 }).uncertainty, calc().uncertainty);
    assert.throws(() => calc({ [flag]: 1, ['Δ' + key]: -1 }), /仪器误差必须是非负数/);
  }
});

test('落球法：格拉布斯检出第 6 行，整行剔除并可恢复', () => {
  const a = sample();
  assert.deepEqual(a.outlier.indices, [5]); assert.deepEqual(a.outlier.indices, PY.excluded_indices);
  assert.ok(a.outlier.statistic > a.outlier.critical);
  assert.equal(a.rows.filter(r => r.excluded).length, 1);
  const restored = E.process(tpl, a.rows.map(r => ({ ...r, excluded: false })));
  assert.ok(restored.value > calc().value); assert.equal(restored.included, 12);
});

test('落球法：直接测量 A/B/合成步骤、修正因子与逐项偏导可展开', () => {
  const r = calc({ wallCorr: 1, bottomCorr: 1 });
  for (const k of ['t', 'd']) for (const type of ['uA', 'uB', 'uC']) {
    const item = r.items.find(i => i.key === type + '.' + k);
    assert.ok(item.steps.length > 0); assert.ok(item.value > 0);
  }
  assert.ok(r.items.find(i => i.key === 'uB.L').value > 0);
  const steps = r.items.find(i => i.key === 'result').steps;
  assert.ok(steps.some(s => s.formula.includes('u_A(L)=0') && s.formula.includes('u_C(L)=u_B(L)')));
  for (const title of ['管壁修正因子', '管底修正因子']) assert.ok(steps.some(s => s.title === title && s.result > 1));
  assert.equal(derivativeSteps(r).length, 8); assert.equal(derivativeSteps(calc()).length, 6);
});

test('落球法：非法物理输入报中文错误，未启用的长度不作计算校验', () => {
  assert.throws(() => calc({ wallCorr: 1, D: 0.001 }), /量筒内径/);
  assert.throws(() => calc({ bottomCorr: 1, H: 0 }), /液柱高度/);
  assert.throws(() => calc({ rho: 900 }), /小球密度必须大于液体密度/);
  const bad = sample().rows.map(r => ({ ...r, values: { ...r.values, d: 0 } }));
  assert.throws(() => E.process(tpl, bad), /直径/);
  assert.doesNotThrow(() => calc({ D: 0, H: 0 }));
});

// 纯 Node DOM/event doubles；不启动浏览器，不使用 Computer Use。
function ui() {
  class Element {
    constructor() { this.handlers = {}; this.innerHTML = ''; this.textContent = ''; this.value = ''; this.checked = false; this.dataset = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
    addEventListener(name, fn) { (this.handlers[name] ||= []).push(fn); }
    emit(name, target) { for (const fn of this.handlers[name] || []) fn({ target, preventDefault() {} }); }
  }
  const html = read('index.html').replace(/<!--[\s\S]*?-->/g, ''), elements = {};
  for (const m of html.matchAll(/id="([^"]+)"/g)) elements[m[1]] = new Element();
  const document = new Element(); document.getElementById = id => elements[id];
  const context = { console, document, location: { hash: '#tpl=viscosity_falling_ball&open=1' } };
  context.window = context; context.globalThis = context; vm.createContext(context);
  for (const m of html.matchAll(/<script src="([^"]+)"/g)) vm.runInContext(read(m[1]), context, { filename: m[1] });
  return { elements, document };
}

test('落球法 UI：默认未勾选、说明公式、勾选/取消实时重算，切换模板重置', () => {
  const { elements: e, document } = ui();
  const check = (key, checked) => e.params.emit('change', { dataset: { switch: key }, checked });
  const markup = e.params.innerHTML;
  assert.match(markup, /type="checkbox" data-switch="wallCorr">/);
  assert.match(markup, /type="checkbox" data-switch="bottomCorr">/);
  assert.equal((markup.match(/只有勾选后才改变结果/g) || []).length, 2);
  assert.match(markup, /1 \+ 2.4 d\/D/); assert.match(markup, /1 \+ 3.3 d\/\(2H\)/);
  assert.match(e.badge.innerHTML, /偏差显著/);
  const original = e['main-value'].innerHTML;
  check('wallCorr', true); assert.notEqual(e['main-value'].innerHTML, original);
  check('bottomCorr', true); assert.match(e.badge.innerHTML, /<b>一致<\/b>/);
  assert.match(e.steps.innerHTML, /管壁修正因子/); assert.match(e.steps.innerHTML, /管底修正因子/);
  check('wallCorr', false); check('bottomCorr', false); assert.equal(e['main-value'].innerHTML, original);
  const select = id => { const button = { dataset: { id }, matches: () => false }; document.emit('click', { closest: () => button }); };
  check('wallCorr', true); select('string_vibration');
  assert.doesNotMatch(e.params.innerHTML, /data-switch/);
  select('viscosity_falling_ball'); assert.equal(e.params.innerHTML, markup);
  assert.equal(e['main-value'].innerHTML, original);
});
