# 实际测试日志

日期：2026-10-29，Asia/Shanghai。阶段 0 技术可行性验收通过。只记录已执行结果，不代表完整游戏验收通过。

## 初始检查

- 当前目录 D:/AI-Agent/codex/projects/golden-hour-racer 为空，无既有项目或用户文件需要迁移。
- Node v24.22.0、npm 11.19.1；Windows PowerShell；安装来自 npm。
- GraphFlow：要求的旧工具名不可用；gf_read 成功响应 No symbols matched query，没有宣称旧接口调用或索引成功。
- Babylon 9.32.1、Havok 1.3.14、Vite 8.3.5、TypeScript 7.0.2、tsx 4.23.15 已精确锁定。

## 修复记录

1. 首轮构建：车顶材质基类/派生类与 Node Buffer/ArrayBuffer 两处类型错误；已修复。
2. 首轮物理：重力、落地、护墙通过，车辆不动。接地射线起点低于地面；改为车体中心下探并忽略自身刚体。
3. 第二轮物理：车辆加速仅 13.85km/h。设置惯量时覆盖质量属性；改为显式同时设置 1150kg 并新增质量回归断言。修复后普通加速 75.37km/h，氮气 122.10km/h。
4. 优化模块导入后，缺少 Scene 物理注册导致测试失败；显式注册 joinedPhysicsEngineComponent 后修复。
5. 浏览器视觉检查发现光照过曝、静态护墙旋转不匹配；降低照明并在创建物理体之前设置四元数旋转，最终浏览器复测已确认正常。
6. npm ci 首次因运行中的 Vite 预览锁定 Windows 原生 rolldown 文件而 EPERM。停止本次预览后重跑安装成功；未删除其他目录或结束无关进程。以后重装依赖前先停 dev/preview。
7. 补充：速度表改用水平速度，避免落地前垂直自由落体显示车速；复位取消自动驱动自检后可重新启动自检。最终代码重新构建、测试并在浏览器加载。

## 最终命令结果

| 命令 | 结果 |
|---|---|
| npm ci | 退出 0，新增 25 个包；存在 esbuild install-scripts 策略提示，但不影响本轮构建/测试 |
| npm run build | 退出 0，TypeScript 检查通过，Vite 生产构建成功；最终主 JS 1,229.93 kB / gzip 300.84 kB |
| npm test | 退出 0；12 个测试计数全部通过（1 个父测试 + 11 个物理断言），0 失败 |

## 最终真实物理结果

| 检查 | 实测 |
|---|---|
| 插件 | Havok，Physics V2 |
| 重力 | 5m 初始，0.5s 后 3.7648m |
| 落地 | 4s 后中心 y=0.5000m，静止 |
| 护墙 | 箱体最大 z=11.0038m，没有穿过墙 |
| 质量 | 1150kg |
| 普通驱动 | 3s 后 75.37km/h |
| 制动 | 2s 后 0.000km/h |
| 氮气 | 3s 后 122.10km/h，余量 0.310 |
| 转向 | 四元数 y=0.3837，朝向发生改变 |
| 空中控制 | 水平位移 0，氮气保持 1 |
| 数值 | 位姿和速度均有限 |

## 最终浏览器与 HTTP 验证

- 对 Vite **生产 dist 构建**进行检查，地址 http://localhost:4173/，不是仅检查源文件。
- 页面和 WASM 均 HTTP 200，WASM MIME 为 application/wasm，大小 2,094,563 字节；许可证文件 2 份随产物输出。校验值保存在 docs/evidence/http.json。
- Codex 内置浏览器：Babylon 9.32.1，WebGL 2，WASM 初始化观测 30–36ms。浏览器重复运行同一组真实物理检查 11/11 通过。
- 最终真实试车场“3 秒驱动自检”：位移 24.75m、结束速度 66.0km/h，通过。该测试含发车下落时间，不能与纯驱动力测试的加速时长直接等同。
- 点击暂停显示“已暂停”，点击继续返回驾驶。复位可重建车辆并回到发车点。
- 844×390 横屏视口：canvas 和页面布局均为 844×390，scrollWidth=844，无横向溢出，6 个驾驶触控按钮可见。按住油门 1.5s 观察到 36km/h，刹车后 0km/h。
- 键盘 W 驱动有响应；复位后按住方向键 ↑ 1.6s 观察到 39km/h。键位映射已实现，但未对每一组组合键做完整回归。
- 最终应用控制台 error/warn 记录为空，见 browser-errors.json。
- 桌面截图与横屏截图已保存。横屏检查是桌面浏览器视口模拟，不能等同 Android/iPhone 真机、多指触控或移动性能测试。桌面瞬时 FPS 不作为手机性能承诺。

## 未验证 / 未实现

- 真机、完整多指与焦点取消矩阵、旧浏览器启动失败、30/60/120 Hz 一致性压力测试尚未执行。
- 当前稳定辅助锁定横滚/俯仰，尚无四轮悬挂、真实轮胎力或变速箱。
- 正式专业赛道、5 AI、8 关生涯、5 车/升级挑战、PB 幽灵、3D 车库、可编辑触控、音量/画质、存档和离线尚未实现。
- 没有公开部署或同学分享链接；本轮仅本地预览，测试服务器完成验证后停止。运行 README 中命令即可重新启动。
- GraphFlow 旧版 context/plan/index 不可用；已回读新建类和测试函数并成功获得调用关系，未声称显式全量索引。

## 证据文件

- docs/evidence/build.txt：实际 TypeScript 检查和 Vite 生产构建输出。
- docs/evidence/physics-tests.txt：实际 Node + Havok WASM 测试输出。
- docs/evidence/install.txt：重装锁定依赖成功日志。
- docs/evidence/http.json：HTTP/WASM 类型、大小、哈希。
- docs/evidence/browser-checks.txt、browser-errors.json：实际浏览器检查内容和错误日志。
- docs/evidence/prototype.jpg、desktop-checks.jpg、mobile-landscape.jpg：实际页面截图。

## 阶段 1 实测记录（2026-10-29）

依赖未改变且可用，未运行 npm ci。npm run build 成功；npm test 最终 14/14 通过，0 失败。新增 50 次 session 取消/销毁以及 20 次真实 Babylon 车库场景释放测试；原 11 项物理断言继续通过。输出保存 stage1-build.txt、stage1-tests.txt。浏览器实测六入口菜单、车库进入/返回和生产版试驾加载。网络失败注入、真机和长期内存性能未测。

GraphFlow 仍仅有 gf_* 接口，以 gf_read 获取上下文；没有声称执行不存在的 context/plan/index。项目内没有独立技术架构文档和 AGENTS.md，已读取 GAME_DESIGN 内架构段落；本次新增 ARCHITECTURE.md。保留原物理控制器，没有更换引擎。
最终浏览器试驾自检通过：3 秒行驶 24.75m、66.0km/h；试驾返回菜单成功。截图 stage1-menu.jpg。

## 阶段 2 实测及修复记录（2026-10-29）

接续已有修改，没有重建项目。当前文件夹没有 .git，git status 返回 not a git repository，不能声称工作树干净或列出 Git 未提交差异。依赖输入未变化，未运行 npm ci。GraphFlow 通过可用 gf_read 读取车辆/入口上下文；context/plan/index 仍未提供。

### 修复过程中真实失败

1. 初次引入角冲量后，原偏航断言失败（四元数 y≈0.0002）。该方案未保留；最终采用有角加速度上限的渐进偏航控制，恢复原断言通过。不把它称作完整轮胎转向动力学。
2. 首次三圈测试仅到 0.245 圈卡在护墙。发现无渲染/同帧多步时方向世界矩阵滞后；每次物理控制前 computeWorldMatrix(true) 后三圈通过。没有降低三圈断言。
3. 首次鼠标暂停操作被诊断面板遮挡，位姿/时间仍变化；不是暂停已通过。调整诊断面板位置与暂停层级后，最终鼠标复测冻结通过；Esc 也通过。
4. 初始严重撞击检测只比较速度大小，斜撞减速但未计数；改为水平速度向量突变后，浏览器相同类型冲击记录 1 次严重撞击。自动墙碰撞与所有回归重跑通过。
5. 修复 CSS 追加时残留的字面 `n；移动返回按钮避免盖住氮气条。

### 最终命令

npm run build：退出 0。npm test：21 tests / 21 pass / 0 fail（原 14 项保留，新增 7 项驾驶行为测试）。证据 stage2-build.txt、stage2-tests.txt。新增测试覆盖倒车/悬挂/静止能量/回正、换挡/里程能量/越界阻力/侧滑、三个辅助独立差异、30/60/120 步进一致性、严重撞击恢复、高低速转向及角加速度限制、实际试车场三圈。

### 浏览器实测（生产 dist）

- Babylon 9.32.1 / WebGL2 / Havok 1.3.14，原 11 项物理断言通过。
- W 1.8s 观测约 50km/h；A 转向时约 45km/h；S 1.8s 停至 0。Q 约 32km/h、R 挡；Shift+W 约 77km/h、能量 61%；Space+A 后约 53km/h，观察侧滑与追尾相机响应。
- 浏览器自动沿实际试车环线连续 3.000 圈，用时 101.13 模拟秒；没有复位/传送，严重撞击 0。maxY=1.500m 包含初始发车下落；巡航 y 约 0.649m。此为单车验证程序，不是 AI 比赛。证据 stage2-three-laps.txt/jpg。后续碰撞判定和 CSS 修正后自动三圈回归仍通过，没有重复声称第二次浏览器三圈。
- 最终构建高速斜撞后：位置 47.434,0.653,57.508、速度 38.291km/h，严重撞击 1，恢复最终 0s；见 stage2-impact.txt。
- 最终鼠标暂停：模拟时间 11.883s，位置 44.942,0.649,61.986，速度 0，能量 0.6263；继续按油门 1.2s 后全部数值不变，继续后时间推进。另一次 Esc 暂停时速度 48.145km/h，持续按油门 1.5s，位姿/速度/计时也不变。见 stage2-pause.json、stage2-pause-final.json。
- 安全复位后 x=54,z=0，水平速度 0，能量仍为 0.6263。原车销毁并清空输入；不是原地补满氮气。见 stage2-reset.txt。
- 菜单→车库→菜单→重新试驾成功；最终应用 warn/error 捕获见 stage2-browser-errors.json。

### 评估与下一步

阶段 2 按当前单车街机试车场范围通过，剩余模型/平台限制详见 ACCEPTANCE 的阶段 2 表。手机真机、多指、长期 GPU/堆性能、坡道和极端高速未测。真实轮胎/传动系统未实现；不把简化辅助或锁定俯仰/横滚描述为真实赛车仿真。后续仍应先按真实设备实测调校，再规划其他阶段；本轮没有开发 AI、生涯或离线。

实际代码修改：src/physics/world.ts、src/input/controls.ts、src/main.ts、src/style.css；新增 tests/driving.test.ts；更新 README、GAME_DESIGN、ARCHITECTURE、ROADMAP、ACCEPTANCE、TEST_LOG，保存 docs/evidence/stage2-*。

## 阶段 3 实现及收尾（2026-10-30）

### 实际实现
新增 src/race/track.ts、scenery.ts、rules.ts、ai.ts、simulation.ts、view.ts；接入 main.ts、style.css。world.ts 仅增加初始 yaw 参数，provingGround.ts 增加可选车漆，保留已有控制器。新增 race-rules、race-ai、race-six 测试。原 21 项保留。赛道为原创程序几何，没有新外部车型或品牌资源。

先跑路线/检查点，再跑单 AI，再扩展六车。历史过程修复：超车线路摆动增加 3 秒保持；跟车停车不再被误判为需要倒车；初始复位测试错误期待拥挤网格可以复位，改为验证拒绝及清空后成功。首次较快验证玩家到终点时部分 AI 尚未冲线，不是卡死；慢速玩家场景专门验证所有 AI 先完赛也不强制结束玩家。

### 本次收尾发现与修复
原复位只排除当前 12m 内车辆，更远高速接近车辆可能立即撞上复位车。现加入当前水平速度在未来 1.5s 内的最近距离检查，8m 内拒绝，保留原 12m 静态间距。新增测试把其他车设置为受控初始场景（仅测试设置，不是 AI 传送）：40m/s 接近所有候选点时拒绝，旧车及能量不变；遍历 62 检查点，成功复位后真实物理推进 1s，车速低于 1km/h、高度 0.4–1m、无严重撞击恢复。拥挤发车网格已有拒绝回归仍通过。

### 最终执行命令与结果
- npm test：退出 0，36 tests / 36 pass / 0 fail / 0 skipped，约 15.98s。日志 docs/evidence/stage3-final-tests.txt。
- npm run build：退出 0，TypeScript/Vite 成功；主包约 1256.23kB、gzip 310.80kB，WASM 2094.56kB。日志 docs/evidence/stage3-final-build.txt。
- 没有执行 npm ci：依赖未变且当前安装可用。

六车慢速玩家场景：玩家 166.433s 完成两圈，AI 均先完成，全部无无效圈/脱困，最大离中心线 6.710m，最高 y 0.674m。默认自动验证网格每渲染帧推进 6 物理步也于 138.783s 完成，无无效圈。独立撞车测试最小车心纵距 4.206m，受撞车获得约 37.974km/h，证明实际碰撞传递动量。以上是 NullEngine+真实 WASM 自动测试，非浏览器 FPS；passes 字段为超车尝试次数，不是成功超车次数。

### 浏览器历史证据及未测试
前一轮通过 UI 打开生产构建菜单、六车验证入口、实际赛道和 HUD；倒计时暂停前后读取六车位置/速度/氮气与计时一致。IAB/Edge 运行观测约 1 FPS，受后台/窗口状态影响，不能当作正常性能。尝试检查前台窗口时，电脑操作工具因无法可靠识别当前浏览器网址而停止，未完成整场浏览器比赛。该尝试属于受阻，不是验收通过。此次收尾没有重试电脑操作，也不声称最终改动已浏览器复验。

未测试：浏览器完整手动/自动比赛、正常前台帧率、最终六车 UI 场景往返、手机真机/多指、长时间 GPU/堆增长、复杂人为堵路及大量随机碰撞。历史 1 FPS 只记录环境观测。最终可执行自动项目全部通过，没有未修复测试失败。阶段 3 开发收尾完成；阶段 4 未开始。

GraphFlow 使用可用 gf_read 获取上下文；旧 context/plan/index 未暴露，不声称执行。项目没有 .git，不能提供 Git 差异或声称工作树干净。

## 阶段 4（2026-10-30）

### 实际修改与边界
新增 src/career/data.ts、progress.ts、race.ts、ui.ts 和 docs/STAGE4_DESIGN.md；参数化原 physics/world.ts，不更换 Havok 或重新实现控制器。比赛 rules 增加逐圈有效性和圈速，simulation 接入固定网格、玩家/对手参数并保留复位配置；ai 加入决策难度和定时犹豫，view 一次性结算与重赛/车库按钮；main/garage/style 接入 3D 车库表单和关卡选择。新增 career.test.ts、career-physics.test.ts，旧 36 项没有删除或减弱。

文档旧五类升级初稿与用户冻结要求不同，采用用户要求的引擎/极速/制动/抓地/氮气。明确固定 19 项奖励，四车通过最佳圈挑战获得，不再绑定主线胜利；第2关调整1圈。所有参数均游戏调校，官方车型特征仅作设计方向，未下载真实车型资产。来源和固定表见 STAGE4_DESIGN。

### 分模块验证与真实失败
生涯数据/结算先跑 4 项通过，再接入物理和车库；中间原回归加生涯共 40/40 通过。升级物理行为逐级比较通过。首次零升级困难八关测试在第4关仅获第2，AI 148.758s、玩家149.225s；保留第一名断言，降低生涯 AI 目标配速（由 .82+.012×关卡索引改为 .78+.008×索引），未改变物理性能或关闭碰撞；重跑八关全部获胜。失败原始日志 stage4-physics-initial-failure.txt。
满配置复位测试首次错误假定赛道交通已清空，安全逻辑返回 null，导致断言失败；把该项改为明确摆放远离复位区的测试初始车辆，针对配置保留测试。没有绕过游戏安全检查，原拥挤发车/高速接近测试仍保留。失败记录 stage4-reset-test-initial-failure.txt。车库面板补设 pointer-events:auto，避免继承主 HUD 的穿透规则导致下拉框无法操作；此修正仅静态检查，未声称浏览器通过。

### 物理证据（程序驾驶，非真人或真机）
零升级 GH–01、困难、全部真实六车碰撞：第1–8关第一名用时约 73.20、73.50、137.90、147.45、211.72、221.92、221.55、287.00 秒，全部无无效圈/复位/严重撞击，符合1–2 / 2–4 / 4–6分钟目标。此为固定程序驾驶的可达性证明，不保证每位玩家轻松获胜。AI 未完成时按合法进度排名，未伪造 AI 冲线。
引擎 0/1/2/3 级3秒距离 34.954/36.433/37.878/39.326m；极速40秒速度 163.937/169.441/174.874/180.232km/h；25m/s 制动距离 12.390/11.700/11.081/10.523m；横向滑移测试位移 2.635/2.587/2.538/2.490m；3秒氮气后余量 .310/.384/.444/.493。五车原厂3秒加速距离分别34.954/33.582/35.656/39.425/37.653m，非实车加速成绩。

### 未测试和持久化边界
未进行阶段4浏览器 UI、完整比赛、正常前台FPS、手机/多指、长时GPU/内存及真实刷新持久化测试。历史后台约1FPS不用于本轮验收。自动测试验证 ProgressStore 读写/恢复、幂等、读坏档不覆盖和写失败保留内存；默认 localStorage 已接入，但真实浏览器刷新需要后续实测。持久化生涯获胜、奖励、难度、选择车、逐车升级和车漆；比赛过程/单场成绩不跨刷新保留。未实现备份、导入导出、迁移、跨设备同步、幽灵、离线或部署。

依赖未改，未执行 npm ci。GraphFlow 使用可用 gf_read 获取并刷新符号上下文，旧 graphflow_context/plan/index 未暴露；没有声称执行旧接口。工作目录没有 .git，不声称已有提交。

### 阶段 4 最终命令结果
- npm test：退出 0，47 tests / 47 pass / 0 fail / 0 skipped，102.993 秒；保留原 36 项，加 11 项生涯与物理测试。原始日志 docs/evidence/stage4-final-tests.txt。
- npm run build：退出 0，TypeScript 与 Vite 成功；最终 JS 主包约 1267.33kB、gzip316.36kB。原始日志 docs/evidence/stage4-final-build.txt。
- 五辆满级车均通过单圈有效圈测试；升级后复位保留 Handling 与氮气 .3。最终没有遗留的自动测试失败；本轮实现结束，后续平台验收限制仍保留，不开始阶段5/6。

## 阶段 5 实现与收尾（2026-10-30）

保留现有阶段 0–4；新增 src/timing/{laps,recording,library,simulation,ghost,setup,view}.ts、tests/timing.test.ts、tests/timing-physics.test.ts。main.ts/style.css 接入模式与 HUD；career/progress.ts 只泛化既有最小存储接口。此轮收尾新增主菜单计时诊断入口及 view 中可选 Driver，未重写车辆/比赛系统。

新增测试覆盖有效圈、越界/跳点/反向/复位、暂停与下圈恢复、20Hz 真实位姿边界、仅更快有效圈刷新 PB、同配置匹配、版本与数据损坏、独立配置与失败保存、慢速逆行、容量保护、真实 Havok 两圈与重赛、幽灵无刚体、30/60/120Hz 一致、四元数跨角度插值。

首次录制单测失败原因是合成夹具把绝对时间 100s 直接乘速度生成坐标 2000m，触发生产校验。修正夹具相对时间；生产校验未放宽。失败证据 stage5-recording-initial-failure.txt，随后通过 stage5-recording-tests.txt。分模块日志 stage5-laps-tests.txt、stage5-integration-tests.txt。

浏览器先前实测：计时蓝色车漆/ABS 选择刷新恢复；正式赛道启动、暂停冻结/继续、安全复位令本圈无效且采样清零；结束后回车库，生涯仍 0/8，生涯金色车漆不变。证据 stage5-settings-refresh.txt、stage5-browser-pause.json、stage5-timing-ui.png/txt。未把观察到的车辆移动记为自动键盘验证。

当前 Edge 后台约 1 FPS，正常实时诊断在约 1 秒圈内进度时仍未完成。为可重复的浏览器集成验收，诊断专用入口每渲染帧执行 120 个真实 1/60s Havok 步；每步仍通过同一车辆控制、检查点和录制链路。普通玩家模式仍按实际帧耗积累物理步，未改变。诊断记录使用无存储适配器的新库，不污染个人 PB。不将批处理的视觉跳帧算作顺滑回放/正常帧率验收。

浏览器补验：Edge 生产 dist 诊断模式实际完成两圈，分别 66.718s、66.401s，0 无效圈；第二圈使用首圈记录回放，幽灵显示 33 个渲染帧；最终最佳 1329 个录制点。见 stage5-browser-two-laps.txt/png。该证据是批量真实物理步的浏览器集成验证，未验证正常实时人工驾驶或顺滑度。

最终命令（收尾诊断代码落地后重新执行）：npm test 退出 0，62/62，通过原 47 项与新增 15 项，0 失败/跳过；npm run build 退出 0，TypeScript/Vite 成功，主 JS 1285.34kB / gzip321.89kB。原始输出 stage5-final-tests.txt、stage5-final-build.txt。依赖未改变，未重复 npm ci。

第二次浏览器诊断再次两圈有效、相同圈速；中途看到金色实车与浅蓝透明幽灵同场，暂停/继续后正常完成。截图工具在后台有滞后，stage5-browser-ghost.png 最终捕获的是结算画面，不把它作为运动连续性证据；回放中页面文本见 stage5-browser-ghost.txt。正常实时流畅度仍待测。

未通过：无遗留自动化失败。未测试：人工完整有效圈、正式存储 PB 刷新后再入回放、各浏览器/手机、多指、持续前台 FPS 和长期资源占用。没有完整存档备份/导入导出、离线缓存或部署。阶段 5 收尾停止于此。

## 阶段 6 实际记录（2026-10-30）

先调用可用 GraphFlow gf_read 阅读现有上下文；旧 context/plan/index 接口仍未暴露。新增 src/storage/vault.ts、src/settings/data.ts、audio.ts、ui.ts、tests/storage.test.ts、audio.test.ts；main.ts 接入主存储与菜单，timing/library.ts、simulation.ts 增加可选逐圈历史回调，style.css 加设置界面。未替换车辆控制器。npm install -D fake-indexeddb 成功；依赖锁文件已更新，没有重复 npm ci。

分模块首批 9 项通过，随后补充解锁/升级/车漆/PB轨迹持久化、音频独立总线，共11项通过。第一轮全量71/71通过，随后加入的2项与最终版本另跑全量。原62项未删除、未降低断言。

发现并处理：浏览器首次布局数值输入未落盘，增加明确“应用布局数值”；复验 x=6 刷新保留，x=99 拒绝。修正不同按钮大小时的矩形重叠计算。启动服务前浏览器 ERR_CONNECTION_REFUSED，启动 npm run preview -- --port 4173 --strictPort 后加载成功。这些尝试不记为成功结果。

浏览器在 Edge 本地产物验证：初始状态存档已初始化；总音量改.35、静音开启，刷新仍保留；布局明确应用、刷新保留及默认恢复通过。测试后音量/静音/布局恢复默认。原始页面证据 stage6-settings-refresh.txt，最终截图 stage6-settings.png。

存档破坏/中断/导入导出往返测试运行于 fake-indexeddb；轨迹持久化测试的样本是测试夹具，不是浏览器跑出的个人圈速。原62项中的真实Havok圈速测试保持。未测与未完成项见 ACCEPTANCE 阶段6，不用自动测试替代真机验收。

音频收尾追加只读 telemetry.ts，在试驾/比赛/计时场景读取真实横向速度及撞击恢复状态，触发自然侧滑与撞击提示；没有修改物理参数或施力逻辑。音频事件仍随渲染采样，极端后台节流可能漏报短事件，听感与平台自动播放限制仍待验收。

浏览器导出按钮已执行并显示“存档已导出”，未检查下载文件再经文件选择器导入，因此不记作浏览器全链路通过。浏览器捕获的 error/warn 日志为空。当前目录无 AGENTS.md、无 .git，不能报告 Git 工作树差异。

最终命令（音频遥测收尾后）：npm test 退出 0，73 tests / 73 pass / 0 fail / 0 skipped，68.615 秒（原62项+新增11项）。npm run build 退出0，TypeScript/Vite通过，主JS1111.83kB / gzip277.98kB。日志 docs/evidence/stage6-tests.txt、stage6-build.txt。没有声称未执行的真机/文件选择器/听感测试通过。

## 阶段 6 最后浏览器验收尝试（2026-10-30）

本轮没有修改源代码或测试，没有进入阶段7。重新执行 npm test：退出0，73/73通过，0失败/跳过，61.229秒；npm run build：退出0，主JS1111.83kB/gzip277.98kB。日志 stage6-acceptance-tests.txt、stage6-acceptance-build.txt。

浏览器生产页面能打开并显示“存档已恢复”。尝试订阅下载事件并导出，浏览器工具30秒超时且会话重置；下载目录仅发现此前20:14:08的1440字节 golden-hour-save.json，不能确认本轮新导出成功。恢复页面后尝试文件选择器导入该已有文件，setFiles 明确被扩展权限阻止：需要 Edge 的 ChatGPT 扩展开启 Allow access to file URLs。文件未送入网页，没有接受覆盖确认，也没有改写原有存档。未自行更改扩展权限。

本轮最终结论：自动回归和构建通过；最终浏览器验收未完成。导出→刷新→导入内容逐字段核对、损坏/错误版本文件的浏览器导入保护均受文件上传权限阻塞。真实PB录制后刷新回放未完成；已有自动诊断明确不持久化，不将其当作此项证据。手机多指、真实音效听感及长期性能继续待真机验证。后续先解决文件选择器权限，再完成正式计时模式持久化PB与刷新回放，不能把当前状态标为浏览器全部通过。

## 2026-10-31 阶段6浏览器最终验收

仅操作现有生产构建与更新文档/证据，无源代码或测试修改；未重新运行npm测试/构建，沿用上轮73/73和构建记录，不能视作本日重跑。

通过：实际导出当前档 golden-hour-save (1).json，保留 docs/evidence/stage6-browser-final/original.json；刷新、将静音从false改true（已安全保存），经真实文件选择器导入original，接受覆盖确认，自动刷新后静音恢复false。再次导出restored.json，与原始career/timing/settings/history所有字段及checksum完全一致。包含5车升级/车漆、驾驶辅助/布局；解锁由wins/rewards推导未改变。覆盖范围限制：原始wins/rewards/history/timing.records均为空，仅GH01开放，升级全0，未验证非空成绩/幽灵内容往返。

通过：真实导入 malformed.json、future.json、checksum.json，分别显示JSON语法错误、不兼容版本、完整性校验失败。再次导出after-rejections.json，全部payload及checksum与原档一致。错误详情rejected.json，比较comparison.json。

未完成：原始档无PB。进入正式计时（不是诊断），W持续2秒观察55km/h，经方向操作到检查点11/62时越界，本圈无效、有效圈0、PB暂无。该驾驶尝试失败，不是已确认游戏缺陷；未生成真实有效PB，因此刷新幽灵回放未测试。保留pb-attempt.txt，不引入虚构轨迹或临时诊断数据。

最后再次通过实际导入恢复original，导出final-restored.json；与original逐字节一致。原始有效状态恢复，备份历史/事务序号因测试正常轮换，未声称其内部字节不变。手机多指、真实音效听感、长期性能待真机验证。阶段6仍未达到全部最终浏览器验收通过。

## 阶段 6 功能验收完成（2026-10-31，最新状态）

本节更新此前“真实 PB 刷新回放未验收”的状态，历史尝试记录保留。证据来源：用户本次提供的真实人工浏览器验收结果；不是本轮助手自动操作或诊断轨迹。

- 通过：单人计时获得个人最佳 46.802 秒。
- 通过：刷新网页后，个人最佳成绩正常恢复。
- 通过：重新进入相同车辆和升级配置的单人计时模式，页面成功加载同配置个人最佳幽灵。
- 通过：开始驾驶后，人工实际观察到半透明幽灵赛车正常出现。

结合此前存档导入导出、字段校验、损坏文件保护及自动回归记录，阶段 6 标记为功能验收完成。此次人工反馈不扩展为新的碰撞/物理/排名隔离专项测试，也不替代其他平台体验验收。

仍待验证：手机多指操作、真实音效听感、长期性能。此前其他未覆盖范围保留，不因本次 PB 验收自动视为通过。

本轮仅更新 ROADMAP.md、ACCEPTANCE.md、TEST_LOG.md，未操作或覆盖当前有效存档和 46.802 秒 PB，未导入 original.json，未修改游戏功能或测试代码。未重新运行测试或构建；73/73 通过与构建成功仍为此前实际执行记录。停止于阶段 6，不开始阶段 7。

## 阶段 7 实际开发记录（2026-10-31）

先使用可用 GraphFlow gf_read 获取上下文；旧 context/plan/index 接口未暴露。项目没有 TECH_ARCHITECTURE.md，读取 ARCHITECTURE.md 及阶段4–6规格作为实现依据。没有新建项目或重新安装依赖。

新增 src/scene/car.ts、dressCar.ts、effects.ts、quality.ts、reflection.ts 与 src/settings/recordings.ts；修改 provingGround/garage、race/scenery/view、timing/view、main、style、career/ui、settings/audio/telemetry；新增 tests/visual.test.ts（原73项文件未修改）。新增 public/audio 七个本地音频文件和 public/licenses/stage7-audio.txt，原始下载压缩包保留 assets/audio。

按显示层接入模型后运行模型/生命周期4项通过；赛道模块规则与显示7项通过；音频与显示3项通过。中途全量75/75通过（stage7-tests.txt），增加画质测试后曾76/76通过。后来加入RawCubeTexture反射时，NullEngine无GPU实现导致车库/模型测试失败（stage7-reflection-tests.txt），已修复为仅无GPU的NullEngine不创建反射纹理，浏览器仍使用真实立方体纹理；没有修改已有测试或放宽物理断言。修复后模型/生命周期/画质5项通过（stage7-reflection-fixed-tests.txt）。失败全量进程停止后重新运行，最终结果另见下方。一次尝试重用仍被占用的日志文件被系统拒绝，随后使用独立stage7-verified-tests.txt，未将该失败命令记为通过。

浏览器：在独立内置浏览器打开 http://localhost:4173 的生产构建，车库面板原遮挡模型，调整侧栏和相机并复查；模型车窗由盒体改为斜面几何后可见；正式六车赛道加载、AI开始前进、暂停可用，error/warn列表为空。玩家停在网格时有两名AI仍在起步区，未据此声称完整比赛验证。桌面瞬时236–240 FPS不作持续/手机性能证据。新音频未做听感确认。没有读取或导入玩家Edge存档，原PB未操作。

音频授权按实际源页面核验：domasx2历史许可评论说明已重新制作公共领域源样本；Kenney签名下载返回forbidden，未使用其资产。录音与音乐通过本地相对路径加载，CC BY/SA作者及许可保留在生产资源中。浏览器声音加载错误未观察到，但空日志不等于听感或全事件验收通过。

最后追加控制器只读 presentation.brake/boost 遥测，供灯光/尾焰读取；未改变任何施力、输入判定或积分公式。修正先前以减速推断刹车灯的问题，停车踩刹车也会亮灯。

### 阶段7最终命令与状态

- 最后只读制动遥测落地后，npm test 退出0：76 tests / 76 pass / 0 fail / 0 skipped，45.192秒。原73项全部保留；新增3项显示几何/释放/画质测试。原始日志 docs/evidence/stage7-release-tests.txt。
- npm run build 退出0：TypeScript与Vite通过，主JS1141.30kB / gzip288.56kB。日志 docs/evidence/stage7-final-build.txt。
- 七个本地音频生产HTTP请求全部200；文件大小/SHA256见 docs/evidence/stage7-audio-http.json。未把HTTP成功当作声音听感通过。
- 浏览器设置实际低→高→中，显示“已安全保存”；未测各档长时帧耗。模型反射最终版浏览器可见且error/warn为空；截图stage7-garage.png。画质切换测试仅改独立内置浏览器档，没有覆盖Edge中的PB。
- 原有Havok驾驶、六车AI、62检查点、生涯、PB幽灵、IndexedDB/导入导出由全量自动回归覆盖。本轮未重新人工跑PB或做文件导入，不能把阶段6人工结果说成此次复测。
- 此次仍有待验收项目，详见ACCEPTANCE阶段7。没有部署、离线或后续阶段开发。

## 2026-11-04 阶段7最终验收

先调用当前可用GraphFlow gf_read并读取项目记录/锚点代码；旧graphflow_context/plan/index不在工具列表，未声称已调用。没有重新安装依赖，没有新建项目。当前目录没有Git仓库，不能提供Git提交差异；本轮用SHA256基线核对已有测试和关键规则。

证据目录：docs/evidence/stage7-acceptance-20261104/。本轮唯一生产源代码修改为src/scene/effects.ts车轮轴向修复。新增tests/wheel-axis.test.ts；新增tests/browser/stage7.html与stage7.ts作为独立浏览器验收夹具，不接入Vault/IndexedDB/个人成绩，也不进入默认生产入口。原13个测试文件中的76项完整保留，tests-preserved.json全部Match=true。track.ts、rules.ts、vault.ts、recording.ts前后哈希不变，见rules-preserved.json。

### 实际命令

| 命令 | 结果 | 日志 |
|---|---|---|
| npm test（修改前） | 76/76，通过 | tests.txt |
| npm run build（修改前） | 退出0 | build.txt |
| npm run dev -- --host 127.0.0.1 | 本地5173启动，供独立夹具 | dev-server.txt |
| npm run preview -- --host 127.0.0.1 --port 4173 --strictPort | 本地预览4173运行，不是公开部署 | preview-server.txt |
| npm run build（添加夹具后） | 类型检查/构建成功 | build-with-harness.txt |
| node --import tsx --test tests/wheel-axis.test.ts（修复前） | 0/1，断言wheel axle must not tumble失败；确认原问题 | wheel-before-test.txt |
| node --import tsx --test tests/wheel-axis.test.ts tests/visual.test.ts（修复后） | 4/4，通过 | wheel-fixed-test.txt |
| npm test（最终） | 退出0，77 tests / 77 pass / 0 fail / 0 skipped | tests-final.txt |
| npm run build（最终） | 退出0，主JS1141.31kB / gzip288.57kB | build-final.txt |

最终测试日志的duration_ms为3721570.2034，保留原始输出，不把测试进程时间当作浏览器性能指标。没有放宽既有断言。一次使用Windows不支持的路径通配符rg查找失败，随后用实际transformNode.pure.d.ts核对rotate(axis, amount, space)签名；一次读取不存在的src/timing/ui.ts失败，随后读取实际view.ts。浏览器只读DOM接口不提供document.hasFocus方法，尝试被拒绝；未借助非UI手段读浏览器隐藏状态。

### 浏览器视觉、物理与性能

工具仅提供内置浏览器，没有原Edge标签连接。隔离夹具逐个使用实际createGarage展示五车；截图car-01.png至car-05.png。车身、灯组、镜子、玻璃和轮毂可见，但主体共用，GH01/04/05外观相近。判断：风格化可玩原型，不满足“五车明显不同的高品质模型”最终要求，不作写实模型宣传。

实际赛道中观察到轮胎向外翻转，wheel-before.png留证。根因：模型轮胎圆柱已绕Z倾斜，动画修改Euler Y导致轮轴绕车身转动。以安装版本的Mesh.rotate(Vector3.Up(), angle, Space.LOCAL)绕本地圆柱轴旋转；不改刚体、车身顶点、施力或驾驶逻辑。新增测试先在旧版本失败，再确认滚动中轴向恒定且胎面确实转动；浏览器修复后截图wheel-fixed.png确认。车轮转向摆角与倒车滚动方向未专项验收。

隔离页复用Competition/Havok、buildCircuit、dressCar，六车均通过原驾驶器施力，碰撞启用；玩家由现有validationPilot控制，不传送、不修改比赛状态、不保存成绩。第一场运行曾观察finished、比赛时钟141.3667秒、有效圈[2,2,1,2,1,2]（是玩家完成时的规则结算，并非所有AI都已冲线）。中/低/高各30秒实测见browser-three-tiers.json：

| 画质 | 绘制缓冲 | 帧数 | 时长ms | 平均FPS | p95帧间隔ms | 后台帧/失焦帧 |
|---|---|---:|---:|---:|---:|---|
| 中 | 591×453 | 7154 | 30000.8 | 238.4603 | 4.3 | 0/0 |
| 低 | 443×340 | 7198 | 30001.3 | 239.9229 | 4.3 | 0/0 |
| 高 | 887×680 | 7198 | 30000.6 | 239.9285 | 4.3 | 0/0 |

高档采样重新发车，避免把已结束的静态比赛当动态六车采样。这是原生WebGL桌面低分辨率、隔离页的前台实测；不是手机、1080p完整产品或长期性能结论。采样在车轮修复前完成。三档实际阴影开关/mapSize、反射贡献0/.18/.3与分辨率不同；粒子预算已有测试，尚未在浏览器逐类覆盖所有粒子峰值。

5轮车库→比赛→清理，车库每次58网格/8材质/1纹理，比赛1045网格/68材质/2纹理/6个beforeRender观察者；清理后均0且engine.scenes为0。browser-lifecycle.json保存序列。只证明短时场景对象释放，不等于GPU驱动/长期JS堆稳定。

正式生产页另一个标签显示约1FPS，诊断均值7–8FPS、最长帧约1005ms，证据production-throttled.png / production-race-diagnostic.txt。切回可见标签页并请求前台显示后仍出现约1FPS；保存的production-foreground-retry.txt记录比赛17.633秒、采样均值10.4FPS、最长帧1005.2ms。浏览器显示能力返回visible=true，但没有取得正式页逐帧焦点/可见性与正常性能的完整证据。异常根因未定位，不能断言只是后台节流，也不能用独立页238–240FPS抵消。**正式比赛性能验收未通过**。文件名中的throttled仅反映当时怀疑，不是已确认诊断。内置浏览器与Edge/手机结论分别记录。

### 音频与许可

七文件SHA256与10月31日记录一致，audio-hashes.json。实际点击解锁后AudioContext为running，engine/music解码完成，另五个样本均已加载，skid和boost循环节点建立，无audioWarning。sound事件观察是验收夹具对真实Sound的只读记录，不替代人工听音。music=0时effects仍约0.8，mute使master=0，恢复默认后0.7/0.8/0.25，见audio-runtime.json。

实际自动驾驶中rpm约900–6336，engine播放速率0.5–2.098，skid增益随侧滑非零；更早一次观察侧滑约3.14、skid增益约0.156（该次开发页后续重载，只保留工具观察，不当作最终JSON数据）。countdown.ogg/GO实际触发；氮气循环在这次驾驶未激活，不能标通过。强弱撞击事件及冲线录音未完成专项听感/参数核对。人工音效听感、循环接缝、多设备解码仍待测。

调用真实loadRecording加载不存在文件，Promise以EncodingError拒绝，页面继续可用（Vite对未知路径返回页面，解码器拒绝非音频）；这仅验证加载器错误，不是完整Sound降级/自动重试测试。代码检查显示失败输出console警告并保留占位音，没有自动重试；撞击强度按渲染帧速度差取样，音效100ms采样可能错过短事件，需后续专测。本轮不凭推测大改音频。

本地许可逐项复核，在线Winning the Race、Car Tire Skid Squealing、Race Start Beeps、Sci-Fi Racing Sfx页面可访问；Racing Car Engine Sound Loops和Crash Collision返回403，保留历史核验记录并标注本次不可复核。无新增第三方素材，不伪造授权。

### 正式UI与存档边界

独立内置浏览器的生产UI：车库GH01金→蓝→刷新仍蓝，实际截图paint-refreshed.png；随后恢复金。音量从0.7/0.8/0.25改为0.69/0.79/0，静音开启，高画质，刷新后恢复，见settings-refreshed.png；随后恢复原默认音量、取消静音和中画质。没有改变车型解锁、奖励、升级或生涯成绩。8关面板及锁定条件可见，career-ui.txt。

正式“计时与幽灵自动验证·不保存成绩”执行结果：两圈有效、0无效，01:06.718/01:06.401，1329采样点、幽灵显示33帧，结束；timing-diagnostic.txt/png。每渲染帧批量2秒真实Havok步进，非正常实时人工驾驶，不作为性能或新个人PB。浏览器error/warn观察为空，不把空日志当作全功能通过。

没有读取/覆盖原Edge存档或46.802秒PB，没有导入original.json；原PB的本次刷新/幽灵复验未测试，仍保留阶段6用户人工通过的历史记录。本轮完整存档往返/损坏保护由保留的自动测试覆盖，浏览器没有重新导入。手机、多指、真实听感、长时GPU/内存仍未测试。

最终验收分类与交付结论见ACCEPTANCE最新节：回归通过；五车视觉差异不足；音频专项、手机和长期表现待测。停止在阶段7，不部署，不进入阶段8。

## 2026-11-05 阶段7文档收尾（不新增开发）

按用户要求核对当前src/scene/effects.ts、tests/wheel-axis.test.ts、最终测试/构建日志、三档采样及正式页面复试证据。车轮仍使用Space.LOCAL局部轴旋转，新轴向回归测试保留。原13个测试文件与修改前SHA256基线全部一致，当前14个*.test.ts文件；最终日志77 tests / 77 pass / 0 fail / 0 skipped，build-final.txt记录构建成功。此处是复核已有执行结果，不是11月5日重新执行npm test或npm run build。

只更新ROADMAP.md、ACCEPTANCE.md、TEST_LOG.md和ASSET_LICENSES.md；没有修改功能、测试代码或资源，没有浏览器新验收，也没有读写玩家存档。原Edge未连接，46.802秒PB没有重新核对或覆盖，original.json未导入。

收尾状态：**阶段7部分验收**。已通过自动回归、构建、车轮修复及短期对象释放；未通过五车明显外观差异和正式比赛性能验收。独立页中画质238.46FPS（另两档约239.92FPS）与正式页约1FPS异常必须分开，不能归并为性能通过。正式页根因待定位；人工听感/完整音频事件、手机真机、多指、长期内存与性能、原Edge PB复查仍未测试或未完成。停止开发，不进入阶段8，不部署。

## 2026-11-05 阶段7性能专项诊断（仅诊断）

报告：[STAGE7_PERFORMANCE_DIAGNOSIS.md](docs/STAGE7_PERFORMANCE_DIAGNOSIS.md)。原始数据：docs/evidence/stage7-performance-20261105/。

使用当前可用GraphFlow gf_read获取上下文；旧graphflow_context/plan/index不在当前工具列表，未声称执行索引。新增tests/performance/下Vite配置、正式页面计时探针及纯RAF最小页，不修改生产src、依赖或已有测试。独立5190来源使用原正式菜单、六车比赛、HUD、音频和物理，仅加入测量，不用此前独立测试页替代正式场景。

- 已实测：正式中/低/高档30秒分别236.787、223.367、0.9995FPS。高档帧间隔1005.934ms，游戏回调CPU平均5.787ms、GPU平均2.578ms；同页原生RAF1005.924ms，100ms定时器99.963ms。采样内无隐藏/失焦帧，无已记录长任务或资源请求。
- 已核对：仅1场景/1渲染循环，每帧1次Scene.render；最多6次固定步进，中档30秒1800次Havok、9000次AI、10800次车辆施力。没有观察到无限补算或自动/手动物理重复。高档异常主要处于倒计时，仅38次实际Havok步进，不能宣称完成持续六车竞速的高画质压力验收。
- 尚未确定：具体帧调度触发根因。纯RAF页232.819/174.447FPS，未复现1FPS。低档窗口操作了另一标签，高档前后发生工具会话重置及服务中断；后续异常标签导航被工具URL策略拦截。不能将DOM visible/focus等同OS前台、将高档相关性认定因果，或声称已完成稳定最小复现和恢复条件A/B。
- 测量工具修正：初版GPU探针漏导入已安装Babylon查询扩展，补齐后采样。仅改探针，没有改游戏代码。npx tsc --noEmit最终退出0，见typecheck-result.json；npm test/npm run build本轮未重跑，77/77及构建成功为前次执行结果。
- 保护核对：preserved.json记录40个src文件与原14个测试文件SHA256全部一致，原77项测试保留。没有读取或覆盖原Edge有效存档、46.802秒PB，没有导入original.json。

结论：优先定位宿主/浏览器帧调度或呈现路径，仍需独立Edge/Chrome真实前台、同页画质A/B、手机、长期性能及合成器追踪。当前证据不足以给出确定性修复；本轮未应用游戏修复。阶段7保持部分验收，不部署、不进入阶段8。

## 2026-11-05 阶段7画质清晰度专项

旧版src/main.ts在每档调用setHardwareScalingLevel(2 / 1.5 / 1)，没有适配DPR；安装版本Babylon 9.32.1的resize按CSS尺寸除以这个值。未发现第二层renderScale或正式比赛的全屏模糊后处理。Canvas的CSS为100vw × 100dvh，HUD为DOM。旧低档只渲染CSS宽高各一半，在DPR 1.5条件下约一个3D像素覆盖3×3个显示像素。根因是绘制缓冲不足，不需要用CSS锐化或去掉抗锯齿掩盖。

修改：新增src/scene/resolution.ts，统一按Canvas实际CSS矩形乘DPR取整，监听尺寸/DPR变化并在硬件最大尺寸内保持长宽比；三档默认100%物理像素。中/低档优先减少阴影绘制、车漆反射与真实粒子池容量；按材质及相邻区域合并静态起终点标记、检查点柱与山体，保留原几何与赛道规则。src/scene/provingGround.ts仅应用画质预算。没有修改物理、AI、比赛规则、保存格式、计时或幽灵。scope.json对照诊断基线列出改动范围；原14个测试文件逐个哈希均相同。

动态分辨率不写入存档。持续慢帧才开始查询GPU；至少3秒且足够多有效样本同时显示帧间隔>33.34ms与GPU耗时>28ms，才按宽高各5个百分点逐步降低，常规下限85%。恢复需要至少8秒持续余量；切换画质重新从原生分辨率开始。不支持GPU计时的设备保持原生分辨率；调度停顿本身不会触发。极大画布仍需遵守GPU尺寸上限。

**前后实测**：node tests/performance/clarity-benchmark.mjs，分别将修改前/后正式入口打成独立本地测试包（Vite production模式），使用全新临时配置的Edge 156无头浏览器、RTX 5070 Laptop / ANGLE D3D11、DPR 1.5。通过实际设置菜单按低→中→高切换，进入“开始比赛”；每次等到倒计时结束、比赛时钟约1秒后，在六车活动场景中记录约8秒渲染回调间隔。玩家未人工驾驶。原始输出为docs/evidence/stage7-clarity/before.json和after-final.json，不使用独立测试页或此前诊断的FPS替代。

| 档位 | 修改前缓冲 → 最终缓冲 | 修改前 → 最终平均FPS | p95帧间隔，ms | 超过33.34ms的间隔，前 → 后 |
|---|---|---:|---:|---:|
| 低 | 513×325 → 1539×977 | 226.37 → 171.46 | 5.6 → 7.8 | 2 → 0 |
| 中 | 684×434 → 1539×977 | 239.88 → 174.47 | 5.5 → 7.7 | 0 → 0 |
| 高 | 1026×651 → 1539×977 | 239.62 → 174.38 | 5.5 → 7.4 | 0 → 0 |

表内为窗口结束时CSS 1026×651.333的对应缓冲。首档采样初段浏览器视口高度曾变化（见两份JSON的sizes），中/高档绘制尺寸稳定。每个版本每档一个最终短样本，前后采样时间不同，未控制显示器呈现、电源和温度，不能将差值全部归于某项改动。明确结论是**原生像素匹配通过，平均FPS并未提高**，没有据此判定用户的中档卡顿或原内置浏览器1 FPS已修复。

最终浏览器命令：`node tests/performance/clarity-benchmark.mjs docs/evidence/stage7-clarity/after-final.json --expect-native`退出0。三档均通过六车、实际WebGL绘制缓冲等于Canvas尺寸并等于round(CSS×DPR)的断言；CSS单独缩为805.406×498.260后，缓冲均跟随到1208×747。第一次修改后采样超时，没有采用为有效数据；修正了测量夹具中引擎类型标注，保留超时日志。重测成功后，将GPU监测改为慢帧时才开启，再执行上述最终测量。

构建：`npm run build`退出0，TypeScript及Vite通过，日志docs/evidence/stage7-clarity/build-final.txt。新增tests/clarity.test.ts四项；相关画质、车轮及车模8项专项测试通过。手机真机、真实用户设备的卡顿、手动清晰度评审和长期热降频未测。未访问玩家原Edge配置或PB。

最终全量回归：`npm test`退出0，**81/81通过**（原77项＋新4项），0失败、0取消、0跳过，耗时70.509秒；见[完整测试输出](docs/evidence/stage7-clarity/tests-final.txt)。未部署，停止于阶段7。
