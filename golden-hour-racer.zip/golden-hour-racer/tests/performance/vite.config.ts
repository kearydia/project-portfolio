import {defineConfig} from 'vite';

// Diagnostics only. Production files stay unchanged; only timing hooks are served.
export default defineConfig({base:'./',server:{host:'127.0.0.1',port:5190,strictPort:true},plugins:[{
 name:'formal-race-performance-probe',enforce:'pre',
 transform(code,id){
  if(id.split('?')[0].replaceAll('\\','/').endsWith('/src/main.ts'))return `import '/tests/performance/probe.ts';\n${code}`;
  if(id.split('?')[0].replaceAll('\\','/').endsWith('/src/scene/effects.ts')){
   let c=code.replaceAll('\r\n','\n');
   if(!c.includes('  const limit=visualQuality().particles;')||!c.includes('\n });'))throw Error('Particle timing anchor changed');
   c=c.replace('  const limit=visualQuality().particles;','  const __particleStart=performance.now();\n  const limit=visualQuality().particles;');
   c=c.replace('\n });',"\n  recordCost('particlePool',performance.now()-__particleStart);\n });");
   return `import {recordCost} from '/tests/performance/probe.ts';\n${c}`;
  }
 }
}]});
