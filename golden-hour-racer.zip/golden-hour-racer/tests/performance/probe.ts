import {Engine,Scene} from '../../src/engine/babylon';
import {PhysicsEngine} from '@babylonjs/core/Physics/v2/physicsEngine';
import {EngineInstrumentation} from '@babylonjs/core/Instrumentation/engineInstrumentation';
import '@babylonjs/core/Engines/Extensions/engine.query';
import '@babylonjs/core/Engines/AbstractEngine/abstractEngine.timeQuery';
import {Competition} from '../../src/race/simulation';
import {Driver} from '../../src/race/ai';
import {PrototypeVehicle} from '../../src/physics/world';
import {Sound} from '../../src/settings/audio';
import {RaceRules} from '../../src/race/rules';
import {visualQuality} from '../../src/scene/quality';

type Stats={n:number,sum:number,max:number,values:number[]};
const stat=():Stats=>({n:0,sum:0,max:0,values:[]});
function add(s:Stats,v:number){s.n++;s.sum+=v;s.max=Math.max(s.max,v);if(s.values.length<50000)s.values.push(v);}
function summarize(s:Stats){const sorted=[...s.values].sort((a,b)=>a-b);return {count:s.n,totalMs:s.sum,meanMs:s.n?s.sum/s.n:0,p95Ms:sorted[Math.floor(sorted.length*.95)]??0,maxMs:s.max};}
let active=false,frame:Record<string,number>|undefined,frameCounts:Record<string,number>|undefined;
let calls:Record<string,Stats>={},perFrame:Record<string,Stats>={},counts:Record<string,Stats>={};
let intervals=stat(),cpu=stat(),rafIntervals=stat(),timerIntervals=stat(),gpu=stat();
let frameCount=0,hiddenFrames=0,unfocusedFrames=0,lastFrame=0,lastRaf=0,lastTimer=0,start=0;
let engines=new Set<Engine>(),gpuIns=new Map<Engine,EngineInstrumentation>(),gpuCounts=new Map<Engine,number>();
let transitions:unknown[]=[],longTasks:unknown[]=[],resources:unknown[]=[];
const history:unknown[]=[];let latestRace:Competition|undefined;
export function recordCost(name:string,ms:number){if(!active)return;add(calls[name]??=stat(),ms);if(frame){frame[name]=(frame[name]??0)+ms;frameCounts![name]=(frameCounts![name]??0)+1;}}
function wrap(proto:any,key:string,name:string){const original=proto[key];if(typeof original!=='function')throw Error('Missing timing target '+name);proto[key]=function(...args:any[]){if(!active)return original.apply(this,args);const t=performance.now();try{return original.apply(this,args);}finally{recordCost(name,performance.now()-t);}};}
wrap(Driver.prototype,'input','ai');wrap(PrototypeVehicle.prototype,'step','vehicleForces');wrap(PhysicsEngine.prototype,'_step','havok');wrap(RaceRules.prototype,'update','rules');wrap(Sound.prototype,'tick','audioTick');
const originalStep=Competition.prototype.step;Competition.prototype.step=function(...args){latestRace=this;return originalStep.apply(this,args);};wrap(Competition.prototype,'step','competitionStep');
const wrappedObservers=new WeakSet<object>();
const originalRender=Scene.prototype.render;
Scene.prototype.render=function(...args){
 // These six observers are the actual vehicleEffects callbacks; wrap once without reordering.
 if(this.getMeshByName('racer-0'))for(const o of this.onBeforeRenderObservable.observers){if(!wrappedObservers.has(o)){wrappedObservers.add(o);const f=o.callback;o.callback=(...a)=>{if(!active)return f(...a);const t=performance.now();try{return f(...a);}finally{recordCost('vehicleEffects',performance.now()-t);}};}}
 if(!active)return originalRender.apply(this,args);const t=performance.now();try{return originalRender.apply(this,args);}finally{recordCost('sceneRenderCPU',performance.now()-t);}
};
const loopMap=new WeakMap<()=>void,()=>void>(),originalRun=Engine.prototype.runRenderLoop,originalStop=Engine.prototype.stopRenderLoop;
Engine.prototype.runRenderLoop=function(callback){
 engines.add(this);if(!gpuIns.has(this)){const ins=new EngineInstrumentation(this);ins.captureGPUFrameTime=true;ins.captureShaderCompilationTime=true;gpuIns.set(this,ins);}
 let wrapped=loopMap.get(callback);if(!wrapped){wrapped=()=>{const t=performance.now();const measuring=active;if(measuring){if(lastFrame)add(intervals,t-lastFrame);lastFrame=t;frame={};frameCounts={};frameCount++;hiddenFrames+=Number(document.hidden);unfocusedFrames+=Number(!document.hasFocus());}
  try{callback();}finally{if(measuring){add(cpu,performance.now()-t);for(const key of ['ai','vehicleForces','havok','rules','competitionStep','particlePool','vehicleEffects','sceneRenderCPU']){add(perFrame[key]??=stat(),frame?.[key]??0);add(counts[key]??=stat(),frameCounts?.[key]??0);}const counter=gpuIns.get(this)!.gpuFrameTimeCounter;if(counter&&counter.count>(gpuCounts.get(this)??0)){gpuCounts.set(this,counter.count);add(gpu,counter.current/1e6);}frame=undefined;frameCounts=undefined;}}
 };loopMap.set(callback,wrapped);}return originalRun.call(this,wrapped);
};
Engine.prototype.stopRenderLoop=function(callback){return originalStop.call(this,callback?loopMap.get(callback)??callback:undefined);};
function raf(t:number){if(active){if(lastRaf)add(rafIntervals,t-lastRaf);lastRaf=t;}requestAnimationFrame(raf);}requestAnimationFrame(raf);
setInterval(()=>{const t=performance.now();if(active){if(lastTimer)add(timerIntervals,t-lastTimer);lastTimer=t;}},100);
for(const event of ['visibilitychange','focus','blur'])addEventListener(event,()=>{if(active)transitions.push({event,t:performance.now()-start,hidden:document.hidden,focus:document.hasFocus()});});
try{new PerformanceObserver(list=>{if(active)for(const e of list.getEntries())longTasks.push({start:e.startTime-start,ms:e.duration});}).observe({type:'longtask',buffered:false});}catch{}
try{new PerformanceObserver(list=>{if(active)for(const e of list.getEntries())resources.push({name:e.name,start:e.startTime-start,ms:e.duration});}).observe({type:'resource',buffered:false});}catch{}
function metadata(){return {url:location.href,userAgent:navigator.userAgent,quality:visualQuality(),hidden:document.hidden,focus:document.hasFocus(),viewport:[innerWidth,innerHeight],dpr:devicePixelRatio,
 engines:[...engines].map(e=>({disposed:e.isDisposed,canvas:[e.getRenderWidth(),e.getRenderHeight()],gl:e.getGlInfo(),timerQuery:!!e.getCaps().timerQuery,loops:(e as any)._activeRenderLoops.length,scenes:e.scenes.map(s=>({meshes:s.meshes.length,materials:s.materials.length,textures:s.textures.length,physicsAuto:s.physicsEnabled,vehicles:s.meshes.filter(m=>/^racer-/.test(m.name)).length,activeMeshes:s.getActiveMeshes().length,indices:s.getActiveIndices(),drawCalls:(e as any)._drawCalls?.current})),shaderCompile:gpuIns.get(e)?.shaderCompilationTimeCounter.total})),race:latestRace?{time:latestRace.rules.time,phase:latestRace.rules.phase,paused:latestRace.rules.paused,laps:latestRace.rules.racers.map(r=>r.laps)}:undefined};}
const panel=document.createElement('section');panel.id='performance-probe';panel.style.cssText='position:fixed;z-index:9999;bottom:30px;left:8px;width:440px;background:#10222de8;color:white;padding:8px;font:12px monospace;pointer-events:auto';panel.innerHTML='<b>正式页面计时探针 · 独立5190端口</b><br><button id="perf-start">预热5秒＋测量30秒</button><span id="perf-live"></span><details><summary>诊断结果</summary><pre id="perf-output" style="max-height:28vh;overflow:auto;white-space:pre-wrap"></pre></details>';
document.body.append(panel);const live=panel.querySelector('#perf-live')!,output=panel.querySelector('#perf-output')!;
const reset=()=>{calls={};perFrame={};counts={};intervals=stat();cpu=stat();rafIntervals=stat();timerIntervals=stat();gpu=stat();frameCount=hiddenFrames=unfocusedFrames=0;lastFrame=lastRaf=lastTimer=0;transitions=[];longTasks=[];resources=[];};
(panel.querySelector('#perf-start') as HTMLButtonElement).onclick=()=>{if(active)return;live.textContent='预热中';setTimeout(()=>{reset();start=performance.now();const before=metadata();active=true;live.textContent='测量中';setTimeout(()=>{active=false;const elapsed=performance.now()-start;history.push({sample:history.length+1,elapsedMs:elapsed,frames:frameCount,fps:frameCount*1000/elapsed,hiddenFrames,unfocusedFrames,before,after:metadata(),frameInterval:summarize(intervals),callbackCPU:summarize(cpu),independentRAF:summarize(rafIntervals),timer100ms:summarize(timerIntervals),gpuMs:summarize(gpu),calls:Object.fromEntries(Object.entries(calls).map(([k,v])=>[k,summarize(v)])),perFrame:Object.fromEntries(Object.entries(perFrame).map(([k,v])=>[k,summarize(v)])),callsPerFrame:Object.fromEntries(Object.entries(counts).map(([k,v])=>[k,summarize(v)])),transitions,longTasks,resources});output.textContent=JSON.stringify(history,null,2);live.textContent='完成 '+frameCount+'帧 / '+(frameCount*1000/elapsed).toFixed(2)+'FPS';},30000);},5000);};
