// node tests/performance/clarity-benchmark.mjs <new-output.json>
// EDGE_BINARY may point to a local Chromium executable. Never uses the player's profile.
import {build,preview} from 'vite';
import {mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import assert from 'node:assert/strict';
import {spawn,execFileSync} from 'node:child_process';
const output=process.argv[2];if(!output)throw Error('Specify a new output JSON path');
const dir=await mkdtemp(join(tmpdir(),'ghr-clarity-')),dist=join(dir,'dist');
let server,browser,timeout;
try{
  const config={configFile:false,base:'./',build:{outDir:dist,target:'es2022',reportCompressedSize:false}};
  await build({...config,plugins:[{name:'clarity-entry',transformIndexHtml:{order:'pre',handler:()=>[
    {tag:'script',children:"const report=e=>fetch('/measurement',{method:'POST',body:JSON.stringify({error:String(e)})});addEventListener('error',e=>report(e.message));addEventListener('unhandledrejection',e=>report(e.reason));",injectTo:'head-prepend'},
    {tag:'script',attrs:{type:'module',src:'/tests/performance/clarity.page.ts'},injectTo:'body'}]}}]});
  const finished=new Promise((resolve,reject)=>{timeout=setTimeout(()=>reject(Error('Browser benchmark timed out')),190000);
    config.plugins=[{name:'local-result',configurePreviewServer(s){s.middlewares.use('/measurement',async(req,res)=>{
      if(req.method!=='POST'||req.headers.origin!=='http://'+req.headers.host){res.statusCode=403;res.end();return;}
      try{let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>20000)throw Error('Oversized result');}const data=JSON.parse(raw);res.end('ok');if(data.error)throw Error(data.error);resolve(data);}catch(e){res.end();reject(e);}
    });}}];
  });
  server=await preview({...config,preview:{host:'127.0.0.1',port:0}});const port=server.httpServer.address().port;
  browser=spawn(process.env.EDGE_BINARY||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',['--headless=new','--no-first-run','--no-default-browser-check','--disable-extensions','--window-size=1056,780','--force-device-scale-factor=1.5','--user-data-dir='+join(dir,'profile'),'http://127.0.0.1:'+port],{stdio:'ignore',windowsHide:true});
  const data=await Promise.race([finished,new Promise((_,reject)=>browser.once('error',reject))]);await writeFile(output,JSON.stringify(data,null,2),{flag:'wx'});console.table(data.results.map(({tier,canvas,fps,p95Ms})=>({tier,canvas:canvas.join('×'),fps,p95Ms})));
  if(process.argv.includes('--expect-native')){
    assert.deepEqual(data.results.map(r=>r.tier),['low','medium','high']);
    for(const r of data.results){
      assert.equal(r.vehicles,6);assert.deepEqual(r.drawingBuffer,r.canvas);
      assert.deepEqual(r.canvas,r.css.map(v=>Math.round(v*r.dpr)),r.tier+' should be native on this unconstrained GPU');
      assert.deepEqual(r.resize.buffer,r.resize.css.map(v=>Math.round(v*r.dpr)),r.tier+' CSS-only resize');
    }
  }
}finally{
  clearTimeout(timeout);browser?.kill();
  // Edge on Windows can hand the isolated profile to a second browser process.
  if(browser&&process.platform==='win32')execFileSync('powershell.exe',['-NoProfile','-Command', "Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | Where-Object { $_.CommandLine -and $_.CommandLine.Contains($env:GHR_PRIVATE_PROFILE) } | ForEach-Object { Stop-Process -Id $_.ProcessId -ErrorAction SilentlyContinue }"],{windowsHide:true,env:{...process.env,GHR_PRIVATE_PROFILE:join(dir,'profile')}});
  server?.httpServer.closeAllConnections();await server?.close();
  await rm(dir,{recursive:true,force:true,maxRetries:5,retryDelay:200}).catch(()=>console.warn('Temporary isolated browser directory retained:',dir));
}
