// Only included by clarity-benchmark.mjs in its disposable local build.
import {EngineStore} from '@babylonjs/core/Engines/engineStore';
import type {Engine} from '../../src/engine/babylon';
const sleep=(ms:number)=>new Promise(r=>setTimeout(r,ms));
const click=(s:string)=>document.querySelector<HTMLButtonElement>(s)!.click();
async function waitFor(f:()=>boolean){const start=performance.now();while(!f()){if(performance.now()-start>50000)throw Error('Timed out: '+document.querySelector('#error-message')?.textContent);await sleep(80);}}
async function measure(tier:string){
  click('[data-info="设置"]'); const q=document.querySelector<HTMLSelectElement>('#quality-setting')!;
  q.value=tier;q.dispatchEvent(new Event('change'));click('#close-settings');click('[data-route="competition"]');
  await waitFor(()=>!!document.querySelector('#race-time')&&Number(document.querySelector('#race-time')?.textContent?.split(':')[1])>=1);
  const canvas=document.querySelector<HTMLCanvasElement>('#game')!,engine=EngineStore.LastCreatedEngine as Engine,scene=engine.scenes[0];
  const times:number[]=[],sizes=new Set<string>();let elapsed=0,previous=0,hidden=0;
  const startClock=document.querySelector('#race-time')!.textContent;
  const frame=()=>{const now=performance.now();if(previous){times.push(now-previous);elapsed+=now-previous;}previous=now;hidden+=Number(document.hidden);sizes.add(canvas.width+'x'+canvas.height);};
  const observer=scene.onAfterRenderObservable.add(frame);await sleep(8000);scene.onAfterRenderObservable.remove(observer);
  if(!times.length)throw Error('No race frames');const sorted=times.slice().sort((a,b)=>a-b);
  const rect=canvas.getBoundingClientRect(),gl=canvas.getContext('webgl2')!;
  const result={tier,css:[rect.width,rect.height],dpr:devicePixelRatio,canvas:[canvas.width,canvas.height],drawingBuffer:[gl.drawingBufferWidth,gl.drawingBufferHeight],sizes:[...sizes],hardwareScaling:engine.getHardwareScalingLevel(),renderer:engine.getGlInfo().renderer,ua:navigator.userAgent,vehicles:scene.meshes.filter(m=>/^racer-/.test(m.name)).length,intervals:times.length,elapsedMs:elapsed,fps:times.length*1000/elapsed,p95Ms:sorted[Math.floor(sorted.length*.95)],p99Ms:sorted[Math.floor(sorted.length*.99)],over33ms:times.filter(t=>t>33.34).length,hiddenFrames:hidden,clock:[startClock,document.querySelector('#race-time')!.textContent]};
  // Outside the FPS window: exercise a CSS-only canvas resize without a window resize.
  const oldStyle=canvas.style.cssText;
  canvas.style.width='78.5vw';canvas.style.height='76.5dvh';
  await new Promise<void>(ok=>requestAnimationFrame(()=>requestAnimationFrame(()=>ok())));
  const smaller=canvas.getBoundingClientRect();
  const resize={css:[smaller.width,smaller.height],buffer:[gl.drawingBufferWidth,gl.drawingBufferHeight]};
  canvas.style.cssText=oldStyle;click('.global-back');return {...result,resize};
}
async function run(){const results=[];await waitFor(()=>!!document.querySelector('[data-route="competition"]'));for(const t of ['low','medium','high'])results.push(await measure(t));return results;}
void run().then(results=>({results}),error=>({error:String(error)})).then(data=>fetch('/measurement',{method:'POST',body:JSON.stringify(data)}));
