import test from 'node:test';
import assert from 'node:assert/strict';
import {rasterSize,ResolutionBudget} from '../src/scene/resolution';
import {applySceneQuality,setVisualQuality,visualQuality} from '../src/scene/quality';
import {Scene,NullEngine,DirectionalLight,ShadowGenerator,Vector3,MeshBuilder} from '../src/engine/babylon';
import {carModel} from '../src/scene/car';
import {vehicleEffects} from '../src/scene/effects';
import type {PrototypeVehicle} from '../src/physics/world';

test('quality switches preserve physical pixels at fractional desktop DPR and mobile landscape DPR',()=>{
  for(const tier of ['low','high','medium','low']){
    setVisualQuality(tier);
    assert.deepEqual(rasterSize(1026,651+1/3,1.5),{width:1539,height:977,level:1/1.5});
    assert.deepEqual(rasterSize(844,390,3),{width:2532,height:1170,level:1/3});
  }
  assert.deepEqual(rasterSize(600,300,2,1,1000),{width:1000,height:500,level:.6});
  setVisualQuality('medium');
});

test('scheduler stalls, slow CPU, hidden pages and isolated expensive frames do not reduce resolution',()=>{
  const policy=new ResolutionBudget();
  for(let i=0;i<800;i++)policy.sample(i*50,i%7===0?1000:50,i%13===0?45:2,true);
  for(let i=0;i<150;i++)policy.sample(41000+i*50,50,45,false);
  assert.equal(policy.fraction,1);
});

test('sustained GPU pressure drops in small steps, holds a floor and recovers only after headroom',()=>{
  const p=new ResolutionBudget();let time=0;
  const feed=(count:number,dt:number,gpu:number)=>{const changes:number[]=[];for(let i=0;i<count;i++){time+=dt;if(p.sample(time,dt,gpu,true))changes.push(p.fraction);}return changes;};
  assert.deepEqual(feed(60,50,45),[]);assert.equal(p.fraction,1);
  assert.deepEqual(feed(400,50,45),[.95,.9,.85]);
  assert.deepEqual(feed(400,16,9),[]);
  assert.deepEqual(feed(1300,16,9),[.9,.95,1]);assert.equal(p.fraction,1);
});

test('lower tiers cut actual shadow refreshes and allocate only their per-car particle budget',()=>{
  const engine=new NullEngine(),scene=new Scene(engine),sun=new DirectionalLight('sun',new Vector3(0,-1,0),scene);
  const shadow=new ShadowGenerator(1024,sun),chassis=MeshBuilder.CreateBox('chassis',{},scene);
  setVisualQuality('low');const model=carModel(scene,chassis,'#eeeedd');
  const car={mesh:chassis,nitro:1,recovery:0,speed:30,grounded:true,presentation:{},aggregate:{body:{getLinearVelocity:()=>Vector3.Zero()}}} as unknown as PrototypeVehicle;
  vehicleEffects(scene,car,model);
  try{
    for(const [tier,particles,shadowInterval,reflection] of [['low',8,2,0],['medium',20,2,.18],['high',40,1,.3],['low',8,2,0]] as const){
      setVisualQuality(tier);applySceneQuality(scene);chassis.position.z+=.1;
      scene.onBeforeRenderObservable.notifyObservers(scene);
      assert.equal(scene.meshes.filter(m=>m.name==='fx-pool').length,particles);
      assert.equal(shadow.getShadowMap()!.refreshRate,shadowInterval);
      assert.equal(scene.shadowsEnabled,tier!=='low');assert.equal(visualQuality().reflection,reflection);
      if(tier==='low')assert.equal(model.paint.reflectionTexture,null);
    }
  }finally{chassis.dispose();scene.dispose();engine.dispose();setVisualQuality('medium');}
});
