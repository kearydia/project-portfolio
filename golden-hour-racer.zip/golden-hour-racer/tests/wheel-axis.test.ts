import test from 'node:test';
import assert from 'node:assert/strict';
import {NullEngine,Scene,MeshBuilder,Vector3} from '../src/engine/babylon';
import {carModel} from '../src/scene/car';
import {vehicleEffects} from '../src/scene/effects';
import type {PrototypeVehicle} from '../src/physics/world';

test('rolling display wheels preserve their axle and rotate the tread',()=>{
 const engine=new NullEngine(),scene=new Scene(engine);
 const mesh=MeshBuilder.CreateBox('chassis',{},scene),model=carModel(scene,mesh,'#edb940');
 const car={mesh,nitro:1,recovery:0,speed:40,grounded:true,presentation:{boost:false,brake:false},aggregate:{body:{getLinearVelocity:()=>new Vector3(0,0,10)}}} as unknown as PrototypeVehicle;
 vehicleEffects(scene,car,model);
 const directions=()=>model.wheels.map(w=>{w.computeWorldMatrix(true);return {axle:w.getDirection(Vector3.Up()).normalize(),tread:w.getDirection(Vector3.Right()).normalize()};});
 const before=directions();
 for(let frame=0;frame<20;frame++){
  mesh.position.z+=.01;
  scene.onBeforeRenderObservable.notifyObservers(scene);
  directions().forEach((v,i)=>assert.ok(Vector3.Dot(v.axle,before[i].axle)>.999999,'wheel axle must not tumble'));
 }
 directions().forEach((v,i)=>assert.ok(Vector3.Dot(v.tread,before[i].tread)<.99,'tread must visibly rotate'));
 mesh.dispose();assert.equal(scene.onBeforeRenderObservable.observers.filter(o=>!o._willBeUnregistered).length,0);
 scene.dispose();engine.dispose();
});
