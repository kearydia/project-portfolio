import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import HavokPhysics from '@babylonjs/havok';
import { verifyPhysics } from '../src/physics/verify';

test('real Havok WASM integration: gravity, contacts, driving and stability', async t => {
  const wasmBinary = await readFile(new URL('../node_modules/@babylonjs/havok/lib/esm/HavokPhysics.wasm', import.meta.url));
  const havok = await HavokPhysics({ wasmBinary: wasmBinary.buffer.slice(wasmBinary.byteOffset, wasmBinary.byteOffset + wasmBinary.byteLength) as ArrayBuffer });
  for (const check of verifyPhysics(havok)) {
    await t.test(check.name, () => assert.ok(check.pass, check.detail));
    console.log(`${check.name}: ${check.detail}`);
  }
});
