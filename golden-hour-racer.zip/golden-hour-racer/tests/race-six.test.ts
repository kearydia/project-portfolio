import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import HavokPhysics from '@babylonjs/havok';
import {NullEngine,Scene,Vector3,FreeCamera} from '../src/engine/babylon';import {Competition} from '../src/race/simulation';import {buildCircuit} from '../src/race/scenery';import {idleInput,PrototypeVehicle,enableWorld,staticBox,FIXED_DT} from '../src/physics/world';import {Driver,STYLES} from '../src/race/ai';import {circuit} from '../src/race/track';
const bytes=await readFile(new URL('../node_modules/@babylonjs/havok/lib/esm/HavokPhysics.wasm',import.meta.url));const havok=await HavokPhysics({wasmBinary:bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength) as ArrayBuffer});
function fixture(){const engine=new NullEngine(),scene=new Scene(engine),race=new Competition(scene,havok);buildCircuit(scene);return {engine,scene,race,dispose(){scene.dispose();engine.dispose();}};}
function placeTraffic(f:ReturnType<typeof fixture>,id:number,position:Vector3,velocity=Vector3.Zero()){
 f.race.cars[id].dispose();const car=new PrototypeVehicle(f.scene,position);car.aggregate.body.setLinearVelocity(velocity);f.race.cars[id]=car;
}
test('checkpoint reset rejects fast approaching traffic outside the static exclusion radius',()=>{const f=fixture();try{
 f.race.rules.advanceCountdown(3);f.race.rules.racers[0].lastGate=3;
 for(let i=1;i<6;i++)placeTraffic(f,i,new Vector3(500+i*15,.65,500));
 const s=circuit.gates[3];placeTraffic(f,1,circuit.sample(s-45).point.add(new Vector3(0,.65,0)),new Vector3(0,0,40));
 const original=f.race.cars[0],energy=original.nitro;assert.equal(f.race.resetPlayer(),null);assert.equal(f.race.cars[0],original);assert.equal(original.nitro,energy);assert.ok(!original.mesh.isDisposed());
 }finally{f.dispose();}});
test('all checkpoint reset sites stay on road and clear traffic; restored car remains stable',()=>{const f=fixture();try{
 f.race.rules.advanceCountdown(3);for(let i=1;i<6;i++)placeTraffic(f,i,new Vector3(500+i*15,.65,500));
 for(let gate=0;gate<circuit.gates.length;gate++){
 f.race.rules.racers[0].lastGate=gate;const car=f.race.resetPlayer();assert.ok(car);assert.ok(circuit.project(car.mesh.position).distance<4);assert.ok(f.race.cars.slice(1).every(other=>Vector3.Distance(car.mesh.position,other.mesh.position)>12));
 for(let tick=0;tick<60;tick++){car.step(idleInput());f.scene.getPhysicsEngine()!._step(FIXED_DT);}
 assert.ok(car.speed<1);assert.ok(car.mesh.position.y>.4&&car.mesh.position.y<1);assert.equal(car.recovery,0);
 } }finally{f.dispose();}});
test('vehicle bodies transfer collision momentum rather than passing through each other',()=>{
 const engine=new NullEngine(),scene=new Scene(engine);enableWorld(scene,havok);staticBox(scene,'floor',new Vector3(0,-.5,0),new Vector3(100,1,100));
 const a=new PrototypeVehicle(scene,new Vector3(0,.65,0)),b=new PrototypeVehicle(scene,new Vector3(0,.65,8));
 try{a.aggregate.body.setLinearVelocity(new Vector3(0,0,20));let minGap=Infinity,maxOtherSpeed=0;
 for(let i=0;i<120;i++){a.step(idleInput());b.step(idleInput());scene.getPhysicsEngine()!._step(FIXED_DT);minGap=Math.min(minGap,b.mesh.position.z-a.mesh.position.z);maxOtherSpeed=Math.max(maxOtherSpeed,b.speed);}
 console.log(JSON.stringify({collisionMinGap:minGap,transferredSpeed:maxOtherSpeed}));assert.ok(minGap>3.8);assert.ok(maxOtherSpeed>15);assert.ok(b.mesh.position.z>12);
 }finally{scene.dispose();engine.dispose();}
});
test('all six stay still before GO and every body, timer, energy freezes during pause',()=>{const f=fixture();try{const positions=f.race.cars.map(car=>car.mesh.position.clone());for(let i=0;i<179;i++)f.race.step({...idleInput(),throttle:1,boost:true},true);assert.equal(f.race.rules.phase,'countdown');for(let i=0;i<6;i++){assert.ok(f.race.cars[i].mesh.position.equals(positions[i]));assert.equal(f.race.cars[i].nitro,1);}f.race.step();assert.equal(f.race.rules.phase,'racing');for(let i=0;i<180;i++)f.race.step(idleInput(),true);f.race.rules.paused=true;const snapshot=()=>JSON.stringify({time:f.race.rules.time,cars:f.race.cars.map(car=>[car.mesh.position.asArray(),car.aggregate.body.getLinearVelocity().asArray(),car.nitro])});const frozen=snapshot();for(let i=0;i<180;i++)f.race.step(idleInput(),true);assert.equal(snapshot(),frozen);f.race.rules.paused=false;f.race.step(idleInput(),true);assert.notEqual(snapshot(),frozen);}finally{f.dispose();}});
test('six colliding cars complete two-lap race with five distinct decision styles',()=>{const f=fixture();try{
 // The player deliberately cruises slowly so all five AI must finish first without ending this race.
 f.race.drivers[0]=new Driver({...STYLES[1],straight:21,corner:5},0);
 let maxY=0,maxDistance=0;const begin=performance.now();
 for(let i=0;i<60*420&&f.race.rules.phase!=='finished';i++){f.race.step(idleInput(),true);for(const car of f.race.cars){maxY=Math.max(maxY,car.mesh.position.y);maxDistance=Math.max(maxDistance,circuit.project(car.mesh.position).distance);assert.ok(Number.isFinite(car.speed)&&car.mesh.position.y>0&&car.mesh.position.y<3);}}
 const result={stage:'six-car',elapsed:f.race.rules.time,wallMs:performance.now()-begin,maxY,maxDistance,collisions:f.race.collisions,cars:f.race.rules.racers.map((r,i)=>({name:r.name,laps:r.laps,finish:r.finishTime,invalid:r.invalidLaps,next:r.nextGate,position:f.race.cars[i].mesh.position.asArray(),recovery:f.race.drivers[i].recoveries,passes:f.race.drivers[i].overtakes}))};console.log(JSON.stringify(result));
 assert.equal(f.race.rules.phase,'finished');assert.ok(f.race.rules.racers.every(r=>r.finishTime!==null));assert.ok(f.race.rules.racers.every(r=>r.invalidLaps===0));assert.ok(maxDistance<9);assert.ok(f.race.drivers.every(d=>d.recoveries<4));
}finally{f.dispose();}});
test('reset preserves energy, refuses occupied area and invalidates player lap',()=>{const f=fixture();try{f.race.rules.advanceCountdown(3);assert.equal(f.race.resetPlayer(),null,'occupied starting grid must refuse reset');for(let i=0;i<600;i++)f.race.step(idleInput(),true);for(let i=0;i<600;i++)f.race.step({...idleInput(),brake:true});f.race.cars[0].nitro=.42;const old=f.race.cars[0];const reset=f.race.resetPlayer();assert.ok(reset);assert.equal(reset.nitro,.42);assert.equal(f.race.rules.racers[0].valid,false);assert.ok(old.mesh.isDisposed());assert.ok(f.race.cars.slice(1).every(car=>Vector3.Distance(car.mesh.position,reset.mesh.position)>10));}finally{f.dispose();}});
test('default validation grid completes with six physical updates per rendered frame',()=>{const f=fixture();new FreeCamera('test-camera',new Vector3(0,6,-20),f.scene);try{for(let i=0;i<60*240&&f.race.rules.phase!=='finished';i++){f.race.step(idleInput(),true);if(i%6===5)f.scene.render();}console.log(JSON.stringify({defaultGrid:f.race.rules.time,phase:f.race.rules.phase,invalid:f.race.rules.racers.map(r=>r.invalidLaps),recoveries:f.race.drivers.map(d=>d.recoveries)}));assert.equal(f.race.rules.phase,'finished');assert.ok(f.race.rules.racers.every(r=>r.invalidLaps===0));}finally{f.dispose();}});
test('repeated six-car circuit creation and disposal releases all scene resources',()=>{const engine=new NullEngine();try{for(let i=0;i<5;i++){const scene=new Scene(engine),race=new Competition(scene,havok);buildCircuit(scene);for(let tick=0;tick<240;tick++)race.step(idleInput(),true);assert.equal(engine.scenes.length,1);scene.dispose();assert.equal(engine.scenes.length,0);assert.equal(scene.meshes.length,0);assert.equal(scene.materials.length,0);assert.ok(race.cars.every(car=>car.mesh.isDisposed()));}}finally{engine.dispose();}});

