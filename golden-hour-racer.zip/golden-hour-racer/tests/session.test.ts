import test from 'node:test';
import assert from 'node:assert/strict';
import { Session } from '../src/game/session';
import { NullEngine, Scene } from '../src/engine/babylon';
import { createGarage } from '../src/scene/garage';
test('real garage scenes release meshes, materials and engine scene references on 20 visits',()=>{
 const engine=new NullEngine();const session=new Session();let meshCount=0;
 for(let i=0;i<20;i++){const scene=new Scene(engine);session.own(()=>scene.dispose());createGarage(scene);if(i===0)meshCount=scene.meshes.length;assert.equal(scene.meshes.length,meshCount);assert.equal(engine.scenes.length,1);session.clear();assert.equal(engine.scenes.length,0);assert.equal(scene.meshes.length,0);assert.equal(scene.materials.length,0);}
 engine.dispose();
});
test('scene session cancels listeners and disposes each resource exactly once across 50 switches',()=>{
 const session=new Session();let disposed=0;
 for(let i=0;i<50;i++){const signal=session.signal;session.own(()=>disposed++);session.clear();assert.equal(signal.aborted,true);assert.equal(session.signal.aborted,false);}
 session.clear();assert.equal(disposed,50);
});
