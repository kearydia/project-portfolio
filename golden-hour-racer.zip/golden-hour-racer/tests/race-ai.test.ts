import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
import HavokPhysics from '@babylonjs/havok';import {NullEngine,Scene,Vector3} from '../src/engine/babylon';import {PrototypeVehicle,enableWorld,FIXED_DT} from '../src/physics/world';import {circuit} from '../src/race/track';import {RaceRules} from '../src/race/rules';import {buildCircuit} from '../src/race/scenery';import {Driver} from '../src/race/ai';
const buffer=await readFile(new URL('../node_modules/@babylonjs/havok/lib/esm/HavokPhysics.wasm',import.meta.url));const havok=await HavokPhysics({wasmBinary:buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.byteLength) as ArrayBuffer});
test('one AI completes original circuit using real Havok and existing controller',()=>{
 const engine=new NullEngine(),scene=new Scene(engine);enableWorld(scene,havok);buildCircuit(scene);const spawn=circuit.sample(-10);const car=new PrototypeVehicle(scene,spawn.point.add(new Vector3(0,.65,0)),spawn.yaw);car.surface=p=>circuit.onRoad(p);const driver=new Driver();const rules=new RaceRules(circuit,[RaceRules.racer(0,'AI',car.mesh.position)],1);rules.advanceCountdown(3);
 let maxDistance=0,maxY=0;
 try{for(let i=0;i<60*240&&rules.phase!=='finished';i++){car.step(driver.input(car,[car]));scene.getPhysicsEngine()!._step(FIXED_DT);rules.update([car.mesh.position],FIXED_DT);maxDistance=Math.max(maxDistance,circuit.project(car.mesh.position).distance);maxY=Math.max(maxY,car.mesh.position.y);assert.ok(Number.isFinite(car.speed)&&car.mesh.position.y>0&&car.mesh.position.y<3);}
 console.log(JSON.stringify({stage:'one-ai',length:circuit.length,time:rules.time,laps:rules.racers[0].laps,next:rules.racers[0].nextGate,invalid:rules.racers[0].invalidLaps,position:car.mesh.position.asArray(),maxDistance,maxY,recoveries:driver.recoveries}));assert.equal(rules.phase,'finished');assert.equal(rules.racers[0].invalidLaps,0);assert.ok(maxDistance<9);
 }finally{scene.dispose();engine.dispose();}
});
test('displaced AI physically steers back onto its route without resetting',()=>{
 const engine=new NullEngine(),scene=new Scene(engine);enableWorld(scene,havok);buildCircuit(scene);
 const spawn=circuit.sample(80,9.2);const car=new PrototypeVehicle(scene,spawn.point.add(new Vector3(0,.65,0)),spawn.yaw-.4);car.surface=p=>circuit.onRoad(p);const driver=new Driver();
 try{for(let i=0;i<60*20;i++){const before=car.mesh.position.clone();const input=driver.input(car,[car]);assert.ok(car.mesh.position.equals(before),'decision must not teleport');car.step(input);scene.getPhysicsEngine()!._step(FIXED_DT);}
 const projection=circuit.project(car.mesh.position);console.log(JSON.stringify({rejoin:projection.s,distance:projection.distance,recoveries:driver.recoveries}));assert.ok(projection.s>200);assert.ok(projection.distance<4);
 }finally{scene.dispose();engine.dispose();}
});
