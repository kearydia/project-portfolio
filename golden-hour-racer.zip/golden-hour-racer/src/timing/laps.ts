import {Vector3} from '../engine/babylon';
import {RaceRules} from '../race/rules';
import {circuit} from '../race/track';
export interface LapBoundary {time:number;fraction:number;completed?:{time:number;valid:boolean}}
/** Timing-only strict wrong-way validation; race/career rules remain unchanged. */
export class LapTimer {
 readonly rules:RaceRules;reason='';private reverseTravel=0;
 constructor(position:Vector3){this.rules=new RaceRules(circuit,[RaceRules.racer(0,'计时车',position)],Infinity);}
 get state(){return this.rules.racers[0];}
 get current(){return this.state.started?this.rules.time-this.state.lapStart:0;}
 invalidate(reason:string,position=this.state.previous){this.rules.invalidate(0,position);this.reason=reason;}
 advance(position:Vector3,dt:number):LapBoundary|undefined{
  if(this.rules.paused||this.rules.phase!=='racing')return;
  const r=this.state,start=this.rules.time,oldStart=r.lapStart,started=r.started,count=r.attempts.length;
  const tangent=circuit.sample(circuit.project(r.previous).s).tangent;
  const along=Vector3.Dot(position.subtract(r.previous),tangent);
  if(r.started&&along<-.0001)this.reverseTravel-=along;
  if(r.started&&this.reverseTravel>.1)this.invalidate('逆向行驶，本圈无效');
  this.rules.update([position],dt);
  if(!r.valid&&!this.reason)this.reason='越界、跳点或路线违规，本圈无效';
  if((!started&&r.started)||r.lapStart!==oldStart){this.reason='';this.reverseTravel=0;return {time:r.lapStart,fraction:Math.max(0,Math.min(1,(r.lapStart-start)/dt)),completed:r.attempts.length>count?{...r.attempts.at(-1)!}:undefined};}
 }
}
