import {CARS,PAINTS,UPGRADES,stock,type Setup} from '../career/data';
import {carUnlocked,tier,type Progress,type ProgressStore} from '../career/progress';
import {configKey,recordIssue,type GhostRecord,type TrialConfig} from './recording';
export interface TrialData {version:1;selected:number;setups:Setup[];paints:string[];assists:TrialConfig['assists'];records:GhostRecord[]}
const fresh=():TrialData=>({version:1,selected:0,setups:CARS.map(()=>stock()),paints:CARS.map(()=>PAINTS[0]),assists:{abs:true,tcs:true,esc:true},records:[]});
export class TrialLibrary {
 onAttempt?:(lap:{time:number;valid:boolean},config:TrialConfig)=>void;
 data=fresh();messages:string[]=[];warning='';private blocked=false;
 constructor(private store?:ProgressStore<TrialData>){try{
  const raw=store?.load() as TrialData;if(raw===undefined||raw===null)return;
  if(raw.version!==1||!Array.isArray(raw.records)||raw.records.length>20||!Array.isArray(raw.setups)||!Array.isArray(raw.paints))throw Error('计时存档版本或格式不兼容');
  this.data.selected=Number.isInteger(raw.selected)&&raw.selected>=0&&raw.selected<5?raw.selected:0;
  this.data.setups=this.data.setups.map((s,i)=>{for(const k of UPGRADES){const v=raw.setups[i]?.[k];s[k]=Number.isInteger(v)?Math.max(0,Math.min(3,v)):0;}return s;});
  this.data.paints=this.data.paints.map((_,i)=>PAINTS.includes(raw.paints[i])?raw.paints[i]:PAINTS[0]);
  for(const k of ['abs','tcs','esc'] as const)if(typeof raw.assists?.[k]==='boolean')this.data.assists[k]=raw.assists[k];
  for(const r of raw.records){const issue=recordIssue(r);if(issue){this.messages.push(issue);continue;}const prior=this.best(r.config);if(!prior)this.data.records.push(structuredClone(r));else if(r.duration<prior.duration)this.data.records[this.data.records.indexOf(prior)]=structuredClone(r);}
 }catch{this.blocked=true;this.warning='计时存档读取失败或版本不兼容；幽灵已停用，未覆盖原数据。';}}
 normalize(progress:Progress){if(!carUnlocked(progress,this.data.selected))this.data.selected=0;for(const s of this.data.setups)for(const k of UPGRADES)s[k]=Math.min(s[k],tier(progress,k));}
 config():TrialConfig{return {car:this.data.selected,setup:{...this.data.setups[this.data.selected]},assists:{...this.data.assists}};}
 best(config:TrialConfig){return this.data.records.find(r=>configKey(r.config)===configKey(config));}
 other(config:TrialConfig){return this.data.records.filter(r=>configKey(r.config)!==configKey(config)).sort((a,b)=>a.duration-b.duration)[0];}
 commit(record:GhostRecord|undefined,valid:boolean){if(!valid||!record||recordIssue(record))return false;const previous=this.best(record.config);if(previous&&record.duration>=previous.duration-1e-7)return false;if(!previous&&this.data.records.length>=20){this.warning='已达20种配置记录上限，本圈未覆盖已有最佳；完整记录管理尚未实现。';return false;}if(previous)this.data.records[this.data.records.indexOf(previous)]=structuredClone(record);else this.data.records.push(structuredClone(record));this.save();return true;}
 save(){if(this.blocked)return;try{this.store?.save(structuredClone(this.data));this.warning='';}catch{this.warning='计时记录保存失败，仅本次会话保留；刷新可能丢失。';}}
}
