import {Quaternion,Vector3} from '../engine/babylon';
import {CARS,UPGRADES,type Setup} from '../career/data';
export const TRACK_VERSION='corona-coast-1';
export const PHYSICS_VERSION='arcade-stage4-1';
export const RECORD_VERSION=1;
export const MAX_LAP_SECONDS=600;
export interface TrialConfig {car:number;setup:Setup;assists:{abs:boolean;tcs:boolean;esc:boolean}}
export interface Sample {t:number;p:[number,number,number];q:[number,number,number,number];speed:number;nitro:number}
export interface GhostRecord {version:number;track:string;physics:string;config:TrialConfig;duration:number;samples:Sample[]}
export function configKey(c:TrialConfig){return [c.car,...UPGRADES.map(k=>c.setup[k]),Number(c.assists.abs),Number(c.assists.tcs),Number(c.assists.esc)].join(':');}
export function configValid(c:TrialConfig){return !!c&&Number.isInteger(c.car)&&c.car>=0&&c.car<CARS.length&&!!c.setup&&UPGRADES.every(k=>Number.isInteger(c.setup[k])&&c.setup[k]>=0&&c.setup[k]<=3)&&!!c.assists&&['abs','tcs','esc'].every(k=>typeof c.assists[k as keyof typeof c.assists]==='boolean');}
export function interpolate(a:Sample,b:Sample,t:number):Sample{
 const f=b.t===a.t?0:Math.max(0,Math.min(1,(t-a.t)/(b.t-a.t)));
 const p=Vector3.Lerp(Vector3.FromArray(a.p),Vector3.FromArray(b.p),f);
 const q=Quaternion.Slerp(Quaternion.FromArray(a.q),Quaternion.FromArray(b.q),f).normalize();
 return {t,p:p.asArray() as Sample['p'],q:q.asArray() as Sample['q'],speed:a.speed+(b.speed-a.speed)*f,nitro:a.nitro+(b.nitro-a.nitro)*f};
}
export function recordIssue(value:unknown):string{
 const r=value as GhostRecord;
 if(!r||r.version!==RECORD_VERSION)return '幽灵数据版本不兼容，已停用';
 if(r.track!==TRACK_VERSION)return '赛道版本不兼容，已停用幽灵';
 if(r.physics!==PHYSICS_VERSION)return '车辆物理版本不兼容，已停用幽灵';
 if(!configValid(r.config)||!Number.isFinite(r.duration)||r.duration<1||r.duration>MAX_LAP_SECONDS||!Array.isArray(r.samples)||r.samples.length<2||r.samples.length>12003)return '幽灵元数据无效，已停用';
 let previous:Sample|undefined;
 for(const s of r.samples){
  if(!s||!Number.isFinite(s.t)||!Array.isArray(s.p)||s.p.length!==3||!Array.isArray(s.q)||s.q.length!==4||!s.p.every(n=>Number.isFinite(n)&&Math.abs(n)<2000)||!s.q.every(Number.isFinite)||Math.abs(Math.hypot(...s.q)-1)>.01||!Number.isFinite(s.speed)||s.speed<0||s.speed>400||!Number.isFinite(s.nitro)||s.nitro<0||s.nitro>1)return '幽灵采样数据损坏，已停用';
  if(previous){const dt=s.t-previous.t;if(dt<=0||dt>.12||Vector3.Distance(Vector3.FromArray(s.p),Vector3.FromArray(previous.p))>dt*110+.1)return '幽灵时间或位置不连续，已停用';}
  previous=s;
 }
 if(Math.abs(r.samples[0].t)>1e-8||Math.abs(r.samples.at(-1)!.t-r.duration)>1e-6)return '幽灵起终点时间不完整，已停用';
 return '';
}
export class Recorder {
 private samples:Sample[]=[];private startTime=0;
 get count(){return this.samples.length;}
 start(sample:Sample){this.startTime=sample.t;this.samples=[{...structuredClone(sample),t:0}];}
 discard(){this.samples=[];}
 push(sample:Sample){if(!this.samples.length)return;const t=sample.t-this.startTime;if(t>MAX_LAP_SECONDS)return;if(t-this.samples.at(-1)!.t>=.05-1e-8)this.samples.push({...structuredClone(sample),t});}
 finish(sample:Sample,config:TrialConfig):GhostRecord|undefined{
  if(!this.samples.length)return;const duration=sample.t-this.startTime;
  if(duration>MAX_LAP_SECONDS){this.discard();return;}
  const end={...structuredClone(sample),t:duration};if(duration>this.samples.at(-1)!.t+1e-8)this.samples.push(end);else this.samples[this.samples.length-1]=end;
  const record:GhostRecord={version:RECORD_VERSION,track:TRACK_VERSION,physics:PHYSICS_VERSION,config:structuredClone(config),duration,samples:this.samples};this.samples=[];return record;
 }
}
export function replay(record:GhostRecord,t:number):Sample|undefined{
 if(!Number.isFinite(t)||t<0||t>record.duration)return;
 let lo=0,hi=record.samples.length-1;
 while(lo+1<hi){const mid=(lo+hi)>>1;if(record.samples[mid].t<=t)lo=mid;else hi=mid;}
 return interpolate(record.samples[lo],record.samples[hi],t);
}
