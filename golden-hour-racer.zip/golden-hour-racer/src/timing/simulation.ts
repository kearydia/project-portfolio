import type {HavokPhysicsWithBindings} from '@babylonjs/havok';
import {Scene,Vector3} from '../engine/babylon';
import {PrototypeVehicle,enableWorld,FIXED_DT,type DriveInput} from '../physics/world';
import {handling} from '../career/data';
import {circuit} from '../race/track';
import {LapTimer} from './laps';
import {Recorder,interpolate,replay,MAX_LAP_SECONDS,type TrialConfig,type Sample,type GhostRecord} from './recording';
import {TrialLibrary} from './library';
export class TimeTrial {
 car:PrototypeVehicle;readonly timer:LapTimer;readonly recorder=new Recorder();readonly config:TrialConfig;
 ghostRecord:GhostRecord|undefined;ended=false;lastMessage='';
 constructor(readonly scene:Scene,havok:HavokPhysicsWithBindings,config:TrialConfig,readonly library:TrialLibrary){
  this.config=structuredClone(config);enableWorld(scene,havok);scene.physicsEnabled=false;
  const spawn=circuit.sample(-10);this.car=new PrototypeVehicle(scene,spawn.point.add(new Vector3(0,.65,0)),spawn.yaw,handling(config.car,config.setup));this.prepare();this.timer=new LapTimer(this.car.mesh.position);this.ghostRecord=library.best(config);
 }
 private prepare(){this.car.surface=p=>circuit.onRoad(p);this.car.assists={...this.config.assists};}
 snapshot():Sample{return {t:this.timer.rules.time,p:this.car.mesh.position.asArray() as Sample['p'],q:this.car.mesh.rotationQuaternion!.asArray() as Sample['q'],speed:this.car.speed,nitro:this.car.nitro};}
 step(input:DriveInput){
  const rules=this.timer.rules;if(this.ended||rules.paused)return;
  if(rules.phase==='countdown'){rules.advanceCountdown(FIXED_DT);return;}
  if(JSON.stringify(this.car.assists)!==JSON.stringify(this.config.assists)){this.timer.invalidate('辅助配置改变，本圈无效');this.recorder.discard();this.car.assists={...this.config.assists};}
  const before=this.snapshot();this.car.step(input);this.scene.getPhysicsEngine()!._step(FIXED_DT);
  const boundary=this.timer.advance(this.car.mesh.position,FIXED_DT);const after=this.snapshot();
  if(boundary){const crossing=interpolate(before,after,boundary.time);
   if(boundary.completed){this.library.onAttempt?.(boundary.completed,this.config);const record=this.recorder.finish(crossing,this.config);const improved=this.library.commit(record,boundary.completed.valid);this.lastMessage=improved?'新的同配置个人最佳！':boundary.completed.valid?'有效圈完成，个人最佳未改变':'无效圈，未更新个人最佳';}
   this.recorder.start(crossing);this.ghostRecord=this.library.best(this.config);
  }
  if(this.timer.current>MAX_LAP_SECONDS){this.timer.invalidate('超过10分钟录制上限，本圈不计最佳');this.recorder.discard();}
  if(this.timer.state.valid)this.recorder.push(after);else this.recorder.discard();
 }
 reset(){if(this.ended||this.timer.rules.paused||this.timer.rules.phase!=='racing')return null;
  const point=circuit.sample(circuit.gates[this.timer.state.lastGate]-5),old=this.car;
  this.car=new PrototypeVehicle(this.scene,point.point.add(new Vector3(0,.65,0)),point.yaw,old.handling);this.car.nitro=old.nitro;this.prepare();old.dispose();
  this.timer.invalidate('安全复位，本圈无效',this.car.mesh.position);this.recorder.discard();return this.car;
 }
 ghost(){return !this.ended&&this.timer.state.started&&this.timer.state.valid&&this.ghostRecord?replay(this.ghostRecord,this.timer.current):undefined;}
 stop(){this.ended=true;this.recorder.discard();}
}
