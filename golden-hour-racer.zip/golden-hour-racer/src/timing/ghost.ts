import {Scene,MeshBuilder,StandardMaterial,Color3,Quaternion,Vector3} from '../engine/babylon';import type {Sample} from './recording';
/** Pure visual meshes: no PhysicsAggregate, AI, raycast shape, or race participant. */
export function createGhost(scene:Scene){
 const material=new StandardMaterial('ghost-translucent',scene);material.diffuseColor=new Color3(.35,.85,1);material.emissiveColor=new Color3(.06,.2,.3);material.alpha=.3;material.disableDepthWrite=true;
 const body=MeshBuilder.CreateBox('personal-best-ghost',{width:1.9,height:.65,depth:4.2},scene);body.material=material;body.isPickable=false;body.checkCollisions=false;
 const cabin=MeshBuilder.CreateBox('ghost-cabin',{width:1.55,height:.65,depth:1.8},scene);cabin.parent=body;cabin.position.set(0,.6,-.1);cabin.material=material;cabin.isPickable=false;cabin.checkCollisions=false;body.setEnabled(false);
 return {body,update(sample:Sample|undefined){body.setEnabled(!!sample);if(sample){body.position.copyFrom(Vector3.FromArray(sample.p));body.rotationQuaternion=Quaternion.FromArray(sample.q);}},dispose(){body.dispose(false,false);material.dispose();}};
}
