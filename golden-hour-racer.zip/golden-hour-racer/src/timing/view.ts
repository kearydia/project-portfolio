import {audioTelemetry} from '../settings/telemetry';
import {Driver} from '../race/ai';
import type {HavokPhysicsWithBindings} from '@babylonjs/havok';
import {Engine,Scene,FreeCamera,Vector3} from '../engine/babylon';import {FIXED_DT} from '../physics/world';import {createControls} from '../input/controls';import {dressCar} from '../scene/provingGround';import {buildCircuit} from '../race/scenery';import {circuit} from '../race/track';import {CARS} from '../career/data';
import {TimeTrial} from './simulation';import {TrialLibrary} from './library';import {createGhost} from './ghost';
const el=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const time=(n:number)=>`${Math.floor(n/60).toString().padStart(2,'0')}:${(n%60).toFixed(3).padStart(6,'0')}`;
export async function showTimeTrial(engine:Engine,havok:HavokPhysicsWithBindings,signal:AbortSignal,own:(cleanup:()=>void)=>void,library:TrialLibrary,actions:{retry:()=>void;setup:()=>void;garage:()=>void},validation=false){
 const scene=new Scene(engine);let hud:HTMLElement|undefined;let ghost:ReturnType<typeof createGhost>|undefined;
 const oldAssists=(['abs','tcs','esc'] as const).map(k=>({k,checked:el<HTMLInputElement>(k).checked,disabled:el<HTMLInputElement>(k).disabled}));
 own(()=>{ghost?.dispose();scene.dispose();hud?.remove();for(const id of ['drive-check','endurance','endurance-result','drive-result'])el(id).hidden=false;for(const s of oldAssists){el<HTMLInputElement>(s.k).checked=s.checked;el<HTMLInputElement>(s.k).disabled=s.disabled;}});
 const config=library.config(),trial=new TimeTrial(scene,havok,config,library),environment=buildCircuit(scene),paint=library.data.paints[config.car];
 dressCar(scene,trial.car.mesh,environment.material,environment.shadows,paint,config.car,trial.car);ghost=createGhost(scene);
 const controls=createControls(signal);const camera=new FreeCamera('timing-camera',new Vector3(0,5,-22),scene);camera.minZ=.1;camera.maxZ=1600;
 hud=document.createElement('section');hud.id='timing-ui';hud.innerHTML=`<section class="race-summary timing-summary"><span class="eyebrow">日冕海岸 · 单人计时</span><h2 id="tt-current">00:00.000</h2><p id="tt-best"></p><p id="tt-validity"></p><p id="tt-gates"></p><p id="tt-message"></p><p id="tt-record-status"></p><button id="tt-end">结束本次计时</button><button id="tt-retry">重新发车</button><button id="tt-settings">计时设置</button><button id="tt-garage">返回车库</button><h3 id="tt-history-title">逐圈成绩</h3><ol id="tt-history"></ol></section><div id="race-countdown"></div><p class="race-mode">${CARS[config.car].name} · 幽灵无碰撞 · 车漆不影响成绩分组</p>`;document.querySelector('#app')!.append(hud);
 el('drive-ui').hidden=false;el('intro').hidden=true;el('pause-screen').hidden=true;el('pause').textContent='暂停';
 for(const s of oldAssists){el<HTMLInputElement>(s.k).checked=config.assists[s.k];el<HTMLInputElement>(s.k).disabled=true;}
 for(const id of ['drive-check','endurance','endurance-result','drive-result'])el(id).hidden=true;
 el('runtime').textContent='单车 Havok V2 / 固定60Hz计时 / 20Hz真实轨迹 / 幽灵仅显示';el('loading-status').textContent='单人计时 · 不影响生涯';
 let accumulator=0,uiTime=0,ghostFrames=0;const pilot=validation?new Driver():undefined;
 if(validation){const note=document.createElement("p");note.id="tt-validation";note.textContent="自动验证：真实物理驾驶，两圈后停止；临时记录不保存";hud.prepend(note);}
 const pause=(paused:boolean)=>{if(trial.ended)return;trial.timer.rules.paused=paused;controls.clear();accumulator=0;el('pause-screen').hidden=!paused;el('pause').textContent=paused?'继续':'暂停';};
 const reset=()=>{controls.clear();const old=[trial.car.mesh,...trial.car.mesh.getChildMeshes()];const car=trial.reset();if(car){for(const mesh of old)environment.shadows.removeShadowCaster(mesh,false);dressCar(scene,car.mesh,environment.material,environment.shadows,paint,config.car,car);}};
 el('pause').onclick=()=>pause(!trial.timer.rules.paused);el('resume').onclick=()=>pause(false);el('reset').onclick=reset;
 el('tt-retry').onclick=actions.retry;el('tt-settings').onclick=actions.setup;el('tt-garage').onclick=actions.garage;
 el('tt-end').onclick=()=>{trial.stop();controls.clear();el('pause-screen').hidden=true;el('tt-history-title').textContent='本次计时结算 · 未完成圈不保存';};
 addEventListener('keydown',e=>{if(e.code==='Escape')pause(!trial.timer.rules.paused);if(e.code==='KeyR')reset();},{signal});document.addEventListener('visibilitychange',()=>{if(document.hidden)pause(true);},{signal});
 await scene.whenReadyAsync();if(signal.aborted)return;
 engine.runRenderLoop(()=>{
  const dt=Math.min(engine.getDeltaTime()/1000,.1),rules=trial.timer.rules;
  if(!rules.paused&&!trial.ended){accumulator+=validation?2:dt;while(accumulator+1e-10>=FIXED_DT){trial.step(pilot?pilot.input(trial.car,[trial.car]):controls.read());if(validation&&trial.timer.state.laps>=2){trial.stop();el("tt-history-title").textContent="自动验证结束 · 临时成绩";}accumulator-=FIXED_DT;}
   trial.car.mesh.computeWorldMatrix(true);const forward=trial.car.mesh.getDirection(Vector3.Forward()),focus=trial.car.mesh.position.add(new Vector3(0,1,0));let wanted=trial.car.mesh.position.subtract(forward.scale(10+trial.car.speed/60)).add(new Vector3(-trial.car.steering,5,0));const hit=scene.getPhysicsEngine()!.raycast(focus,wanted,{ignoreBody:trial.car.aggregate.body});if(hit.hasHit)wanted=hit.hitPointWorld.add(hit.hitNormalWorld.scale(.5));camera.position=Vector3.Lerp(camera.position,wanted,1-Math.exp(-dt*5));camera.setTarget(focus.add(forward.scale(5)));camera.fov+=(.85+Math.min(trial.car.speed/800,.2)-camera.fov)*(1-Math.exp(-dt*3));
  }
  const sample=trial.ghost();audioTelemetry(trial.car);ghost!.update(sample);if(sample&&!rules.paused)ghostFrames++;scene.render();uiTime+=dt;if(uiTime<.1)return;uiTime=0;
  const state=trial.timer.state,best=library.best(config);
  if(validation)el('tt-validation').textContent=`自动验证 · 每帧2秒真实物理步 · 临时记录不保存 · 有效圈 ${state.laps}/2 · 无效圈 ${state.attempts.filter(a=>!a.valid).length} · 幽灵显示帧 ${ghostFrames} · 录制点 ${best?.samples.length??0} · ${trial.ended?'结束':'真实物理驾驶中'}`;
  el('race-countdown').textContent=rules.phase==='countdown'?String(Math.ceil(rules.countdown)):rules.time<.8?'GO':'';
  el('tt-current').textContent=time(trial.timer.current);el('tt-best').textContent='同配置最佳：'+(best?time(best.duration):'暂无');el('tt-gates').textContent=`检查点 ${state.nextGate+1}/${circuit.gates.length} · 有效圈 ${state.laps}`;
  el('tt-validity').textContent=trial.ended?'计时结束':trial.timer.reason||(!state.started?'正向通过起点开始计圈':state.valid?'当前圈有效':'当前圈无效');el('tt-message').textContent=trial.lastMessage;
  el('tt-record-status').textContent=library.warning||library.messages.join('；')||(trial.ghostRecord?'已载入同配置个人最佳幽灵':'暂无同配置幽灵；其他配置不参与比较');
  el('tt-history').replaceChildren(...(trial.ended?state.attempts:state.attempts.slice(-12)).map((lap,i)=>{const li=document.createElement('li');li.textContent=`圈 ${(trial.ended?0:Math.max(0,state.attempts.length-12))+i+1} · ${time(lap.time)} · ${lap.valid?'有效':'无效'}`;return li;}));
  el('speed').textContent=Math.round(trial.car.speed).toString().padStart(3,'0');el('gear').textContent=trial.car.speed<1?'N':trial.car.gear<0?'R':`D${trial.car.gear}`;el('nitro-value').textContent=`${Math.round(trial.car.nitro*100)}%`;el('nitro-bar').style.width=`${trial.car.nitro*100}%`;el('assist-state').textContent=trial.car.offTrack?'越界 · 当前圈无效':`接地 ${trial.car.contacts}/4`;el('fps').textContent=`${Math.round(engine.getFps())} FPS`;
  el('live-physics').textContent=`计时时钟 ${rules.time.toFixed(3)}s · 单车场景 ${engine.scenes.length} · 轨迹采样 ${trial.recorder.count} · ${rules.paused?'暂停':trial.ended?'结束':'运行'}`;
  el('checks').replaceChildren();const li=document.createElement('li');li.textContent=`玩家 ${trial.car.mesh.position.asArray().map(n=>n.toFixed(3)).join(',')} / ${trial.car.speed.toFixed(3)}km/h / 氮气 ${trial.car.nitro.toFixed(4)} / 幽灵无刚体`;el('checks').append(li);
 });
}



