// Explicit entry points keep unused Babylon subsystems out of the mobile build.
import '@babylonjs/core/Physics/v2/physicsEngineComponent';
import '@babylonjs/core/Physics/joinedPhysicsEngineComponent';
import '@babylonjs/core/Lights/Shadows/shadowGeneratorSceneComponent';
export { Engine } from '@babylonjs/core/Engines/engine';
export { NullEngine } from '@babylonjs/core/Engines/nullEngine';
export { Scene } from '@babylonjs/core/scene';
export { Vector3, Quaternion } from '@babylonjs/core/Maths/math.vector';
export { Color3, Color4 } from '@babylonjs/core/Maths/math.color';
export { FreeCamera } from '@babylonjs/core/Cameras/freeCamera';
export { MeshBuilder } from '@babylonjs/core/Meshes/meshBuilder';
export { Mesh } from '@babylonjs/core/Meshes/mesh';
export { StandardMaterial } from '@babylonjs/core/Materials/standardMaterial';
export { HemisphericLight } from '@babylonjs/core/Lights/hemisphericLight';
export { DirectionalLight } from '@babylonjs/core/Lights/directionalLight';
export { ShadowGenerator } from '@babylonjs/core/Lights/Shadows/shadowGenerator';
export { HavokPlugin } from '@babylonjs/core/Physics/v2/Plugins/havokPlugin';
export { PhysicsAggregate } from '@babylonjs/core/Physics/v2/physicsAggregate';
export { PhysicsShapeType } from '@babylonjs/core/Physics/v2/IPhysicsEnginePlugin';
