import {setVisualQuality,applySceneQuality} from './scene/quality';
import {installResolution} from './scene/resolution';
import {audioTelemetry} from './settings/telemetry';
import {Vault} from './storage/vault';
import {Sound} from './settings/audio';
import {settingsPanel} from './settings/ui';
import {applyLayout} from './settings/data';
const vault=await Vault.open().catch(error=>{document.body.textContent='IndexedDB 无法打开，未覆盖已有存档。请检查浏览器存储权限后刷新：'+String(error);throw error;});await vault.init(()=>({career:jsonStore('golden-hour-career-v1').load(),timing:jsonStore('golden-hour-timing-v1').load()}));
import {TrialLibrary,type TrialData} from './timing/library';
import {timingSetup} from './timing/setup';
import {showTimeTrial} from './timing/view';
import {jsonStore} from './career/progress';
const timingLibrary=new TrialLibrary(vault.store('timing'));
import {Career,browserStore,openEvent} from './career/progress';
import {careerPanel} from './career/ui';
import {EVENTS} from './career/data';
import {raceOptions,raceResult} from './career/race';
import {Color3,StandardMaterial} from './engine/babylon';
timingLibrary.onAttempt=(lap,config)=>{vault.data.history.push({mode:'timing',time:lap.time,valid:lap.valid,config});vault.data.history=vault.data.history.slice(-1000);void vault.save();};
const career=new Career(vault.store('career'));let careerEvent=0;
import { showCompetition } from './race/view';
import { Session } from './game/session';
import { createGarage } from './scene/garage';
import './style.css';
import { Engine, Scene, Vector3, FreeCamera } from './engine/babylon';
import HavokPhysics from '@babylonjs/havok';
import wasmUrl from '@babylonjs/havok/lib/esm/HavokPhysics.wasm?url';
import { enableWorld, FIXED_DT, PrototypeVehicle, idleInput } from './physics/world';
import { verifyPhysics } from './physics/verify';
import { createProvingGround, dressCar } from './scene/provingGround';
import { createControls } from './input/controls';

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
  <header><a class="wordmark" href="./" aria-label="黄金时刻首页"><span class="emblem">G<span>/</span>H</span><span>GOLDEN HOUR<small>黄金时刻 · 赛车</small></span></a><span class="build">DEVELOPMENT BUILD <b>00.01</b></span><button id="diagnostics-toggle" class="quiet">系统检查 <span id="health">●</span></button></header>
  <aside class="location"><span class="eyebrow">SUNSET PROVING GROUND</span><h2>落日试车场</h2><p><span class="live-dot"></span> 自由驾驶 · 物理原型</p></aside>
  <section id="intro" class="intro"><p class="eyebrow">CHASE THE LAST LIGHT</p><h1>逐光而行<span>GOLDEN HOUR</span></h1><p class="lead">引擎就绪，驶向最后一道金色地平线。</p><div class="tag-row"><span>原创试验车型 GH–01</span><span>封闭试车环线</span></div><button id="start" class="primary" disabled>正在加载物理引擎…</button><p class="prototype-note">自由试驾 · 生涯请返回菜单进入</p></section>
  <section id="diagnostics" class="panel" hidden><div class="panel-title"><h2>物理与比赛诊断</h2><button id="close-diagnostics" class="quiet">关闭</button></div><p id="runtime">初始化中</p><ul id="checks"></ul><button id="drive-check" class="secondary" disabled>运行场景驱动自检（3 秒）</button><button id="endurance" class="secondary">连续三圈验证</button><p id="endurance-result">自动沿测试环线行驶，仅供验证。</p><p id="live-physics"></p><p id="drive-result">自检会将车辆放回发车位并自动向前行驶。</p><p class="fine">四点弹簧阻尼悬挂；街机抗侧翻约束。Q/倒车键倒车。</p><label><input id="abs" type="checkbox" checked>ABS</label> <label><input id="tcs" type="checkbox" checked>TCS</label> <label><input id="esc" type="checkbox" checked>ESC</label></section>
  <section id="error" class="panel error" hidden role="alert"><h2>引擎启动失败</h2><p id="error-message"></p><p>请使用支持 WebGL 2 与 WebAssembly SIMD 的现代浏览器。iOS 建议 16.4 或以上。</p><button id="retry" class="primary">重新加载</button></section>
  <div id="drive-ui" hidden><nav class="race-actions"><button id="pause" class="quiet">暂停</button><button id="reset" class="quiet">复位 R</button></nav><div class="assist"><span class="live-dot"></span><span id="assist-state">稳定辅助开启</span></div><div class="telemetry"><div class="speed-line"><strong id="speed">000</strong><span>KM/H<br><b id="gear">N</b></span></div><div class="nitro-label"><span>N₂O / 氮气</span><span id="nitro-value">100%</span></div><div class="nitro-track"><i id="nitro-bar"></i></div></div><div class="touch-controls"><div class="steering"><button data-control="left" aria-label="向左转">◀</button><button data-control="right" aria-label="向右转">▶</button></div><div class="pedals"><button data-control="drift" class="small">漂移</button><button data-control="boost" class="small boost">氮气</button><button data-control="reverse" class="small">倒车</button><button data-control="brake" class="brake">刹车</button><button data-control="throttle" class="gas">油门</button></div></div></div>
  <div id="pause-screen" class="pause-screen" hidden><p class="eyebrow">TAKE A BREATH</p><h2>已暂停</h2><button id="resume" class="primary">继续驾驶</button></div>
  <footer><span id="loading-status">BABYLON.JS / HAVOK · 加载中</span><span class="keyboard-hint">WASD / 方向键驾驶 &nbsp; SPACE 漂移 &nbsp; SHIFT 氮气 &nbsp; Q 倒车</span><span id="fps">— FPS</span></footer><div class="rotate-notice">↻<span>横过手机，视野更开阔<small>本原型以横屏驾驶为优先</small></span></div>`;

const element = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
element('retry').onclick = () => location.reload();
element('diagnostics-toggle').onclick = () => { element('diagnostics').hidden = !element('diagnostics').hidden; };
element('close-diagnostics').onclick = () => { element('diagnostics').hidden = true; };

const session = new Session();
let engine: Engine;
let busy = false;
let target: 'race'|'garage'|'competition'|'validation'|'career'|'event'|'timing-setup'|'timing'|'timing-check' = 'race';
let cachedHavok: Awaited<ReturnType<typeof HavokPhysics>> | undefined;
const menu = document.createElement('section');menu.id='main-menu';menu.className='menu-panel';
menu.innerHTML='<h1>黄金时刻</h1><p>GOLDEN HOUR · 阶段 7</p><button data-route="competition">开始比赛 · 日冕海岸</button><button data-route="race">自由试驾 · 保留试车场</button><button data-route="validation">六车自动验证赛 · 不记录成绩</button><button data-route="career">继续生涯 · 8 关</button><button data-route="timing-setup">单人计时 · 个人最佳</button><button data-route="timing-check">计时与幽灵自动验证 · 不保存成绩</button><button data-route="garage">车库</button><button data-info="设置">设置 · 音频与触控</button><button data-info="存档管理">存档管理 · 备份与导入</button><p id="menu-info">请选择模式</p>';
document.querySelector('#app')!.append(menu);
const back=document.createElement('button');back.textContent='返回主菜单';back.className='global-back';document.querySelector('#app')!.append(back);
const loading=document.createElement('section');loading.className='panel';loading.id='stage-loading';loading.hidden=true;loading.innerHTML='<h2>正在准备场景</h2><p id="stage-progress" role="status"></p>';document.querySelector('#app')!.append(loading);
function progress(text:string){element('stage-progress').textContent=text;}
function leave(){session.clear();engine?.stopRenderLoop();busy=false;menu.hidden=false;loading.hidden=true;for(const id of ['intro','drive-ui','pause-screen','diagnostics','error'])element(id).hidden=true;element('drive-check').onclick=null;element('start').onclick=null;for(const id of ['pause','resume','reset','endurance'])element(id).onclick=null;element('loading-status').textContent='主菜单 · 请选择模式';}
back.onclick=leave;
menu.querySelectorAll<HTMLButtonElement>('[data-route]').forEach(b=>b.onclick=()=>void enter(b.dataset.route as 'race'|'garage'|'competition'|'validation'|'career'|'event'|'timing-setup'|'timing'|'timing-check'));
let closeSettings:(()=>void)|undefined;
const sound=new Sound(()=>vault.data.settings);
let syncResolution:ReturnType<typeof installResolution>|undefined;
const quality=()=>{const tier=vault.data.settings.quality;setVisualQuality(tier);syncResolution?.(tier);engine?.scenes.forEach(applySceneQuality);};
menu.querySelectorAll<HTMLButtonElement>('[data-info]').forEach(b=>b.onclick=()=>{closeSettings?.();closeSettings=settingsPanel(vault,sound,quality);});
addEventListener('pointerdown',()=>void sound.unlock().catch(()=>{}));
addEventListener('keydown',()=>void sound.unlock().catch(()=>{}));
const saveBanner=document.createElement('p');saveBanner.className='save-banner';document.body.append(saveBanner);
setInterval(()=>{saveBanner.textContent=vault.status;sound.tick();},100);
applyLayout(vault.data.settings);
for(const k of ['abs','tcs','esc'] as const){element<HTMLInputElement>(k).checked=vault.data.settings.assists[k];element<HTMLInputElement>(k).addEventListener('change',()=>{vault.data.settings.assists[k]=element<HTMLInputElement>(k).checked;void vault.save();});}
element('retry').onclick=()=>void enter(target);
async function enter(route:'race'|'garage'|'competition'|'validation'|'career'|'event'|'timing-setup'|'timing'|'timing-check'){
 if(busy)return;leave();busy=true;target=route;menu.hidden=true;loading.hidden=false;
 const signal=session.signal;
 try{
 progress('阶段 1/3：初始化渲染器');
 if(!engine){const canvas=element<HTMLCanvasElement>('game');engine=new Engine(canvas,true);syncResolution=installResolution(engine,canvas);}quality();
 if(route==='garage'||route==='career'||route==='timing-setup'){
 const scene=new Scene(engine);let removePanel:(()=>void)|undefined;session.own(()=>{removePanel?.();scene.dispose();});if(route==='timing-setup'){timingLibrary.normalize(career.progress);const updateCar=createGarage(scene,timingLibrary.data.paints[timingLibrary.data.selected],timingLibrary.data.selected);removePanel=timingSetup(career.progress,timingLibrary,()=>void enter('timing'),color=>{updateCar(color,timingLibrary.data.selected);});}else{const updateCar=createGarage(scene,career.progress.paints[career.progress.selected],career.progress.selected);removePanel=careerPanel(career,route==='career'?'career':'garage',id=>{careerEvent=id;void enter('event');},color=>{updateCar(color,career.progress.selected);});}progress('阶段 3/3：等待车库材质就绪');await scene.whenReadyAsync();if(signal.aborted)return;
 engine.runRenderLoop(()=>scene.render());element('loading-status').textContent='车库 · 车辆 / 升级 / 生涯';
 }else{await boot(signal,route==='competition'||route==='validation'||route==='event',route==='validation',route==='event',route==='timing'||route==='timing-check',route==='timing-check');}
 if(signal.aborted)return;loading.hidden=true;busy=false;
 }catch(error){if(signal.aborted)return;session.clear();engine?.stopRenderLoop();loading.hidden=true;busy=false;element('error').hidden=false;element('error-message').textContent=String(error);}
}
async function boot(signal:AbortSignal,competition=false,validation=false,careerRace=false,timeTrial=false,timingCheck=false) {
  const canvas = element<HTMLCanvasElement>('game');

  quality();
  const started = performance.now();
  if(!cachedHavok){
    progress('阶段 2/3：下载物理资源');
    const response=await fetch(wasmUrl,{signal});if(!response.ok)throw new Error('WASM HTTP '+response.status);
    const total=Number(response.headers.get('content-length'));const reader=response.body!.getReader();const chunks:Uint8Array[]=[];let bytes=0;
    for(;;){const {done,value}=await reader.read();if(done)break;chunks.push(value);bytes+=value.length;progress('阶段 2/3：WASM '+bytes+' 字节'+(total?' / '+total+' ('+Math.round(bytes/total*100)+'%)':''));}
    const binary=new Uint8Array(bytes);let offset=0;for(const chunk of chunks){binary.set(chunk,offset);offset+=chunk.length;}
    progress('阶段 2/3：编译物理引擎');const initialized=await HavokPhysics({wasmBinary:binary.buffer});if(signal.aborted)return;cachedHavok=initialized;
  }
  const havok=cachedHavok;
  const wasmMs = performance.now() - started;
  const checks = verifyPhysics(havok);
  element('checks').replaceChildren(...checks.map(check => { const li = document.createElement('li');li.className = check.pass ? 'pass' : 'fail';li.textContent = `${check.pass ? '✓' : '✕'} ${check.name} — ${check.detail}`;return li; }));
  if(checks.some(check => !check.pass)) throw new Error('物理集成测试未通过；请打开系统检查查看失败项。');
  if(timeTrial){timingLibrary.normalize(career.progress);progress('阶段 3/3：准备独立计时场景');await showTimeTrial(engine,havok,signal,cleanup=>session.own(cleanup),timingCheck?new TrialLibrary():timingLibrary,{retry:()=>void enter(timingCheck?'timing-check':'timing'),setup:()=>void enter('timing-setup'),garage:()=>void enter('garage')},timingCheck);return;}
  if(competition){progress('阶段 3/3：准备日冕海岸与六辆赛车');if(careerRace&&!openEvent(career.progress,careerEvent))throw Error('关卡未解锁');const event=careerEvent;await showCompetition(engine,havok,signal,cleanup=>session.own(cleanup),validation,careerRace?{laps:EVENTS[event].laps,options:raceOptions(event,career.progress),finish:race=>{const result=raceResult(event,race);vault.data.history.push(structuredClone(result));vault.data.history=vault.data.history.slice(-1000);return career.settle(result);},notice:()=>career.warning,retry:()=>void enter('event'),garage:()=>void enter('garage')}:undefined);return;}
  const scene = new Scene(engine);
  session.own(()=>scene.dispose());
  progress('阶段 3/3：构建试车场');
  enableWorld(scene, havok);
  // A render-independent accumulator drives exactly the same 60 Hz Havok steps as the test suite.
  scene.physicsEnabled = false;
  const environment = createProvingGround(scene);
  const spawn = new Vector3(54, 1.5, 0);
  let vehicle: PrototypeVehicle;
  const reset = () => { if(vehicle){environment.shadows.removeShadowCaster(vehicle.mesh,true);vehicle.dispose();} const energy=vehicle?.nitro ?? 1; vehicle = new PrototypeVehicle(scene, spawn);vehicle.nitro=energy;vehicle.surface=p=>{const inner=p.x*p.x/(46*46)+p.z*p.z/(77*77);const outer=p.x*p.x/(62*62)+p.z*p.z/(93*93);return inner>=1&&outer<=1;};dressCar(scene,vehicle.mesh,environment.material,environment.shadows,'#edb940',0,vehicle); };
  reset();
  const camera = new FreeCamera('chase-camera',new Vector3(64,7,-13),scene);camera.minZ=0.1;camera.maxZ=1000;camera.fov=0.85;scene.activeCamera=camera;
  const controls = createControls(signal);
  let driving = false, paused = false, accumulator = 0, pilotRemaining = 0, pilotStart: Vector3 | null = null;
  let endurance=false, loopProgress=0, previousAngle=0, enduranceTime=0, elapsed=0, maxHeight=0, impacts=0, previousRecovery=0;
  const cancelPilot = () => { endurance=false; if(pilotRemaining>0) element('drive-result').textContent='自检已取消，请重新运行。';pilotRemaining=0;element<HTMLButtonElement>('drive-check').disabled=false; };
  const setPaused = (value: boolean) => { paused=value;controls.clear();accumulator=0;element('pause-screen').hidden=!value;element('pause').textContent=value?'继续':'暂停'; };
  const start = () => {driving=true;element('intro').hidden=true;element('drive-ui').hidden=false;controls.clear();};
  element<HTMLButtonElement>('start').disabled=false;element('start').textContent='驶入试车场 ↗';element('start').onclick=start;
  element('pause').onclick = () => setPaused(!paused);
  element('resume').onclick = () => setPaused(false);
  element('reset').onclick = () => { cancelPilot();reset();controls.clear(); };
  addEventListener('keydown',e=>{if(e.code==='KeyR'&&driving) {cancelPilot();reset();controls.clear();} if(e.code==='Escape'&&driving)setPaused(!paused);},{signal});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&driving)setPaused(true);},{signal});
  element<HTMLButtonElement>('drive-check').disabled=false;
  element('drive-check').onclick=()=>{reset();start();setPaused(false);pilotRemaining=3;pilotStart=spawn.clone();element('drive-result').textContent='场景驱动自检运行中…';element<HTMLButtonElement>('drive-check').disabled=true;};
  element('endurance').onclick=()=>{cancelPilot();reset();start();setPaused(false);endurance=true;loopProgress=0;previousAngle=0;enduranceTime=0;maxHeight=0;element('endurance-result').textContent='连续三圈运行中…';};
  element('loading-status').textContent='引擎就绪 / HAVOK V2';element('health').className='healthy';
  element('runtime').textContent=`Babylon.js ${Engine.Version} · WebGL ${engine.webGLVersion} · WASM ${wasmMs.toFixed(0)}ms · ${checks.length}/${checks.length} 项通过`;
  await scene.whenReadyAsync();if(signal.aborted)return;
  start();
  let frames=0;
  engine.runRenderLoop(()=>{
    const dt=Math.min(engine.getDeltaTime()/1000,0.1);
    if(!paused) {
      accumulator+=dt;
      while(accumulator>=FIXED_DT) {
        let input=pilotRemaining>0?{...idleInput(),throttle:1}:driving?controls.read():idleInput();
        elapsed+=FIXED_DT;
        if(endurance){
          const p=vehicle.mesh.position;const angle=Math.atan2(p.z/85,p.x/54);let delta=angle-previousAngle;delta=Math.atan2(Math.sin(delta),Math.cos(delta));loopProgress+=delta;previousAngle=angle;enduranceTime+=FIXED_DT;maxHeight=Math.max(maxHeight,p.y);
          const aim=new Vector3(54*Math.cos(angle+0.2),p.y,85*Math.sin(angle+0.2)).subtract(p);const forward=vehicle.mesh.getDirection(Vector3.Forward());let error=Math.atan2(aim.x,aim.z)-Math.atan2(forward.x,forward.z);error=Math.atan2(Math.sin(error),Math.cos(error));
          input={...idleInput(),throttle:vehicle.speed<48?1:0,brake:vehicle.speed>55,steer:Math.max(-1,Math.min(1,error*2.4))};
          if(loopProgress>=Math.PI*6||enduranceTime>300||p.y<0||p.y>3){endurance=false;input=idleInput();element('endurance-result').textContent=(loopProgress>=Math.PI*6?'通过':'失败')+'：'+(loopProgress/(2*Math.PI)).toFixed(3)+' 圈 / '+enduranceTime.toFixed(2)+'s / 最大高度 '+maxHeight.toFixed(3)+'m';}
          else element('endurance-result').textContent='运行中：'+(loopProgress/(2*Math.PI)).toFixed(3)+' 圈 / '+enduranceTime.toFixed(1)+'s';
        }
        for(const name of ['abs','tcs','esc'] as const)vehicle.assists[name]=element<HTMLInputElement>(name).checked;
        vehicle.step(input);
        if(vehicle.recovery>previousRecovery)impacts++;previousRecovery=vehicle.recovery;
        scene.getPhysicsEngine()!._step(FIXED_DT);
        accumulator-=FIXED_DT;
        if(pilotRemaining>0) {
          pilotRemaining-=FIXED_DT;
          if(pilotRemaining<=0) { const distance=Vector3.Distance(vehicle.mesh.position,pilotStart!);const pass=distance>15&&vehicle.speed>30;element('drive-result').textContent=`${pass?'通过':'失败'}：实际场景行驶 ${distance.toFixed(2)}m，车速 ${vehicle.speed.toFixed(1)}km/h`;element<HTMLButtonElement>('drive-check').disabled=false; }
        }
      }
      const forward=vehicle.mesh.getDirection(Vector3.Forward());
      const wanted=vehicle.mesh.position.subtract(forward.scale(10+vehicle.speed/60)).add(new Vector3(-vehicle.steering*1.2,5,0));
      const focus=vehicle.mesh.position.add(new Vector3(0,1,0));
      const obstruction=scene.getPhysicsEngine()!.raycast(focus,wanted,{ignoreBody:vehicle.aggregate.body});
      if(obstruction.hasHit)wanted.copyFrom(obstruction.hitPointWorld.add(obstruction.hitNormalWorld.scale(0.5)));
      camera.fov+=(0.85+Math.min(vehicle.speed/800,0.2)-camera.fov)*(1-Math.exp(-dt*3));
      camera.position=Vector3.Lerp(camera.position,wanted,1-Math.exp(-dt*5));camera.setTarget(vehicle.mesh.position.add(forward.scale(5)).add(new Vector3(0,1,0)));
      if(vehicle.mesh.position.y < -10) reset();
    }
    audioTelemetry(vehicle);scene.render();
    if(++frames%6===0) {
      element('live-physics').textContent='模拟时间 '+elapsed.toFixed(3)+'s · 位置 '+vehicle.mesh.position.asArray().map(n=>n.toFixed(3)).join(',')+' · 速度 '+vehicle.speed.toFixed(3)+' · 氮气 '+vehicle.nitro.toFixed(4)+' · 严重撞击 '+impacts+' · 恢复 '+vehicle.recovery.toFixed(2)+'s';
      const speed=vehicle.speed;element('speed').textContent=Math.round(speed).toString().padStart(3,'0');element('gear').textContent=speed<1?'N':vehicle.gear<0?'R':`D${vehicle.gear}`;
      element('nitro-value').textContent=`${Math.round(vehicle.nitro*100)}%`;element('nitro-bar').style.width=`${vehicle.nitro*100}%`;
      element('fps').textContent=`${Math.round(engine.getFps())} FPS`;element('assist-state').textContent=controls.read().drift?'漂移 · 低抓地力':vehicle.grounded?(vehicle.recovery>0?'撞击恢复中':vehicle.offTrack?'驶离路面 · 减速':'接地 '+vehicle.contacts+'/4'):'腾空 · 等待落地';
    }
  });

}
leave();





