import { Vector3 } from '../engine/babylon';

export const TRACK_NAME = '日冕海岸 · Corona Coast';
export const HALF_WIDTH = 9;
const knots = [[0,0],[0,120],[0,240],[30,295],[110,315],[200,280],[235,220],[210,160],[150,115],[165,60],[235,15],[270,-35],[240,-65],[185,-50],[140,-90],[125,-165],[65,-210],[0,-170],[0,-85]];
const cat = (a:number,b:number,c:number,d:number,t:number) => 0.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
export interface Projection { index:number; fraction:number; distance:number; s:number; point:Vector3; tangent:Vector3; lateral:number }
export class Circuit {
  readonly points:Vector3[]=[];
  readonly distances:number[]=[0];
  readonly length:number;
  readonly gates:number[]=[];
  constructor(){
    const raw:Vector3[]=[];
    for(let i=0;i<knots.length;i++)for(let j=0;j<40;j++){
      const a=knots[(i+knots.length-1)%knots.length],b=knots[i],c=knots[(i+1)%knots.length],d=knots[(i+2)%knots.length],t=j/40;
      raw.push(new Vector3(cat(a[0],b[0],c[0],d[0],t),0,cat(a[1],b[1],c[1],d[1],t)));
    }
    // Resample uniformly so gate density and curvature are independent of control knot spacing.
    let total=0;const cumulative=[0];for(let i=0;i<raw.length;i++){total+=Vector3.Distance(raw[i],raw[(i+1)%raw.length]);cumulative.push(total);}
    const count=Math.ceil(total/4);let segment=0;
    for(let i=0;i<count;i++){const s=i/count*total;while(cumulative[segment+1]<s)segment++;this.points.push(Vector3.Lerp(raw[segment],raw[(segment+1)%raw.length],(s-cumulative[segment])/(cumulative[segment+1]-cumulative[segment])));}
    for(let i=0;i<this.points.length;i++)this.distances.push(this.distances[i]+Vector3.Distance(this.points[i],this.points[(i+1)%this.points.length]));
    this.length=this.distances.at(-1)!;
    for(let i=0;i<this.points.length;i+=6)this.gates.push(this.distances[i]);
  }
  sample(distance:number,offset=0){
    const s=((distance%this.length)+this.length)%this.length;
    let lo=0,hi=this.points.length-1;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(this.distances[mid]<=s)lo=mid;else hi=mid-1;}
    const a=this.points[lo],b=this.points[(lo+1)%this.points.length];const tangent=b.subtract(a).normalize();
    const point=Vector3.Lerp(a,b,(s-this.distances[lo])/(this.distances[lo+1]-this.distances[lo]));
    return {point:point.add(new Vector3(tangent.z,0,-tangent.x).scale(offset)),tangent,yaw:Math.atan2(tangent.x,tangent.z)};
  }
  project(position:Vector3):Projection{
    let best:Projection|undefined;
    for(let i=0;i<this.points.length;i++){
      const a=this.points[i],b=this.points[(i+1)%this.points.length],v=b.subtract(a),len=v.lengthSquared();
      const t=Math.max(0,Math.min(1,Vector3.Dot(position.subtract(a),v)/len));const point=a.add(v.scale(t));
      const distance=Math.hypot(position.x-point.x,position.z-point.z);
      if(!best||distance<best.distance){const tangent=v.normalize();best={index:i,fraction:t,distance,s:this.distances[i]+t*Math.sqrt(len),point,tangent,lateral:(position.x-point.x)*tangent.z-(position.z-point.z)*tangent.x};}
    }
    return best!;
  }
  curvature(s:number){const a=this.sample(s-6).tangent,b=this.sample(s+6).tangent;return Math.acos(Math.max(-1,Math.min(1,Vector3.Dot(a,b))))/12;}
  onRoad(p:Vector3){return this.project(p).distance<=HALF_WIDTH;}
}
export const circuit=new Circuit();
