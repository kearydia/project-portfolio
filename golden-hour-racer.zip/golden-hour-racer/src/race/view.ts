import {CARS} from '../career/data';
import {audioTelemetry} from '../settings/telemetry';
import type {HavokPhysicsWithBindings} from '@babylonjs/havok';
import {Engine,Scene,FreeCamera,Vector3} from '../engine/babylon';
import {FIXED_DT} from '../physics/world';import {createControls} from '../input/controls';import {dressCar} from '../scene/provingGround';
import {Competition,type CompetitionOptions} from './simulation';import {buildCircuit} from './scenery';import {circuit,TRACK_NAME} from './track';

const colors=['#edb940','#dd6958','#82b4a0','#658cc6','#bd92c6','#e4ddd0'];
const element=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const formatTime=(seconds:number)=>`${Math.floor(seconds/60).toString().padStart(2,'0')}:${(seconds%60).toFixed(2).padStart(5,'0')}`;

export async function showCompetition(engine:Engine,havok:HavokPhysicsWithBindings,signal:AbortSignal,own:(dispose:()=>void)=>void,validation=false,career?:{laps:number;options:CompetitionOptions;finish:(race:Competition)=>string[];notice?:()=>string;retry:()=>void;garage:()=>void}){
  const scene=new Scene(engine);
  let hud:HTMLElement|undefined;
  own(()=>{scene.dispose();hud?.remove();for(const id of ['drive-check','endurance','endurance-result','drive-result'])element(id).hidden=false;});
  const competition=new Competition(scene,havok,career?.laps??2,career?.options),environment=buildCircuit(scene);
  competition.cars.forEach((car,i)=>dressCar(scene,car.mesh,environment.material,environment.shadows,i===0?career?.options.paint??colors[0]:colors[i],Math.max(0,CARS.findIndex(c=>c.params.mass===car.mass)),car));
  const controls=createControls(signal);
  const camera=new FreeCamera('race-camera',new Vector3(-3,6,-25),scene);camera.minZ=.1;camera.maxZ=1600;camera.fov=.9;
  hud=document.createElement('section');hud.id='competition-ui';
  const poly=circuit.points.map(p=>`${p.x.toFixed(1)},${(-p.z).toFixed(1)}`).join(' ');
  hud.innerHTML=`<section class="race-summary"><span class="eyebrow">${TRACK_NAME} · ${(circuit.length/1000).toFixed(3)} KM</span><h2 id="race-position">P1 / 6</h2><p id="race-lap">第 1 / 2 圈</p><p id="race-time">00:00.00</p><p id="race-validity"></p><ol id="race-order"></ol></section><svg class="race-map" viewBox="-30 -345 340 590" aria-label="赛道及六辆赛车位置"><polyline points="${poly}" fill="none" stroke="#d1b882" stroke-width="8"/>${colors.map((color,i)=>`<circle id="race-dot-${i}" r="7" fill="${color}" stroke="#14272a" stroke-width="2"/>`).join('')}<circle id="next-gate-dot" r="10" fill="none" stroke="#fff" stroke-width="2"/></svg><div id="race-countdown" aria-live="polite"></div><p class="race-mode">${validation?'自动验证赛 · 玩家由同一驾驶器控制 · 不记录成绩':`${competition.laps} 圈比赛 · 依序通过检查点 · Q 倒车 / R 安全复位`}</p><section id="race-results" class="panel" hidden><h2>比赛完成</h2><p id="race-result-title"></p><ol id="race-result-list"></ol><p>未冲线车辆按有效圈数及已验证的赛道进度排名。</p></section>`;
  document.querySelector('#app')!.append(hud);
  element('drive-ui').hidden=false;element('intro').hidden=true;
  element('pause').textContent='暂停';element('pause-screen').hidden=true;
  for(const id of ['drive-check','endurance','endurance-result','drive-result'])element(id).hidden=true;
  element('runtime').textContent='六车共用 Havok V2 / 固定 60Hz / 全碰撞开启';
  element('loading-status').textContent=`${career?.options.name??'日冕海岸'} · ${competition.laps} 圈比赛`;
  let settled=false;
  const summary=document.createElement('div');element('race-results').append(summary);
  let accumulator=0,frameCount=0,uiElapsed=0,frameTotal=0,framesMeasured=0,worstFrame=0;
  const pause=(value:boolean)=>{if(competition.rules.phase==='finished')return;competition.rules.paused=value;controls.clear();accumulator=0;element('pause-screen').hidden=!value;element('pause').textContent=value?'继续':'暂停';};
  const reset=()=>{controls.clear();const oldMeshes=[competition.cars[0].mesh,...competition.cars[0].mesh.getChildMeshes()];const car=competition.resetPlayer();if(car){for(const mesh of oldMeshes)environment.shadows.removeShadowCaster(mesh,false);dressCar(scene,car.mesh,environment.material,environment.shadows,career?.options.paint??colors[0],Math.max(0,CARS.findIndex(c=>c.params.mass===car.mass)),car);}};
  element('pause').onclick=()=>pause(!competition.rules.paused);element('resume').onclick=()=>pause(false);element('reset').onclick=reset;
  addEventListener('keydown',e=>{if(e.code==='Escape')pause(!competition.rules.paused);if(e.code==='KeyR')reset();},{signal});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pause(true);},{signal});
  await scene.whenReadyAsync();if(signal.aborted)return;
  engine.runRenderLoop(()=>{
    const rawDt=engine.getDeltaTime()/1000,dt=Math.min(rawDt,.1);
    if(!competition.rules.paused){
      accumulator+=dt;
      while(accumulator+1e-10>=FIXED_DT){
        for(const name of ['abs','tcs','esc'] as const)competition.cars[0].assists[name]=element<HTMLInputElement>(name).checked;
        competition.step(controls.read(),validation);accumulator-=FIXED_DT;
      }
      const player=competition.cars[0];player.mesh.computeWorldMatrix(true);const forward=player.mesh.getDirection(Vector3.Forward()),focus=player.mesh.position.add(new Vector3(0,1,0));
      let wanted=player.mesh.position.subtract(forward.scale(10+player.speed/60)).add(new Vector3(-player.steering,5,0));
      const hit=scene.getPhysicsEngine()!.raycast(focus,wanted,{ignoreBody:player.aggregate.body});if(hit.hasHit)wanted=hit.hitPointWorld.add(hit.hitNormalWorld.scale(.5));
      camera.position=Vector3.Lerp(camera.position,wanted,1-Math.exp(-dt*5));camera.setTarget(focus.add(forward.scale(5)));camera.fov+=(.85+Math.min(player.speed/800,.2)-camera.fov)*(1-Math.exp(-dt*3));
    }
    scene.render();frameCount++;uiElapsed+=dt;
    if(competition.rules.phase==='racing'&&!competition.rules.paused){frameTotal+=rawDt;framesMeasured++;worstFrame=Math.max(worstFrame,rawDt);}
    if(uiElapsed<.1&&frameCount>1)return;uiElapsed=0;
    const rules=competition.rules,player=competition.cars[0],state=rules.racers[0],ranking=rules.ranking();
    element('race-countdown').textContent=rules.phase==='countdown'?String(Math.ceil(rules.countdown)):rules.phase==='racing'&&rules.time<.8?'GO':'';
    element('race-position').textContent=`P${ranking.findIndex(r=>r.id===0)+1} / 6`;
    element('race-lap').textContent=`第 ${Math.min(state.laps+1,competition.laps)} / ${competition.laps} 圈 · 检查点 ${state.nextGate+1}/${circuit.gates.length}`;
    element('race-time').textContent=formatTime(rules.time);
    element('race-validity').textContent=competition.resetMessage||(!state.valid?'当前圈无效 · 下一次过终点重新计圈':state.started?'有效圈计时中':'通过起点开始计圈');
    const items=ranking.map(r=>{const li=document.createElement('li');li.textContent=`${r.name}  ${r.finishTime!==null?formatTime(r.finishTime):`${r.laps} 圈 · ${Math.floor(r.progress)}m`}`;li.style.color=colors[r.id];return li;});element('race-order').replaceChildren(...items);
    for(let i=0;i<6;i++){const dot=document.getElementById('race-dot-'+i)!;dot.setAttribute('cx',competition.cars[i].mesh.position.x.toFixed(1));dot.setAttribute('cy',(-competition.cars[i].mesh.position.z).toFixed(1));}
    const next=circuit.sample(circuit.gates[state.nextGate]).point;document.getElementById('next-gate-dot')!.setAttribute('cx',String(next.x));document.getElementById('next-gate-dot')!.setAttribute('cy',String(-next.z));
    element('speed').textContent=Math.round(player.speed).toString().padStart(3,'0');element('gear').textContent=player.speed<1?'N':player.gear<0?'R':`D${player.gear}`;
    element('nitro-value').textContent=`${Math.round(player.nitro*100)}%`;element('nitro-bar').style.width=`${player.nitro*100}%`;element('fps').textContent=`${Math.round(engine.getFps())} FPS`;
    audioTelemetry(player);element('assist-state').textContent=player.offTrack?'驶离路面 · 本圈无效':player.recovery>0?'撞击恢复中':'接地 '+player.contacts+'/4';
    element('live-physics').textContent=`状态 ${rules.phase} · 比赛时间 ${rules.time.toFixed(3)}s · 场景 ${engine.scenes.length} · 采样均值 ${framesMeasured&&frameTotal?(framesMeasured/frameTotal).toFixed(1):'—'} FPS · 最长帧 ${(worstFrame*1000).toFixed(1)}ms`;
    element('checks').replaceChildren(...competition.cars.map((car,i)=>{const li=document.createElement('li');li.textContent=`${rules.racers[i].name}: ${car.mesh.position.asArray().map(n=>n.toFixed(2)).join(',')} / ${car.speed.toFixed(2)}km/h / N₂O ${car.nitro.toFixed(4)} / 撞击 ${competition.collisions[i]} / 恢复 ${competition.drivers[i].recoveries} / 无效圈 ${rules.racers[i].invalidLaps}`;return li;}));
    if(rules.phase==='finished'){
      if(!settled){settled=true;const rewards=career&&!validation?career.finish(competition):[];summary.innerHTML=`<p>最佳有效圈 ${state.lapTimes.length?formatTime(Math.min(...state.lapTimes)):'—'} · 无效圈 ${state.invalidLaps} · 复位 ${competition.resets} · 严重撞击 ${competition.collisions[0]}</p><ol>${state.attempts.map((lap,i)=>`<li>第 ${i+1} 次：${formatTime(lap.time)} ${lap.valid?'有效':'无效'}</li>`).join('')}</ol><p>${rewards.length?'新奖励：'+rewards.join(' / '):'没有新增奖励；可重赛补做挑战。'}</p><p>${career?.notice?.()??''}</p>`;if(career){for(const [label,action] of [['立即重赛',career.retry],['返回车库',career.garage]] as const){const button=document.createElement('button');button.textContent=label;button.onclick=action;summary.append(button);}}}

      element('race-results').hidden=false;element('race-result-title').textContent=`${validation?'自动验证完成':'你已完成规定圈数'} · 第 ${ranking.findIndex(r=>r.id===0)+1} 名 · ${formatTime(state.finishTime!)}`;
      element('race-result-list').replaceChildren(...ranking.map(r=>{const li=document.createElement('li');li.textContent=`${r.name} — ${r.finishTime!==null?formatTime(r.finishTime):`未冲线 / ${r.laps} 有效圈 / ${Math.floor(r.progress)}m`}`;return li;}));
    }
  });
}


