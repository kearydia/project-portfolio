import {Vector3} from '../engine/babylon';
import {PrototypeVehicle,idleInput,type DriveInput,FIXED_DT} from '../physics/world';
import {circuit,HALF_WIDTH} from './track';

export const STYLES=[
  {name:'进攻型',straight:30,corner:7.5,gap:9,pass:1,boost:35},
  {name:'稳健型',straight:26,corner:6.3,gap:15,pass:.5,boost:60},
  {name:'弯道型',straight:27,corner:8,gap:11,pass:.8,boost:55},
  {name:'直线型',straight:33,corner:6.5,gap:12,pass:.9,boost:25},
  {name:'均衡型',straight:29,corner:7,gap:12,pass:.7,boost:45},
];
export class Driver {
  lane=0;
  stuck=0;
  reverseTime=0;
  overtakes=0;
  recoveries=0;
  private elapsed=0;
  private passTime=0;
  private passLane=0;
  constructor(readonly style=STYLES[4],readonly id=0,readonly mistakePeriod=0){}
  input(car:PrototypeVehicle,others:PrototypeVehicle[],dt=FIXED_DT):DriveInput{
    car.mesh.computeWorldMatrix(true);
    const p=car.mesh.position,projection=circuit.project(p),speed=car.speed/3.6;
    const forward=car.mesh.getDirection(Vector3.Forward()),right=car.mesh.getDirection(Vector3.Right());
    const look=Math.min(22,9+speed*.55);
    this.elapsed+=dt;
    let targetSpeed=this.style.straight;
    for(let ahead=0;ahead<=75;ahead+=6){const curvature=circuit.curvature(projection.s+ahead);const cornerSpeed=Math.min(this.style.straight,Math.sqrt(this.style.corner/Math.max(.0001,curvature)));targetSpeed=Math.min(targetSpeed,Math.sqrt(cornerSpeed*cornerSpeed+2*7*Math.max(0,ahead-9)));}
    let lead:PrototypeVehicle|undefined,leadGap=Infinity;
    for(const other of others){if(other===car)continue;const rel=other.mesh.position.subtract(p),along=Vector3.Dot(rel,forward),side=Vector3.Dot(rel,right);if(along>0&&along<35&&Math.abs(side)<3.2&&along<leadGap){lead=other;leadGap=along;}}
    this.passTime=Math.max(0,this.passTime-dt);
    let desiredLane=this.passTime>0?this.passLane:0;
    if(lead&&leadGap<27&&car.speed>lead.speed-3){
      const candidateOrder=this.id%2?[3.5,-3.5]:[-3.5,3.5];
      if(this.passTime===0)for(const lane of candidateOrder){const safe=others.every(other=>{if(other===car)return true;const rel=other.mesh.position.subtract(p);return Math.abs(Vector3.Dot(rel,forward))>14||Math.abs(circuit.project(other.mesh.position).lateral-lane)>2.8;});if(safe&&circuit.curvature(projection.s+look)<.025){desiredLane=lane;this.passLane=lane;this.passTime=3;this.overtakes++;break;}}
      if(!desiredLane||leadGap<this.style.gap)targetSpeed=Math.min(targetSpeed,Math.max(0,lead.speed/3.6+(leadGap-this.style.gap)*.65));
    }
    this.lane+=(desiredLane-this.lane)*Math.min(1,dt*(1+this.style.pass));
    // A displaced car aims back inside the road. Never change body pose or velocities here.
    const target=circuit.sample(projection.s+look,this.lane).point;
    const difference=target.subtract(p);let error=Math.atan2(difference.x,difference.z)-Math.atan2(forward.x,forward.z);error=Math.atan2(Math.sin(error),Math.cos(error));
    if(projection.distance>HALF_WIDTH-2)targetSpeed=Math.min(targetSpeed,10);
    if(Math.abs(error)>1.1)targetSpeed=Math.min(targetSpeed,7);
    this.stuck=speed<1&&targetSpeed>2?this.stuck+dt:0;
    if(this.stuck>2.5&&this.reverseTime<=0){this.reverseTime=1.4;this.stuck=0;this.recoveries++;}
    if(this.reverseTime>0){this.reverseTime-=dt;return {...idleInput(),reverse:true,steer:-Math.sign(error)};}
    const hesitation=this.mistakePeriod>0&&(this.elapsed+this.id*3)%this.mistakePeriod<.7;
    const boost=!hesitation&&!lead&&targetSpeed>speed+4&&speed>13&&circuit.curvature(projection.s+this.style.boost)<.003&&Math.abs(error)<.1&&car.nitro>.35;
    return {...idleInput(),throttle:!hesitation&&speed<targetSpeed?1:0,brake:speed>targetSpeed+1,steer:Math.max(-1,Math.min(1,error*2.4)),boost};
  }
}
