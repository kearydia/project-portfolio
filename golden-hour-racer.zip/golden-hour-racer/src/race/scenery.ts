import {applySceneQuality} from '../scene/quality';
import {Scene,Vector3,Color3,Color4,MeshBuilder,Mesh,StandardMaterial,HemisphericLight,DirectionalLight,ShadowGenerator} from '../engine/babylon';
import {staticBox} from '../physics/world';
import {circuit,HALF_WIDTH} from './track';

export function buildCircuit(scene:Scene){
  const material=(name:string,color:string)=>{const found=scene.getMaterialByName(name);if(found)return found as StandardMaterial;const m=new StandardMaterial(name,scene);m.diffuseColor=Color3.FromHexString(color);m.specularColor.set(.08,.08,.08);return m;};
  const asphalt=material('circuit-asphalt','#303c42'),sand=material('runoff','#aa9679'),white=material('paint','#e5dfc4'),red=material('curb-red','#b95542');
  scene.clearColor=new Color4(.85,.65,.46,1);scene.fogMode=Scene.FOGMODE_EXP2;scene.fogDensity=.0012;scene.fogColor=new Color3(.85,.65,.46);
  new HemisphericLight('sky',Vector3.Up(),scene).intensity=.6;
  const sun=new DirectionalLight('sun',new Vector3(-.8,-.28,.5),scene);sun.position.set(100,150,-80);sun.intensity=.8;sun.diffuse=new Color3(1,.82,.6);
  const shadows=new ShadowGenerator(1024,sun);shadows.usePercentageCloserFiltering=true;shadows.darkness=.3;
  const ground=staticBox(scene,'circuit-foundation',new Vector3(130,-.5,40),new Vector3(1500,1,1500));ground.mesh.material=sand;ground.mesh.receiveShadows=true;
  const ribbon=(name:string,left:number,right:number,mat:StandardMaterial)=>{const paths=[left,right].map(offset=>Array.from({length:circuit.points.length+1},(_,i)=>circuit.sample(circuit.distances[i]??0,offset).point.add(new Vector3(0,.025,0))));const mesh=MeshBuilder.CreateRibbon(name,{pathArray:paths,sideOrientation:Mesh.DOUBLESIDE},scene);mesh.material=mat;mesh.receiveShadows=true;return mesh;};
  ribbon('racing-surface',-HALF_WIDTH,HALF_WIDTH,asphalt);
  ribbon('left-edge',-HALF_WIDTH,-HALF_WIDTH+.16,white);ribbon('right-edge',HALF_WIDTH-.16,HALF_WIDTH,white);
  const walls:Mesh[]=[],curbs:Mesh[]=[];
  for(let i=0;i<circuit.points.length;i++){
    if(i%3===0)for(const side of [-1,1]){
      const s=circuit.distances[i],next=circuit.distances[Math.min(i+3,circuit.points.length)];
      const a=circuit.sample(s,side*(HALF_WIDTH+2)).point,b=circuit.sample(next,side*(HALF_WIDTH+2)).point;
      const wall=staticBox(scene,'circuit-barrier',Vector3.Center(a,b).add(new Vector3(0,.75,0)),new Vector3(.7,1.5,Vector3.Distance(a,b)+.5),Math.atan2(b.x-a.x,b.z-a.z));wall.mesh.material=white;walls.push(wall.mesh);
    }
    if(i%2===0)for(const side of [-1,1]){const s=circuit.distances[i],a=circuit.sample(s,side*(HALF_WIDTH+.4)),m=MeshBuilder.CreateBox('curb',{width:.8,height:.08,depth:4},scene);m.position=a.point.add(new Vector3(0,.04,0));m.rotation.y=a.yaw;m.material=red;curbs.push(m);}
  }
  // Merge visible wall geometry, keeping the hidden source meshes as real static physics bodies.
  const wallVisual=Mesh.MergeMeshes(walls,false,true);if(wallVisual){wallVisual.name='merged-barriers';for(const wall of walls)wall.isVisible=false;}
  Mesh.MergeMeshes(curbs,true,true);
  for(let x=-9;x<9;x++)for(let z=0;z<2;z++){const tile=MeshBuilder.CreateBox('finish-checker',{width:1,height:.025,depth:1},scene);tile.position.set(x+.5,.05,z-.5);tile.material=(x+z)%2===0?white:asphalt;}
  const poleMaterial=material('gate-post','#495a5d');
  for(let g=0;g<circuit.gates.length;g++)for(const side of [-1,1]){const gate=circuit.sample(circuit.gates[g],side*9.8);const post=MeshBuilder.CreateBox('checkpoint-post',{width:.2,height:1.8,depth:.2},scene);post.position=gate.point.add(new Vector3(0,.9,0));post.material=poleMaterial;}
  for(const s of circuit.gates.filter(s=>circuit.curvature(s+35)>.025&&circuit.curvature(s)<.015)){
    for(let d=0;d<3;d++){const mark=circuit.sample(s-d*7);const strip=MeshBuilder.CreateBox('braking-zone',{width:16,height:.02,depth:.3},scene);strip.position=mark.point.add(new Vector3(0,.06,0));strip.rotation.y=mark.yaw;strip.material=red;}
  }
  for(let i=0;i<6;i++){const s=-10-Math.floor(i/2)*8,offset=i%2?3:-3,grid=circuit.sample(s,offset);const slot=MeshBuilder.CreateBox('grid-box',{width:2.5,height:.02,depth:5},scene);slot.position=grid.point.add(new Vector3(0,.06,0));slot.rotation.y=grid.yaw;slot.material=white;}
  for(let i=0;i<18;i++){const t=i/18*Math.PI*2,h=30+(i%5)*10;const m=MeshBuilder.CreateCylinder('ridge',{diameterTop:0,diameterBottom:100,height:h,tessellation:5},scene);m.position.set(130+Math.cos(t)*550,h/2,50+Math.sin(t)*550);m.material=material('ridge','#9b8676');}
  const gantry=MeshBuilder.CreateBox('finish-gantry',{width:23,height:1,depth:1},scene);gantry.position.set(0,7,0);gantry.material=red;
  // Batch static, purely visual markers by material and nearby section. Physics walls and gates stay independent.
  const batch=(name:string,size:number)=>{
    const groups=new Map<StandardMaterial,Mesh[]>();
    for(const m of scene.meshes)if(m.name===name&&m instanceof Mesh&&m.material instanceof StandardMaterial){
      const group=groups.get(m.material)??[];group.push(m);groups.set(m.material,group);
    }
    for(const group of groups.values())for(let i=0;i<group.length;i+=size){
      const merged=Mesh.MergeMeshes(group.slice(i,i+size),true,true);if(merged)merged.name=name+'-batch';
    }
  };
  batch('finish-checker',36);batch('checkpoint-post',16);batch('ridge',6);
  const disc=MeshBuilder.CreateSphere('sun-disc',{diameter:38,segments:24},scene);disc.position.set(520,130,-220);disc.material=material('sun-glow','#ffcb80');(disc.material as StandardMaterial).emissiveColor=new Color3(1,.65,.25);
  const structures:Mesh[]=[];
  for(let i=0;i<4;i++)for(let row=0;row<5;row++){const seat=MeshBuilder.CreateBox('grandstand-tier',{width:35,height:.6,depth:2},scene);seat.position.set(-35-row*2,1+row*.65,65+i*42);seat.rotation.y=Math.PI/2;seat.material=material('stand-seats',i%2?'#334d59':'#a56347');structures.push(seat);}
  const stands=Mesh.MergeMeshes(structures,true,true,undefined,false,true);if(stands){stands.receiveShadows=true;stands.freezeWorldMatrix();}
  for(const m of scene.meshes)if(!m.physicsBody&&m.name!=='prototype-chassis'&&!m.parent)m.freezeWorldMatrix();
  applySceneQuality(scene);
  return {material,shadows};
}

