import {BASE,type Handling} from '../career/data';
export interface CompetitionOptions {grid?:number;player?:Handling;opponents?:Handling[];styles?:typeof STYLES;mistakePeriod?:number;name?:string;paint?:string}
import {Scene,Vector3} from '../engine/babylon';
import type {HavokPhysicsWithBindings} from '@babylonjs/havok';
import {PrototypeVehicle,enableWorld,FIXED_DT,idleInput,type DriveInput} from '../physics/world';
import {circuit} from './track';import {RaceRules} from './rules';import {Driver,STYLES} from './ai';

export class Competition {
  readonly cars:PrototypeVehicle[]=[];
  readonly drivers:Driver[]=[];
  readonly rules:RaceRules;
  readonly collisions:number[]=[];
  private previousRecovery:number[]=[];
  resetMessage='';
  resets=0;
  private noticeUntil=0;
  constructor(readonly scene:Scene,havok:HavokPhysicsWithBindings,readonly laps=2,readonly options:CompetitionOptions={}){
    enableWorld(scene,havok);scene.physicsEnabled=false;
    for(let i=0;i<6;i++){
      const playerSlot=options.grid??0;const slots=[playerSlot,...[0,1,2,3,4,5].filter(slot=>slot!==playerSlot)];const slot=slots[i];
      const grid=circuit.sample(-10-Math.floor(slot/2)*8,slot%2?3:-3);
      const car=new PrototypeVehicle(scene,grid.point.add(new Vector3(0,.65,0)),grid.yaw,i===0?options.player??BASE:options.opponents?.[i-1]??BASE);
      car.mesh.name='racer-'+i;car.surface=p=>circuit.onRoad(p);this.cars.push(car);
      this.drivers.push(new Driver(i===0?STYLES[4]:options.styles?.[i-1]??STYLES[i-1],i,i===0?0:options.mistakePeriod??0));this.collisions.push(0);this.previousRecovery.push(0);
    }
    this.rules=new RaceRules(circuit,this.cars.map((car,i)=>RaceRules.racer(i,i===0?'玩家':STYLES[i-1].name,car.mesh.position)),laps);
  }
  step(playerInput:DriveInput=idleInput(),validationPilot=false){
    if(this.rules.paused||this.rules.phase==='finished')return;
    if(this.rules.phase==='countdown'){this.rules.advanceCountdown(FIXED_DT);return;}
    // Compute all decisions from the same pre-step world. No AI changes transforms or velocities.
    const inputs=this.cars.map((car,i)=>i===0&&!validationPilot?playerInput:this.drivers[i].input(car,this.cars));
    for(let i=0;i<6;i++){
      // Finishers keep circulating with physical controls, avoiding a stopped car on the finish line.
      this.cars[i].step(inputs[i]);
      if(this.cars[i].recovery>this.previousRecovery[i])this.collisions[i]++;
      this.previousRecovery[i]=this.cars[i].recovery;
    }
    this.scene.getPhysicsEngine()!._step(FIXED_DT);
    this.rules.update(this.cars.map(car=>car.mesh.position),FIXED_DT);
    if(this.rules.time>=this.noticeUntil)this.resetMessage='';
  }
  resetPlayer(){
    if(this.rules.phase!=='racing'||this.rules.paused)return null;
    const progress=this.rules.racers[0];
    // Return behind the last legitimate gate; no checkpoint is awarded and this lap is invalidated.
    for(const back of [4,9,14])for(const lane of [-3,3,0]){
      const spawn=circuit.sample(circuit.gates[progress.lastGate]-back,lane);
      if(this.cars.slice(1).some(car=>{
        const relative=car.mesh.position.subtract(spawn.point);relative.y=0;
        if(relative.length()<12)return true;
        // Reject traffic whose current velocity sweeps through the reset area in the next 1.5s.
        const velocity=car.aggregate.body.getLinearVelocity();velocity.y=0;
        const closestTime=Math.max(0,Math.min(1.5,-Vector3.Dot(relative,velocity)/Math.max(.001,velocity.lengthSquared())));
        return relative.add(velocity.scale(closestTime)).length()<8;
      }))continue;
      const old=this.cars[0],energy=old.nitro,assists={...old.assists};
      const replacement=new PrototypeVehicle(this.scene,spawn.point.add(new Vector3(0,.65,0)),spawn.yaw,old.handling);
      this.resets++;replacement.nitro=energy;replacement.assists=assists;replacement.surface=p=>circuit.onRoad(p);
      this.cars[0]=replacement;this.previousRecovery[0]=0;this.rules.invalidate(0,replacement.mesh.position);old.dispose();
      this.noticeUntil=this.rules.time+5;
      this.resetMessage='已安全复位；当前圈无效，下一次过终点重新计圈。';return replacement;
    }
    this.noticeUntil=this.rules.time+5;this.resetMessage='复位区有车，请稍后重试。';return null;
  }
}
