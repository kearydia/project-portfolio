import {Vector3} from '../engine/babylon';
import {Circuit,HALF_WIDTH} from './track';

export interface RacerProgress {id:number;name:string;laps:number;nextGate:number;started:boolean;valid:boolean;previous:Vector3;finishTime:number|null;lastGate:number;invalidLaps:number;progress:number;lapStart:number;lapTimes:number[];attempts:{time:number;valid:boolean}[]}
export class RaceRules {
  time=0;
  countdown=3;
  phase:'countdown'|'racing'|'finished'='countdown';
  paused=false;
  constructor(readonly track:Circuit,readonly racers:RacerProgress[],readonly laps=2){}
  static racer(id:number,name:string,position:Vector3):RacerProgress{return {id,name,laps:0,nextGate:0,started:false,valid:true,previous:position.clone(),finishTime:null,lastGate:0,invalidLaps:0,progress:0,lapStart:0,lapTimes:[],attempts:[]};}
  invalidate(id:number,position:Vector3){const r=this.racers[id];r.valid=false;r.previous.copyFrom(position);}
  advanceCountdown(dt:number){if(this.paused||this.phase!=='countdown')return;this.countdown=Math.max(0,this.countdown-dt);if(this.countdown<=1e-8){this.countdown=0;this.phase='racing';}}
  update(positions:Vector3[],dt:number){
    if(this.paused||this.phase!=='racing')return;
    const start=this.time;this.time+=dt;
    for(const [i,r] of this.racers.entries()){
      const p=positions[i],projection=this.track.project(p);
      if(r.finishTime!==null){r.previous.copyFrom(p);continue;}
      if(projection.distance>HALF_WIDTH+0.5||p.y<0||p.y>3||Vector3.Distance(p,r.previous)>8)r.valid=false;
      const crossings:{gate:number;t:number}[]=[];
      for(let gate=0;gate<this.track.gates.length;gate++){
        const g=this.track.sample(this.track.gates[gate]);
        const before=Vector3.Dot(r.previous.subtract(g.point),g.tangent),after=Vector3.Dot(p.subtract(g.point),g.tangent);
        if(before<0&&after>=0){const t=-before/(after-before),cross=Vector3.Lerp(r.previous,p,t).subtract(g.point);const lateral=cross.x*g.tangent.z-cross.z*g.tangent.x;if(Math.abs(lateral)<=HALF_WIDTH&&Math.abs(cross.y)<3)crossings.push({gate,t});}
      }
      crossings.sort((a,b)=>a.t-b.t);
      for(const {gate,t} of crossings){
        if(gate===r.nextGate){
          if(gate===0){
            if(r.started){const duration=start+t*dt-r.lapStart;r.attempts.push({time:duration,valid:r.valid});if(r.valid){r.laps++;r.lapTimes.push(duration);}else r.invalidLaps++;}r.lapStart=start+t*dt;
            r.started=true;r.valid=true;
            if(r.laps>=this.laps){r.finishTime=start+t*dt;break;}
          }
          r.lastGate=gate;r.nextGate=(gate+1)%this.track.gates.length;
        }else if(gate===0){if(r.started)r.attempts.push({time:start+t*dt-r.lapStart,valid:false});r.lapStart=start+t*dt;r.invalidLaps+=Number(r.started);r.started=true;r.valid=true;r.lastGate=0;r.nextGate=1;}
        else if(r.started)r.valid=false;
      }
      // Ranking progress is bounded by the last legitimately passed gate, never a global nearest-point shortcut.
      const base=this.track.gates[r.lastGate];const next=this.track.gates[r.nextGate]??0;
      const span=(next-base+this.track.length)%this.track.length;
      const delta=(projection.s-base+this.track.length)%this.track.length;
      r.progress=r.started?base+Math.min(delta,span):0;
      r.previous.copyFrom(p);
    }
    if(this.racers[0].finishTime!==null)this.phase='finished';
  }
  ranking(){return [...this.racers].sort((a,b)=>{
    if(a.finishTime!==null&&b.finishTime!==null)return a.finishTime-b.finishTime||a.id-b.id;
    if(a.finishTime!==null)return -1;if(b.finishTime!==null)return 1;
    return b.laps-a.laps||b.progress-a.progress||a.id-b.id;
  });}
}
