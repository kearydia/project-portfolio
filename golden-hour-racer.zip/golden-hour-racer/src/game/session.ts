export class Session {
  private cleanup?: () => void;
  private controller = new AbortController();
  get signal() { return this.controller.signal; }
  clear() { this.controller.abort(); this.cleanup?.(); this.cleanup = undefined; this.controller = new AbortController(); }
  own(cleanup: () => void) { this.cleanup = cleanup; }
}
