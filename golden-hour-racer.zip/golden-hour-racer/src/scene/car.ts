import {bindCarReflection} from './quality';
import {Scene,Mesh,MeshBuilder,Vector3,StandardMaterial,Color3,ShadowGenerator} from '../engine/babylon';

/** Original, unbranded silhouettes. Geometry is display-only, never a physics shape. */
export const BODY_STYLES=[
 {roof:.82,cabin:1.65,front:1.8,wing:1.9},
 {roof:.65,cabin:1.25,front:1.65,wing:1.5},
 {roof:1.02,cabin:2.25,front:1.72,wing:2.1},
 {roof:.73,cabin:1.45,front:1.95,wing:1.75},
 {roof:.9,cabin:1.85,front:1.7,wing:2.02},
];
export function carModel(scene:Scene,parent:Mesh,color:string,id=0,shadows?:ShadowGenerator){
 const style=BODY_STYLES[id]??BODY_STYLES[0],root=new Mesh('car-display-'+id,scene);root.parent=parent;
 const materials:StandardMaterial[]=[];
 const mat=(name:string,hex:string,shine=20)=>{const m=new StandardMaterial(name,scene);m.diffuseColor=Color3.FromHexString(hex);m.specularColor=new Color3(.65,.65,.65);m.specularPower=shine;materials.push(m);return m;};
 const paint=mat('body-paint',color,100),rubber=mat('tire-rubber','#101417',8),glass=mat('laminated-glass','#24404b',160),metal=mat('machined-alloy','#b5bfcb',90),dark=mat('carbon-trim','#202a31');
 bindCarReflection(scene,paint);bindCarReflection(scene,glass);
 const tail=mat('rear-lamps','#ae1724');tail.emissiveColor=new Color3(.45,.015,.01);
 const light=mat('led-lamps','#fff1cf');light.emissiveColor=new Color3(1,.82,.52);
 const attach=(m:Mesh,p:Vector3,material:StandardMaterial)=>{m.parent=root;m.position=p;m.material=material;m.isPickable=false;shadows?.addShadowCaster(m);return m;};
 const box=(n:string,w:number,h:number,d:number,x:number,y:number,z:number,m=paint)=>attach(MeshBuilder.CreateBox(n,{width:w,height:h,depth:d},scene),new Vector3(x,y,z),m);
 // Curved transverse rings produce a tapered body instead of resizing the rigid chassis.
 const rings=[[-2.1,.77,.08],[-1.6,.96,.29],[-.6,.94,.34],[.65,.94,.3],[1.5,.9,.22],[2.1,.72,.04]].map(([z,w,y])=>[new Vector3(-w,-.28,z),new Vector3(-w,y-.12,z),new Vector3(-w*.78,y,z),new Vector3(w*.78,y,z),new Vector3(w,y-.12,z),new Vector3(w,-.28,z)]);
 attach(MeshBuilder.CreateRibbon('sculpted-shell',{pathArray:rings,closePath:true,sideOrientation:Mesh.DOUBLESIDE},scene),Vector3.Zero(),paint);
  const canopyRings=[[-style.cabin*.65,.72,.32],[-style.cabin*.35,.59,style.roof],[style.cabin*.12,.58,style.roof],[style.cabin*.5,.72,.32]].map(([z,w,y])=>[new Vector3(-.72,.29,z-.2),new Vector3(-w,y,z-.2),new Vector3(w,y,z-.2),new Vector3(.72,.29,z-.2)]);
 attach(MeshBuilder.CreateRibbon('glass-canopy',{pathArray:canopyRings,closePath:true,sideOrientation:Mesh.DOUBLESIDE},scene),Vector3.Zero(),glass);
 box('roof-panel',1.28,.07,style.cabin*.57,0,style.roof,-.3);
 box('front-splitter',1.98,.08,.42,0,-.28,1.85,dark);
 box('rear-diffuser',1.85,.16,.38,0,-.22,-1.95,dark);
 box('rear-wing',style.wing,.07,.38,0,.65,-1.85,dark);
 for(const x of [-.6,.6])box('wing-upright',.06,.4,.1,x,.42,-1.85,metal);
 for(const x of [-.78,.78]){box('headlamp',.36,.075,.06,x,.08,2.08,light);box('tail-lamp',.36,.085,.06,x,.08,-2.08,tail);box('side-intake',.04,.16,.6,x*1.21,0,-.45,dark);box('mirror',.18,.12,.27,x*1.28,.48,.35,dark);}
 for(const x of [-.97,.97])box('side-skirt',.08,.12,2.6,x,-.25,0,dark);
 const wheels:Mesh[]=[];
 for(const x of [-.97,.97])for(const z of [-1.35,1.35]){
  const wheel=attach(MeshBuilder.CreateCylinder('tire',{diameter:.76,height:.29,tessellation:24},scene),new Vector3(x,-.1,z),rubber);wheel.rotation.z=Math.PI/2;wheels.push(wheel);
  const rim=MeshBuilder.CreateCylinder('rim',{diameter:.54,height:.305,tessellation:24},scene);rim.parent=wheel;rim.material=dark;
  for(let i=0;i<5;i++){const spoke=MeshBuilder.CreateBox('alloy-spoke',{width:.045,height:.32,depth:.48},scene);spoke.parent=wheel;spoke.rotation.y=i*Math.PI/5;spoke.material=metal;}
  const hub=MeshBuilder.CreateCylinder('hub',{diameter:.15,height:.33,tessellation:12},scene);hub.parent=wheel;hub.material=metal;
 }
 for(let i=0;i<5;i++)box('hood-vent',.42,.015,.045,.42,.28,.85+i*.1,dark);
 parent.isVisible=false;
 let disposed=false;
 const dispose=()=>{if(disposed)return;disposed=true;parent.onDisposeObservable.remove(disposeObserver);for(const m of root.getChildMeshes())shadows?.removeShadowCaster(m,false);root.dispose();materials.forEach(m=>m.dispose());};
 const disposeObserver=parent.onDisposeObservable.addOnce(dispose);
 return {root,paint,wheels,tail,dispose};
}



