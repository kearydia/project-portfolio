import {Scene,ShadowGenerator,StandardMaterial} from '../engine/babylon';
import {sunsetReflection} from './reflection';
export const QUALITY={
  low:{shadow:512,particles:8,reflection:0,shadowInterval:2},
  medium:{shadow:1024,particles:20,reflection:.18,shadowInterval:2},
  high:{shadow:2048,particles:40,reflection:.3,shadowInterval:1}
} as const;
export type Quality=keyof typeof QUALITY;
let current:Quality='medium';
export const visualQuality=()=>QUALITY[current];
export function setVisualQuality(value:string){current=Object.hasOwn(QUALITY,value)?value as Quality:'medium';}
export function bindCarReflection(scene:Scene,material:StandardMaterial){
  material.metadata={...material.metadata,carReflection:true};
  const level=visualQuality().reflection;
  material.reflectionTexture=level?sunsetReflection(scene,level):null;
}
export function applySceneQuality(scene:Scene){
  const q=visualQuality();scene.shadowsEnabled=current!=='low';
  for(const material of scene.materials)if(material instanceof StandardMaterial&&material.metadata?.carReflection)bindCarReflection(scene,material);
  for(const light of scene.lights){
    const generator=light.getShadowGenerator();if(!(generator instanceof ShadowGenerator))continue;
    if(generator.mapSize!==q.shadow)generator.mapSize=q.shadow;
    const filter=current==='high'?ShadowGenerator.FILTER_PCF:ShadowGenerator.FILTER_NONE;
    if(generator.filter!==filter)generator.filter=filter;
    const map=generator.getShadowMap();if(map&&map.refreshRate!==q.shadowInterval)map.refreshRate=q.shadowInterval;
  }
}

