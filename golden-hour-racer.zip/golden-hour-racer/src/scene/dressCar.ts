import {vehicleEffects} from './effects';import type {PrototypeVehicle} from '../physics/world';
import {Scene,Mesh,StandardMaterial,ShadowGenerator} from '../engine/babylon';
import {carModel} from './car';
export function dressCar(scene:Scene,chassis:Mesh,_material:(name:string,color:string)=>StandardMaterial,shadows:ShadowGenerator,color='#edb940',id=0,car?:PrototypeVehicle){const model=carModel(scene,chassis,color,id,shadows);if(car)vehicleEffects(scene,car,model);return model;}

