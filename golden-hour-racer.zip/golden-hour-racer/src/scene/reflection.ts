import {RawCubeTexture} from '@babylonjs/core/Materials/Textures/rawCubeTexture';
import {Constants} from '@babylonjs/core/Engines/constants';
import {Scene,NullEngine} from '../engine/babylon';
/** Original static sunset environment, shared by all cars in a scene. No scene capture cost. */
export function sunsetReflection(scene:Scene,level:number){
 // NullEngine has no GPU cube-texture implementation; keep geometry tests renderless.
 if(scene.getEngine() instanceof NullEngine)return null;
 const old=scene.textures.find(t=>t.name==='sunset-reflection');if(old){old.level=level;return old;}
 const size=32,faces=Array.from({length:6},(_,face)=>{const bytes=new Uint8Array(size*size*4);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const k=(y*size+x)*4,t=face===2?0:face===3?1:y/(size-1);bytes[k]=Math.round(85+125*t);bytes[k+1]=Math.round(115+35*t);bytes[k+2]=Math.round(155-65*t);bytes[k+3]=255;}return bytes;});
 const texture=new RawCubeTexture(scene,faces,size,Constants.TEXTUREFORMAT_RGBA,Constants.TEXTURETYPE_UNSIGNED_BYTE,true);texture.name='sunset-reflection';texture.level=level;return texture;
}


