import {Scene,MeshBuilder,Vector3,StandardMaterial,Color3} from '../engine/babylon';
import {Space} from '@babylonjs/core/Maths/math.axis';
import type {PrototypeVehicle} from '../physics/world';import type {carModel} from './car';import {visualQuality} from './quality';
/** Read-only rendering; motion and energy changes come from the real vehicle. */
export function vehicleEffects(scene:Scene,car:PrototypeVehicle,model:ReturnType<typeof carModel>){
 const smokeMat=new StandardMaterial('tire-smoke',scene);smokeMat.diffuseColor=new Color3(.65,.62,.58);smokeMat.alpha=.22;
 const flameMat=new StandardMaterial('nitro-flame',scene);flameMat.emissiveColor=new Color3(.15,.55,1);flameMat.alpha=.75;
 const sparkMat=new StandardMaterial('impact-spark',scene);sparkMat.emissiveColor=new Color3(1,.6,.12);
 const makeParticle=()=>{const m=MeshBuilder.CreateSphere('fx-pool',{diameter:1,segments:4},scene);m.isPickable=false;m.setEnabled(false);return {m,life:0,v:Vector3.Zero()};};
 const pool=Array.from({length:visualQuality().particles},makeParticle);
 const flames=[-.55,.55].map(x=>{const m=MeshBuilder.CreateCylinder('nitro-exhaust',{diameterTop:.02,diameterBottom:.2,height:.8,tessellation:8},scene);m.parent=model.root;m.position.set(x,-.2,-2.3);m.rotation.x=Math.PI/2;m.material=flameMat;m.setEnabled(false);return m;});
 let previous=car.mesh.position.clone(),nitro=car.nitro,recovery=0,speed=0;
 const observer=scene.onBeforeRenderObservable.add(()=>{
  const distance=Vector3.Distance(previous,car.mesh.position),moving=distance>.00001&&distance<20;previous.copyFrom(car.mesh.position);
  const boosting=moving&&car.presentation.boost&&car.nitro<nitro;nitro=car.nitro;flames.forEach(m=>m.setEnabled(boosting));
  if(!moving){model.tail.emissiveColor.set(car.presentation.brake?1:.45,.015,.01);return;}const dt=Math.min(scene.getEngine().getDeltaTime()/1000,.1);
  // The cylinder axle is local Y, already tilted into chassis X by the model.
  // Rotate locally so rolling never changes the axle's direction.
  model.wheels.forEach(w=>w.rotate(Vector3.Up(),distance/.38,Space.LOCAL));
  const velocity=car.aggregate.body.getLinearVelocity(),slip=Math.abs(Vector3.Dot(velocity,car.mesh.getDirection(Vector3.Right())));
  model.tail.emissiveColor.set(car.presentation.brake?1:.45,.015,.01);speed=car.speed;
  const impact=car.recovery>recovery;recovery=car.recovery;
  const limit=visualQuality().particles;
  while(pool.length>limit)pool.pop()!.m.dispose();
  while(pool.length<limit)pool.push(makeParticle());
  for(const p of pool){if(p.life>0){p.life-=dt;p.m.position.addInPlace(p.v.scale(dt));p.m.scaling.scaleInPlace(1+dt);p.m.setEnabled(p.life>0);}}
  if((car.grounded&&slip>2)||impact){const p=pool.find(p=>p.life<=0);if(p){p.life=impact?.2:.6;p.m.material=impact?sparkMat:smokeMat;p.m.position.copyFrom(car.mesh.position);p.m.position.y-=.2;p.m.scaling.setAll(impact?.12:.45);p.v.set(0,impact?3:1,0);p.m.setEnabled(true);}}
 });
 car.mesh.onDisposeObservable.addOnce(()=>{scene.onBeforeRenderObservable.remove(observer);pool.forEach(p=>p.m.dispose());smokeMat.dispose();flameMat.dispose();sparkMat.dispose();});
}


