import type {Engine} from '../engine/babylon';
import '@babylonjs/core/Engines/Extensions/engine.query';
import '@babylonjs/core/Engines/AbstractEngine/abstractEngine.timeQuery';

/** Scale relative to physical pixels, independent of the selected effects tier. */
export function rasterSize(width:number,height:number,dpr:number,fraction=1,limit=Infinity){
  const native=Number.isFinite(dpr)&&dpr>0?dpr:1;
  const ratio=Math.min(native*Math.max(.85,Math.min(1,fraction)),limit/Math.max(1,width,height));
  return {width:Math.max(1,Math.round(width*ratio)),height:Math.max(1,Math.round(height*ratio)),level:1/ratio};
}

export class ResolutionBudget {
  fraction=1;
  private start:number|null=null;
  private samples=0;private slow=0;private fast=0;
  clearWindow(){this.start=null;this.samples=this.slow=this.fast=0;}
  reset(){this.fraction=1;this.clearWindow();}
  sample(now:number,frameMs:number,gpuMs:number,playing:boolean){
    if(!playing||frameMs<=0||frameMs>=200||!Number.isFinite(gpuMs)||gpuMs<=0){this.clearWindow();return false;}
    this.start??=now;this.samples++;
    if(frameMs>33.34&&gpuMs>28)this.slow++;
    if(frameMs<22&&gpuMs<17)this.fast++;
    const duration=now-this.start;
    if(duration<3000||this.samples<12)return false;
    const next=this.slow>=this.samples*.8?Math.max(.85,this.fraction-.05):
      duration>=8000&&this.fast>=this.samples*.9?Math.min(1,this.fraction+.05):this.fraction;
    if(next!==this.fraction){this.fraction=Math.round(next*100)/100;this.clearWindow();return true;}
    if(duration>=8000)this.clearWindow();
    return false;
  }
}

/** One observer set per engine, shared by all scenes. No persistent quality writes. */
export function installResolution(engine:Engine,canvas:HTMLCanvasElement){
  const budget=new ResolutionBudget();let tier='',last=0,gpuCount=0;
  const resize=()=>{
    const rect=canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;
    const target=rasterSize(rect.width,rect.height,window.devicePixelRatio,budget.fraction,engine.getCaps().maxTextureSize);
    if(engine.getHardwareScalingLevel()!==target.level)engine.setHardwareScalingLevel(target.level);
    // Babylon's default resize uses integer clientWidth/clientHeight. Preserve fractional CSS sizes at non-integer DPR.
    if(canvas.width!==target.width||canvas.height!==target.height)engine.setSize(target.width,target.height);
  };
  const observer=new ResizeObserver(resize);observer.observe(canvas);
  let media:MediaQueryList;
  const watchDpr=()=>{media?.removeEventListener('change',watchDpr);media=matchMedia('(resolution: '+devicePixelRatio+'dppx)');media.addEventListener('change',watchDpr);resize();};
  watchDpr();
  const timer=!!engine.getCaps().timerQuery;
  let measuringGPU=false,slowFrameMs=0;
  const end=timer?engine.onEndFrameObservable.add(()=>{
    const now=performance.now(),dt=now-last;last=now;
    // Avoid timer-query overhead altogether on devices already meeting the frame budget.
    if(!measuringGPU&&dt<=33.34){slowFrameMs=0;return;}
    const playing=!document.hidden&&document.hasFocus()&&document.getElementById('drive-ui')?.hidden===false&&document.getElementById('pause-screen')?.hidden===true;
    if(!playing||dt>=200){slowFrameMs=0;budget.clearWindow();return;}
    if(!measuringGPU){
      slowFrameMs+=dt;if(slowFrameMs<1500)return;
      engine.captureGPUFrameTime(true);measuringGPU=true;gpuCount=engine.getGPUFrameTimeCounter().count;return;
    }
    const counter=engine.getGPUFrameTimeCounter();
    if(counter.count===gpuCount)return;gpuCount=counter.count;
    if(budget.sample(now,dt,counter.current/1e6,playing))resize();
  }):null;
  engine.onDisposeObservable.addOnce(()=>{observer.disconnect();media.removeEventListener('change',watchDpr);engine.onEndFrameObservable.remove(end);if(measuringGPU)engine.captureGPUFrameTime(false);});
  return (nextTier:string)=>{if(tier!==nextTier){tier=nextTier;budget.reset();}resize();};
}
