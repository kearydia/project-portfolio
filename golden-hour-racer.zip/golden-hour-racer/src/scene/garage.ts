import { Scene, FreeCamera, Vector3, HemisphericLight, MeshBuilder, StandardMaterial, Color3 } from '../engine/babylon';
import {carModel} from './car';
export function createGarage(scene:Scene,color='#edb940',id=0){
 const camera=new FreeCamera('garage-camera',new Vector3(8,4.2,-10),scene);camera.setTarget(new Vector3(-1.8,.8,-1.2));
 const light=new HemisphericLight('garage-light',Vector3.Up(),scene);light.intensity=.95;
 const floor=MeshBuilder.CreateCylinder('display-platform',{diameter:9,height:.3,tessellation:64},scene);
 const dark=new StandardMaterial('platform',scene);dark.diffuseColor=Color3.FromHexString('#182932');floor.material=dark;
 const body=MeshBuilder.CreateBox('garage-anchor',{size:1},scene);body.position.y=.8;
 let model=carModel(scene,body,color,id);model.paint.name='gold';
 return (nextColor:string,nextId:number)=>{if(nextId===id){model.paint.diffuseColor=Color3.FromHexString(nextColor);return;}model.dispose();id=nextId;model=carModel(scene,body,nextColor,id);model.paint.name='gold';};
}


