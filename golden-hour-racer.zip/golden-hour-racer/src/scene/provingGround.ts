import { Scene, Vector3, Color3, Color4, MeshBuilder, StandardMaterial, HemisphericLight, DirectionalLight, ShadowGenerator, Mesh } from '../engine/babylon';
import { staticBox } from '../physics/world';
import {applySceneQuality} from './quality';

export function createProvingGround(scene: Scene) {
  const material = (name: string, hex: string) => { const existing = scene.getMaterialByName(name); if(existing) return existing as StandardMaterial; const m = new StandardMaterial(name, scene); m.diffuseColor = Color3.FromHexString(hex); m.specularColor.set(0.12,0.12,0.12); return m; };
  const asphalt = material('asphalt','#38434a'), sand = material('sand','#ac967b'), white = material('ivory','#eee7cb'), red = material('coral','#c55d46'), dark = material('rubber','#19292c');
  scene.clearColor = new Color4(0.91, 0.68, 0.46, 1);
  scene.fogMode = Scene.FOGMODE_EXP2;
  scene.fogDensity = 0.0026;
  scene.fogColor = new Color3(0.88, 0.67, 0.48);
  const ambient = new HemisphericLight('sky', new Vector3(0,1,0),scene); ambient.intensity = 0.55; ambient.groundColor = new Color3(0.46,0.35,0.3);
  const sunLight = new DirectionalLight('sunlight',new Vector3(-0.5,-0.6,0.8),scene); sunLight.position.set(80,100,-100); sunLight.intensity = 0.85; sunLight.diffuse = new Color3(1,0.79,0.52);
  const shadows = new ShadowGenerator(1024,sunLight); shadows.useBlurExponentialShadowMap = true; shadows.blurKernel = 16; shadows.darkness = 0.28;
  const ground = staticBox(scene,'foundation',new Vector3(0,-0.5,0),new Vector3(900,1,900)); ground.mesh.material=sand; ground.mesh.receiveShadows=true;
  const inner: Vector3[] = [], outer: Vector3[] = [];
  const steps=96;
  for(let i=0;i<=steps;i++) { const t=i/steps*Math.PI*2; inner.push(new Vector3(Math.cos(t)*46,0.015,Math.sin(t)*77)); outer.push(new Vector3(Math.cos(t)*62,0.015,Math.sin(t)*93)); }
  const road=MeshBuilder.CreateRibbon('test-loop',{pathArray:[inner,outer],sideOrientation:Mesh.DOUBLESIDE},scene); road.material=asphalt;road.receiveShadows=true;
  for(let i=0;i<steps;i++) {
    const t=(i+0.5)/steps*Math.PI*2;
    for(const edge of [-1,1]) {
      const rx=54+edge*8, rz=85+edge*8;
      const a=new Vector3(Math.cos(i/steps*Math.PI*2)*rx,0.06,Math.sin(i/steps*Math.PI*2)*rz);
      const b=new Vector3(Math.cos((i+1)/steps*Math.PI*2)*rx,0.06,Math.sin((i+1)/steps*Math.PI*2)*rz);
      const curb=MeshBuilder.CreateBox('curb',{width:0.7,height:0.1,depth:Vector3.Distance(a,b)+0.05},scene);curb.position=Vector3.Center(a,b);curb.rotation.y=Math.atan2(b.x-a.x,b.z-a.z);curb.material=i%2?white:red;
      const wall=staticBox(scene,'barrier',new Vector3(Math.cos(t)*(rx+edge*1.5),0.65,Math.sin(t)*(rz+edge*1.5)),new Vector3(0.65,1.3,Vector3.Distance(a,b)+0.5),curb.rotation.y);
      wall.mesh.material=i%8<2?red:white;
    }
    if(i%2===0) { const mark=MeshBuilder.CreateBox('lane-dash',{width:0.15,height:0.025,depth:2},scene);mark.position.set(Math.cos(t)*54,0.04,Math.sin(t)*85);mark.rotation.y=Math.atan2(-Math.sin(t)*54,Math.cos(t)*85);mark.material=white; }
  }
  for(let x=0;x<16;x++) for(let z=0;z<2;z++) { const tile=MeshBuilder.CreateBox('start-tile',{width:1,height:0.02,depth:1},scene);tile.position.set(46.5+x,0.045,z-4);tile.material=(x+z)%2?dark:white; }
  const sun=MeshBuilder.CreateSphere('sun-disc',{diameter:34,segments:24},scene);sun.position.set(-100,77,260);const glow=material('sun-emission','#ffdf96');glow.emissiveColor=new Color3(1,0.7,0.28);sun.material=glow;
  for(let i=0;i<22;i++) { const t=i/22*Math.PI*2;const height=30+Math.sin(i*3.7)*17;const mountain=MeshBuilder.CreateCylinder('distant-ridge',{diameterTop:0,diameterBottom:80+Math.cos(i*8)*25,height,tessellation:5},scene);mountain.position.set(Math.cos(t)*300,height/2-3,Math.sin(t)*310);mountain.rotation.y=i;mountain.material=material(`ridge-${i}`,i%2?'#9c8574':'#8d8079'); }
  const tower=staticBox(scene,'timing-tower',new Vector3(29,5,-10),new Vector3(6,10,8));tower.mesh.material=dark;
  const glass=material('tower-glass','#91aaa4'); const cabin=MeshBuilder.CreateBox('timing-cabin',{width:8,height:3,depth:10},scene);cabin.position.set(29,10,-10);cabin.material=glass;
  for(let i=0;i<10;i++) {const slab=MeshBuilder.CreateBox('paddock-fin',{width:1,height:4,depth:14},scene);slab.position.set(-22+i*3,2,-22);slab.material=white;}
  applySceneQuality(scene);
  return { shadows, material };
}

export { dressCar } from './dressCar';

