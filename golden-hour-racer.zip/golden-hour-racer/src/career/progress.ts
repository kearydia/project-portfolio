import {CHALLENGES,CARS,EVENTS,PAINTS,UPGRADES,stock,rewardLabel,type Difficulty,type Result,type Setup,type Upgrade} from './data';
export interface Progress {version:1;wins:number[];rewards:string[];selected:number;difficulty:Difficulty;setups:Setup[];paints:string[]}
export const fresh=():Progress=>({version:1,wins:[],rewards:[],selected:0,difficulty:'standard',setups:CARS.map(()=>stock()),paints:CARS.map(()=>PAINTS[0])});
export interface ProgressStore<T=Progress> {load():unknown;save(progress:T):void}
export function carUnlocked(p:Progress,car:number){return car===0||CHALLENGES.some(c=>'car' in c.reward&&c.reward.car===car&&p.rewards.includes(c.id));}
export function tier(p:Progress,key:Upgrade){return Math.max(0,...CHALLENGES.filter(c=>p.rewards.includes(c.id)&&'upgrade' in c.reward&&c.reward.upgrade===key).map(c=>'upgrade' in c.reward?c.reward.level:0));}
export function openEvent(p:Progress,id:number){return Number.isInteger(id)&&id>=0&&id<8&&(id===0||p.wins.includes(id-1));}
export function restore(raw:unknown):Progress{
 const p=raw as Progress;if(!p||p.version!==1||!Array.isArray(p.wins)||!Array.isArray(p.rewards)||!Array.isArray(p.setups)||!Array.isArray(p.paints))throw Error('无法读取进度版本或格式');
 const n=fresh();for(let i=0;i<8&&p.wins.includes(i);i++)n.wins.push(i);
 n.rewards=CHALLENGES.filter(c=>p.rewards.includes(c.id)&&openEvent(n,c.event)).map(c=>c.id);
 n.selected=Number.isInteger(p.selected)&&p.selected>=0&&p.selected<5&&carUnlocked(n,p.selected)?p.selected:0;
 if(['easy','standard','hard'].includes(p.difficulty))n.difficulty=p.difficulty;
 n.setups=n.setups.map((s,i)=>{for(const key of UPGRADES){const v=p.setups[i]?.[key];s[key]=Number.isInteger(v)?Math.max(0,Math.min(v,3,tier(n,key))):0;}return s;});
 n.paints=n.paints.map((_,i)=>PAINTS.includes(p.paints[i])?p.paints[i]:PAINTS[0]);return n;
}
export class Career {
 progress=fresh();warning='';
 constructor(private store?:ProgressStore){try{const data=store?.load();if(data!==null&&data!==undefined)this.progress=restore(data);}catch{this.warning='本地进度读取失败，本次使用临时进度；未覆盖原数据。';}}
 save(){try{if(this.warning.startsWith('本地进度读取失败'))return;this.store?.save(structuredClone(this.progress));this.warning='';}catch{this.warning='进度写入失败，仅本次页面会话保留；刷新可能丢失。';}}
 choose(car:number){if(!Number.isInteger(car)||car<0||car>=5||!carUnlocked(this.progress,car))return false;this.progress.selected=car;this.save();return true;}
 upgrade(car:number,key:Upgrade,level:number){if(!carUnlocked(this.progress,car)||!Number.isInteger(level)||level<0||level>tier(this.progress,key))return false;this.progress.setups[car][key]=level;this.save();return true;}
 settle(r:Result):string[]{
 if(!openEvent(this.progress,r.event)||!r.finished||!Number.isInteger(r.rank)||r.rank<1||r.rank>6||!Number.isFinite(r.time)||r.time<=0||r.lapTimes.length!==EVENTS[r.event].laps||r.lapTimes.some(t=>!Number.isFinite(t)||t<=0))return [];
 const awards:string[]=[];
 if(r.rank===1&&!this.progress.wins.includes(r.event)){this.progress.wins.push(r.event);awards.push(r.event<7?`解锁第 ${r.event+2} 关`:'生涯冠军已达成');}
 for(const c of CHALLENGES)if(c.event===r.event&&!this.progress.rewards.includes(c.id)&&c.meets(r)){this.progress.rewards.push(c.id);awards.push(rewardLabel(c));}
 this.save();return awards;
 }
}
export function jsonStore<T>(key:string):ProgressStore<T>{return {load:()=>{const value=localStorage.getItem(key);if(value&&value.length>8000000)throw Error('记录超出大小限制');return value?JSON.parse(value):null;},save:p=>localStorage.setItem(key,JSON.stringify(p))};}
export function browserStore():ProgressStore{return jsonStore<Progress>('golden-hour-career-v1');}
