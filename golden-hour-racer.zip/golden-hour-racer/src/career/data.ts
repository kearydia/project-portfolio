export type Upgrade='engine'|'speed'|'brakes'|'grip'|'nitro';
export const UPGRADES:Upgrade[]=['engine','speed','brakes','grip','nitro'];
export const LABELS:Record<Upgrade,string>={engine:'引擎',speed:'极速',brakes:'制动',grip:'抓地力',nitro:'氮气'};
export type Setup=Record<Upgrade,number>;
export const stock=():Setup=>({engine:0,speed:0,brakes:0,grip:0,nitro:0});
export interface Handling {mass:number;engine:number;speed:number;brakes:number;grip:number;nitro:number;steer:number}
export const BASE:Handling={mass:1150,engine:1,speed:1,brakes:1,grip:1,nitro:1,steer:1};
export const CARS=[
 {name:'GH–01 均衡',trait:'均衡轻型跑车，易控制',params:{...BASE}},
 {name:'GH–02 轻羽',trait:'轻量、转向灵敏，直线动力较低',params:{...BASE,mass:1030,engine:.96,speed:.96,steer:1.08}},
 {name:'GH–03 弯锋',trait:'抓地与制动优先，偏航较稳',params:{...BASE,mass:1250,engine:1.02,grip:1.12,brakes:1.08,steer:.96}},
 {name:'GH–04 长风',trait:'直线动力强，低抓地更容易侧滑',params:{...BASE,mass:1320,engine:1.13,speed:1.08,grip:.94,steer:.98}},
 {name:'GH–05 曙光',trait:'动力与抓地均衡，质量较大',params:{...BASE,mass:1380,engine:1.08,speed:1.04,grip:1.06,brakes:1.04}},
];
export const PAINTS=['#edb940','#dd6958','#82b4a0','#658cc6','#bd92c6','#e4ddd0'];
export function handling(car:number,setup=stock()):Handling{const p=CARS[car].params;return {...p,engine:p.engine*(1+.045*setup.engine),speed:p.speed*(1+.04*setup.speed),brakes:p.brakes*(1+.06*setup.brakes),grip:p.grip*(1+.045*setup.grip),nitro:p.nitro*(1+.12*setup.nitro)};}
export type Difficulty='easy'|'standard'|'hard';
export const DIFFICULTIES:Record<Difficulty,string>={easy:'简单',standard:'标准',hard:'困难'};
export const EVENTS=['追光起步','制动边界','弯心节奏','氮气窗口','侧滑艺术','山脊竞逐','最后一束光','黄金冠军'].map((name,id)=>({id,name,laps:[1,1,2,2,3,3,3,4][id],grid:[0,1,2,3,4,5,5,5][id],opponents:[0,1,2,3,4],pace:.78+id*.008,target:id<2?'1–2 分钟':id===7?'4–6 分钟':'2–4 分钟'}));
export interface Result {event:number;rank:number;finished:boolean;time:number;lapTimes:number[];invalid:number;resets:number;impacts:number}
export interface Challenge {id:string;event:number;label:string;reward:{car:number}|{upgrade:Upgrade;level:number};meets:(r:Result)=>boolean}
const allocation:Upgrade[][]=[['engine','brakes'],['grip','speed'],['nitro','engine'],['brakes','grip'],['speed','nitro'],['engine','brakes'],['grip','speed'],['nitro']];
const tiers=stock();
export const CHALLENGES:Challenge[]=allocation.flatMap((keys,event)=>keys.map((upgrade,index)=>({id:`${event}-${upgrade}`,event,label:index===0?'完成赛事且不复位':'完成赛事且没有无效圈',reward:{upgrade,level:++tiers[upgrade]},meets:(r:Result)=>index===0?r.resets===0:r.invalid===0})));
for(const [car,event] of [[1,1],[2,3],[3,5],[4,7]])CHALLENGES.push({id:`car-${car}`,event,label:'完成赛事且最佳有效圈 ≤ 105 秒',reward:{car},meets:r=>r.lapTimes.length>0&&Math.min(...r.lapTimes)<=105});
export function rewardLabel(c:Challenge){return 'car' in c.reward?CARS[c.reward.car].name:`${LABELS[c.reward.upgrade]} ${c.reward.level} 级`;}

