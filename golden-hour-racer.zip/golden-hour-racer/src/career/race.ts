import {EVENTS,handling,type Difficulty} from './data';import type {Progress} from './progress';import {STYLES} from '../race/ai';import type {CompetitionOptions,Competition} from '../race/simulation';
export function raceOptions(event:number,p:Progress):CompetitionOptions{
 const e=EVENTS[event],skill:Record<Difficulty,number>={easy:.84,standard:.94,hard:1};const scale=e.pace*skill[p.difficulty];
 return {name:e.name,grid:e.grid,player:handling(p.selected,p.setups[p.selected]),paint:p.paints[p.selected],opponents:e.opponents.map(car=>handling(car)),styles:STYLES.map(s=>({...s,straight:s.straight*scale,corner:s.corner*scale*scale,gap:s.gap+(1-scale)*10,pass:s.pass*scale})),mistakePeriod:p.difficulty==='easy'?12:p.difficulty==='standard'?24:0};
}
export function raceResult(event:number,race:Competition){const p=race.rules.racers[0];return {event,rank:race.rules.ranking().findIndex(r=>r.id===0)+1,finished:race.rules.phase==='finished'&&p.finishTime!==null,time:p.finishTime??0,lapTimes:[...p.lapTimes],invalid:p.invalidLaps,resets:race.resets,impacts:race.collisions[0]};}
