import {fresh,restore,type Progress,type ProgressStore} from '../career/progress';
import {TrialLibrary,type TrialData} from '../timing/library';
import {recordIssue} from '../timing/recording';
import {defaults,validLayout,type Settings} from '../settings/data';
export interface SaveData {career:Progress;timing:TrialData;settings:Settings;history:unknown[]}
export const initial=():SaveData=>({career:fresh(),timing:new TrialLibrary().data,settings:defaults(),history:[]});
export const LIMIT=32*1024*1024;
export function canonical(x:unknown):string{if(x===null||typeof x!=='object')return JSON.stringify(x);if(Array.isArray(x))return '['+x.map(canonical).join(',')+']';return '{'+Object.keys(x).sort().map(k=>JSON.stringify(k)+':'+canonical((x as Record<string,unknown>)[k])).join(',')+'}';}
function same(a:unknown,b:unknown){return canonical(a)===canonical(b);}
export function validate(raw:unknown):SaveData{
 const p=raw as SaveData;if(!p||Object.keys(p).sort().join()!=='career,history,settings,timing')throw Error('存档字段错误');
 if(!same(p.career,restore(p.career)))throw Error('生涯数据非法');
 const lib=new TrialLibrary({load:()=>p.timing,save:()=>{}});if(lib.warning||lib.messages.length||!same(lib.data,p.timing))throw Error('计时或幽灵记录不兼容');lib.normalize(p.career);if(!same(lib.data,p.timing))throw Error('计时配置未解锁');
 const s=p.settings,d=defaults();if(!s||Object.keys(s).sort().join()!==Object.keys(d).sort().join()||!['low','medium','high'].includes(s.quality)||typeof s.mute!=='boolean'||!['master','music','effects'].every(k=>Number.isFinite(s[k as 'master'])&&s[k as 'master']>=0&&s[k as 'master']<=1)||!same(Object.keys(s.assists).sort(),['abs','esc','tcs'])||!Object.values(s.assists).every(v=>typeof v==='boolean')||!validLayout(s.layout)||!same(Object.keys(s.layout).sort(),Object.keys(d.layout).sort())||Object.values(s.layout).some(b=>Object.keys(b).sort().join()!=='opacity,size,x,y'))throw Error('设置数据非法');
 if(!Array.isArray(p.history)||p.history.length>1000||p.history.some(h=>{if((h as any)?.mode==='timing'){const a=h as any;const cfg=a.config;return Object.keys(a).sort().join()!=='config,mode,time,valid'||!Number.isFinite(a.time)||a.time<=0||typeof a.valid!=='boolean'||!cfg||!Number.isInteger(cfg.car)||cfg.car<0||cfg.car>4||Object.keys(cfg).sort().join()!=='assists,car,setup'||!same(Object.keys(cfg.setup).sort(),Object.keys(initial().career.setups[0]).sort())||!Object.values(cfg.setup).every(v=>Number.isInteger(v)&&Number(v)>=0&&Number(v)<=3)||!same(Object.keys(cfg.assists).sort(),['abs','esc','tcs'])||!Object.values(cfg.assists).every(v=>typeof v==='boolean');}const r=h as {event:number;rank:number;time:number;lapTimes:number[]};return !r||Object.keys(r).sort().join()!=='event,finished,impacts,invalid,lapTimes,rank,resets,time'||typeof (r as any).finished!=='boolean'||['impacts','invalid','resets'].some(k=>!Number.isInteger((r as any)[k])||(r as any)[k]<0)||!Number.isInteger(r.event)||r.event<0||r.event>7||!Number.isInteger(r.rank)||r.rank<1||r.rank>6||!Number.isFinite(r.time)||r.time<=0||!Array.isArray(r.lapTimes)||r.lapTimes.some(n=>!Number.isFinite(n)||n<=0);}))throw Error('历史成绩非法');
 return structuredClone(p);
}
export async function checksum(data:unknown){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(canonical(data)));return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}
export async function pack(data:SaveData){const payload=validate(data);return {version:2,payload,checksum:await checksum(payload)};}
export async function unpack(text:string){if(new TextEncoder().encode(text).length>LIMIT)throw Error('文件超过32MB');const e=JSON.parse(text);if(!e||typeof e!=='object'||Object.keys(e).sort().join()!=='checksum,payload,version')throw Error('存档外层字段错误');if(e.version!==2&&e.version!==1)throw Error('不兼容版本，保留原始数据');if(e.checksum!==await checksum(e.payload))throw Error('完整性校验失败');if(e.version===1&&!e.payload.settings)e.payload.settings=defaults();return validate(e.payload);}
const req=<T>(r:IDBRequest<T>)=>new Promise<T>((resolve,reject)=>{r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
const done=(t:IDBTransaction)=>new Promise<void>((resolve,reject)=>{t.oncomplete=()=>resolve();t.onabort=()=>reject(t.error??Error('事务中断'));t.onerror=()=>reject(t.error);});
export class Vault {
 data=initial();status='正在读取存档';blocked=false;private revision=0;private queue=Promise.resolve();
 constructor(readonly db:IDBDatabase){}
 static async open(name='golden-hour-save'){const r=indexedDB.open(name,1);r.onupgradeneeded=()=>r.result.createObjectStore('saves');return new Vault(await req(r));}
 async read(key:string){return req(this.db.transaction('saves').objectStore('saves').get(key));}
 async init(legacy?:()=>{career:unknown;timing:unknown}){const main=await this.read('main');this.revision=(await this.read('revision'))??0;
  if(main){try{this.data=await unpack(main);this.status='存档已恢复';return;}catch(error){const raw=JSON.parse.bind(JSON);let incompatible=false;try{incompatible=![1,2].includes(raw(main).version);}catch{}if(incompatible){this.blocked=true;this.status='不兼容主档：已保留，禁止自动覆盖';return;}const backups=(await this.read('backups'))??[];for(const text of backups){try{this.data=await unpack(text);this.status='主档损坏，已恢复有效备份；原始主档保留至隔离区';await this.persist(this.data,true);return;}catch{}}this.blocked=true;this.status='主档及备份无法恢复，原数据已保留';return;}}
  try{if(legacy){const old=legacy();if(old.career)this.data.career=old.career as Progress;if(old.timing)this.data.timing=old.timing as TrialData;}validate(this.data);await this.persist(this.data);this.status='存档已初始化（旧本地档保留）';}catch(e){this.blocked=true;this.status=String(e);}
 }
 store<K extends 'career'|'timing'>(key:K):ProgressStore<SaveData[K]>{return {load:()=>structuredClone(this.data[key]),save:v=>{if(this.blocked)throw Error(this.status);this.data[key]=structuredClone(v);this.save();}};}
 save(){const snapshot=structuredClone(this.data);this.status='保存中，请勿关闭页面';this.queue=this.queue.then(()=>this.persist(snapshot)).then(()=>{this.status='已安全保存';}).catch(e=>{this.status='保存失败（可重试；其他页面冲突需刷新）：'+String(e);});return this.queue;}
 async persist(data:SaveData,recover=false){if(this.blocked)throw Error('原始数据受保护');const text=JSON.stringify(await pack(data));await unpack(text);const old=await this.read('main');let validOld=false;try{if(old){await unpack(old);validOld=true;}}catch{}
 const t=this.db.transaction('saves','readwrite'),finished=done(t),s=t.objectStore('saves');const revision=await req(s.get('revision'));if((revision??0)!==this.revision){t.abort();await finished;return;}
 const backups=(await req(s.get('backups')))??[];if(validOld)s.put([old,...backups].slice(0,5),'backups');else if(old&&recover)s.put(old,'quarantined');s.put(text,'main');s.put(this.revision+1,'revision');await finished;this.revision++;await unpack(await this.read('main'));
 }
 async flush(){await this.queue;}
 async export(){await this.flush();return JSON.stringify(await pack(this.data));}
 async import(text:string){const data=await unpack(text);await this.flush();await this.persist(data);this.data=data;this.status='导入成功';}
 async backups(){return (await this.read('backups')) as string[]??[];}
}

