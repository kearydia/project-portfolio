import {BASE,type Handling} from '../career/data';
import { Scene, Vector3, MeshBuilder, PhysicsAggregate, PhysicsShapeType, HavokPlugin, Quaternion, Mesh } from '../engine/babylon';
import type { HavokPhysicsWithBindings } from '@babylonjs/havok';

export const FIXED_DT = 1 / 60;
export function enableWorld(scene: Scene, havok: HavokPhysicsWithBindings) {
  const plugin = new HavokPlugin(false, havok);
  scene.enablePhysics(new Vector3(0, -9.81, 0), plugin);
  scene.getPhysicsEngine()!.setTimeStep(FIXED_DT);
  return plugin;
}
export function staticBox(scene: Scene, name: string, position: Vector3, size: Vector3, yaw = 0) {
  const mesh = MeshBuilder.CreateBox(name, { width: size.x, height: size.y, depth: size.z }, scene);
  mesh.position.copyFrom(position);
  mesh.rotationQuaternion = Quaternion.RotationYawPitchRoll(yaw, 0, 0);
  const aggregate = new PhysicsAggregate(mesh, PhysicsShapeType.BOX, { mass: 0, friction: 0.65, restitution: 0.05 }, scene);
  return { mesh, aggregate };
}
export function dynamicBox(scene: Scene, name: string, position: Vector3, size = new Vector3(1, 1, 1), mass = 1, yaw = 0) {
  const mesh = MeshBuilder.CreateBox(name, { width: size.x, height: size.y, depth: size.z }, scene);
  mesh.position.copyFrom(position);
  mesh.rotationQuaternion = Quaternion.RotationYawPitchRoll(yaw, 0, 0);
  const aggregate = new PhysicsAggregate(mesh, PhysicsShapeType.BOX, { mass, friction: 0.35, restitution: 0.05 }, scene);
  return { mesh, aggregate };
}
export interface DriveInput { throttle: number; steer: number; brake: boolean; drift: boolean; boost: boolean; reverse?: boolean }
export const idleInput = (): DriveInput => ({ throttle: 0, steer: 0, brake: false, drift: false, boost: false });

/** Arcade rigid-body controller: four suspension probes, bounded tire forces and yaw inertia. */
export class PrototypeVehicle {
  readonly mesh: Mesh;
  readonly aggregate: PhysicsAggregate;
  // Read-only presentation telemetry; not consumed by the driving solver.
  readonly presentation={brake:false,boost:false};
  nitro = 1;
  grounded = false;
  get mass(){return this.handling.mass;}
  assists = { abs: true, tcs: true, esc: true };
  steering = 0;
  gear = 1;
  rpm = 900;
  recovery = 0;
  offTrack = false;
  wheelCompression = [0,0,0,0];
  contacts = 0;
  private previousSpeed = 0;
  private previousHorizontal = Vector3.Zero();
  private previousBraking = false;
  private shiftTime = 0;
  private travel = 0;
  private previousPosition: Vector3;
  surface: (position: Vector3) => boolean = () => true;
  constructor(private scene: Scene, position: Vector3, yaw = 0, readonly handling:Handling=BASE) {
    const car = dynamicBox(scene, 'prototype-chassis', position, new Vector3(1.9, 0.65, 4.2), this.mass, yaw);
    this.previousPosition = position.clone();
    this.mesh = car.mesh;
    this.aggregate = car.aggregate;
    // Deliberate arcade anti-roll constraint; vertical suspension and yaw remain physical.
    this.aggregate.body.setMassProperties({ mass: this.mass, inertia: new Vector3(0, 1800, 0), inertiaOrientation: Quaternion.Identity() });
    this.aggregate.body.setLinearDamping(0.05);
    this.aggregate.body.setAngularDamping(3);
    if (this.aggregate.shape) this.aggregate.shape.material = { friction: 0.05, restitution: 0.08 };
  }
  get speed() { const velocity = this.aggregate.body.getLinearVelocity(); return Math.hypot(velocity.x, velocity.z) * 3.6; }
  step(input: DriveInput, dt = FIXED_DT) {
    this.presentation.brake=input.brake;
    this.mesh.computeWorldMatrix(true);
    const body = this.aggregate.body;
    const velocity = body.getLinearVelocity();
    const forward = this.mesh.getDirection(Vector3.Forward()).normalize();
    const right = this.mesh.getDirection(Vector3.Right()).normalize();
    const longitudinal = Vector3.Dot(velocity, forward);
    const lateral = Vector3.Dot(velocity, right);
    dt = Math.min(Math.max(dt, 0), FIXED_DT);
    if(!dt)return;
    const speed = Math.hypot(velocity.x,velocity.z);
    const velocityChange=Math.hypot(velocity.x-this.previousHorizontal.x,velocity.z-this.previousHorizontal.z);
    if(this.previousSpeed>5 && velocityChange>6 && !this.previousBraking)this.recovery=0.8;
    this.previousHorizontal.set(velocity.x,0,velocity.z);
    this.previousSpeed=speed;this.previousBraking=input.brake||input.drift;
    this.recovery=Math.max(0,this.recovery-dt);
    this.offTrack=!this.surface(this.mesh.position);
    this.contacts=0;
    let index=0;
    for(const x of [-0.8,0.8])for(const z of [-1.35,1.35]){
      const from=this.mesh.position.add(right.scale(x)).add(forward.scale(z));
      const hit=this.scene.getPhysicsEngine()!.raycast(from,from.add(new Vector3(0,-0.9,0)),{ignoreBody:body});
      const contact=hit.hasHit && hit.hitNormalWorld.y>0.5;
      const compression=contact?Math.max(0,0.8-hit.hitDistance):0;
      this.wheelCompression[index++]=compression;
      if(contact){this.contacts++;const force=Math.max(0,Math.min(this.mass*9.81,(compression*18000-velocity.y*1700)*(this.mass/1150)));body.applyImpulse(new Vector3(0,force*dt,0),from);}
    }
    this.grounded=this.contacts>=2;
    this.steering+=(Math.max(-1,Math.min(1,input.steer))-this.steering)*(1-Math.exp(-dt*6));
    const distance=Vector3.Distance(this.mesh.position,this.previousPosition);this.previousPosition.copyFrom(this.mesh.position);
    // Only forward progress on the circuit earns energy, never idling, reversing or reset teleports.
    this.travel+=this.grounded&&!this.offTrack&&longitudinal>5&&distance<3?distance:0;
    const boosting=input.boost&&input.throttle>0&&!input.brake&&!input.reverse&&this.nitro>0&&this.grounded&&this.recovery===0;
    this.presentation.boost=boosting;
    if(boosting)this.nitro=Math.max(0,this.nitro-0.23*dt/this.handling.nitro);
    else if(this.travel>=5){this.nitro=Math.min(1,this.nitro+0.006);this.travel=0;}
    this.shiftTime=Math.max(0,this.shiftTime-dt);
    if(longitudinal < -0.5)this.gear=-1;
    else {if(this.gear<1)this.gear=1;const up=[0,12,22,33,44,55,100][this.gear];if(this.shiftTime===0&&longitudinal>up&&this.gear<6){this.gear++;this.shiftTime=0.12;}else if(this.shiftTime===0&&this.gear>1&&longitudinal<([0,0,9,19,30,41,52][this.gear])){this.gear--;this.shiftTime=0.12;}}
    this.rpm=Math.min(7200,900+Math.abs(longitudinal)*[0,430,250,180,140,115,95][Math.max(1,this.gear)]);
    if(!this.grounded)return;
    const traction=(this.offTrack?0.45:1)*(this.contacts/4);
    const demand=(input.reverse?-Math.max(0,1):Math.max(0,input.throttle))*(boosting?14:8.5)*this.handling.engine;
    const wheelspin=Math.abs(demand)>10*traction;
    let acceleration=demand*(this.shiftTime>0?0.7:1)*(this.recovery>0?0.25:1);
    if(this.assists.tcs&&wheelspin)acceleration=Math.sign(acceleration)*Math.min(Math.abs(acceleration),14*traction);
    else if(wheelspin)acceleration*=0.78;
    acceleration-=longitudinal*Math.abs(longitudinal)*0.003/(this.handling.speed*this.handling.speed);
    if(this.offTrack)acceleration-=longitudinal*0.7;
    const braking=input.brake||(input.reverse&&longitudinal>0.5)||(input.throttle>0&&longitudinal< -0.5);
    if(braking)acceleration=-Math.sign(longitudinal)*Math.min((this.assists.abs?24:28)*this.handling.brakes,Math.abs(longitudinal)/dt);
    if(longitudinal>(boosting?65:49)*this.handling.speed&&acceleration>0)acceleration=0;
    if(longitudinal< -9&&acceleration<0)acceleration=0;
    let grip=(input.drift?1.25:8)*traction*this.handling.grip;
    if(braking&&!this.assists.abs)grip*=0.25;
    if(wheelspin&&!this.assists.tcs)grip*=0.65;
    const slip=Math.atan2(lateral,Math.max(3,Math.abs(longitudinal)));
    if(this.assists.esc&&!input.drift)grip*=1.15;
    const lateralAcceleration=Math.max(-12*traction*this.handling.grip,Math.min(12*traction*this.handling.grip,-lateral*grip));
    if(input.drift)acceleration-=Math.sign(longitudinal)*Math.min(3,Math.abs(longitudinal)/dt);
    body.applyImpulse(forward.scale(acceleration*this.mass*dt).add(right.scale(lateralAcceleration*this.mass*dt)),this.mesh.position);
    const sensitivity=1/(1+Math.max(0,speed-10)*0.028);
    let yaw=this.handling.steer*this.steering*Math.min(Math.abs(longitudinal)/7,1)*(input.drift?1.55:1.05)*sensitivity*Math.sign(longitudinal);
    if(this.assists.esc&&!input.drift)yaw+=Math.max(-0.3,Math.min(0.3,slip*0.5));
    const angular=body.getAngularVelocity().y;
    body.setAngularVelocity(new Vector3(0,angular+Math.max(-4,Math.min(4,(yaw-angular)*8))*dt,0));
    const wheels=this.mesh.getChildMeshes().filter(m=>m.name==='wheel');
    wheels.forEach((wheel,i)=>{wheel.position.y=0.38-(0.8-this.wheelCompression[i]);if(wheel.position.z>0)wheel.rotation.y=this.steering*0.4*sensitivity;});
  }
  dispose() { this.aggregate.dispose(); this.mesh.dispose(false, false); }
}




