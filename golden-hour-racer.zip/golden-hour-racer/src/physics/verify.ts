import { NullEngine, Scene, Vector3 } from '../engine/babylon';
import type { HavokPhysicsWithBindings } from '@babylonjs/havok';
import { dynamicBox, enableWorld, FIXED_DT, idleInput, PrototypeVehicle, staticBox } from './world';

export interface Check { name: string; pass: boolean; detail: string }
/** Same real Havok integration suite runs under Node and from the browser diagnostics button. */
export function verifyPhysics(havok: HavokPhysicsWithBindings): Check[] {
  const engine = new NullEngine();
  const scene = new Scene(engine);
  const plugin = enableWorld(scene, havok);
  const checks: Check[] = [];
  const step = (count: number, before?: () => void) => {
    for (let i = 0; i < count; i++) { before?.(); scene.getPhysicsEngine()!._step(FIXED_DT); }
  };
  try {
    checks.push({ name: 'Havok Physics V2', pass: plugin.getPluginVersion() === 2, detail: `plugin version = ${plugin.getPluginVersion()}` });
    staticBox(scene, 'test-floor', new Vector3(0, -0.5, 0), new Vector3(300, 1, 300));
    const box = dynamicBox(scene, 'falling-box', new Vector3(-20, 5, 0));
    step(30);
    const fallingY = box.mesh.position.y;
    checks.push({ name: '重力下降', pass: fallingY < 4.5 && fallingY > 2, detail: `0.5s 后 y=${fallingY.toFixed(4)}m（初始 5m）` });
    step(210);
    const restingY = box.mesh.position.y;
    checks.push({ name: '落地与静止', pass: Math.abs(restingY - 0.5) < 0.08 && box.aggregate.body.getLinearVelocity().length() < 0.1, detail: `4s 后 y=${restingY.toFixed(4)}m` });
    staticBox(scene, 'collision-wall', new Vector3(0, 2, 12), new Vector3(12, 4, 1));
    const projectile = dynamicBox(scene, 'collision-box', new Vector3(0, 0.55, 0));
    projectile.aggregate.body.setLinearVelocity(new Vector3(0, 0, 20));
    let maxZ = 0;
    for (let i = 0; i < 120; i++) { step(1); maxZ = Math.max(maxZ, projectile.mesh.position.z); }
    checks.push({ name: '静态护墙碰撞', pass: maxZ > 5 && maxZ < 11.1, detail: `最大 z=${maxZ.toFixed(4)}m；护墙前缘 11.5m` });
    const car = new PrototypeVehicle(scene, new Vector3(30, 1, -60));
    checks.push({ name: '车辆质量保持', pass: Math.abs(car.aggregate.body.getMassProperties().mass! - car.mass) < 0.01, detail: `${car.aggregate.body.getMassProperties().mass}kg` });
    step(90);
    const drive = { ...idleInput(), throttle: 1 };
    step(180, () => car.step(drive));
    const driveSpeed = car.speed;
    checks.push({ name: '车辆驱动力', pass: driveSpeed > 35 && car.mesh.position.z > -45, detail: `3s 加速 ${driveSpeed.toFixed(2)}km/h，z=${car.mesh.position.z.toFixed(3)}m` });
    step(120, () => car.step({ ...idleInput(), brake: true }));
    checks.push({ name: '制动', pass: car.speed < 3, detail: `制动 2s 后 ${car.speed.toFixed(3)}km/h` });
    step(180, () => car.step({ ...drive, boost: true }));
    checks.push({ name: '氮气驱动力与消耗', pass: car.speed > driveSpeed && car.nitro < 0.5, detail: `${car.speed.toFixed(2)}km/h，余量 ${car.nitro.toFixed(3)}` });
    step(45, () => car.step({ ...drive, steer: 1 }));
    checks.push({ name: '转向', pass: Math.abs(car.mesh.rotationQuaternion!.y) > 0.1, detail: `旋转四元数 y=${car.mesh.rotationQuaternion!.y.toFixed(4)}` });
    const aerial = new PrototypeVehicle(scene, new Vector3(-50, 20, 0));
    step(20, () => aerial.step({ ...drive, boost: true }));
    checks.push({ name: '空中禁止驱动', pass: Math.abs(aerial.mesh.position.z) < 0.01 && aerial.nitro === 1, detail: `空中 z=${aerial.mesh.position.z.toFixed(5)}m，氮气=${aerial.nitro}` });
    checks.push({ name: '数值稳定', pass: [car.mesh.position.x, car.mesh.position.y, car.mesh.position.z, car.speed].every(Number.isFinite), detail: '无 NaN / Infinity' });
    return checks;
  } finally { scene.dispose(); engine.dispose(); }
}
