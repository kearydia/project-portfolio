import { idleInput, type DriveInput } from '../physics/world';
export function createControls(signal?: AbortSignal) {
  const keys = new Set<string>();
  const pointers = new Map<number, string>();
  const accepted = new Set(['KeyQ','KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','ShiftLeft','ShiftRight']);
  const clear = () => { keys.clear(); pointers.clear(); document.querySelectorAll('.held').forEach(e => e.classList.remove('held')); };
  signal?.addEventListener('abort', clear, { once: true });
  addEventListener('keydown', e => { if (accepted.has(e.code)) { e.preventDefault(); keys.add(e.code); } }, { signal });
  addEventListener('keyup', e => keys.delete(e.code), { signal });
  addEventListener('blur', clear, { signal });
  document.addEventListener('visibilitychange', clear, { signal });
  document.querySelectorAll<HTMLButtonElement>('[data-control]').forEach(button => {
    button.addEventListener('pointerdown', e => { e.preventDefault(); pointers.set(e.pointerId, button.dataset.control!); button.setPointerCapture(e.pointerId); button.classList.add('held'); }, { signal });
    const release = (e: PointerEvent) => { pointers.delete(e.pointerId); button.classList.remove('held'); };
    button.addEventListener('pointerup', release, { signal });
    button.addEventListener('pointercancel', release, { signal });
    button.addEventListener('lostpointercapture', release, { signal });
  });
  const read = (): DriveInput => {
    const has = (...names: string[]) => names.some(n => keys.has(n) || [...pointers.values()].includes(n));
    return { ...idleInput(), reverse: has('KeyQ','reverse'), throttle: Number(has('KeyW','ArrowUp','throttle')), brake: has('KeyS','ArrowDown','brake'), steer: Number(has('KeyD','ArrowRight','right')) - Number(has('KeyA','ArrowLeft','left')), drift: has('Space','drift'), boost: has('ShiftLeft','ShiftRight','boost') };
  };
  return { read, clear };
}
