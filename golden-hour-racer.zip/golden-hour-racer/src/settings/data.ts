export const buttons=['left','right','reverse','brake','throttle','drift','boost'] as const;
export type Layout=Record<string,{x:number;y:number;size:number;opacity:number}>;
export const defaults=()=>({master:.7,effects:.8,music:.25,mute:false,quality:'medium',assists:{abs:true,tcs:true,esc:true},layout:Object.fromEntries(buttons.map((k,i)=>[k,{x:5+i*13,y:72,size:9,opacity:.8}])) as Layout});
export type Settings=ReturnType<typeof defaults>;
export function validLayout(layout:Layout){return buttons.every(k=>{const b=layout[k];return b&&Number.isFinite(b.x)&&Number.isFinite(b.y)&&b.size>=6&&b.size<=12&&b.opacity>=.2&&b.opacity<=1&&b.x>=0&&b.y>=0&&b.x+b.size<=100&&b.y+b.size*2<=100&&buttons.every(j=>j===k||b.x+b.size<=layout[j].x||layout[j].x+layout[j].size<=b.x||b.y+b.size<=layout[j].y||layout[j].y+layout[j].size<=b.y);});}
export function applyLayout(settings:Settings){for(const k of buttons){const b=settings.layout[k],el=document.querySelector<HTMLElement>(`[data-control="${k}"]`);if(el)Object.assign(el.style,{position:'fixed',left:`${b.x}vw`,top:`${b.y}vh`,width:`${b.size}vw`,height:`${b.size}vh`,opacity:String(b.opacity),minWidth:'0',minHeight:'0',maxWidth:'none'});}}

