/** Local licensed recordings. No runtime CDN dependency. */
export async function loadRecording(context:AudioContext,path:string){const response=await fetch(import.meta.env.BASE_URL+'audio/'+path);if(!response.ok)throw Error('音频加载失败 '+path);return context.decodeAudioData(await response.arrayBuffer());}

