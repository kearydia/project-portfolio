const previousVelocity=new WeakMap<PrototypeVehicle,Vector3>();
import {Vector3} from '../engine/babylon';import type {PrototypeVehicle} from '../physics/world';
/** Read-only audio telemetry: never applies forces or alters vehicle state. */
export function audioTelemetry(car:PrototypeVehicle){const root=document.getElementById('drive-ui');if(!root)return;car.mesh.computeWorldMatrix(true);const velocity=car.aggregate.body.getLinearVelocity(),right=car.mesh.getDirection(Vector3.Right());const previous=previousVelocity.get(car);root.dataset.impactStrength=String(previous?Vector3.Distance(previous,velocity):0);previousVelocity.set(car,velocity.clone());root.dataset.rpm=String(car.rpm);root.dataset.slip=String(car.grounded?Math.abs(Vector3.Dot(velocity,right)):0);root.dataset.impact=String(car.recovery>0);}


