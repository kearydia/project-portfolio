# 资源与许可清单

记录日期：2026-10-29。许可状态来自实际包文件或官方来源；不编造真实汽车品牌授权。

| 资源 | 来源/版本 | 许可与处理 | 使用范围 |
|---|---|---|---|
| Babylon.js Core | npm @babylonjs/core 9.32.1；https://github.com/BabylonJS/Babylon.js | 包内 license.md，Apache-2.0，已复制至 public/licenses/babylonjs-Apache-2.0.txt | 渲染与 Physics V2 接口 |
| Havok Web WASM | npm @babylonjs/havok 1.3.14；https://github.com/BabylonJS/havok | 包内 LICENSE，MIT，保留 Copyright (c) 2023 Babylon.js，已复制至 public/licenses/havok-MIT.txt | WASM 刚体引擎 |
| GH–01 临时车模 | 本项目 src/scene/provingGround.ts 程序几何 | 本项目生成的无品牌原创占位几何，无第三方模型来源；未额外声明整个项目开源许可 | 开发原型 |
| 试车场、山体、塔楼、路肩 | 本项目程序几何 | 同上；非真实赛道扫描或复制 | 开发原型 |
| 材质与颜色 | 本项目程序材质 | 未引入第三方贴图 | 开发原型 |
| 字体 | 用户系统 Inter/Segoe UI/Microsoft YaHei/sans-serif 回退 | 只引用本机字体，不分发字体文件 | 界面 |
| 音频、音乐、品牌标志、真实车型 | 无 | 未使用、未取得或声称任何品牌授权 | 尚未实现 |

## 工具链

Vite、TypeScript、tsx、Node 类型仅用于开发与构建；依赖版本及各包许可证以 package-lock.json 和包内文件为准。发布前对完整生产依赖再生成一次许可证清单。Havok 的本表许可仅指 BabylonJS 发布的 Web WASM 包，不外推到其他 Havok 产品。

## 后续资产准入

每个新增外部模型、贴图、音频记录：文件名、原始 URL、作者、许可名称/版本、下载日期、商业/修改/再分发条件、署名文字与修改说明。优先自制、CC0、明确授权的 CC-BY 或许可清晰包资源。下载可用不等于品牌外观、商标或音乐已授权；不确定时继续使用无品牌占位资源。发布分发包必须包含必要许可与署名。

阶段 3 日冕海岸路径、护墙、路肩、山体、网格与六种车漆均由本项目程序生成，无外部模型/贴图/音乐；六辆车共用原创无品牌 GH–01 占位模型，不代表已实现五种可解锁车型。

阶段 4 五种车仍使用原 GH–01 程序几何及预设颜色，不引入真实车型模型/品牌标志。车型特征参考官方文字的链接及游戏参数边界见 docs/STAGE4_DESIGN.md；参考性能方向不是取得车型资产授权，不复制真实试驾成绩。

## 阶段 5 资源补充

幽灵车为本项目程序生成的方盒车身/车舱及半透明材质，没有引入外部车型、品牌或第三方图像资源。沿用既有 Babylon/Havok 许可证。

阶段6新增音频均为本项目 Web Audio 程序合成占位声音/和声，没有下载外部录音或音乐。fake-indexeddb 为开发测试依赖，不打包进游戏生产代码。

## 阶段 7 资源（2026-10-31）

五车显示几何、看台、太阳与特效由本项目原创程序生成，无品牌商标或外部车型授权。src/scene/car.ts 为原创虚构车身；没有复制真实车型模型。材质为程序颜色和高光，未引入第三方贴图。

本地音频及许可/作者/原始下载URL/修改范围完整列于 public/licenses/stage7-audio.txt，随静态产物分发。发动机 domasx2、音乐 section31、撞击 qubodup 为 CC0；轮胎 Mike Koenig / qubodup 为 CC BY 3.0；倒计时 Ulrich Metzner / qubodup、氮气 James Legg 为 CC BY-SA 3.0。SA 音频保持原许可，未将整个游戏声称为 CC0。文件仅重命名，实时调速/音量/循环；冲线复用 go.ogg。所有文件位于 public/audio，通过 Vite BASE_URL 相对路径加载，不依赖个人电脑路径或运行时外部服务。原始压缩包在 assets/audio 留存。

Kenney 下载链接返回 forbidden，未采用其资源。早期音频“无资源/合成占位”描述为历史记录；加载失败时仍保留合成音作为降级，不能称为真实录音回放成功。

阶段7反射补充：src/scene/reflection.ts在本机生成32×32六面日落颜色渐变，不使用第三方环境贴图。按场景共享，低画质关闭贡献，高画质增加贡献；不代表实时反射或真实环境扫描。

## 阶段 7 最终资源复核（2026-11-04）

本轮未新增/替换外部资产。public/audio七文件与此前stage7-audio-http.json的SHA256全部一致，结果见docs/evidence/stage7-acceptance-20261104/audio-hashes.json；浏览器实际成功解码七文件（不等于人工听感通过）。随构建分发的public/licenses/stage7-audio.txt仍保留作者、许可、原始URL、重命名及播放处理说明。

| 文件 | 既有授权记录 | 本轮源页面访问 |
|---|---|---|
| engine.wav | domasx2，CC0；历史重制说明保留 | 来源返回403，未重新确认页面内容，沿用10月31日核验记录 |
| music.ogg | section31，CC0 | Winning the Race页面可访问，作者及许可复核 |
| skid.wav | Mike Koenig / qubodup，CC BY 3.0 | Car Tire Skid Squealing页面可访问，署名及许可复核 |
| crash.ogg | qubodup，CC0 | 来源返回403，未重新确认页面内容，沿用10月31日核验记录 |
| countdown.ogg、go.ogg | Ulrich Metzner / qubodup，CC BY-SA 3.0 | Race Start Beeps页面可访问，许可复核；GO/冲线共用文件 |
| boost.wav | James Legg / qubodup，CC BY-SA 3.0 | Sci-Fi Racing Sfx页面可访问，作者及许可复核 |

音频来源链接见上述随包许可文件；不因可播放或文件哈希相同而虚构新的授权。五车始终为无品牌原创程序几何，共用基础车壳，不是真实高精度车型资产。本轮局部车轮动画修复不改变资产来源。静态部署路径仍通过BASE_URL，未引入电脑绝对路径、临时外链资源或新的许可依赖；没有部署。

## 2026-11-05 文档收尾确认

本次仅核对既有资源记录，未新增、下载、替换或修改模型、材质、音频及许可文件，也未再次访问来源网站。上节七个音频解码与来源访问情况为11月4日验收记录：成功解码不等于人工听感验收通过；两个403来源不能记作本次已重新核实授权。人工听感及完整音频事件仍待验收。

五车为原创风格化程序几何，外观辨识度仍不足，不描述为真实高精度车型。项目阶段7保持部分验收；资源记录完整不代表视觉、声音或性能全部达标。未公开部署。
